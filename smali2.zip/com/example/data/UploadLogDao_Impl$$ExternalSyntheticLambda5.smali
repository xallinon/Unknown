# classes4.dex

.class public final synthetic Lcom/example/data/UploadLogDao_Impl$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Lcom/example/data/UploadLogDao_Impl;

.field public final synthetic f$1:Lcom/example/data/UploadLog;


# direct methods
.method public synthetic constructor <init>(Lcom/example/data/UploadLogDao_Impl;Lcom/example/data/UploadLog;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/data/UploadLogDao_Impl$$ExternalSyntheticLambda5;->f$0:Lcom/example/data/UploadLogDao_Impl;

    iput-object p2, p0, Lcom/example/data/UploadLogDao_Impl$$ExternalSyntheticLambda5;->f$1:Lcom/example/data/UploadLog;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/example/data/UploadLogDao_Impl$$ExternalSyntheticLambda5;->f$0:Lcom/example/data/UploadLogDao_Impl;

    iget-object v1, p0, Lcom/example/data/UploadLogDao_Impl$$ExternalSyntheticLambda5;->f$1:Lcom/example/data/UploadLog;

    check-cast p1, Landroidx/sqlite/SQLiteConnection;

    invoke-static {v0, v1, p1}, Lcom/example/data/UploadLogDao_Impl;->updateLog$lambda$1(Lcom/example/data/UploadLogDao_Impl;Lcom/example/data/UploadLog;Landroidx/sqlite/SQLiteConnection;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method
