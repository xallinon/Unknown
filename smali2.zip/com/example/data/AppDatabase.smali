# classes4.dex

.class public abstract Lcom/example/data/AppDatabase;
.super Landroidx/room/RoomDatabase;
.source "AppDatabase.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/data/AppDatabase$Companion;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\b\'\u0018\u0000 \u00062\u00020\u0001:\u0001\u0006B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H&¨\u0006\u0007"
    }
    d2 = {
        "Lcom/example/data/AppDatabase;",
        "Landroidx/room/RoomDatabase;",
        "<init>",
        "()V",
        "uploadLogDao",
        "Lcom/example/data/UploadLogDao;",
        "Companion",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lcom/example/data/AppDatabase$Companion;

.field private static volatile INSTANCE:Lcom/example/data/AppDatabase;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/example/data/AppDatabase$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/example/data/AppDatabase$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/example/data/AppDatabase;->Companion:Lcom/example/data/AppDatabase$Companion;

    const/16 v0, 0x8

    sput v0, Lcom/example/data/AppDatabase;->$stable:I

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 9
    invoke-direct {p0}, Landroidx/room/RoomDatabase;-><init>()V

    .line 8
    return-void
.end method

.method public static final synthetic access$getINSTANCE$cp()Lcom/example/data/AppDatabase;
    .registers 1

    .line 8
    sget-object v0, Lcom/example/data/AppDatabase;->INSTANCE:Lcom/example/data/AppDatabase;

    return-object v0
.end method

.method public static final synthetic access$setINSTANCE$cp(Lcom/example/data/AppDatabase;)V
    .registers 1
    .param p0, "<set-?>"  # Lcom/example/data/AppDatabase;

    .line 8
    sput-object p0, Lcom/example/data/AppDatabase;->INSTANCE:Lcom/example/data/AppDatabase;

    return-void
.end method


# virtual methods
.method public abstract uploadLogDao()Lcom/example/data/UploadLogDao;
.end method
