# classes4.dex

.class public final Lcom/example/data/UploadLog;
.super Ljava/lang/Object;
.source "UploadLog.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0019\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001BG\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0005\u0012\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\n\u001a\u00020\u0003¢\u0006\u0004\b\u000b\u0010\fJ\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0005HÆ\u0003J\u000b\u0010\u001b\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\t\u0010\u001c\u001a\u00020\u0003HÆ\u0003JQ\u0010\u001d\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00052\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u00052\b\b\u0002\u0010\n\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u001e\u001a\u00020\u001f2\b\u0010 \u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010!\u001a\u00020\"HÖ\u0001J\t\u0010#\u001a\u00020\u0005HÖ\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0010R\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u000eR\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0010R\u0013\u0010\t\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0010R\u0011\u0010\n\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u000e¨\u0006$"
    }
    d2 = {
        "Lcom/example/data/UploadLog;",
        "",
        "id",
        "",
        "uriString",
        "",
        "fileName",
        "fileSize",
        "status",
        "errorMessage",
        "timestamp",
        "<init>",
        "(JLjava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;J)V",
        "getId",
        "()J",
        "getUriString",
        "()Ljava/lang/String;",
        "getFileName",
        "getFileSize",
        "getStatus",
        "getErrorMessage",
        "getTimestamp",
        "component1",
        "component2",
        "component3",
        "component4",
        "component5",
        "component6",
        "component7",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "",
        "toString",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private final errorMessage:Ljava/lang/String;

.field private final fileName:Ljava/lang/String;

.field private final fileSize:J

.field private final id:J

.field private final status:Ljava/lang/String;

.field private final timestamp:J

.field private final uriString:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>(JLjava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;J)V
    .registers 12
    .param p1, "id"  # J
    .param p3, "uriString"  # Ljava/lang/String;
    .param p4, "fileName"  # Ljava/lang/String;
    .param p5, "fileSize"  # J
    .param p7, "status"  # Ljava/lang/String;
    .param p8, "errorMessage"  # Ljava/lang/String;
    .param p9, "timestamp"  # J

    const-string v0, "uriString"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "fileName"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "status"

    invoke-static {p7, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    iput-wide p1, p0, Lcom/example/data/UploadLog;->id:J

    .line 9
    iput-object p3, p0, Lcom/example/data/UploadLog;->uriString:Ljava/lang/String;

    .line 10
    iput-object p4, p0, Lcom/example/data/UploadLog;->fileName:Ljava/lang/String;

    .line 11
    iput-wide p5, p0, Lcom/example/data/UploadLog;->fileSize:J

    .line 12
    iput-object p7, p0, Lcom/example/data/UploadLog;->status:Ljava/lang/String;

    .line 13
    iput-object p8, p0, Lcom/example/data/UploadLog;->errorMessage:Ljava/lang/String;

    .line 14
    iput-wide p9, p0, Lcom/example/data/UploadLog;->timestamp:J

    .line 7
    return-void
.end method

.method public synthetic constructor <init>(JLjava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;JILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 24

    .line 7
    and-int/lit8 v0, p11, 0x1

    if-eqz v0, :cond_8

    .line 8
    const-wide/16 p1, 0x0

    move-wide v1, p1

    goto :goto_9

    .line 7
    :cond_8
    move-wide v1, p1

    :goto_9
    and-int/lit8 p1, p11, 0x20

    if-eqz p1, :cond_10

    .line 13
    const/4 p1, 0x0

    move-object v8, p1

    goto :goto_12

    .line 7
    :cond_10
    move-object/from16 v8, p8

    :goto_12
    and-int/lit8 p1, p11, 0x40

    if-eqz p1, :cond_1c

    .line 14
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p1

    move-wide v9, p1

    goto :goto_1e

    .line 7
    :cond_1c
    move-wide/from16 v9, p9

    :goto_1e
    move-object v0, p0

    move-object v3, p3

    move-object v4, p4

    move-wide/from16 v5, p5

    move-object/from16 v7, p7

    invoke-direct/range {v0 .. v10}, Lcom/example/data/UploadLog;-><init>(JLjava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;J)V

    .line 15
    return-void
.end method

.method public static synthetic copy$default(Lcom/example/data/UploadLog;JLjava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;JILjava/lang/Object;)Lcom/example/data/UploadLog;
    .registers 24

    and-int/lit8 v0, p11, 0x1

    if-eqz v0, :cond_6

    iget-wide p1, p0, Lcom/example/data/UploadLog;->id:J

    :cond_6
    move-wide v1, p1

    and-int/lit8 p1, p11, 0x2

    if-eqz p1, :cond_d

    iget-object p3, p0, Lcom/example/data/UploadLog;->uriString:Ljava/lang/String;

    :cond_d
    move-object v3, p3

    and-int/lit8 p1, p11, 0x4

    if-eqz p1, :cond_14

    iget-object p4, p0, Lcom/example/data/UploadLog;->fileName:Ljava/lang/String;

    :cond_14
    move-object v4, p4

    and-int/lit8 p1, p11, 0x8

    if-eqz p1, :cond_1d

    iget-wide p1, p0, Lcom/example/data/UploadLog;->fileSize:J

    move-wide v5, p1

    goto :goto_1f

    :cond_1d
    move-wide/from16 v5, p5

    :goto_1f
    and-int/lit8 p1, p11, 0x10

    if-eqz p1, :cond_27

    iget-object p1, p0, Lcom/example/data/UploadLog;->status:Ljava/lang/String;

    move-object v7, p1

    goto :goto_29

    :cond_27
    move-object/from16 v7, p7

    :goto_29
    and-int/lit8 p1, p11, 0x20

    if-eqz p1, :cond_31

    iget-object p1, p0, Lcom/example/data/UploadLog;->errorMessage:Ljava/lang/String;

    move-object v8, p1

    goto :goto_33

    :cond_31
    move-object/from16 v8, p8

    :goto_33
    and-int/lit8 p1, p11, 0x40

    if-eqz p1, :cond_3b

    iget-wide p1, p0, Lcom/example/data/UploadLog;->timestamp:J

    move-wide v9, p1

    goto :goto_3d

    :cond_3b
    move-wide/from16 v9, p9

    :goto_3d
    move-object v0, p0

    invoke-virtual/range {v0 .. v10}, Lcom/example/data/UploadLog;->copy(JLjava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;J)Lcom/example/data/UploadLog;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()J
    .registers 3

    iget-wide v0, p0, Lcom/example/data/UploadLog;->id:J

    return-wide v0
.end method

.method public final component2()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/example/data/UploadLog;->uriString:Ljava/lang/String;

    return-object v0
.end method

.method public final component3()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/example/data/UploadLog;->fileName:Ljava/lang/String;

    return-object v0
.end method

.method public final component4()J
    .registers 3

    iget-wide v0, p0, Lcom/example/data/UploadLog;->fileSize:J

    return-wide v0
.end method

.method public final component5()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/example/data/UploadLog;->status:Ljava/lang/String;

    return-object v0
.end method

.method public final component6()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/example/data/UploadLog;->errorMessage:Ljava/lang/String;

    return-object v0
.end method

.method public final component7()J
    .registers 3

    iget-wide v0, p0, Lcom/example/data/UploadLog;->timestamp:J

    return-wide v0
.end method

.method public final copy(JLjava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;J)Lcom/example/data/UploadLog;
    .registers 23

    const-string v0, "uriString"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "fileName"

    move-object/from16 v5, p4

    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "status"

    move-object/from16 v8, p7

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Lcom/example/data/UploadLog;

    move-wide v2, p1

    move-object v4, p3

    move-wide/from16 v6, p5

    move-object/from16 v9, p8

    move-wide/from16 v10, p9

    invoke-direct/range {v1 .. v11}, Lcom/example/data/UploadLog;-><init>(JLjava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;J)V

    return-object v1
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 9

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/example/data/UploadLog;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    move-object v1, p1

    check-cast v1, Lcom/example/data/UploadLog;

    iget-wide v3, p0, Lcom/example/data/UploadLog;->id:J

    iget-wide v5, v1, Lcom/example/data/UploadLog;->id:J

    cmp-long v3, v3, v5

    if-eqz v3, :cond_16

    return v2

    :cond_16
    iget-object v3, p0, Lcom/example/data/UploadLog;->uriString:Ljava/lang/String;

    iget-object v4, v1, Lcom/example/data/UploadLog;->uriString:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_21

    return v2

    :cond_21
    iget-object v3, p0, Lcom/example/data/UploadLog;->fileName:Ljava/lang/String;

    iget-object v4, v1, Lcom/example/data/UploadLog;->fileName:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2c

    return v2

    :cond_2c
    iget-wide v3, p0, Lcom/example/data/UploadLog;->fileSize:J

    iget-wide v5, v1, Lcom/example/data/UploadLog;->fileSize:J

    cmp-long v3, v3, v5

    if-eqz v3, :cond_35

    return v2

    :cond_35
    iget-object v3, p0, Lcom/example/data/UploadLog;->status:Ljava/lang/String;

    iget-object v4, v1, Lcom/example/data/UploadLog;->status:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_40

    return v2

    :cond_40
    iget-object v3, p0, Lcom/example/data/UploadLog;->errorMessage:Ljava/lang/String;

    iget-object v4, v1, Lcom/example/data/UploadLog;->errorMessage:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4b

    return v2

    :cond_4b
    iget-wide v3, p0, Lcom/example/data/UploadLog;->timestamp:J

    iget-wide v5, v1, Lcom/example/data/UploadLog;->timestamp:J

    cmp-long v1, v3, v5

    if-eqz v1, :cond_54

    return v2

    :cond_54
    return v0
.end method

.method public final getErrorMessage()Ljava/lang/String;
    .registers 2

    .line 13
    iget-object v0, p0, Lcom/example/data/UploadLog;->errorMessage:Ljava/lang/String;

    return-object v0
.end method

.method public final getFileName()Ljava/lang/String;
    .registers 2

    .line 10
    iget-object v0, p0, Lcom/example/data/UploadLog;->fileName:Ljava/lang/String;

    return-object v0
.end method

.method public final getFileSize()J
    .registers 3

    .line 11
    iget-wide v0, p0, Lcom/example/data/UploadLog;->fileSize:J

    return-wide v0
.end method

.method public final getId()J
    .registers 3

    .line 8
    iget-wide v0, p0, Lcom/example/data/UploadLog;->id:J

    return-wide v0
.end method

.method public final getStatus()Ljava/lang/String;
    .registers 2

    .line 12
    iget-object v0, p0, Lcom/example/data/UploadLog;->status:Ljava/lang/String;

    return-object v0
.end method

.method public final getTimestamp()J
    .registers 3

    .line 14
    iget-wide v0, p0, Lcom/example/data/UploadLog;->timestamp:J

    return-wide v0
.end method

.method public final getUriString()Ljava/lang/String;
    .registers 2

    .line 9
    iget-object v0, p0, Lcom/example/data/UploadLog;->uriString:Ljava/lang/String;

    return-object v0
.end method

.method public hashCode()I
    .registers 5

    iget-wide v0, p0, Lcom/example/data/UploadLog;->id:J

    invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I

    move-result v0

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Lcom/example/data/UploadLog;->uriString:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Lcom/example/data/UploadLog;->fileName:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget-wide v2, p0, Lcom/example/data/UploadLog;->fileSize:J

    invoke-static {v2, v3}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Lcom/example/data/UploadLog;->status:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Lcom/example/data/UploadLog;->errorMessage:Ljava/lang/String;

    if-nez v2, :cond_32

    const/4 v2, 0x0

    goto :goto_38

    :cond_32
    iget-object v2, p0, Lcom/example/data/UploadLog;->errorMessage:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_38
    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-wide v2, p0, Lcom/example/data/UploadLog;->timestamp:J

    invoke-static {v2, v3}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    add-int/2addr v0, v2

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 13

    iget-wide v0, p0, Lcom/example/data/UploadLog;->id:J

    iget-object v2, p0, Lcom/example/data/UploadLog;->uriString:Ljava/lang/String;

    iget-object v3, p0, Lcom/example/data/UploadLog;->fileName:Ljava/lang/String;

    iget-wide v4, p0, Lcom/example/data/UploadLog;->fileSize:J

    iget-object v6, p0, Lcom/example/data/UploadLog;->status:Ljava/lang/String;

    iget-object v7, p0, Lcom/example/data/UploadLog;->errorMessage:Ljava/lang/String;

    iget-wide v8, p0, Lcom/example/data/UploadLog;->timestamp:J

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "UploadLog(id="

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", uriString="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", fileName="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", fileSize="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", status="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", errorMessage="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", timestamp="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
