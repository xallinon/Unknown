# classes4.dex

.class public final Lcom/example/data/UploadLogDao_Impl;
.super Ljava/lang/Object;
.source "UploadLogDao_Impl.kt"

# interfaces
.implements Lcom/example/data/UploadLogDao;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/data/UploadLogDao_Impl$Companion;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000L\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\b\u0007\u0018\u0000 \u001d2\u00020\u0001:\u0001\u001dB\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0016\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\u000eJ\u0016\u0010\u000f\u001a\u00020\u00102\u0006\u0010\r\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\u000eJ\u0014\u0010\u0011\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u00130\u0012H\u0016J\u0018\u0010\u0014\u001a\u0004\u0018\u00010\b2\u0006\u0010\u0015\u001a\u00020\u0016H\u0096@¢\u0006\u0002\u0010\u0017J\u000e\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00190\u0012H\u0016J\u000e\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u00190\u0012H\u0016J\u000e\u0010\u001b\u001a\u00020\u0010H\u0096@¢\u0006\u0002\u0010\u001cR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\b0\nX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001e"
    }
    d2 = {
        "Lcom/example/data/UploadLogDao_Impl;",
        "Lcom/example/data/UploadLogDao;",
        "__db",
        "Landroidx/room/RoomDatabase;",
        "<init>",
        "(Landroidx/room/RoomDatabase;)V",
        "__insertAdapterOfUploadLog",
        "Landroidx/room/EntityInsertAdapter;",
        "Lcom/example/data/UploadLog;",
        "__updateAdapterOfUploadLog",
        "Landroidx/room/EntityDeleteOrUpdateAdapter;",
        "insertLog",
        "",
        "uploadLog",
        "(Lcom/example/data/UploadLog;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;",
        "updateLog",
        "",
        "getAllLogsFlow",
        "Lkotlinx/coroutines/flow/Flow;",
        "",
        "getLogByUri",
        "uriString",
        "",
        "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;",
        "getSuccessCountFlow",
        "",
        "getFailedCountFlow",
        "clearAllLogs",
        "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;",
        "Companion",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lcom/example/data/UploadLogDao_Impl$Companion;


# instance fields
.field private final __db:Landroidx/room/RoomDatabase;

.field private final __insertAdapterOfUploadLog:Landroidx/room/EntityInsertAdapter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/room/EntityInsertAdapter<",
            "Lcom/example/data/UploadLog;",
            ">;"
        }
    .end annotation
.end field

.field private final __updateAdapterOfUploadLog:Landroidx/room/EntityDeleteOrUpdateAdapter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/room/EntityDeleteOrUpdateAdapter<",
            "Lcom/example/data/UploadLog;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/example/data/UploadLogDao_Impl$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/example/data/UploadLogDao_Impl$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/example/data/UploadLogDao_Impl;->Companion:Lcom/example/data/UploadLogDao_Impl$Companion;

    const/16 v0, 0x8

    sput v0, Lcom/example/data/UploadLogDao_Impl;->$stable:I

    return-void
.end method

.method public constructor <init>(Landroidx/room/RoomDatabase;)V
    .registers 3
    .param p1, "__db"  # Landroidx/room/RoomDatabase;

    const-string v0, "__db"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 32
    nop

    .line 33
    iput-object p1, p0, Lcom/example/data/UploadLogDao_Impl;->__db:Landroidx/room/RoomDatabase;

    .line 34
    new-instance v0, Lcom/example/data/UploadLogDao_Impl$1;

    invoke-direct {v0}, Lcom/example/data/UploadLogDao_Impl$1;-><init>()V

    check-cast v0, Landroidx/room/EntityInsertAdapter;

    iput-object v0, p0, Lcom/example/data/UploadLogDao_Impl;->__insertAdapterOfUploadLog:Landroidx/room/EntityInsertAdapter;

    .line 53
    new-instance v0, Lcom/example/data/UploadLogDao_Impl$2;

    invoke-direct {v0}, Lcom/example/data/UploadLogDao_Impl$2;-><init>()V

    check-cast v0, Landroidx/room/EntityDeleteOrUpdateAdapter;

    iput-object v0, p0, Lcom/example/data/UploadLogDao_Impl;->__updateAdapterOfUploadLog:Landroidx/room/EntityDeleteOrUpdateAdapter;

    .line 73
    nop

    .line 24
    return-void
.end method

.method static final clearAllLogs$lambda$6(Ljava/lang/String;Landroidx/sqlite/SQLiteConnection;)Lkotlin/Unit;
    .registers 4
    .param p0, "$_sql"  # Ljava/lang/String;
    .param p1, "_connection"  # Landroidx/sqlite/SQLiteConnection;

    const-string v0, "_connection"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 219
    invoke-interface {p1, p0}, Landroidx/sqlite/SQLiteConnection;->prepare(Ljava/lang/String;)Landroidx/sqlite/SQLiteStatement;

    move-result-object v0

    .line 220
    .local v0, "_stmt":Landroidx/sqlite/SQLiteStatement;
    nop

    .line 221
    :try_start_a
    invoke-interface {v0}, Landroidx/sqlite/SQLiteStatement;->step()Z
    :try_end_d
    .catchall {:try_start_a .. :try_end_d} :catchall_14

    .line 223
    invoke-interface {v0}, Landroidx/sqlite/SQLiteStatement;->close()V

    .line 224
    nop

    .line 225
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1

    .line 223
    :catchall_14
    move-exception v1

    invoke-interface {v0}, Landroidx/sqlite/SQLiteStatement;->close()V

    throw v1
.end method

.method static final getAllLogsFlow$lambda$2(Ljava/lang/String;Landroidx/sqlite/SQLiteConnection;)Ljava/util/List;
    .registers 29
    .param p0, "$_sql"  # Ljava/lang/String;
    .param p1, "_connection"  # Landroidx/sqlite/SQLiteConnection;

    move-object/from16 v1, p1

    const-string v0, "_connection"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 89
    move-object/from16 v2, p0

    invoke-interface {v1, v2}, Landroidx/sqlite/SQLiteConnection;->prepare(Ljava/lang/String;)Landroidx/sqlite/SQLiteStatement;

    move-result-object v3

    .line 90
    .local v3, "_stmt":Landroidx/sqlite/SQLiteStatement;
    nop

    .line 91
    :try_start_e
    const-string v0, "id"

    invoke-static {v3, v0}, Landroidx/room/util/SQLiteStatementUtil;->getColumnIndexOrThrow(Landroidx/sqlite/SQLiteStatement;Ljava/lang/String;)I

    move-result v0

    .line 92
    .local v0, "_columnIndexOfId":I
    const-string v4, "uriString"

    invoke-static {v3, v4}, Landroidx/room/util/SQLiteStatementUtil;->getColumnIndexOrThrow(Landroidx/sqlite/SQLiteStatement;Ljava/lang/String;)I

    move-result v4

    .line 93
    .local v4, "_columnIndexOfUriString":I
    const-string v5, "fileName"

    invoke-static {v3, v5}, Landroidx/room/util/SQLiteStatementUtil;->getColumnIndexOrThrow(Landroidx/sqlite/SQLiteStatement;Ljava/lang/String;)I

    move-result v5

    .line 94
    .local v5, "_columnIndexOfFileName":I
    const-string v6, "fileSize"

    invoke-static {v3, v6}, Landroidx/room/util/SQLiteStatementUtil;->getColumnIndexOrThrow(Landroidx/sqlite/SQLiteStatement;Ljava/lang/String;)I

    move-result v6

    .line 95
    .local v6, "_columnIndexOfFileSize":I
    const-string v7, "status"

    invoke-static {v3, v7}, Landroidx/room/util/SQLiteStatementUtil;->getColumnIndexOrThrow(Landroidx/sqlite/SQLiteStatement;Ljava/lang/String;)I

    move-result v7

    .line 96
    .local v7, "_columnIndexOfStatus":I
    const-string v8, "errorMessage"

    invoke-static {v3, v8}, Landroidx/room/util/SQLiteStatementUtil;->getColumnIndexOrThrow(Landroidx/sqlite/SQLiteStatement;Ljava/lang/String;)I

    move-result v8

    .line 97
    .local v8, "_columnIndexOfErrorMessage":I
    const-string v9, "timestamp"

    invoke-static {v3, v9}, Landroidx/room/util/SQLiteStatementUtil;->getColumnIndexOrThrow(Landroidx/sqlite/SQLiteStatement;Ljava/lang/String;)I

    move-result v9

    .line 98
    .local v9, "_columnIndexOfTimestamp":I
    new-instance v10, Ljava/util/ArrayList;

    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    check-cast v10, Ljava/util/List;

    .line 99
    .local v10, "_result":Ljava/util/List;
    :goto_3f
    invoke-interface {v3}, Landroidx/sqlite/SQLiteStatement;->step()Z

    move-result v11

    if-eqz v11, :cond_86

    .line 100
    const/4 v11, 0x0

    .line 101
    .local v11, "_item":Lcom/example/data/UploadLog;
    const-wide/16 v12, 0x0

    .line 102
    .local v12, "_tmpId":J
    invoke-interface {v3, v0}, Landroidx/sqlite/SQLiteStatement;->getLong(I)J

    move-result-wide v14

    move-wide/from16 v17, v14

    .line 103
    .end local v12  # "_tmpId":J
    .local v17, "_tmpId":J
    const/4 v12, 0x0

    .line 104
    .local v12, "_tmpUriString":Ljava/lang/String;
    invoke-interface {v3, v4}, Landroidx/sqlite/SQLiteStatement;->getText(I)Ljava/lang/String;

    move-result-object v19

    .line 105
    .end local v12  # "_tmpUriString":Ljava/lang/String;
    .local v19, "_tmpUriString":Ljava/lang/String;
    const/4 v12, 0x0

    .line 106
    .local v12, "_tmpFileName":Ljava/lang/String;
    invoke-interface {v3, v5}, Landroidx/sqlite/SQLiteStatement;->getText(I)Ljava/lang/String;

    move-result-object v20

    .line 107
    .end local v12  # "_tmpFileName":Ljava/lang/String;
    .local v20, "_tmpFileName":Ljava/lang/String;
    const-wide/16 v12, 0x0

    .line 108
    .local v12, "_tmpFileSize":J
    invoke-interface {v3, v6}, Landroidx/sqlite/SQLiteStatement;->getLong(I)J

    move-result-wide v21

    .line 109
    .end local v12  # "_tmpFileSize":J
    .local v21, "_tmpFileSize":J
    const/4 v12, 0x0

    .line 110
    .local v12, "_tmpStatus":Ljava/lang/String;
    invoke-interface {v3, v7}, Landroidx/sqlite/SQLiteStatement;->getText(I)Ljava/lang/String;

    move-result-object v23

    .line 111
    .end local v12  # "_tmpStatus":Ljava/lang/String;
    .local v23, "_tmpStatus":Ljava/lang/String;
    const/4 v12, 0x0

    .line 112
    .local v12, "_tmpErrorMessage":Ljava/lang/String;
    invoke-interface {v3, v8}, Landroidx/sqlite/SQLiteStatement;->isNull(I)Z

    move-result v13

    if-eqz v13, :cond_6e

    .line 113
    const/4 v12, 0x0

    move-object/from16 v24, v12

    goto :goto_75

    .line 115
    :cond_6e
    invoke-interface {v3, v8}, Landroidx/sqlite/SQLiteStatement;->getText(I)Ljava/lang/String;

    move-result-object v13

    move-object v12, v13

    move-object/from16 v24, v12

    .line 117
    .end local v12  # "_tmpErrorMessage":Ljava/lang/String;
    .local v24, "_tmpErrorMessage":Ljava/lang/String;
    :goto_75
    const-wide/16 v12, 0x0

    .line 118
    .local v12, "_tmpTimestamp":J
    invoke-interface {v3, v9}, Landroidx/sqlite/SQLiteStatement;->getLong(I)J

    move-result-wide v25

    .line 120
    .end local v12  # "_tmpTimestamp":J
    .local v25, "_tmpTimestamp":J
    new-instance v16, Lcom/example/data/UploadLog;

    invoke-direct/range {v16 .. v26}, Lcom/example/data/UploadLog;-><init>(JLjava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;J)V

    .line 119
    move-object/from16 v11, v16

    .line 121
    invoke-interface {v10, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_85
    .catchall {:try_start_e .. :try_end_85} :catchall_8b

    goto :goto_3f

    .line 123
    .end local v11  # "_item":Lcom/example/data/UploadLog;
    .end local v17  # "_tmpId":J
    .end local v19  # "_tmpUriString":Ljava/lang/String;
    .end local v20  # "_tmpFileName":Ljava/lang/String;
    .end local v21  # "_tmpFileSize":J
    .end local v23  # "_tmpStatus":Ljava/lang/String;
    .end local v24  # "_tmpErrorMessage":Ljava/lang/String;
    .end local v25  # "_tmpTimestamp":J
    :cond_86
    nop

    .line 125
    .end local v0  # "_columnIndexOfId":I
    .end local v4  # "_columnIndexOfUriString":I
    .end local v5  # "_columnIndexOfFileName":I
    .end local v6  # "_columnIndexOfFileSize":I
    .end local v7  # "_columnIndexOfStatus":I
    .end local v8  # "_columnIndexOfErrorMessage":I
    .end local v9  # "_columnIndexOfTimestamp":I
    .end local v10  # "_result":Ljava/util/List;
    invoke-interface {v3}, Landroidx/sqlite/SQLiteStatement;->close()V

    .line 126
    return-object v10

    .line 125
    :catchall_8b
    move-exception v0

    invoke-interface {v3}, Landroidx/sqlite/SQLiteStatement;->close()V

    throw v0
.end method

.method static final getFailedCountFlow$lambda$5(Ljava/lang/String;Landroidx/sqlite/SQLiteConnection;)I
    .registers 7
    .param p0, "$_sql"  # Ljava/lang/String;
    .param p1, "_connection"  # Landroidx/sqlite/SQLiteConnection;

    const-string v0, "_connection"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 199
    invoke-interface {p1, p0}, Landroidx/sqlite/SQLiteConnection;->prepare(Ljava/lang/String;)Landroidx/sqlite/SQLiteStatement;

    move-result-object v0

    .line 200
    .local v0, "_stmt":Landroidx/sqlite/SQLiteStatement;
    nop

    .line 201
    const/4 v1, 0x0

    .line 202
    .local v1, "_result":I
    :try_start_b
    invoke-interface {v0}, Landroidx/sqlite/SQLiteStatement;->step()Z

    move-result v2

    if-eqz v2, :cond_1a

    .line 203
    const/4 v2, 0x0

    .line 204
    .local v2, "_tmp":I
    const/4 v3, 0x0

    invoke-interface {v0, v3}, Landroidx/sqlite/SQLiteStatement;->getLong(I)J

    move-result-wide v3
    :try_end_17
    .catchall {:try_start_b .. :try_end_17} :catchall_20

    long-to-int v2, v3

    .line 205
    nop

    .end local v1  # "_result":I
    .local v2, "_result":I
    goto :goto_1b

    .line 207
    .end local v2  # "_result":I
    .restart local v1  # "_result":I
    :cond_1a
    const/4 v2, 0x0

    .line 209
    .end local v1  # "_result":I
    .restart local v2  # "_result":I
    :goto_1b
    nop

    .line 211
    .end local v2  # "_result":I
    invoke-interface {v0}, Landroidx/sqlite/SQLiteStatement;->close()V

    .line 212
    return v2

    .line 211
    :catchall_20
    move-exception v1

    invoke-interface {v0}, Landroidx/sqlite/SQLiteStatement;->close()V

    throw v1
.end method

.method static final getLogByUri$lambda$3(Ljava/lang/String;Ljava/lang/String;Landroidx/sqlite/SQLiteConnection;)Lcom/example/data/UploadLog;
    .registers 31
    .param p0, "$_sql"  # Ljava/lang/String;
    .param p1, "$uriString"  # Ljava/lang/String;
    .param p2, "_connection"  # Landroidx/sqlite/SQLiteConnection;

    move-object/from16 v1, p2

    const-string v0, "_connection"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 133
    move-object/from16 v2, p0

    invoke-interface {v1, v2}, Landroidx/sqlite/SQLiteConnection;->prepare(Ljava/lang/String;)Landroidx/sqlite/SQLiteStatement;

    move-result-object v3

    .line 134
    .local v3, "_stmt":Landroidx/sqlite/SQLiteStatement;
    nop

    .line 135
    const/4 v0, 0x1

    .line 136
    .local v0, "_argIndex":I
    move-object/from16 v4, p1

    :try_start_11
    invoke-interface {v3, v0, v4}, Landroidx/sqlite/SQLiteStatement;->bindText(ILjava/lang/String;)V

    .line 137
    const-string v5, "id"

    invoke-static {v3, v5}, Landroidx/room/util/SQLiteStatementUtil;->getColumnIndexOrThrow(Landroidx/sqlite/SQLiteStatement;Ljava/lang/String;)I

    move-result v5

    .line 138
    .local v5, "_columnIndexOfId":I
    const-string v6, "uriString"

    invoke-static {v3, v6}, Landroidx/room/util/SQLiteStatementUtil;->getColumnIndexOrThrow(Landroidx/sqlite/SQLiteStatement;Ljava/lang/String;)I

    move-result v6

    .line 139
    .local v6, "_columnIndexOfUriString":I
    const-string v7, "fileName"

    invoke-static {v3, v7}, Landroidx/room/util/SQLiteStatementUtil;->getColumnIndexOrThrow(Landroidx/sqlite/SQLiteStatement;Ljava/lang/String;)I

    move-result v7

    .line 140
    .local v7, "_columnIndexOfFileName":I
    const-string v8, "fileSize"

    invoke-static {v3, v8}, Landroidx/room/util/SQLiteStatementUtil;->getColumnIndexOrThrow(Landroidx/sqlite/SQLiteStatement;Ljava/lang/String;)I

    move-result v8

    .line 141
    .local v8, "_columnIndexOfFileSize":I
    const-string v9, "status"

    invoke-static {v3, v9}, Landroidx/room/util/SQLiteStatementUtil;->getColumnIndexOrThrow(Landroidx/sqlite/SQLiteStatement;Ljava/lang/String;)I

    move-result v9

    .line 142
    .local v9, "_columnIndexOfStatus":I
    const-string v10, "errorMessage"

    invoke-static {v3, v10}, Landroidx/room/util/SQLiteStatementUtil;->getColumnIndexOrThrow(Landroidx/sqlite/SQLiteStatement;Ljava/lang/String;)I

    move-result v10

    .line 143
    .local v10, "_columnIndexOfErrorMessage":I
    const-string v11, "timestamp"

    invoke-static {v3, v11}, Landroidx/room/util/SQLiteStatementUtil;->getColumnIndexOrThrow(Landroidx/sqlite/SQLiteStatement;Ljava/lang/String;)I

    move-result v11

    .line 144
    .local v11, "_columnIndexOfTimestamp":I
    const/4 v12, 0x0

    .line 145
    .local v12, "_result":Lcom/example/data/UploadLog;
    invoke-interface {v3}, Landroidx/sqlite/SQLiteStatement;->step()Z

    move-result v13

    if-eqz v13, :cond_81

    .line 146
    const-wide/16 v13, 0x0

    .line 147
    .local v13, "_tmpId":J
    invoke-interface {v3, v5}, Landroidx/sqlite/SQLiteStatement;->getLong(I)J

    move-result-wide v15

    move-wide/from16 v18, v15

    .line 148
    .end local v13  # "_tmpId":J
    .local v18, "_tmpId":J
    const/4 v13, 0x0

    .line 149
    .local v13, "_tmpUriString":Ljava/lang/String;
    invoke-interface {v3, v6}, Landroidx/sqlite/SQLiteStatement;->getText(I)Ljava/lang/String;

    move-result-object v20

    .line 150
    .end local v13  # "_tmpUriString":Ljava/lang/String;
    .local v20, "_tmpUriString":Ljava/lang/String;
    const/4 v13, 0x0

    .line 151
    .local v13, "_tmpFileName":Ljava/lang/String;
    invoke-interface {v3, v7}, Landroidx/sqlite/SQLiteStatement;->getText(I)Ljava/lang/String;

    move-result-object v21

    .line 152
    .end local v13  # "_tmpFileName":Ljava/lang/String;
    .local v21, "_tmpFileName":Ljava/lang/String;
    const-wide/16 v13, 0x0

    .line 153
    .local v13, "_tmpFileSize":J
    invoke-interface {v3, v8}, Landroidx/sqlite/SQLiteStatement;->getLong(I)J

    move-result-wide v22

    .line 154
    .end local v13  # "_tmpFileSize":J
    .local v22, "_tmpFileSize":J
    const/4 v13, 0x0

    .line 155
    .local v13, "_tmpStatus":Ljava/lang/String;
    invoke-interface {v3, v9}, Landroidx/sqlite/SQLiteStatement;->getText(I)Ljava/lang/String;

    move-result-object v24

    .line 156
    .end local v13  # "_tmpStatus":Ljava/lang/String;
    .local v24, "_tmpStatus":Ljava/lang/String;
    const/4 v13, 0x0

    .line 157
    .local v13, "_tmpErrorMessage":Ljava/lang/String;
    invoke-interface {v3, v10}, Landroidx/sqlite/SQLiteStatement;->isNull(I)Z

    move-result v14

    if-eqz v14, :cond_6d

    .line 158
    const/4 v13, 0x0

    move-object/from16 v25, v13

    goto :goto_74

    .line 160
    :cond_6d
    invoke-interface {v3, v10}, Landroidx/sqlite/SQLiteStatement;->getText(I)Ljava/lang/String;

    move-result-object v14

    move-object v13, v14

    move-object/from16 v25, v13

    .line 162
    .end local v13  # "_tmpErrorMessage":Ljava/lang/String;
    .local v25, "_tmpErrorMessage":Ljava/lang/String;
    :goto_74
    const-wide/16 v13, 0x0

    .line 163
    .local v13, "_tmpTimestamp":J
    invoke-interface {v3, v11}, Landroidx/sqlite/SQLiteStatement;->getLong(I)J

    move-result-wide v26

    .line 165
    .end local v13  # "_tmpTimestamp":J
    .local v26, "_tmpTimestamp":J
    new-instance v17, Lcom/example/data/UploadLog;

    invoke-direct/range {v17 .. v27}, Lcom/example/data/UploadLog;-><init>(JLjava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;J)V
    :try_end_7f
    .catchall {:try_start_11 .. :try_end_7f} :catchall_88

    .line 164
    nop

    .end local v12  # "_result":Lcom/example/data/UploadLog;
    .end local v18  # "_tmpId":J
    .end local v20  # "_tmpUriString":Ljava/lang/String;
    .end local v21  # "_tmpFileName":Ljava/lang/String;
    .end local v22  # "_tmpFileSize":J
    .end local v24  # "_tmpStatus":Ljava/lang/String;
    .end local v25  # "_tmpErrorMessage":Ljava/lang/String;
    .end local v26  # "_tmpTimestamp":J
    .local v17, "_result":Lcom/example/data/UploadLog;
    goto :goto_83

    .line 167
    .end local v17  # "_result":Lcom/example/data/UploadLog;
    .restart local v12  # "_result":Lcom/example/data/UploadLog;
    :cond_81
    const/16 v17, 0x0

    .line 169
    .end local v12  # "_result":Lcom/example/data/UploadLog;
    .restart local v17  # "_result":Lcom/example/data/UploadLog;
    :goto_83
    nop

    .line 171
    .end local v0  # "_argIndex":I
    .end local v5  # "_columnIndexOfId":I
    .end local v6  # "_columnIndexOfUriString":I
    .end local v7  # "_columnIndexOfFileName":I
    .end local v8  # "_columnIndexOfFileSize":I
    .end local v9  # "_columnIndexOfStatus":I
    .end local v10  # "_columnIndexOfErrorMessage":I
    .end local v11  # "_columnIndexOfTimestamp":I
    .end local v17  # "_result":Lcom/example/data/UploadLog;
    invoke-interface {v3}, Landroidx/sqlite/SQLiteStatement;->close()V

    .line 172
    return-object v17

    .line 171
    :catchall_88
    move-exception v0

    invoke-interface {v3}, Landroidx/sqlite/SQLiteStatement;->close()V

    throw v0
.end method

.method static final getSuccessCountFlow$lambda$4(Ljava/lang/String;Landroidx/sqlite/SQLiteConnection;)I
    .registers 7
    .param p0, "$_sql"  # Ljava/lang/String;
    .param p1, "_connection"  # Landroidx/sqlite/SQLiteConnection;

    const-string v0, "_connection"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 179
    invoke-interface {p1, p0}, Landroidx/sqlite/SQLiteConnection;->prepare(Ljava/lang/String;)Landroidx/sqlite/SQLiteStatement;

    move-result-object v0

    .line 180
    .local v0, "_stmt":Landroidx/sqlite/SQLiteStatement;
    nop

    .line 181
    const/4 v1, 0x0

    .line 182
    .local v1, "_result":I
    :try_start_b
    invoke-interface {v0}, Landroidx/sqlite/SQLiteStatement;->step()Z

    move-result v2

    if-eqz v2, :cond_1a

    .line 183
    const/4 v2, 0x0

    .line 184
    .local v2, "_tmp":I
    const/4 v3, 0x0

    invoke-interface {v0, v3}, Landroidx/sqlite/SQLiteStatement;->getLong(I)J

    move-result-wide v3
    :try_end_17
    .catchall {:try_start_b .. :try_end_17} :catchall_20

    long-to-int v2, v3

    .line 185
    nop

    .end local v1  # "_result":I
    .local v2, "_result":I
    goto :goto_1b

    .line 187
    .end local v2  # "_result":I
    .restart local v1  # "_result":I
    :cond_1a
    const/4 v2, 0x0

    .line 189
    .end local v1  # "_result":I
    .restart local v2  # "_result":I
    :goto_1b
    nop

    .line 191
    .end local v2  # "_result":I
    invoke-interface {v0}, Landroidx/sqlite/SQLiteStatement;->close()V

    .line 192
    return v2

    .line 191
    :catchall_20
    move-exception v1

    invoke-interface {v0}, Landroidx/sqlite/SQLiteStatement;->close()V

    throw v1
.end method

.method static final insertLog$lambda$0(Lcom/example/data/UploadLogDao_Impl;Lcom/example/data/UploadLog;Landroidx/sqlite/SQLiteConnection;)J
    .registers 5
    .param p0, "this$0"  # Lcom/example/data/UploadLogDao_Impl;
    .param p1, "$uploadLog"  # Lcom/example/data/UploadLog;
    .param p2, "_connection"  # Landroidx/sqlite/SQLiteConnection;

    const-string v0, "_connection"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 77
    iget-object v0, p0, Lcom/example/data/UploadLogDao_Impl;->__insertAdapterOfUploadLog:Landroidx/room/EntityInsertAdapter;

    invoke-virtual {v0, p2, p1}, Landroidx/room/EntityInsertAdapter;->insertAndReturnId(Landroidx/sqlite/SQLiteConnection;Ljava/lang/Object;)J

    move-result-wide v0

    .line 78
    .local v0, "_result":J
    return-wide v0
.end method

.method static final updateLog$lambda$1(Lcom/example/data/UploadLogDao_Impl;Lcom/example/data/UploadLog;Landroidx/sqlite/SQLiteConnection;)Lkotlin/Unit;
    .registers 4
    .param p0, "this$0"  # Lcom/example/data/UploadLogDao_Impl;
    .param p1, "$uploadLog"  # Lcom/example/data/UploadLog;
    .param p2, "_connection"  # Landroidx/sqlite/SQLiteConnection;

    const-string v0, "_connection"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 83
    iget-object v0, p0, Lcom/example/data/UploadLogDao_Impl;->__updateAdapterOfUploadLog:Landroidx/room/EntityDeleteOrUpdateAdapter;

    invoke-virtual {v0, p2, p1}, Landroidx/room/EntityDeleteOrUpdateAdapter;->handle(Landroidx/sqlite/SQLiteConnection;Ljava/lang/Object;)I

    .line 84
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public clearAllLogs(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 7
    .param p1, "$completion"  # Lkotlin/coroutines/Continuation;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 217
    const-string v0, "DELETE FROM upload_logs"

    .line 218
    .local v0, "_sql":Ljava/lang/String;
    iget-object v1, p0, Lcom/example/data/UploadLogDao_Impl;->__db:Landroidx/room/RoomDatabase;

    new-instance v2, Lcom/example/data/UploadLogDao_Impl$$ExternalSyntheticLambda1;

    invoke-direct {v2, v0}, Lcom/example/data/UploadLogDao_Impl$$ExternalSyntheticLambda1;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v1, v3, v4, v2, p1}, Landroidx/room/util/DBUtil;->performSuspending(Landroidx/room/RoomDatabase;ZZLkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v2

    if-ne v1, v2, :cond_16

    return-object v1

    :cond_16
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method public getAllLogsFlow()Lkotlinx/coroutines/flow/Flow;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/flow/Flow<",
            "Ljava/util/List<",
            "Lcom/example/data/UploadLog;",
            ">;>;"
        }
    .end annotation

    .line 87
    const-string v0, "SELECT * FROM upload_logs ORDER BY timestamp DESC"

    .line 88
    .local v0, "_sql":Ljava/lang/String;
    iget-object v1, p0, Lcom/example/data/UploadLogDao_Impl;->__db:Landroidx/room/RoomDatabase;

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "upload_logs"

    const/4 v4, 0x0

    aput-object v3, v2, v4

    new-instance v3, Lcom/example/data/UploadLogDao_Impl$$ExternalSyntheticLambda2;

    invoke-direct {v3, v0}, Lcom/example/data/UploadLogDao_Impl$$ExternalSyntheticLambda2;-><init>(Ljava/lang/String;)V

    invoke-static {v1, v4, v2, v3}, Landroidx/room/coroutines/FlowUtil;->createFlow(Landroidx/room/RoomDatabase;Z[Ljava/lang/String;Lkotlin/jvm/functions/Function1;)Lkotlinx/coroutines/flow/Flow;

    move-result-object v1

    return-object v1
.end method

.method public getFailedCountFlow()Lkotlinx/coroutines/flow/Flow;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/flow/Flow<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 197
    const-string v0, "SELECT COUNT(*) FROM upload_logs WHERE status = \'FAILED\'"

    .line 198
    .local v0, "_sql":Ljava/lang/String;
    iget-object v1, p0, Lcom/example/data/UploadLogDao_Impl;->__db:Landroidx/room/RoomDatabase;

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "upload_logs"

    const/4 v4, 0x0

    aput-object v3, v2, v4

    new-instance v3, Lcom/example/data/UploadLogDao_Impl$$ExternalSyntheticLambda6;

    invoke-direct {v3, v0}, Lcom/example/data/UploadLogDao_Impl$$ExternalSyntheticLambda6;-><init>(Ljava/lang/String;)V

    invoke-static {v1, v4, v2, v3}, Landroidx/room/coroutines/FlowUtil;->createFlow(Landroidx/room/RoomDatabase;Z[Ljava/lang/String;Lkotlin/jvm/functions/Function1;)Lkotlinx/coroutines/flow/Flow;

    move-result-object v1

    return-object v1
.end method

.method public getLogByUri(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 8
    .param p1, "uriString"  # Ljava/lang/String;
    .param p2, "$completion"  # Lkotlin/coroutines/Continuation;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/example/data/UploadLog;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 131
    const-string v0, "SELECT * FROM upload_logs WHERE uriString = ? LIMIT 1"

    .line 132
    .local v0, "_sql":Ljava/lang/String;
    iget-object v1, p0, Lcom/example/data/UploadLogDao_Impl;->__db:Landroidx/room/RoomDatabase;

    new-instance v2, Lcom/example/data/UploadLogDao_Impl$$ExternalSyntheticLambda0;

    invoke-direct {v2, v0, p1}, Lcom/example/data/UploadLogDao_Impl$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {v1, v3, v4, v2, p2}, Landroidx/room/util/DBUtil;->performSuspending(Landroidx/room/RoomDatabase;ZZLkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v1

    return-object v1
.end method

.method public getSuccessCountFlow()Lkotlinx/coroutines/flow/Flow;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/flow/Flow<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 177
    const-string v0, "SELECT COUNT(*) FROM upload_logs WHERE status = \'SUCCESS\'"

    .line 178
    .local v0, "_sql":Ljava/lang/String;
    iget-object v1, p0, Lcom/example/data/UploadLogDao_Impl;->__db:Landroidx/room/RoomDatabase;

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "upload_logs"

    const/4 v4, 0x0

    aput-object v3, v2, v4

    new-instance v3, Lcom/example/data/UploadLogDao_Impl$$ExternalSyntheticLambda4;

    invoke-direct {v3, v0}, Lcom/example/data/UploadLogDao_Impl$$ExternalSyntheticLambda4;-><init>(Ljava/lang/String;)V

    invoke-static {v1, v4, v2, v3}, Landroidx/room/coroutines/FlowUtil;->createFlow(Landroidx/room/RoomDatabase;Z[Ljava/lang/String;Lkotlin/jvm/functions/Function1;)Lkotlinx/coroutines/flow/Flow;

    move-result-object v1

    return-object v1
.end method

.method public insertLog(Lcom/example/data/UploadLog;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 7
    .param p1, "uploadLog"  # Lcom/example/data/UploadLog;
    .param p2, "$completion"  # Lkotlin/coroutines/Continuation;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/example/data/UploadLog;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ljava/lang/Long;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 75
    iget-object v0, p0, Lcom/example/data/UploadLogDao_Impl;->__db:Landroidx/room/RoomDatabase;

    .line 76
    nop

    .line 75
    new-instance v1, Lcom/example/data/UploadLogDao_Impl$$ExternalSyntheticLambda3;

    invoke-direct {v1, p0, p1}, Lcom/example/data/UploadLogDao_Impl$$ExternalSyntheticLambda3;-><init>(Lcom/example/data/UploadLogDao_Impl;Lcom/example/data/UploadLog;)V

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v0, v2, v3, v1, p2}, Landroidx/room/util/DBUtil;->performSuspending(Landroidx/room/RoomDatabase;ZZLkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    .line 79
    return-object v0
.end method

.method public updateLog(Lcom/example/data/UploadLog;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 7
    .param p1, "uploadLog"  # Lcom/example/data/UploadLog;
    .param p2, "$completion"  # Lkotlin/coroutines/Continuation;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/example/data/UploadLog;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 81
    iget-object v0, p0, Lcom/example/data/UploadLogDao_Impl;->__db:Landroidx/room/RoomDatabase;

    .line 82
    nop

    .line 81
    new-instance v1, Lcom/example/data/UploadLogDao_Impl$$ExternalSyntheticLambda5;

    invoke-direct {v1, p0, p1}, Lcom/example/data/UploadLogDao_Impl$$ExternalSyntheticLambda5;-><init>(Lcom/example/data/UploadLogDao_Impl;Lcom/example/data/UploadLog;)V

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v0, v2, v3, v1, p2}, Landroidx/room/util/DBUtil;->performSuspending(Landroidx/room/RoomDatabase;ZZLkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v1

    if-ne v0, v1, :cond_15

    return-object v0

    :cond_15
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 84
    return-object v0
.end method
