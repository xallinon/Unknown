# classes4.dex

.class public final Lcom/example/data/AppDatabase$Companion;
.super Ljava/lang/Object;
.source "AppDatabase.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/data/AppDatabase;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\bR\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\t"
    }
    d2 = {
        "Lcom/example/data/AppDatabase$Companion;",
        "",
        "<init>",
        "()V",
        "INSTANCE",
        "Lcom/example/data/AppDatabase;",
        "getDatabase",
        "context",
        "Landroid/content/Context;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 2

    invoke-direct {p0}, Lcom/example/data/AppDatabase$Companion;-><init>()V

    return-void
.end method


# virtual methods
.method public final getDatabase(Landroid/content/Context;)Lcom/example/data/AppDatabase;
    .registers 6
    .param p1, "context"  # Landroid/content/Context;

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    invoke-static {}, Lcom/example/data/AppDatabase;->access$getINSTANCE$cp()Lcom/example/data/AppDatabase;

    move-result-object v0

    if-nez v0, :cond_35

    monitor-enter p0

    const/4 v0, 0x0

    .line 19
    .local v0, "$i$a$-synchronized-AppDatabase$Companion$getDatabase$1\\1\\17\\0":I
    :try_start_d
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "getApplicationContext(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    const-class v2, Lcom/example/data/AppDatabase;

    .line 21
    const-string v3, "gallery_sender_database"

    .line 18
    invoke-static {v1, v2, v3}, Landroidx/room/Room;->databaseBuilder(Landroid/content/Context;Ljava/lang/Class;Ljava/lang/String;)Landroidx/room/RoomDatabase$Builder;

    move-result-object v1

    .line 23
    invoke-virtual {v1}, Landroidx/room/RoomDatabase$Builder;->fallbackToDestructiveMigration()Landroidx/room/RoomDatabase$Builder;

    move-result-object v1

    .line 24
    invoke-virtual {v1}, Landroidx/room/RoomDatabase$Builder;->build()Landroidx/room/RoomDatabase;

    move-result-object v1

    check-cast v1, Lcom/example/data/AppDatabase;

    .line 18
    nop

    .line 25
    .local v1, "instance\\1":Lcom/example/data/AppDatabase;
    sget-object v2, Lcom/example/data/AppDatabase;->Companion:Lcom/example/data/AppDatabase$Companion;

    invoke-static {v1}, Lcom/example/data/AppDatabase;->access$setINSTANCE$cp(Lcom/example/data/AppDatabase;)V
    :try_end_2e
    .catchall {:try_start_d .. :try_end_2e} :catchall_32

    .line 26
    nop

    .line 17
    .end local v0  # "$i$a$-synchronized-AppDatabase$Companion$getDatabase$1\\1\\17\\0":I
    .end local v1  # "instance\\1":Lcom/example/data/AppDatabase;
    monitor-exit p0

    move-object v0, v1

    goto :goto_35

    :catchall_32
    move-exception v0

    monitor-exit p0

    throw v0

    :cond_35
    :goto_35
    return-object v0
.end method
