# classes4.dex

.class public final Lcom/example/data/UploadRepository;
.super Ljava/lang/Object;
.source "UploadRepository.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0018\u0010\u0011\u001a\u0004\u0018\u00010\t2\u0006\u0010\u0012\u001a\u00020\u0013H\u0086@¢\u0006\u0002\u0010\u0014J\u0016\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\tH\u0086@¢\u0006\u0002\u0010\u0018J\u0016\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u0017\u001a\u00020\tH\u0086@¢\u0006\u0002\u0010\u0018J\u000e\u0010\u001b\u001a\u00020\u001aH\u0086@¢\u0006\u0002\u0010\u001cR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u0010\u0006\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\t0\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0017\u0010\f\u001a\b\u0012\u0004\u0012\u00020\r0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000bR\u0017\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\r0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000b¨\u0006\u001d"
    }
    d2 = {
        "Lcom/example/data/UploadRepository;",
        "",
        "uploadLogDao",
        "Lcom/example/data/UploadLogDao;",
        "<init>",
        "(Lcom/example/data/UploadLogDao;)V",
        "allLogs",
        "Lkotlinx/coroutines/flow/Flow;",
        "",
        "Lcom/example/data/UploadLog;",
        "getAllLogs",
        "()Lkotlinx/coroutines/flow/Flow;",
        "successCount",
        "",
        "getSuccessCount",
        "failedCount",
        "getFailedCount",
        "getLogByUri",
        "uriString",
        "",
        "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;",
        "insert",
        "",
        "uploadLog",
        "(Lcom/example/data/UploadLog;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;",
        "update",
        "",
        "clearAll",
        "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private final allLogs:Lkotlinx/coroutines/flow/Flow;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/Flow<",
            "Ljava/util/List<",
            "Lcom/example/data/UploadLog;",
            ">;>;"
        }
    .end annotation
.end field

.field private final failedCount:Lkotlinx/coroutines/flow/Flow;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/Flow<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final successCount:Lkotlinx/coroutines/flow/Flow;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/Flow<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final uploadLogDao:Lcom/example/data/UploadLogDao;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x8

    sput v0, Lcom/example/data/UploadRepository;->$stable:I

    return-void
.end method

.method public constructor <init>(Lcom/example/data/UploadLogDao;)V
    .registers 3
    .param p1, "uploadLogDao"  # Lcom/example/data/UploadLogDao;

    const-string v0, "uploadLogDao"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/data/UploadRepository;->uploadLogDao:Lcom/example/data/UploadLogDao;

    .line 6
    iget-object v0, p0, Lcom/example/data/UploadRepository;->uploadLogDao:Lcom/example/data/UploadLogDao;

    invoke-interface {v0}, Lcom/example/data/UploadLogDao;->getAllLogsFlow()Lkotlinx/coroutines/flow/Flow;

    move-result-object v0

    iput-object v0, p0, Lcom/example/data/UploadRepository;->allLogs:Lkotlinx/coroutines/flow/Flow;

    .line 7
    iget-object v0, p0, Lcom/example/data/UploadRepository;->uploadLogDao:Lcom/example/data/UploadLogDao;

    invoke-interface {v0}, Lcom/example/data/UploadLogDao;->getSuccessCountFlow()Lkotlinx/coroutines/flow/Flow;

    move-result-object v0

    iput-object v0, p0, Lcom/example/data/UploadRepository;->successCount:Lkotlinx/coroutines/flow/Flow;

    .line 8
    iget-object v0, p0, Lcom/example/data/UploadRepository;->uploadLogDao:Lcom/example/data/UploadLogDao;

    invoke-interface {v0}, Lcom/example/data/UploadLogDao;->getFailedCountFlow()Lkotlinx/coroutines/flow/Flow;

    move-result-object v0

    iput-object v0, p0, Lcom/example/data/UploadRepository;->failedCount:Lkotlinx/coroutines/flow/Flow;

    .line 5
    return-void
.end method


# virtual methods
.method public final clearAll(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 4
    .param p1, "$completion"  # Lkotlin/coroutines/Continuation;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 23
    iget-object v0, p0, Lcom/example/data/UploadRepository;->uploadLogDao:Lcom/example/data/UploadLogDao;

    invoke-interface {v0, p1}, Lcom/example/data/UploadLogDao;->clearAllLogs(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v1

    if-ne v0, v1, :cond_d

    return-object v0

    :cond_d
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 24
    return-object v0
.end method

.method public final getAllLogs()Lkotlinx/coroutines/flow/Flow;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/flow/Flow<",
            "Ljava/util/List<",
            "Lcom/example/data/UploadLog;",
            ">;>;"
        }
    .end annotation

    .line 6
    iget-object v0, p0, Lcom/example/data/UploadRepository;->allLogs:Lkotlinx/coroutines/flow/Flow;

    return-object v0
.end method

.method public final getFailedCount()Lkotlinx/coroutines/flow/Flow;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/flow/Flow<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 8
    iget-object v0, p0, Lcom/example/data/UploadRepository;->failedCount:Lkotlinx/coroutines/flow/Flow;

    return-object v0
.end method

.method public final getLogByUri(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 4
    .param p1, "uriString"  # Ljava/lang/String;
    .param p2, "$completion"  # Lkotlin/coroutines/Continuation;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/example/data/UploadLog;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 11
    iget-object v0, p0, Lcom/example/data/UploadRepository;->uploadLogDao:Lcom/example/data/UploadLogDao;

    invoke-interface {v0, p1, p2}, Lcom/example/data/UploadLogDao;->getLogByUri(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final getSuccessCount()Lkotlinx/coroutines/flow/Flow;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/flow/Flow<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 7
    iget-object v0, p0, Lcom/example/data/UploadRepository;->successCount:Lkotlinx/coroutines/flow/Flow;

    return-object v0
.end method

.method public final insert(Lcom/example/data/UploadLog;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 4
    .param p1, "uploadLog"  # Lcom/example/data/UploadLog;
    .param p2, "$completion"  # Lkotlin/coroutines/Continuation;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/example/data/UploadLog;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ljava/lang/Long;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 15
    iget-object v0, p0, Lcom/example/data/UploadRepository;->uploadLogDao:Lcom/example/data/UploadLogDao;

    invoke-interface {v0, p1, p2}, Lcom/example/data/UploadLogDao;->insertLog(Lcom/example/data/UploadLog;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final update(Lcom/example/data/UploadLog;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 5
    .param p1, "uploadLog"  # Lcom/example/data/UploadLog;
    .param p2, "$completion"  # Lkotlin/coroutines/Continuation;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/example/data/UploadLog;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 19
    iget-object v0, p0, Lcom/example/data/UploadRepository;->uploadLogDao:Lcom/example/data/UploadLogDao;

    invoke-interface {v0, p1, p2}, Lcom/example/data/UploadLogDao;->updateLog(Lcom/example/data/UploadLog;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v1

    if-ne v0, v1, :cond_d

    return-object v0

    :cond_d
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 20
    return-object v0
.end method
