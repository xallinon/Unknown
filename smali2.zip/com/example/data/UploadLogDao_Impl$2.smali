# classes4.dex

.class public final Lcom/example/data/UploadLogDao_Impl$2;
.super Landroidx/room/EntityDeleteOrUpdateAdapter;
.source "UploadLogDao_Impl.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/data/UploadLogDao_Impl;-><init>(Landroidx/room/RoomDatabase;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/room/EntityDeleteOrUpdateAdapter<",
        "Lcom/example/data/UploadLog;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000#\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001J\b\u0010\u0003\u001a\u00020\u0004H\u0014J\u0018\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u0002H\u0014¨\u0006\n"
    }
    d2 = {
        "com/example/data/UploadLogDao_Impl$2",
        "Landroidx/room/EntityDeleteOrUpdateAdapter;",
        "Lcom/example/data/UploadLog;",
        "createQuery",
        "",
        "bind",
        "",
        "statement",
        "Landroidx/sqlite/SQLiteStatement;",
        "entity",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .line 53
    invoke-direct {p0}, Landroidx/room/EntityDeleteOrUpdateAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method protected bind(Landroidx/sqlite/SQLiteStatement;Lcom/example/data/UploadLog;)V
    .registers 7
    .param p1, "statement"  # Landroidx/sqlite/SQLiteStatement;
    .param p2, "entity"  # Lcom/example/data/UploadLog;

    const-string v0, "statement"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "entity"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 58
    const/4 v0, 0x1

    invoke-virtual {p2}, Lcom/example/data/UploadLog;->getId()J

    move-result-wide v1

    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/SQLiteStatement;->bindLong(IJ)V

    .line 59
    const/4 v0, 0x2

    invoke-virtual {p2}, Lcom/example/data/UploadLog;->getUriString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {p1, v0, v1}, Landroidx/sqlite/SQLiteStatement;->bindText(ILjava/lang/String;)V

    .line 60
    const/4 v0, 0x3

    invoke-virtual {p2}, Lcom/example/data/UploadLog;->getFileName()Ljava/lang/String;

    move-result-object v1

    invoke-interface {p1, v0, v1}, Landroidx/sqlite/SQLiteStatement;->bindText(ILjava/lang/String;)V

    .line 61
    const/4 v0, 0x4

    invoke-virtual {p2}, Lcom/example/data/UploadLog;->getFileSize()J

    move-result-wide v1

    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/SQLiteStatement;->bindLong(IJ)V

    .line 62
    const/4 v0, 0x5

    invoke-virtual {p2}, Lcom/example/data/UploadLog;->getStatus()Ljava/lang/String;

    move-result-object v1

    invoke-interface {p1, v0, v1}, Landroidx/sqlite/SQLiteStatement;->bindText(ILjava/lang/String;)V

    .line 63
    invoke-virtual {p2}, Lcom/example/data/UploadLog;->getErrorMessage()Ljava/lang/String;

    move-result-object v0

    .line 64
    .local v0, "_tmpErrorMessage":Ljava/lang/String;
    const/4 v1, 0x6

    if-nez v0, :cond_3d

    .line 65
    invoke-interface {p1, v1}, Landroidx/sqlite/SQLiteStatement;->bindNull(I)V

    goto :goto_40

    .line 67
    :cond_3d
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/SQLiteStatement;->bindText(ILjava/lang/String;)V

    .line 69
    :goto_40
    const/4 v1, 0x7

    invoke-virtual {p2}, Lcom/example/data/UploadLog;->getTimestamp()J

    move-result-wide v2

    invoke-interface {p1, v1, v2, v3}, Landroidx/sqlite/SQLiteStatement;->bindLong(IJ)V

    .line 70
    const/16 v1, 0x8

    invoke-virtual {p2}, Lcom/example/data/UploadLog;->getId()J

    move-result-wide v2

    invoke-interface {p1, v1, v2, v3}, Landroidx/sqlite/SQLiteStatement;->bindLong(IJ)V

    .line 71
    return-void
.end method

.method public bridge synthetic bind(Landroidx/sqlite/SQLiteStatement;Ljava/lang/Object;)V
    .registers 4
    .param p1, "statement"  # Landroidx/sqlite/SQLiteStatement;
    .param p2, "entity"  # Ljava/lang/Object;

    .line 53
    move-object v0, p2

    check-cast v0, Lcom/example/data/UploadLog;

    invoke-virtual {p0, p1, v0}, Lcom/example/data/UploadLogDao_Impl$2;->bind(Landroidx/sqlite/SQLiteStatement;Lcom/example/data/UploadLog;)V

    return-void
.end method

.method protected createQuery()Ljava/lang/String;
    .registers 2

    .line 55
    const-string v0, "UPDATE OR ABORT `upload_logs` SET `id` = ?,`uriString` = ?,`fileName` = ?,`fileSize` = ?,`status` = ?,`errorMessage` = ?,`timestamp` = ? WHERE `id` = ?"

    return-object v0
.end method
