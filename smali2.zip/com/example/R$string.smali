# classes2.dex

.class public final Lcom/example/R$string;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static app_name:I = 0x7f090001

.field public static confirm_no:I = 0x7f09000b

.field public static confirm_yes:I = 0x7f09000c

.field public static first_confirm_desc:I = 0x7f090010

.field public static first_confirm_title:I = 0x7f090011

.field public static permission_btn:I = 0x7f09004f

.field public static permission_rationale_desc:I = 0x7f090050

.field public static permission_rationale_title:I = 0x7f090051

.field public static second_confirm_desc:I = 0x7f090054

.field public static second_confirm_title:I = 0x7f090055

.field public static send_photos_btn:I = 0x7f090057


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
