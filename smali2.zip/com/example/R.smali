# classes2.dex

.class public final Lcom/example/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/R$color;,
        Lcom/example/R$drawable;,
        Lcom/example/R$mipmap;,
        Lcom/example/R$string;,
        Lcom/example/R$style;,
        Lcom/example/R$xml;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
