# classes6.dex

.class public final Lcom/example/ui/MainViewModel;
.super Landroidx/lifecycle/AndroidViewModel;
.source "MainViewModel.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/ui/MainViewModel$Factory;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000^\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001:\u00014B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0016\u0010+\u001a\u00020,2\u0006\u0010-\u001a\u00020\u00162\u0006\u0010.\u001a\u00020\u0014J\u0006\u0010/\u001a\u00020,J\u000e\u00100\u001a\u00020,2\u0006\u00101\u001a\u000202J\u000e\u00103\u001a\u00020,2\u0006\u00101\u001a\u000202R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u0010\b\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000b0\n0\t¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0017\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u000f0\t¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\rR\u0017\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u000f0\t¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\rR\u0017\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00140\t¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\rR\u0017\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00160\t¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\rR\u0017\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u000f0\t¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\rR\u0017\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u000f0\t¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\rR\u0017\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u001d0\t¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\rR\u0017\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\u00160\t¢\u0006\b\n\u0000\u001a\u0004\b \u0010\rR\u0017\u0010!\u001a\b\u0012\u0004\u0012\u00020\u00140\t¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\rR \u0010\"\u001a\b\u0012\u0004\u0012\u00020\u00140#X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b$\u0010%\"\u0004\b&\u0010\'R \u0010(\u001a\b\u0012\u0004\u0012\u00020\u00140#X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b)\u0010%\"\u0004\b*\u0010\'¨\u00065"
    }
    d2 = {
        "Lcom/example/ui/MainViewModel;",
        "Landroidx/lifecycle/AndroidViewModel;",
        "application",
        "Landroid/app/Application;",
        "<init>",
        "(Landroid/app/Application;)V",
        "repository",
        "Lcom/example/data/UploadRepository;",
        "allLogs",
        "Lkotlinx/coroutines/flow/StateFlow;",
        "",
        "Lcom/example/data/UploadLog;",
        "getAllLogs",
        "()Lkotlinx/coroutines/flow/StateFlow;",
        "successCount",
        "",
        "getSuccessCount",
        "failedCount",
        "getFailedCount",
        "isServiceRunning",
        "",
        "currentPhotoName",
        "",
        "getCurrentPhotoName",
        "currentIndex",
        "getCurrentIndex",
        "totalPhotos",
        "getTotalPhotos",
        "progressPercentage",
        "",
        "getProgressPercentage",
        "customServerUrl",
        "getCustomServerUrl",
        "isSimulationMode",
        "showFirstConfirm",
        "Landroidx/compose/runtime/MutableState;",
        "getShowFirstConfirm",
        "()Landroidx/compose/runtime/MutableState;",
        "setShowFirstConfirm",
        "(Landroidx/compose/runtime/MutableState;)V",
        "showSecondConfirm",
        "getShowSecondConfirm",
        "setShowSecondConfirm",
        "updateServerConfig",
        "",
        "url",
        "simulation",
        "clearAllLogs",
        "startService",
        "context",
        "Landroid/content/Context;",
        "stopService",
        "Factory",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private final allLogs:Lkotlinx/coroutines/flow/StateFlow;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/util/List<",
            "Lcom/example/data/UploadLog;",
            ">;>;"
        }
    .end annotation
.end field

.field private final currentIndex:Lkotlinx/coroutines/flow/StateFlow;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final currentPhotoName:Lkotlinx/coroutines/flow/StateFlow;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final customServerUrl:Lkotlinx/coroutines/flow/StateFlow;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final failedCount:Lkotlinx/coroutines/flow/StateFlow;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final isServiceRunning:Lkotlinx/coroutines/flow/StateFlow;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field private final isSimulationMode:Lkotlinx/coroutines/flow/StateFlow;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field private final progressPercentage:Lkotlinx/coroutines/flow/StateFlow;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field private final repository:Lcom/example/data/UploadRepository;

.field private showFirstConfirm:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field private showSecondConfirm:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field private final successCount:Lkotlinx/coroutines/flow/StateFlow;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final totalPhotos:Lkotlinx/coroutines/flow/StateFlow;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x8

    sput v0, Lcom/example/ui/MainViewModel;->$stable:I

    return-void
.end method

.method public constructor <init>(Landroid/app/Application;)V
    .registers 13
    .param p1, "application"  # Landroid/app/Application;

    const-string v0, "application"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    invoke-direct {p0, p1}, Landroidx/lifecycle/AndroidViewModel;-><init>(Landroid/app/Application;)V

    .line 32
    sget-object v0, Lcom/example/data/UploadStateTracker;->INSTANCE:Lcom/example/data/UploadStateTracker;

    invoke-virtual {v0}, Lcom/example/data/UploadStateTracker;->isServiceRunning()Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v0

    iput-object v0, p0, Lcom/example/ui/MainViewModel;->isServiceRunning:Lkotlinx/coroutines/flow/StateFlow;

    .line 33
    sget-object v0, Lcom/example/data/UploadStateTracker;->INSTANCE:Lcom/example/data/UploadStateTracker;

    invoke-virtual {v0}, Lcom/example/data/UploadStateTracker;->getCurrentPhotoName()Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v0

    iput-object v0, p0, Lcom/example/ui/MainViewModel;->currentPhotoName:Lkotlinx/coroutines/flow/StateFlow;

    .line 34
    sget-object v0, Lcom/example/data/UploadStateTracker;->INSTANCE:Lcom/example/data/UploadStateTracker;

    invoke-virtual {v0}, Lcom/example/data/UploadStateTracker;->getCurrentIndex()Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v0

    iput-object v0, p0, Lcom/example/ui/MainViewModel;->currentIndex:Lkotlinx/coroutines/flow/StateFlow;

    .line 35
    sget-object v0, Lcom/example/data/UploadStateTracker;->INSTANCE:Lcom/example/data/UploadStateTracker;

    invoke-virtual {v0}, Lcom/example/data/UploadStateTracker;->getTotalPhotos()Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v0

    iput-object v0, p0, Lcom/example/ui/MainViewModel;->totalPhotos:Lkotlinx/coroutines/flow/StateFlow;

    .line 36
    sget-object v0, Lcom/example/data/UploadStateTracker;->INSTANCE:Lcom/example/data/UploadStateTracker;

    invoke-virtual {v0}, Lcom/example/data/UploadStateTracker;->getProgressPercentage()Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v0

    iput-object v0, p0, Lcom/example/ui/MainViewModel;->progressPercentage:Lkotlinx/coroutines/flow/StateFlow;

    .line 37
    sget-object v0, Lcom/example/data/UploadStateTracker;->INSTANCE:Lcom/example/data/UploadStateTracker;

    invoke-virtual {v0}, Lcom/example/data/UploadStateTracker;->getCustomServerUrl()Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v0

    iput-object v0, p0, Lcom/example/ui/MainViewModel;->customServerUrl:Lkotlinx/coroutines/flow/StateFlow;

    .line 38
    sget-object v0, Lcom/example/data/UploadStateTracker;->INSTANCE:Lcom/example/data/UploadStateTracker;

    invoke-virtual {v0}, Lcom/example/data/UploadStateTracker;->isSimulationMode()Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v0

    iput-object v0, p0, Lcom/example/ui/MainViewModel;->isSimulationMode:Lkotlinx/coroutines/flow/StateFlow;

    .line 41
    const/4 v0, 0x0

    .line 57
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    .line 41
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v0, v2, v3, v2}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v4

    iput-object v4, p0, Lcom/example/ui/MainViewModel;->showFirstConfirm:Landroidx/compose/runtime/MutableState;

    .line 42
    invoke-static {v0, v2, v3, v2}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    iput-object v0, p0, Lcom/example/ui/MainViewModel;->showSecondConfirm:Landroidx/compose/runtime/MutableState;

    .line 44
    nop

    .line 45
    sget-object v0, Lcom/example/data/AppDatabase;->Companion:Lcom/example/data/AppDatabase$Companion;

    move-object v2, p1

    check-cast v2, Landroid/content/Context;

    invoke-virtual {v0, v2}, Lcom/example/data/AppDatabase$Companion;->getDatabase(Landroid/content/Context;)Lcom/example/data/AppDatabase;

    move-result-object v0

    invoke-virtual {v0}, Lcom/example/data/AppDatabase;->uploadLogDao()Lcom/example/data/UploadLogDao;

    move-result-object v0

    .line 46
    .local v0, "dao":Lcom/example/data/UploadLogDao;
    new-instance v2, Lcom/example/data/UploadRepository;

    invoke-direct {v2, v0}, Lcom/example/data/UploadRepository;-><init>(Lcom/example/data/UploadLogDao;)V

    iput-object v2, p0, Lcom/example/ui/MainViewModel;->repository:Lcom/example/data/UploadRepository;

    .line 48
    iget-object v2, p0, Lcom/example/ui/MainViewModel;->repository:Lcom/example/data/UploadRepository;

    invoke-virtual {v2}, Lcom/example/data/UploadRepository;->getAllLogs()Lkotlinx/coroutines/flow/Flow;

    move-result-object v2

    .line 49
    move-object v3, p0

    check-cast v3, Landroidx/lifecycle/ViewModel;

    invoke-static {v3}, Landroidx/lifecycle/ViewModelKt;->getViewModelScope(Landroidx/lifecycle/ViewModel;)Lkotlinx/coroutines/CoroutineScope;

    move-result-object v3

    .line 50
    sget-object v4, Lkotlinx/coroutines/flow/SharingStarted;->Companion:Lkotlinx/coroutines/flow/SharingStarted$Companion;

    const/4 v9, 0x2

    const/4 v10, 0x0

    const-wide/16 v5, 0x1388

    const-wide/16 v7, 0x0

    invoke-static/range {v4 .. v10}, Lkotlinx/coroutines/flow/SharingStarted$Companion;->WhileSubscribed$default(Lkotlinx/coroutines/flow/SharingStarted$Companion;JJILjava/lang/Object;)Lkotlinx/coroutines/flow/SharingStarted;

    move-result-object v4

    .line 51
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v5

    .line 48
    invoke-static {v2, v3, v4, v5}, Lkotlinx/coroutines/flow/FlowKt;->stateIn(Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/CoroutineScope;Lkotlinx/coroutines/flow/SharingStarted;Ljava/lang/Object;)Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v2

    iput-object v2, p0, Lcom/example/ui/MainViewModel;->allLogs:Lkotlinx/coroutines/flow/StateFlow;

    .line 54
    iget-object v2, p0, Lcom/example/ui/MainViewModel;->repository:Lcom/example/data/UploadRepository;

    invoke-virtual {v2}, Lcom/example/data/UploadRepository;->getSuccessCount()Lkotlinx/coroutines/flow/Flow;

    move-result-object v2

    .line 55
    move-object v3, p0

    check-cast v3, Landroidx/lifecycle/ViewModel;

    invoke-static {v3}, Landroidx/lifecycle/ViewModelKt;->getViewModelScope(Landroidx/lifecycle/ViewModel;)Lkotlinx/coroutines/CoroutineScope;

    move-result-object v3

    .line 56
    sget-object v4, Lkotlinx/coroutines/flow/SharingStarted;->Companion:Lkotlinx/coroutines/flow/SharingStarted$Companion;

    const-wide/16 v5, 0x1388

    invoke-static/range {v4 .. v10}, Lkotlinx/coroutines/flow/SharingStarted$Companion;->WhileSubscribed$default(Lkotlinx/coroutines/flow/SharingStarted$Companion;JJILjava/lang/Object;)Lkotlinx/coroutines/flow/SharingStarted;

    move-result-object v4

    .line 57
    nop

    .line 54
    invoke-static {v2, v3, v4, v1}, Lkotlinx/coroutines/flow/FlowKt;->stateIn(Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/CoroutineScope;Lkotlinx/coroutines/flow/SharingStarted;Ljava/lang/Object;)Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v2

    iput-object v2, p0, Lcom/example/ui/MainViewModel;->successCount:Lkotlinx/coroutines/flow/StateFlow;

    .line 60
    iget-object v2, p0, Lcom/example/ui/MainViewModel;->repository:Lcom/example/data/UploadRepository;

    invoke-virtual {v2}, Lcom/example/data/UploadRepository;->getFailedCount()Lkotlinx/coroutines/flow/Flow;

    move-result-object v2

    .line 61
    move-object v3, p0

    check-cast v3, Landroidx/lifecycle/ViewModel;

    invoke-static {v3}, Landroidx/lifecycle/ViewModelKt;->getViewModelScope(Landroidx/lifecycle/ViewModel;)Lkotlinx/coroutines/CoroutineScope;

    move-result-object v3

    .line 62
    sget-object v4, Lkotlinx/coroutines/flow/SharingStarted;->Companion:Lkotlinx/coroutines/flow/SharingStarted$Companion;

    invoke-static/range {v4 .. v10}, Lkotlinx/coroutines/flow/SharingStarted$Companion;->WhileSubscribed$default(Lkotlinx/coroutines/flow/SharingStarted$Companion;JJILjava/lang/Object;)Lkotlinx/coroutines/flow/SharingStarted;

    move-result-object v4

    .line 63
    nop

    .line 60
    invoke-static {v2, v3, v4, v1}, Lkotlinx/coroutines/flow/FlowKt;->stateIn(Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/CoroutineScope;Lkotlinx/coroutines/flow/SharingStarted;Ljava/lang/Object;)Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v1

    iput-object v1, p0, Lcom/example/ui/MainViewModel;->failedCount:Lkotlinx/coroutines/flow/StateFlow;

    .line 65
    .end local v0  # "dao":Lcom/example/data/UploadLogDao;
    nop

    .line 22
    return-void
.end method

.method public static final synthetic access$getRepository$p(Lcom/example/ui/MainViewModel;)Lcom/example/data/UploadRepository;
    .registers 2
    .param p0, "$this"  # Lcom/example/ui/MainViewModel;

    .line 22
    iget-object v0, p0, Lcom/example/ui/MainViewModel;->repository:Lcom/example/data/UploadRepository;

    return-object v0
.end method


# virtual methods
.method public final clearAllLogs()V
    .registers 8

    .line 72
    move-object v0, p0

    check-cast v0, Landroidx/lifecycle/ViewModel;

    invoke-static {v0}, Landroidx/lifecycle/ViewModelKt;->getViewModelScope(Landroidx/lifecycle/ViewModel;)Lkotlinx/coroutines/CoroutineScope;

    move-result-object v1

    new-instance v0, Lcom/example/ui/MainViewModel$clearAllLogs$1;

    const/4 v2, 0x0

    invoke-direct {v0, p0, v2}, Lcom/example/ui/MainViewModel$clearAllLogs$1;-><init>(Lcom/example/ui/MainViewModel;Lkotlin/coroutines/Continuation;)V

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function2;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v3, 0x0

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    .line 75
    return-void
.end method

.method public final getAllLogs()Lkotlinx/coroutines/flow/StateFlow;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/util/List<",
            "Lcom/example/data/UploadLog;",
            ">;>;"
        }
    .end annotation

    .line 27
    iget-object v0, p0, Lcom/example/ui/MainViewModel;->allLogs:Lkotlinx/coroutines/flow/StateFlow;

    return-object v0
.end method

.method public final getCurrentIndex()Lkotlinx/coroutines/flow/StateFlow;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 34
    iget-object v0, p0, Lcom/example/ui/MainViewModel;->currentIndex:Lkotlinx/coroutines/flow/StateFlow;

    return-object v0
.end method

.method public final getCurrentPhotoName()Lkotlinx/coroutines/flow/StateFlow;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 33
    iget-object v0, p0, Lcom/example/ui/MainViewModel;->currentPhotoName:Lkotlinx/coroutines/flow/StateFlow;

    return-object v0
.end method

.method public final getCustomServerUrl()Lkotlinx/coroutines/flow/StateFlow;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 37
    iget-object v0, p0, Lcom/example/ui/MainViewModel;->customServerUrl:Lkotlinx/coroutines/flow/StateFlow;

    return-object v0
.end method

.method public final getFailedCount()Lkotlinx/coroutines/flow/StateFlow;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 29
    iget-object v0, p0, Lcom/example/ui/MainViewModel;->failedCount:Lkotlinx/coroutines/flow/StateFlow;

    return-object v0
.end method

.method public final getProgressPercentage()Lkotlinx/coroutines/flow/StateFlow;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation

    .line 36
    iget-object v0, p0, Lcom/example/ui/MainViewModel;->progressPercentage:Lkotlinx/coroutines/flow/StateFlow;

    return-object v0
.end method

.method public final getShowFirstConfirm()Landroidx/compose/runtime/MutableState;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 41
    iget-object v0, p0, Lcom/example/ui/MainViewModel;->showFirstConfirm:Landroidx/compose/runtime/MutableState;

    return-object v0
.end method

.method public final getShowSecondConfirm()Landroidx/compose/runtime/MutableState;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 42
    iget-object v0, p0, Lcom/example/ui/MainViewModel;->showSecondConfirm:Landroidx/compose/runtime/MutableState;

    return-object v0
.end method

.method public final getSuccessCount()Lkotlinx/coroutines/flow/StateFlow;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 28
    iget-object v0, p0, Lcom/example/ui/MainViewModel;->successCount:Lkotlinx/coroutines/flow/StateFlow;

    return-object v0
.end method

.method public final getTotalPhotos()Lkotlinx/coroutines/flow/StateFlow;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 35
    iget-object v0, p0, Lcom/example/ui/MainViewModel;->totalPhotos:Lkotlinx/coroutines/flow/StateFlow;

    return-object v0
.end method

.method public final isServiceRunning()Lkotlinx/coroutines/flow/StateFlow;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 32
    iget-object v0, p0, Lcom/example/ui/MainViewModel;->isServiceRunning:Lkotlinx/coroutines/flow/StateFlow;

    return-object v0
.end method

.method public final isSimulationMode()Lkotlinx/coroutines/flow/StateFlow;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/flow/StateFlow<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 38
    iget-object v0, p0, Lcom/example/ui/MainViewModel;->isSimulationMode:Lkotlinx/coroutines/flow/StateFlow;

    return-object v0
.end method

.method public final setShowFirstConfirm(Landroidx/compose/runtime/MutableState;)V
    .registers 3
    .param p1, "<set-?>"  # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 41
    iput-object p1, p0, Lcom/example/ui/MainViewModel;->showFirstConfirm:Landroidx/compose/runtime/MutableState;

    return-void
.end method

.method public final setShowSecondConfirm(Landroidx/compose/runtime/MutableState;)V
    .registers 3
    .param p1, "<set-?>"  # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    iput-object p1, p0, Lcom/example/ui/MainViewModel;->showSecondConfirm:Landroidx/compose/runtime/MutableState;

    return-void
.end method

.method public final startService(Landroid/content/Context;)V
    .registers 6
    .param p1, "context"  # Landroid/content/Context;

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 78
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/example/service/PhotoUploadService;

    invoke-direct {v0, p1, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    move-object v1, v0

    .local v1, "$this$startService_u24lambda_u240\\1":Landroid/content/Intent;
    const/4 v2, 0x0

    .line 79
    .local v2, "$i$a$-apply-MainViewModel$startService$intent$1\\1\\78\\0":I
    const-string v3, "com.example.service.ACTION_START"

    invoke-virtual {v1, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 80
    nop

    .line 78
    .end local v1  # "$this$startService_u24lambda_u240\\1":Landroid/content/Intent;
    .end local v2  # "$i$a$-apply-MainViewModel$startService$intent$1\\1\\78\\0":I
    nop

    .line 81
    .local v0, "intent":Landroid/content/Intent;
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1a

    if-lt v1, v2, :cond_1f

    .line 82
    invoke-virtual {p1, v0}, Landroid/content/Context;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_22

    .line 84
    :cond_1f
    invoke-virtual {p1, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 86
    :goto_22
    return-void
.end method

.method public final stopService(Landroid/content/Context;)V
    .registers 6
    .param p1, "context"  # Landroid/content/Context;

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 89
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/example/service/PhotoUploadService;

    invoke-direct {v0, p1, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    move-object v1, v0

    .local v1, "$this$stopService_u24lambda_u241\\1":Landroid/content/Intent;
    const/4 v2, 0x0

    .line 90
    .local v2, "$i$a$-apply-MainViewModel$stopService$intent$1\\1\\89\\0":I
    const-string v3, "com.example.service.ACTION_STOP"

    invoke-virtual {v1, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 91
    nop

    .line 89
    .end local v1  # "$this$stopService_u24lambda_u241\\1":Landroid/content/Intent;
    .end local v2  # "$i$a$-apply-MainViewModel$stopService$intent$1\\1\\89\\0":I
    nop

    .line 92
    .local v0, "intent":Landroid/content/Intent;
    invoke-virtual {p1, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 93
    return-void
.end method

.method public final updateServerConfig(Ljava/lang/String;Z)V
    .registers 4
    .param p1, "url"  # Ljava/lang/String;
    .param p2, "simulation"  # Z

    const-string v0, "url"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 68
    sget-object v0, Lcom/example/data/UploadStateTracker;->INSTANCE:Lcom/example/data/UploadStateTracker;

    invoke-virtual {v0, p1, p2}, Lcom/example/data/UploadStateTracker;->setServerConfig(Ljava/lang/String;Z)V

    .line 69
    return-void
.end method
