# classes6.dex

.class public final Lcom/example/MainActivityKt;
.super Ljava/lang/Object;
.source "MainActivity.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nMainActivity.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MainActivity.kt\ncom/example/MainActivityKt\n+ 2 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n+ 3 ViewModel.kt\nandroidx/lifecycle/viewmodel/compose/ViewModelKt__ViewModelKt\n+ 4 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 5 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n+ 6 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 7 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 8 Composer.kt\nandroidx/compose/runtime/Updater\n+ 9 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 10 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 11 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 12 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 13 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,852:1\n77#2:853\n55#3,11:854\n1225#4,6:865\n1225#4,6:871\n1225#4,6:877\n1225#4,6:883\n1225#4,6:925\n1225#4,6:931\n1225#4,6:973\n1225#4,6:1151\n1225#4,6:1241\n1225#4,6:1498\n1225#4,6:1513\n1225#4,6:2018\n71#5:889\n68#5,6:890\n74#5:924\n71#5:938\n69#5,5:939\n74#5:972\n78#5:982\n78#5:986\n71#5:1059\n69#5,5:1060\n74#5:1093\n78#5:1098\n71#5:1299\n69#5,5:1300\n74#5:1333\n78#5:1338\n71#5:1726\n69#5,5:1727\n74#5:1760\n78#5:1765\n78#6,6:896\n85#6,4:911\n89#6,2:921\n78#6,6:944\n85#6,4:959\n89#6,2:969\n93#6:981\n93#6:985\n78#6,6:991\n85#6,4:1006\n89#6,2:1016\n78#6,6:1028\n85#6,4:1043\n89#6,2:1053\n78#6,6:1065\n85#6,4:1080\n89#6,2:1090\n93#6:1097\n78#6,6:1108\n85#6,4:1123\n89#6,2:1133\n93#6:1139\n93#6:1143\n93#6:1147\n78#6,6:1168\n85#6,4:1183\n89#6,2:1193\n93#6:1199\n78#6,6:1211\n85#6,4:1226\n89#6,2:1236\n93#6:1249\n78#6,6:1269\n85#6,4:1284\n89#6,2:1294\n78#6,6:1305\n85#6,4:1320\n89#6,2:1330\n93#6:1337\n93#6:1344\n78#6,6:1352\n85#6,4:1367\n89#6,2:1377\n93#6:1388\n78#6,6:1398\n85#6,4:1413\n89#6,2:1423\n78#6,6:1430\n85#6,4:1445\n89#6,2:1455\n78#6,6:1467\n85#6,4:1482\n89#6,2:1492\n93#6:1507\n93#6:1511\n78#6,6:1528\n85#6,4:1543\n89#6,2:1553\n93#6:1562\n93#6:1566\n78#6,6:1576\n85#6,4:1591\n89#6,2:1601\n93#6:1609\n78#6,6:1619\n85#6,4:1634\n89#6,2:1644\n93#6:1652\n78#6,6:1659\n85#6,4:1674\n89#6,2:1684\n78#6,6:1695\n85#6,4:1710\n89#6,2:1720\n78#6,6:1732\n85#6,4:1747\n89#6,2:1757\n93#6:1764\n78#6,6:1775\n85#6,4:1790\n89#6,2:1800\n78#6,6:1813\n85#6,4:1828\n89#6,2:1838\n93#6:1844\n93#6:1848\n93#6:1852\n93#6:1858\n78#6,6:1868\n85#6,4:1883\n89#6,2:1893\n78#6,6:1900\n85#6,4:1915\n89#6,2:1925\n78#6,6:1936\n85#6,4:1951\n89#6,2:1961\n78#6,6:1974\n85#6,4:1989\n89#6,2:1999\n93#6:2005\n93#6:2009\n93#6:2015\n93#6:2028\n368#7,9:902\n377#7:923\n368#7,9:950\n377#7:971\n378#7,2:979\n378#7,2:983\n368#7,9:997\n377#7:1018\n368#7,9:1034\n377#7:1055\n368#7,9:1071\n377#7:1092\n378#7,2:1095\n368#7,9:1114\n377#7:1135\n378#7,2:1137\n378#7,2:1141\n378#7,2:1145\n368#7,9:1174\n377#7:1195\n378#7,2:1197\n368#7,9:1217\n377#7:1238\n378#7,2:1247\n368#7,9:1275\n377#7:1296\n368#7,9:1311\n377#7:1332\n378#7,2:1335\n378#7,2:1342\n368#7,9:1358\n377#7:1379\n378#7,2:1386\n368#7,9:1404\n377#7:1425\n368#7,9:1436\n377#7:1457\n368#7,9:1473\n377#7:1494\n378#7,2:1505\n378#7,2:1509\n368#7,9:1534\n377#7:1555\n378#7,2:1560\n378#7,2:1564\n368#7,9:1582\n377#7:1603\n378#7,2:1607\n368#7,9:1625\n377#7:1646\n378#7,2:1650\n368#7,9:1665\n377#7:1686\n368#7,9:1701\n377#7:1722\n368#7,9:1738\n377#7:1759\n378#7,2:1762\n368#7,9:1781\n377#7:1802\n368#7,9:1819\n377#7:1840\n378#7,2:1842\n378#7,2:1846\n378#7,2:1850\n378#7,2:1856\n368#7,9:1874\n377#7:1895\n368#7,9:1906\n377#7:1927\n368#7,9:1942\n377#7:1963\n368#7,9:1980\n377#7:2001\n378#7,2:2003\n378#7,2:2007\n378#7,2:2013\n378#7,2:2026\n4032#8,6:915\n4032#8,6:963\n4032#8,6:1010\n4032#8,6:1047\n4032#8,6:1084\n4032#8,6:1127\n4032#8,6:1187\n4032#8,6:1230\n4032#8,6:1288\n4032#8,6:1324\n4032#8,6:1371\n4032#8,6:1417\n4032#8,6:1449\n4032#8,6:1486\n4032#8,6:1547\n4032#8,6:1595\n4032#8,6:1638\n4032#8,6:1678\n4032#8,6:1714\n4032#8,6:1751\n4032#8,6:1794\n4032#8,6:1832\n4032#8,6:1887\n4032#8,6:1919\n4032#8,6:1955\n4032#8,6:1993\n148#9:937\n148#9:987\n148#9:1057\n148#9:1058\n148#9:1094\n148#9:1099\n148#9:1149\n148#9:1150\n148#9:1157\n148#9:1158\n148#9:1159\n148#9:1160\n148#9:1161\n148#9:1201\n148#9:1202\n148#9:1203\n148#9:1240\n148#9:1264\n148#9:1265\n148#9:1298\n148#9:1334\n148#9:1339\n148#9:1340\n148#9:1341\n148#9:1347\n148#9:1348\n148#9:1381\n148#9:1382\n148#9:1383\n148#9:1384\n148#9:1385\n148#9:1390\n148#9:1391\n148#9:1496\n148#9:1497\n148#9:1504\n148#9:1519\n148#9:1520\n148#9:1557\n148#9:1558\n148#9:1568\n148#9:1605\n148#9:1606\n148#9:1611\n148#9:1648\n148#9:1649\n148#9:1654\n148#9:1655\n148#9:1724\n148#9:1725\n148#9:1761\n148#9:1766\n148#9:1804\n148#9:1854\n148#9:1855\n148#9:1860\n148#9:1965\n148#9:2011\n148#9:2012\n148#9:2017\n148#9:2024\n148#9:2025\n98#10,3:988\n101#10:1019\n98#10:1020\n94#10,7:1021\n101#10:1056\n105#10:1144\n105#10:1148\n98#10:1162\n96#10,5:1163\n101#10:1196\n105#10:1200\n98#10,3:1427\n101#10:1458\n98#10:1459\n94#10,7:1460\n101#10:1495\n105#10:1508\n105#10:1512\n98#10:1521\n95#10,6:1522\n101#10:1556\n105#10:1563\n98#10,3:1656\n101#10:1687\n98#10:1688\n95#10,6:1689\n101#10:1723\n98#10:1805\n94#10,7:1806\n101#10:1841\n105#10:1845\n105#10:1853\n105#10:1859\n98#10,3:1897\n101#10:1928\n98#10:1929\n95#10,6:1930\n101#10:1964\n105#10:2010\n105#10:2016\n85#11:1100\n81#11,7:1101\n88#11:1136\n92#11:1140\n85#11:1204\n82#11,6:1205\n88#11:1239\n92#11:1250\n85#11,3:1266\n88#11:1297\n92#11:1345\n85#11,3:1349\n88#11:1380\n92#11:1389\n85#11:1392\n83#11,5:1393\n88#11:1426\n92#11:1567\n85#11:1569\n82#11,6:1570\n88#11:1604\n92#11:1610\n85#11:1612\n82#11,6:1613\n88#11:1647\n92#11:1653\n85#11:1767\n81#11,7:1768\n88#11:1803\n92#11:1849\n85#11:1861\n82#11,6:1862\n88#11:1896\n85#11:1966\n81#11,7:1967\n88#11:2002\n92#11:2006\n92#11:2029\n81#12:1251\n81#12:1252\n81#12:1253\n81#12:1254\n81#12:1255\n81#12:1256\n81#12:1257\n81#12:1258\n81#12:1259\n81#12:1260\n81#12:1261\n107#12,2:1262\n81#12:1346\n1#13:1559\n*S KotlinDebug\n*F\n+ 1 MainActivity.kt\ncom/example/MainActivityKt\n*L\n84#1:853\n87#1:854,11\n105#1:865,6\n117#1:871,6\n132#1:877,6\n137#1:883,6\n156#1:925,6\n160#1:931,6\n178#1:973,6\n318#1:1151,6\n832#1:1241,6\n423#1:1498,6\n444#1:1513,6\n818#1:2018,6\n145#1:889\n145#1:890,6\n145#1:924\n163#1:938\n163#1:939,5\n163#1:972\n163#1:982\n145#1:986\n197#1:1059\n197#1:1060,5\n197#1:1093\n197#1:1098\n247#1:1299\n247#1:1300,5\n247#1:1333\n247#1:1338\n560#1:1726\n560#1:1727,5\n560#1:1760\n560#1:1765\n145#1:896,6\n145#1:911,4\n145#1:921,2\n163#1:944,6\n163#1:959,4\n163#1:969,2\n163#1:981\n145#1:985\n189#1:991,6\n189#1:1006,4\n189#1:1016,2\n196#1:1028,6\n196#1:1043,4\n196#1:1053,2\n197#1:1065,6\n197#1:1080,4\n197#1:1090,2\n197#1:1097\n212#1:1108,6\n212#1:1123,4\n212#1:1133,2\n212#1:1139\n196#1:1143\n189#1:1147\n481#1:1168,6\n481#1:1183,4\n481#1:1193,2\n481#1:1199\n744#1:1211,6\n744#1:1226,4\n744#1:1236,2\n744#1:1249\n240#1:1269,6\n240#1:1284,4\n240#1:1294,2\n247#1:1305,6\n247#1:1320,4\n247#1:1330,2\n247#1:1337\n240#1:1344\n334#1:1352,6\n334#1:1367,4\n334#1:1377,2\n334#1:1388\n412#1:1398,6\n412#1:1413,4\n412#1:1423,2\n416#1:1430,6\n416#1:1445,4\n416#1:1455,2\n421#1:1467,6\n421#1:1482,4\n421#1:1492,2\n421#1:1507\n416#1:1511\n453#1:1528,6\n453#1:1543,4\n453#1:1553,2\n453#1:1562\n412#1:1566\n492#1:1576,6\n492#1:1591,4\n492#1:1601,2\n492#1:1609\n518#1:1619,6\n518#1:1634,4\n518#1:1644,2\n518#1:1652\n548#1:1659,6\n548#1:1674,4\n548#1:1684,2\n555#1:1695,6\n555#1:1710,4\n555#1:1720,2\n560#1:1732,6\n560#1:1747,4\n560#1:1757,2\n560#1:1764\n593#1:1775,6\n593#1:1790,4\n593#1:1800,2\n602#1:1813,6\n602#1:1828,4\n602#1:1838,2\n602#1:1844\n593#1:1848\n555#1:1852\n548#1:1858\n751#1:1868,6\n751#1:1883,4\n751#1:1893,2\n752#1:1900,6\n752#1:1915,4\n752#1:1925,2\n757#1:1936,6\n757#1:1951,4\n757#1:1961,2\n769#1:1974,6\n769#1:1989,4\n769#1:1999,2\n769#1:2005\n757#1:2009\n752#1:2015\n751#1:2028\n145#1:902,9\n145#1:923\n163#1:950,9\n163#1:971\n163#1:979,2\n145#1:983,2\n189#1:997,9\n189#1:1018\n196#1:1034,9\n196#1:1055\n197#1:1071,9\n197#1:1092\n197#1:1095,2\n212#1:1114,9\n212#1:1135\n212#1:1137,2\n196#1:1141,2\n189#1:1145,2\n481#1:1174,9\n481#1:1195\n481#1:1197,2\n744#1:1217,9\n744#1:1238\n744#1:1247,2\n240#1:1275,9\n240#1:1296\n247#1:1311,9\n247#1:1332\n247#1:1335,2\n240#1:1342,2\n334#1:1358,9\n334#1:1379\n334#1:1386,2\n412#1:1404,9\n412#1:1425\n416#1:1436,9\n416#1:1457\n421#1:1473,9\n421#1:1494\n421#1:1505,2\n416#1:1509,2\n453#1:1534,9\n453#1:1555\n453#1:1560,2\n412#1:1564,2\n492#1:1582,9\n492#1:1603\n492#1:1607,2\n518#1:1625,9\n518#1:1646\n518#1:1650,2\n548#1:1665,9\n548#1:1686\n555#1:1701,9\n555#1:1722\n560#1:1738,9\n560#1:1759\n560#1:1762,2\n593#1:1781,9\n593#1:1802\n602#1:1819,9\n602#1:1840\n602#1:1842,2\n593#1:1846,2\n555#1:1850,2\n548#1:1856,2\n751#1:1874,9\n751#1:1895\n752#1:1906,9\n752#1:1927\n757#1:1942,9\n757#1:1963\n769#1:1980,9\n769#1:2001\n769#1:2003,2\n757#1:2007,2\n752#1:2013,2\n751#1:2026,2\n145#1:915,6\n163#1:963,6\n189#1:1010,6\n196#1:1047,6\n197#1:1084,6\n212#1:1127,6\n481#1:1187,6\n744#1:1230,6\n240#1:1288,6\n247#1:1324,6\n334#1:1371,6\n412#1:1417,6\n416#1:1449,6\n421#1:1486,6\n453#1:1547,6\n492#1:1595,6\n518#1:1638,6\n548#1:1678,6\n555#1:1714,6\n560#1:1751,6\n593#1:1794,6\n602#1:1832,6\n751#1:1887,6\n752#1:1919,6\n757#1:1955,6\n769#1:1993,6\n174#1:937\n192#1:987\n199#1:1057\n200#1:1058\n208#1:1094\n211#1:1099\n236#1:1149\n237#1:1150\n324#1:1157\n325#1:1158\n409#1:1159\n484#1:1160\n485#1:1161\n545#1:1201\n672#1:1202\n674#1:1203\n748#1:1240\n243#1:1264\n245#1:1265\n249#1:1298\n258#1:1334\n278#1:1339\n282#1:1340\n285#1:1341\n337#1:1347\n339#1:1348\n357#1:1381\n362#1:1382\n366#1:1383\n380#1:1384\n384#1:1385\n413#1:1390\n414#1:1391\n424#1:1496\n425#1:1497\n428#1:1504\n447#1:1519\n448#1:1520\n461#1:1557\n463#1:1558\n493#1:1568\n500#1:1605\n502#1:1606\n519#1:1611\n526#1:1648\n528#1:1649\n660#1:1654\n551#1:1655\n562#1:1724\n563#1:1725\n586#1:1761\n590#1:1766\n603#1:1804\n636#1:1854\n643#1:1855\n751#1:1860\n768#1:1965\n800#1:2011\n801#1:2012\n816#1:2017\n821#1:2024\n822#1:2025\n189#1:988,3\n189#1:1019\n196#1:1020\n196#1:1021,7\n196#1:1056\n196#1:1144\n189#1:1148\n481#1:1162\n481#1:1163,5\n481#1:1196\n481#1:1200\n416#1:1427,3\n416#1:1458\n421#1:1459\n421#1:1460,7\n421#1:1495\n421#1:1508\n416#1:1512\n453#1:1521\n453#1:1522,6\n453#1:1556\n453#1:1563\n548#1:1656,3\n548#1:1687\n555#1:1688\n555#1:1689,6\n555#1:1723\n602#1:1805\n602#1:1806,7\n602#1:1841\n602#1:1845\n555#1:1853\n548#1:1859\n752#1:1897,3\n752#1:1928\n757#1:1929\n757#1:1930,6\n757#1:1964\n757#1:2010\n752#1:2016\n212#1:1100\n212#1:1101,7\n212#1:1136\n212#1:1140\n744#1:1204\n744#1:1205,6\n744#1:1239\n744#1:1250\n240#1:1266,3\n240#1:1297\n240#1:1345\n334#1:1349,3\n334#1:1380\n334#1:1389\n412#1:1392\n412#1:1393,5\n412#1:1426\n412#1:1567\n492#1:1569\n492#1:1570,6\n492#1:1604\n492#1:1610\n518#1:1612\n518#1:1613,6\n518#1:1647\n518#1:1653\n593#1:1767\n593#1:1768,7\n593#1:1803\n593#1:1849\n751#1:1861\n751#1:1862,6\n751#1:1896\n769#1:1966\n769#1:1967,7\n769#1:2002\n769#1:2006\n751#1:2029\n92#1:1251\n93#1:1252\n94#1:1253\n95#1:1254\n96#1:1255\n97#1:1256\n98#1:1257\n100#1:1258\n101#1:1259\n102#1:1260\n105#1:1261\n105#1:1262,2\n307#1:1346\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\\\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\n\n\u0002\u0010 \n\u0002\b\u0002\u001a\u001f\u0010\u0000\u001a\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0007¢\u0006\u0002\u0010\u0006\u001a\r\u0010\u0007\u001a\u00020\u0001H\u0007¢\u0006\u0002\u0010\b\u001a\u001b\u0010\t\u001a\u00020\u00012\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00010\u000bH\u0007¢\u0006\u0002\u0010\f\u001a1\u0010\r\u001a\u00020\u00012\u0006\u0010\u000e\u001a\u00020\u000f2\f\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00010\u000b2\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00010\u000bH\u0007¢\u0006\u0002\u0010\u0012\u001a-\u0010\u0013\u001a\u00020\u00012\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u00172\u0006\u0010\u0019\u001a\u00020\u001aH\u0007¢\u0006\u0002\u0010\u001b\u001a\u001d\u0010\u001c\u001a\u00020\u00012\u0006\u0010\u001d\u001a\u00020\u00172\u0006\u0010\u001e\u001a\u00020\u0017H\u0007¢\u0006\u0002\u0010\u001f\u001a\u0015\u0010 \u001a\u00020\u00012\u0006\u0010!\u001a\u00020\"H\u0007¢\u0006\u0002\u0010#\u001a\r\u0010$\u001a\u00020\u0001H\u0007¢\u0006\u0002\u0010\b\u001a\u000e\u0010%\u001a\u00020\u000f2\u0006\u0010&\u001a\u00020\'\u001a\u000e\u0010(\u001a\u00020\u00152\u0006\u0010)\u001a\u00020*\u001a\u000e\u0010+\u001a\u00020\u00152\u0006\u0010,\u001a\u00020*\u001a[\u0010-\u001a\u00020\u00012\b\b\u0002\u0010.\u001a\u00020\u00152\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u00172\u0006\u0010\u0019\u001a\u00020\u001a2\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00010\u000b2\f\u0010/\u001a\b\u0012\u0004\u0012\u00020\u00010\u000bH\u0007¢\u0006\u0002\u00100¨\u00061²\u0006\n\u0010\u000e\u001a\u00020\u000fX\u008a\u0084\u0002²\u0006\n\u0010\u0014\u001a\u00020\u0015X\u008a\u0084\u0002²\u0006\n\u0010\u0016\u001a\u00020\u0017X\u008a\u0084\u0002²\u0006\n\u0010\u0018\u001a\u00020\u0017X\u008a\u0084\u0002²\u0006\n\u0010\u0019\u001a\u00020\u001aX\u008a\u0084\u0002²\u0006\n\u00102\u001a\u00020\u0015X\u008a\u0084\u0002²\u0006\n\u00103\u001a\u00020\u000fX\u008a\u0084\u0002²\u0006\u0010\u00104\u001a\b\u0012\u0004\u0012\u00020\"05X\u008a\u0084\u0002²\u0006\n\u0010\u001d\u001a\u00020\u0017X\u008a\u0084\u0002²\u0006\n\u0010\u001e\u001a\u00020\u0017X\u008a\u0084\u0002²\u0006\n\u00106\u001a\u00020\u000fX\u008a\u008e\u0002²\u0006\n\u00107\u001a\u00020\u001aX\u008a\u0084\u0002"
    }
    d2 = {
        "PhotoSenderApp",
        "",
        "modifier",
        "Landroidx/compose/ui/Modifier;",
        "application",
        "Landroid/app/Application;",
        "(Landroidx/compose/ui/Modifier;Landroid/app/Application;Landroidx/compose/runtime/Composer;II)V",
        "HeaderBar",
        "(Landroidx/compose/runtime/Composer;I)V",
        "PermissionOnboardingCard",
        "onRequestPermission",
        "Lkotlin/Function0;",
        "(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "SendPhotosCard",
        "isServiceRunning",
        "",
        "onStartClick",
        "onStopClick",
        "(ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "ActiveProgressPanel",
        "currentPhotoName",
        "",
        "currentIndex",
        "",
        "totalPhotos",
        "progressPercentage",
        "",
        "(Ljava/lang/String;IIFLandroidx/compose/runtime/Composer;I)V",
        "SimpleStatsPanel",
        "successCount",
        "failedCount",
        "(IILandroidx/compose/runtime/Composer;I)V",
        "UploadLogItem",
        "log",
        "Lcom/example/data/UploadLog;",
        "(Lcom/example/data/UploadLog;Landroidx/compose/runtime/Composer;I)V",
        "EmptyLogsCard",
        "hasRequiredGalleryPermission",
        "context",
        "Landroid/content/Context;",
        "formatFileSize",
        "bytes",
        "",
        "formatTimestamp",
        "millis",
        "ChatGPTWebView",
        "url",
        "onBackClick",
        "(Ljava/lang/String;ZLjava/lang/String;IIFLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V",
        "app",
        "customServerUrl",
        "isSimulationMode",
        "allLogs",
        "",
        "hasGalleryPermission",
        "scale"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final ActiveProgressPanel(Ljava/lang/String;IIFLandroidx/compose/runtime/Composer;I)V
    .registers 29
    .param p0, "currentPhotoName"  # Ljava/lang/String;
    .param p1, "currentIndex"  # I
    .param p2, "totalPhotos"  # I
    .param p3, "progressPercentage"  # F
    .param p4, "$composer"  # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"  # I

    move-object/from16 v1, p0

    move/from16 v2, p1

    move/from16 v3, p2

    move/from16 v4, p3

    move/from16 v5, p5

    const-string v0, "currentPhotoName"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 406
    const v0, -0x1d3ed6c1

    move-object/from16 v6, p4

    invoke-interface {v6, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v12

    .end local p4  # "$composer":Landroidx/compose/runtime/Composer;
    .local v12, "$composer":Landroidx/compose/runtime/Composer;
    const-string v6, "C(ActiveProgressPanel)P(1!1,3)409@15503L11,409@15461L62,410@15530L2569,406@15338L2761:MainActivity.kt#to5c3"

    invoke-static {v12, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v6, p5

    .local v6, "$dirty":I
    and-int/lit8 v7, v5, 0x6

    if-nez v7, :cond_2d

    invoke-interface {v12, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_2b

    const/4 v7, 0x4

    goto :goto_2c

    :cond_2b
    const/4 v7, 0x2

    :goto_2c
    or-int/2addr v6, v7

    :cond_2d
    and-int/lit8 v7, v5, 0x30

    if-nez v7, :cond_3d

    invoke-interface {v12, v2}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v7

    if-eqz v7, :cond_3a

    const/16 v7, 0x20

    goto :goto_3c

    :cond_3a
    const/16 v7, 0x10

    :goto_3c
    or-int/2addr v6, v7

    :cond_3d
    and-int/lit16 v7, v5, 0x180

    if-nez v7, :cond_4d

    invoke-interface {v12, v3}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v7

    if-eqz v7, :cond_4a

    const/16 v7, 0x100

    goto :goto_4c

    :cond_4a
    const/16 v7, 0x80

    :goto_4c
    or-int/2addr v6, v7

    :cond_4d
    and-int/lit16 v7, v5, 0xc00

    if-nez v7, :cond_5d

    invoke-interface {v12, v4}, Landroidx/compose/runtime/Composer;->changed(F)Z

    move-result v7

    if-eqz v7, :cond_5a

    const/16 v7, 0x800

    goto :goto_5c

    :cond_5a
    const/16 v7, 0x400

    :goto_5c
    or-int/2addr v6, v7

    :cond_5d
    and-int/lit16 v7, v6, 0x493

    const/16 v8, 0x492

    if-ne v7, v8, :cond_72

    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v7

    if-nez v7, :cond_6a

    goto :goto_72

    .line 400
    :cond_6a
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v19, v6

    move-object v15, v12

    goto/16 :goto_f1

    .line 406
    :cond_72
    :goto_72
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v7

    if-eqz v7, :cond_7e

    const/4 v7, -0x1

    const-string v8, "com.example.ActiveProgressPanel (MainActivity.kt:405)"

    invoke-static {v0, v6, v7, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 408
    :cond_7e
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-static {v0, v7, v9, v8}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .line 409
    const/16 v7, 0x10

    .local v7, "$this$dp\\1":I
    const/4 v8, 0x0

    .line 1159
    .local v8, "$i$f$getDp\\1\\409":I
    int-to-float v10, v7

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 409
    .end local v7  # "$this$dp\\1":I
    .end local v8  # "$i$f$getDp\\1\\409":I
    invoke-static {v7}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v7

    move-object/from16 v18, v7

    check-cast v18, Landroidx/compose/ui/graphics/Shape;

    .line 410
    move v7, v6

    .end local v6  # "$dirty":I
    .local v7, "$dirty":I
    sget-object v6, Landroidx/compose/material3/CardDefaults;->INSTANCE:Landroidx/compose/material3/CardDefaults;

    sget-object v8, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v10, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v8, v12, v10}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v8

    invoke-virtual {v8}, Landroidx/compose/material3/ColorScheme;->getSurface-0d7_KjU()J

    move-result-wide v10

    sget v8, Landroidx/compose/material3/CardDefaults;->$stable:I

    shl-int/lit8 v16, v8, 0xc

    const/16 v17, 0xe

    move-wide/from16 v21, v10

    move v11, v7

    move-wide/from16 v7, v21

    move v13, v9

    .end local v7  # "$dirty":I
    .local v11, "$dirty":I
    const-wide/16 v9, 0x0

    move v14, v11

    move-object v15, v12

    .end local v11  # "$dirty":I
    .end local v12  # "$composer":Landroidx/compose/runtime/Composer;
    .local v14, "$dirty":I
    .local v15, "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v11, 0x0

    move/from16 v20, v13

    move/from16 v19, v14

    .end local v14  # "$dirty":I
    .local v19, "$dirty":I
    const-wide/16 v13, 0x0

    move-object/from16 p4, v0

    move/from16 v0, v20

    invoke-virtual/range {v6 .. v17}, Landroidx/compose/material3/CardDefaults;->cardColors-ro_MJ88(JJJJLandroidx/compose/runtime/Composer;II)Landroidx/compose/material3/CardColors;

    move-result-object v8

    .line 411
    new-instance v6, Lcom/example/MainActivityKt$$ExternalSyntheticLambda4;

    invoke-direct {v6, v4, v2, v3, v1}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda4;-><init>(FIILjava/lang/String;)V

    const/16 v7, 0x36

    const v9, 0x2240db0d

    invoke-static {v9, v0, v6, v15, v7}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v11, v0

    check-cast v11, Lkotlin/jvm/functions/Function3;

    .line 407
    const/4 v9, 0x0

    const/4 v10, 0x0

    const v13, 0x30006

    const/16 v14, 0x18

    move-object/from16 v6, p4

    move-object v12, v15

    move-object/from16 v7, v18

    .end local v15  # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v12  # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v6 .. v14}, Landroidx/compose/material3/CardKt;->Card(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/CardColors;Landroidx/compose/material3/CardElevation;Landroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .end local v12  # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v15  # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_f1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 474
    :cond_f1
    :goto_f1
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v6

    if-eqz v6, :cond_ff

    new-instance v0, Lcom/example/MainActivityKt$$ExternalSyntheticLambda5;

    invoke-direct/range {v0 .. v5}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda5;-><init>(Ljava/lang/String;IIFI)V

    invoke-interface {v6, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_ff
    return-void
.end method

.method static final ActiveProgressPanel$lambda$49(FIILjava/lang/String;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 118
    .param p0, "$progressPercentage"  # F
    .param p1, "$currentIndex"  # I
    .param p2, "$totalPhotos"  # I
    .param p3, "$currentPhotoName"  # Ljava/lang/String;
    .param p4, "$this$Card"  # Landroidx/compose/foundation/layout/ColumnScope;
    .param p5, "$composer"  # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"  # I

    move/from16 v0, p0

    move/from16 v1, p6

    const-string v2, "$this$Card"

    move-object/from16 v3, p4

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "C411@15540L2553:MainActivity.kt#to5c3"

    move-object/from16 v4, p5

    invoke-static {v4, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x11

    const/16 v5, 0x10

    if-ne v2, v5, :cond_28

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v2

    if-nez v2, :cond_1f

    goto :goto_28

    .line 411
    :cond_1f
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v8, p1

    move/from16 v9, p2

    goto/16 :goto_7a6

    .line 0
    :cond_28
    :goto_28
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_37

    const/4 v2, -0x1

    const-string v5, "com.example.ActiveProgressPanel.<anonymous> (MainActivity.kt:411)"

    const v6, 0x2240db0d

    invoke-static {v6, v1, v2, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 413
    :cond_37
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v5, 0x10

    .local v5, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 1390
    .local v6, "$i$f$getDp\\1\\413":I
    int-to-float v7, v5

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 413
    .end local v5  # "$this$dp\\1":I
    .end local v6  # "$i$f$getDp\\1\\413":I
    invoke-static {v2, v5}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 414
    sget-object v5, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v6, 0xc

    .local v6, "$this$dp\\2":I
    const/4 v7, 0x0

    .line 1391
    .local v7, "$i$f$getDp\\2\\414":I
    int-to-float v8, v6

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 414
    .end local v6  # "$this$dp\\2":I
    .end local v7  # "$i$f$getDp\\2\\414":I
    invoke-virtual {v5, v6}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v5

    check-cast v5, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .line 412
    nop

    .local v5, "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v6, 0x36

    .local v6, "$changed\\3":I
    move-object/from16 v7, p5

    .local v2, "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v7, "$composer\\3":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 1392
    .local v8, "$i$f$Column\\3\\412":I
    const v9, -0x1cd0f17e

    const-string v10, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo"

    invoke-static {v7, v9, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1393
    sget-object v9, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v9

    .line 1396
    .local v9, "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v10, v6, 0x3

    and-int/lit8 v10, v10, 0xe

    shr-int/lit8 v11, v6, 0x3

    and-int/lit8 v11, v11, 0x70

    or-int/2addr v10, v11

    invoke-static {v5, v9, v7, v10}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .local v10, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v11, v6, 0x3

    and-int/lit8 v11, v11, 0x70

    .line 1397
    nop

    .local v11, "$changed\\4":I
    const/4 v12, 0x0

    .line 1398
    .local v12, "$i$f$Layout\\4\\1397":I
    const v13, -0x4ee9b9da

    const-string v14, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh"

    invoke-static {v7, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1399
    const/4 v15, 0x0

    invoke-static {v7, v15}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v16

    .line 1400
    .local v16, "compositeKeyHash\\4":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v15

    .line 1401
    .local v15, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v7, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v13

    .line 1403
    .local v13, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v18

    shl-int/lit8 v1, v11, 0x6

    and-int/lit16 v1, v1, 0x380

    move/from16 v19, v1

    const/4 v1, 0x6

    or-int/lit8 v19, v19, 0x6

    .line 1402
    move-object/from16 v20, v18

    .local v19, "$changed\\5":I
    .local v20, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/16 v18, 0x0

    .line 1404
    .local v18, "$i$f$ReusableComposeNode\\5\\1402":I
    move/from16 v21, v1

    const v1, -0x2942ffcf

    move-object/from16 v22, v2

    .end local v2  # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v22, "modifier\\3":Landroidx/compose/ui/Modifier;
    const-string v2, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v7, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1405
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_bd

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1406
    :cond_bd
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1407
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_cc

    .line 1408
    move-object/from16 v1, v20

    .end local v20  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_d1

    .line 1410
    .end local v1  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v20  # "factory\\5":Lkotlin/jvm/functions/Function0;
    :cond_cc
    move-object/from16 v1, v20

    .end local v20  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v1  # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1412
    :goto_d1
    move-object/from16 v20, v1

    .end local v1  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v20  # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 1413
    .local v24, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\1412\\4":I
    sget-object v25, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v25 .. v25}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v1, v10, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1414
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v1, v15, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1416
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v25, 0x0

    .line 1417
    .local v25, "$i$f$set-impl\\7\\1416":I
    move-object/from16 v26, v1

    .local v26, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 1418
    .local v27, "$i$a$-with-Updater$set$1\\8\\1417\\7":I
    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v28

    if-nez v28, :cond_111

    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v28, v5

    .end local v5  # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v28, "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_10e

    goto :goto_113

    :cond_10e
    move-object/from16 v5, v26

    goto :goto_123

    .end local v28  # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v5  # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    :cond_111
    move-object/from16 v28, v5

    .line 1419
    .end local v5  # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v28  # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    :goto_113
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v5, v26

    .end local v26  # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1420
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v1, v4, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1422
    :goto_123
    nop

    .line 1417
    .end local v5  # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v27  # "$i$a$-with-Updater$set$1\\8\\1417\\7":I
    nop

    .line 1422
    nop

    .line 1423
    .end local v3  # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v25  # "$i$f$set-impl\\7\\1416":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v1, v13, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1424
    nop

    .line 1412
    .end local v1  # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v24  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\1412\\4":I
    nop

    .line 1425
    shr-int/lit8 v1, v19, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\9":I
    move-object v3, v7

    .local v3, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 1426
    .local v4, "$i$a$-Layout-ColumnKt$Column$1\\9\\1425\\3":I
    const v5, -0x16f088b9

    move/from16 v24, v1

    .end local v1  # "$changed\\9":I
    .local v24, "$changed\\9":I
    const-string v1, "C87@4365L9:Column.kt#2w3rfo"

    invoke-static {v3, v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v5, v6, 0x6

    and-int/lit8 v5, v5, 0x70

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\10":I
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScope;

    .local v1, "$this$ActiveProgressPanel_u24lambda_u2449_u24lambda_u2448\\10":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v38, v3

    .local v38, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 416
    .local v25, "$i$a$-Column-MainActivityKt$ActiveProgressPanel$1$1\\10\\1426\\0":I
    move-object/from16 v26, v1

    .end local v1  # "$this$ActiveProgressPanel_u24lambda_u2449_u24lambda_u2448\\10":Landroidx/compose/foundation/layout/ColumnScope;
    .local v26, "$this$ActiveProgressPanel_u24lambda_u2449_u24lambda_u2448\\10":Landroidx/compose/foundation/layout/ColumnScope;
    const v1, 0xd86cb

    move-object/from16 v27, v3

    .end local v3  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v27, "$composer\\9":Landroidx/compose/runtime/Composer;
    const-string v3, "C415@15682L1169,443@16917L22,448@17138L11,449@17202L11,442@16865L389,452@17268L815:MainActivity.kt#to5c3"

    move/from16 v41, v4

    move-object/from16 v4, v38

    .end local v38  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v41, "$i$a$-Layout-ColumnKt$Column$1\\9\\1425\\3":I
    invoke-static {v4, v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 417
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v3, 0x0

    move/from16 v42, v5

    .end local v5  # "$changed\\10":I
    .local v42, "$changed\\10":I
    const/4 v5, 0x1

    move/from16 v43, v6

    .end local v6  # "$changed\\3":I
    .local v43, "$changed\\3":I
    const/4 v6, 0x0

    invoke-static {v1, v3, v5, v6}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 418
    sget-object v29, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual/range {v29 .. v29}, Landroidx/compose/foundation/layout/Arrangement;->getSpaceBetween()Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v29

    check-cast v29, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .line 419
    sget-object v30, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual/range {v30 .. v30}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v30

    .line 416
    move-object/from16 v31, v30

    .local v1, "modifier\\11":Landroidx/compose/ui/Modifier;
    .local v31, "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v30, 0x1b6

    .local v30, "$changed\\11":I
    move-object/from16 v32, v4

    .local v32, "$composer\\11":Landroidx/compose/runtime/Composer;
    move-object/from16 v33, v29

    .local v33, "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/16 v29, 0x0

    .line 1427
    .local v29, "$i$f$Row\\11\\416":I
    const v3, 0x2952b718

    const-string v5, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo"

    move-object/from16 v6, v32

    .end local v32  # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v6, "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static {v6, v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1428
    shr-int/lit8 v32, v30, 0x3

    and-int/lit8 v32, v32, 0xe

    shr-int/lit8 v34, v30, 0x3

    and-int/lit8 v34, v34, 0x70

    or-int v3, v32, v34

    move-object/from16 v48, v7

    move/from16 v49, v8

    move-object/from16 v7, v31

    move-object/from16 v8, v33

    .end local v31  # "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    .end local v33  # "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v7, "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    .local v8, "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v48, "$composer\\3":Landroidx/compose/runtime/Composer;
    .local v49, "$i$f$Column\\3\\412":I
    invoke-static {v8, v7, v6, v3}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v3

    .local v3, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v31, v30, 0x3

    and-int/lit8 v31, v31, 0x70

    .line 1429
    nop

    .local v31, "$changed\\12":I
    const/16 v32, 0x0

    .line 1430
    .local v32, "$i$f$Layout\\12\\1429":I
    move-object/from16 v33, v7

    const v7, -0x4ee9b9da

    .end local v7  # "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    .local v33, "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v6, v7, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1431
    const/4 v7, 0x0

    invoke-static {v6, v7}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v34

    .line 1432
    .local v34, "compositeKeyHash\\12":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v7

    .line 1433
    .local v7, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v35, v8

    .end local v8  # "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v35, "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v6, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 1435
    .local v8, "materialized\\12":Landroidx/compose/ui/Modifier;
    sget-object v36, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v36 .. v36}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v36

    move-object/from16 v37, v1

    .end local v1  # "modifier\\11":Landroidx/compose/ui/Modifier;
    .local v37, "modifier\\11":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v1, v31, 0x6

    and-int/lit16 v1, v1, 0x380

    or-int/lit8 v1, v1, 0x6

    .line 1434
    move-object/from16 v38, v36

    .local v1, "$changed\\13":I
    .local v38, "factory\\13":Lkotlin/jvm/functions/Function0;
    const/16 v36, 0x0

    .line 1436
    .local v36, "$i$f$ReusableComposeNode\\13\\1434":I
    move/from16 v39, v1

    const v1, -0x2942ffcf

    .end local v1  # "$changed\\13":I
    .local v39, "$changed\\13":I
    invoke-static {v6, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1437
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_1e9

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1438
    :cond_1e9
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1439
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_1f8

    .line 1440
    move-object/from16 v1, v38

    .end local v38  # "factory\\13":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1fd

    .line 1442
    .end local v1  # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v38  # "factory\\13":Lkotlin/jvm/functions/Function0;
    :cond_1f8
    move-object/from16 v1, v38

    .end local v38  # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v1  # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1444
    :goto_1fd
    move-object/from16 v38, v1

    .end local v1  # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v38  # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    const/16 v40, 0x0

    .line 1445
    .local v40, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\1444\\12":I
    sget-object v50, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v51, v6

    .end local v6  # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v51, "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v50 .. v50}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v1, v3, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1446
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v1, v7, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1448
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    .local v6, "block\\15":Lkotlin/jvm/functions/Function2;
    const/16 v50, 0x0

    .line 1449
    .local v50, "$i$f$set-impl\\15\\1448":I
    move-object/from16 v52, v1

    .local v52, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/16 v53, 0x0

    .line 1450
    .local v53, "$i$a$-with-Updater$set$1\\16\\1449\\15":I
    invoke-interface/range {v52 .. v52}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v54

    if-nez v54, :cond_241

    move-object/from16 v54, v3

    .end local v3  # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v54, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface/range {v52 .. v52}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v55, v7

    .end local v7  # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .local v55, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v34 .. v34}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-static {v3, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_23e

    goto :goto_245

    :cond_23e
    move-object/from16 v7, v52

    goto :goto_255

    .end local v54  # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v55  # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v3  # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v7  # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_241
    move-object/from16 v54, v3

    move-object/from16 v55, v7

    .line 1451
    .end local v3  # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v7  # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v54  # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v55  # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_245
    invoke-static/range {v34 .. v34}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v7, v52

    .end local v52  # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .local v7, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    invoke-interface {v7, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1452
    invoke-static/range {v34 .. v34}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v1, v3, v6}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1454
    :goto_255
    nop

    .line 1449
    .end local v7  # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v53  # "$i$a$-with-Updater$set$1\\16\\1449\\15":I
    nop

    .line 1454
    nop

    .line 1455
    .end local v6  # "block\\15":Lkotlin/jvm/functions/Function2;
    .end local v50  # "$i$f$set-impl\\15\\1448":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v1, v8, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1456
    nop

    .line 1444
    .end local v1  # "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .end local v40  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\1444\\12":I
    nop

    .line 1457
    shr-int/lit8 v1, v39, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\17":I
    move-object/from16 v3, v51

    .local v3, "$composer\\17":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 1458
    .local v6, "$i$a$-Layout-RowKt$Row$1\\17\\1457\\11":I
    const v7, -0x18505826

    move/from16 v40, v1

    .end local v1  # "$changed\\17":I
    .local v40, "$changed\\17":I
    const-string v1, "C100@5047L9:Row.kt#2w3rfo"

    invoke-static {v3, v7, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v50, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v52, v30, 0x6

    and-int/lit8 v52, v52, 0x70

    or-int/lit8 v52, v52, 0x6

    .local v52, "$changed\\18":I
    check-cast v50, Landroidx/compose/foundation/layout/RowScope;

    .local v50, "$this$ActiveProgressPanel_u24lambda_u2449_u24lambda_u2448_u24lambda_u2443\\18":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v77, v3

    .local v77, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/16 v53, 0x0

    .line 421
    .local v53, "$i$a$-Row-MainActivityKt$ActiveProgressPanel$1$1$1\\18\\1458\\10":I
    const v7, -0x1c9b9d99

    move-object/from16 v81, v3

    .end local v3  # "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v81, "$composer\\17":Landroidx/compose/runtime/Composer;
    const-string v3, "C420@15900L661,436@16685L10,438@16800L11,434@16578L259:MainActivity.kt#to5c3"

    move/from16 v82, v6

    move-object/from16 v6, v77

    .end local v77  # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v6, "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v82, "$i$a$-Layout-RowKt$Row$1\\17\\1457\\11":I
    invoke-static {v6, v7, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v3

    .local v3, "verticalAlignment\\19":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v7, 0x180

    .local v7, "$changed\\19":I
    move-object/from16 v56, v6

    .local v56, "$composer\\19":Landroidx/compose/runtime/Composer;
    const/16 v57, 0x0

    .line 1459
    .local v57, "$i$f$Row\\19\\421":I
    move/from16 v58, v7

    move-object/from16 v83, v8

    move-object/from16 v7, v56

    const v8, 0x2952b718

    .end local v8  # "materialized\\12":Landroidx/compose/ui/Modifier;
    .end local v56  # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v7, "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v58, "$changed\\19":I
    .local v83, "materialized\\12":Landroidx/compose/ui/Modifier;
    invoke-static {v7, v8, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1460
    sget-object v8, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v8, Landroidx/compose/ui/Modifier;

    .line 1461
    .local v8, "modifier\\19":Landroidx/compose/ui/Modifier;
    sget-object v56, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    move-object/from16 v84, v9

    .end local v9  # "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    .local v84, "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-virtual/range {v56 .. v56}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v9

    .line 1465
    .local v9, "horizontalArrangement\\19":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v56, v58, 0x3

    and-int/lit8 v56, v56, 0xe

    shr-int/lit8 v59, v58, 0x3

    and-int/lit8 v59, v59, 0x70

    move-object/from16 v85, v10

    .end local v10  # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v85, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    or-int v10, v56, v59

    invoke-static {v9, v3, v7, v10}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .local v10, "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v56, v58, 0x3

    and-int/lit8 v56, v56, 0x70

    .line 1466
    nop

    .local v56, "$changed\\20":I
    const/16 v59, 0x0

    .line 1467
    .local v59, "$i$f$Layout\\20\\1466":I
    move-object/from16 v60, v3

    const v3, -0x4ee9b9da

    .end local v3  # "verticalAlignment\\19":Landroidx/compose/ui/Alignment$Vertical;
    .local v60, "verticalAlignment\\19":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v7, v3, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1468
    const/4 v3, 0x0

    invoke-static {v7, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v61

    .line 1469
    .local v61, "compositeKeyHash\\20":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v3

    .line 1470
    .local v3, "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v62, v9

    .end local v9  # "horizontalArrangement\\19":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v62, "horizontalArrangement\\19":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v7, v8}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    .line 1472
    .local v9, "materialized\\20":Landroidx/compose/ui/Modifier;
    sget-object v63, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v63 .. v63}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v63

    move-object/from16 v64, v8

    .end local v8  # "modifier\\19":Landroidx/compose/ui/Modifier;
    .local v64, "modifier\\19":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v8, v56, 0x6

    and-int/lit16 v8, v8, 0x380

    or-int/lit8 v8, v8, 0x6

    .line 1471
    move-object/from16 v65, v63

    .local v8, "$changed\\21":I
    .local v65, "factory\\21":Lkotlin/jvm/functions/Function0;
    const/16 v63, 0x0

    .line 1473
    .local v63, "$i$f$ReusableComposeNode\\21\\1471":I
    move/from16 v66, v8

    const v8, -0x2942ffcf

    .end local v8  # "$changed\\21":I
    .local v66, "$changed\\21":I
    invoke-static {v7, v8, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1474
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v8

    instance-of v8, v8, Landroidx/compose/runtime/Applier;

    if-nez v8, :cond_307

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1475
    :cond_307
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1476
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v8

    if-eqz v8, :cond_316

    .line 1477
    move-object/from16 v8, v65

    .end local v65  # "factory\\21":Lkotlin/jvm/functions/Function0;
    .local v8, "factory\\21":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v8}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_31b

    .line 1479
    .end local v8  # "factory\\21":Lkotlin/jvm/functions/Function0;
    .restart local v65  # "factory\\21":Lkotlin/jvm/functions/Function0;
    :cond_316
    move-object/from16 v8, v65

    .end local v65  # "factory\\21":Lkotlin/jvm/functions/Function0;
    .restart local v8  # "factory\\21":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1481
    :goto_31b
    move-object/from16 v65, v7

    .end local v7  # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v65, "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-static/range {v65 .. v65}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .local v7, "$this$Layout_u24lambda_u240\\22":Landroidx/compose/runtime/Composer;
    const/16 v67, 0x0

    .line 1482
    .local v67, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\22\\1481\\20":I
    sget-object v68, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v69, v8

    .end local v8  # "factory\\21":Lkotlin/jvm/functions/Function0;
    .local v69, "factory\\21":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v68 .. v68}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v7, v10, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1483
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v7, v3, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1485
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    .local v8, "block\\23":Lkotlin/jvm/functions/Function2;
    const/16 v68, 0x0

    .line 1486
    .local v68, "$i$f$set-impl\\23\\1485":I
    move-object/from16 v70, v7

    .local v70, "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    const/16 v71, 0x0

    .line 1487
    .local v71, "$i$a$-with-Updater$set$1\\24\\1486\\23":I
    invoke-interface/range {v70 .. v70}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v72

    if-nez v72, :cond_35f

    move-object/from16 v72, v3

    .end local v3  # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .local v72, "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v70 .. v70}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v73, v10

    .end local v10  # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v73, "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v61 .. v61}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v3, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_35c

    goto :goto_363

    :cond_35c
    move-object/from16 v10, v70

    goto :goto_373

    .end local v72  # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v73  # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v3  # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v10  # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_35f
    move-object/from16 v72, v3

    move-object/from16 v73, v10

    .line 1488
    .end local v3  # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v10  # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v72  # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v73  # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_363
    invoke-static/range {v61 .. v61}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v10, v70

    .end local v70  # "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    .local v10, "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    invoke-interface {v10, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1489
    invoke-static/range {v61 .. v61}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v7, v3, v8}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1491
    :goto_373
    nop

    .line 1486
    .end local v10  # "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    .end local v71  # "$i$a$-with-Updater$set$1\\24\\1486\\23":I
    nop

    .line 1491
    nop

    .line 1492
    .end local v8  # "block\\23":Lkotlin/jvm/functions/Function2;
    .end local v68  # "$i$f$set-impl\\23\\1485":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v7, v9, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1493
    nop

    .line 1481
    .end local v7  # "$this$Layout_u24lambda_u240\\22":Landroidx/compose/runtime/Composer;
    .end local v67  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\22\\1481\\20":I
    nop

    .line 1494
    shr-int/lit8 v3, v66, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\25":I
    move-object/from16 v7, v65

    .local v7, "$composer\\25":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 1495
    .local v8, "$i$a$-Layout-RowKt$Row$1\\25\\1494\\19":I
    const v10, -0x18505826

    invoke-static {v7, v10, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v10, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v67, v58, 0x6

    and-int/lit8 v67, v67, 0x70

    or-int/lit8 v67, v67, 0x6

    .local v67, "$changed\\26":I
    check-cast v10, Landroidx/compose/foundation/layout/RowScope;

    .local v10, "$this$ActiveProgressPanel_u24lambda_u2449_u24lambda_u2448_u24lambda_u2443_u24lambda_u2442\\26":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v95, v7

    .local v95, "$composer\\26":Landroidx/compose/runtime/Composer;
    const/16 v68, 0x0

    .line 422
    .local v68, "$i$a$-Row-MainActivityKt$ActiveProgressPanel$1$1$1$1\\26\\1495\\18":I
    move/from16 v70, v3

    .end local v3  # "$changed\\25":I
    .local v70, "$changed\\25":I
    const v3, 0xedff3bb

    move-object/from16 v71, v7

    .end local v7  # "$composer\\25":Landroidx/compose/runtime/Composer;
    .local v71, "$composer\\25":Landroidx/compose/runtime/Composer;
    const-string v7, "C425@16207L11,422@16036L22,421@15974L274,427@16269L39,430@16446L10,428@16329L214:MainActivity.kt#to5c3"

    move/from16 v74, v8

    move-object/from16 v8, v95

    .end local v95  # "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v8, "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v74, "$i$a$-Layout-RowKt$Row$1\\25\\1494\\19":I
    invoke-static {v8, v3, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 424
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/16 v7, 0x18

    .local v7, "$this$dp\\27":I
    const/16 v75, 0x0

    .line 1496
    .local v75, "$i$f$getDp\\27\\424":I
    move-object/from16 v76, v9

    .end local v9  # "materialized\\20":Landroidx/compose/ui/Modifier;
    .local v76, "materialized\\20":Landroidx/compose/ui/Modifier;
    int-to-float v9, v7

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 424
    .end local v7  # "$this$dp\\27":I
    .end local v75  # "$i$f$getDp\\27\\424":I
    invoke-static {v3, v7}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v87

    .line 425
    const/4 v3, 0x3

    .local v3, "$this$dp\\28":I
    const/4 v7, 0x0

    .line 1497
    .local v7, "$i$f$getDp\\28\\425":I
    int-to-float v9, v3

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v90

    .line 425
    .end local v3  # "$this$dp\\28":I
    .end local v7  # "$i$f$getDp\\28\\425":I
    nop

    .line 426
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v7, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v8, v7}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v88

    .line 423
    const v3, -0x1009451b

    const-string v7, "CC(remember):MainActivity.kt#9igjgp"

    invoke-static {v8, v3, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/Composer;->changed(F)Z

    move-result v3

    .local v3, "invalid\\29":Z
    move-object v9, v8

    .local v9, "$this$cache\\29":Landroidx/compose/runtime/Composer;
    const/16 v75, 0x0

    .line 1498
    .local v75, "$i$f$cache\\29\\423":I
    move/from16 v77, v3

    .end local v3  # "invalid\\29":Z
    .local v77, "invalid\\29":Z
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .local v3, "it\\29":Ljava/lang/Object;
    const/16 v78, 0x0

    .line 1499
    .local v78, "$i$a$-let-ComposerKt$cache$1\\30\\1498\\29":I
    if-nez v77, :cond_3fa

    sget-object v79, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v95, v8

    .end local v8  # "$composer\\26":Landroidx/compose/runtime/Composer;
    .restart local v95  # "$composer\\26":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v79 .. v79}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v3, v8, :cond_3f7

    goto :goto_3fc

    .line 1503
    :cond_3f7
    move-object/from16 v79, v3

    goto :goto_409

    .line 1499
    .end local v95  # "$composer\\26":Landroidx/compose/runtime/Composer;
    .restart local v8  # "$composer\\26":Landroidx/compose/runtime/Composer;
    :cond_3fa
    move-object/from16 v95, v8

    .line 1500
    .end local v8  # "$composer\\26":Landroidx/compose/runtime/Composer;
    .restart local v95  # "$composer\\26":Landroidx/compose/runtime/Composer;
    :goto_3fc
    const/4 v8, 0x0

    .line 423
    .local v8, "$i$a$-cache-MainActivityKt$ActiveProgressPanel$1$1$1$1$1\\31\\1500\\26":I
    move-object/from16 v79, v3

    .end local v3  # "it\\29":Ljava/lang/Object;
    .local v79, "it\\29":Ljava/lang/Object;
    new-instance v3, Lcom/example/MainActivityKt$$ExternalSyntheticLambda13;

    invoke-direct {v3, v0}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda13;-><init>(F)V

    .line 1500
    .end local v8  # "$i$a$-cache-MainActivityKt$ActiveProgressPanel$1$1$1$1$1\\31\\1500\\26":I
    nop

    .line 1501
    .local v3, "value\\30":Ljava/lang/Object;
    invoke-interface {v9, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1502
    nop

    .line 1499
    .end local v3  # "value\\30":Ljava/lang/Object;
    :goto_409
    nop

    .line 1498
    .end local v78  # "$i$a$-let-ComposerKt$cache$1\\30\\1498\\29":I
    .end local v79  # "it\\29":Ljava/lang/Object;
    nop

    .line 423
    .end local v9  # "$this$cache\\29":Landroidx/compose/runtime/Composer;
    .end local v75  # "$i$f$cache\\29\\423":I
    .end local v77  # "invalid\\29":Z
    move-object/from16 v86, v3

    check-cast v86, Lkotlin/jvm/functions/Function0;

    invoke-static/range {v95 .. v95}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 424
    nop

    .line 426
    nop

    .line 425
    nop

    .line 422
    const-wide/16 v91, 0x0

    const/16 v93, 0x0

    const/16 v94, 0x0

    const/16 v96, 0xc30

    const/16 v97, 0x70

    invoke-static/range {v86 .. v97}, Landroidx/compose/material3/ProgressIndicatorKt;->CircularProgressIndicator-IyT6zlY(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;JFJIFLandroidx/compose/runtime/Composer;II)V

    .line 428
    move-object/from16 v8, v95

    .end local v95  # "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v8, "$composer\\26":Landroidx/compose/runtime/Composer;
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/16 v9, 0x8

    .local v9, "$this$dp\\32":I
    const/16 v75, 0x0

    .line 1504
    .local v75, "$i$f$getDp\\32\\428":I
    move-object/from16 v77, v10

    .end local v10  # "$this$ActiveProgressPanel_u24lambda_u2449_u24lambda_u2448_u24lambda_u2443_u24lambda_u2442\\26":Landroidx/compose/foundation/layout/RowScope;
    .local v77, "$this$ActiveProgressPanel_u24lambda_u2449_u24lambda_u2448_u24lambda_u2443_u24lambda_u2442\\26":Landroidx/compose/foundation/layout/RowScope;
    int-to-float v10, v9

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 428
    .end local v9  # "$this$dp\\32":I
    .end local v75  # "$i$f$getDp\\32\\428":I
    invoke-static {v3, v9}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v3

    move/from16 v9, v21

    invoke-static {v3, v8, v9}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 431
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v8, v9}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v106

    .line 432
    sget-object v3, Landroidx/compose/ui/text/font/FontWeight;->Companion:Landroidx/compose/ui/text/font/FontWeight$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/text/font/FontWeight$Companion;->getBold()Landroidx/compose/ui/text/font/FontWeight;

    move-result-object v93

    .line 430
    nop

    .line 432
    nop

    .line 431
    nop

    .line 429
    const-string v86, "ব্যাকগ্রাউন্ডে পাঠানো হচ্ছে..."

    const/16 v87, 0x0

    const-wide/16 v88, 0x0

    const-wide/16 v90, 0x0

    const/16 v92, 0x0

    const/16 v94, 0x0

    const-wide/16 v95, 0x0

    const/16 v97, 0x0

    const/16 v98, 0x0

    const-wide/16 v99, 0x0

    const/16 v101, 0x0

    const/16 v102, 0x0

    const/16 v103, 0x0

    const/16 v104, 0x0

    const/16 v105, 0x0

    const v108, 0x30006

    const/16 v109, 0x0

    const v110, 0xffde

    move-object/from16 v107, v8

    .end local v8  # "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v107, "$composer\\26":Landroidx/compose/runtime/Composer;
    invoke-static/range {v86 .. v110}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 422
    move-object/from16 v95, v107

    .end local v107  # "$composer\\26":Landroidx/compose/runtime/Composer;
    .restart local v95  # "$composer\\26":Landroidx/compose/runtime/Composer;
    invoke-static/range {v95 .. v95}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 434
    nop

    .line 1495
    .end local v67  # "$changed\\26":I
    .end local v68  # "$i$a$-Row-MainActivityKt$ActiveProgressPanel$1$1$1$1\\26\\1495\\18":I
    .end local v77  # "$this$ActiveProgressPanel_u24lambda_u2449_u24lambda_u2448_u24lambda_u2443_u24lambda_u2442\\26":Landroidx/compose/foundation/layout/RowScope;
    .end local v95  # "$composer\\26":Landroidx/compose/runtime/Composer;
    invoke-static/range {v71 .. v71}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1494
    .end local v70  # "$changed\\25":I
    .end local v71  # "$composer\\25":Landroidx/compose/runtime/Composer;
    .end local v74  # "$i$a$-Layout-RowKt$Row$1\\25\\1494\\19":I
    nop

    .line 1505
    invoke-interface/range {v65 .. v65}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1473
    invoke-static/range {v65 .. v65}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1506
    nop

    .line 1467
    .end local v63  # "$i$f$ReusableComposeNode\\21\\1471":I
    .end local v66  # "$changed\\21":I
    .end local v69  # "factory\\21":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v65 .. v65}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1507
    nop

    .line 1459
    .end local v56  # "$changed\\20":I
    .end local v59  # "$i$f$Layout\\20\\1466":I
    .end local v61  # "compositeKeyHash\\20":I
    .end local v72  # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v76  # "materialized\\20":Landroidx/compose/ui/Modifier;
    invoke-static/range {v65 .. v65}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1508
    nop

    .line 436
    .end local v57  # "$i$f$Row\\19\\421":I
    .end local v58  # "$changed\\19":I
    .end local v60  # "verticalAlignment\\19":Landroidx/compose/ui/Alignment$Vertical;
    .end local v62  # "horizontalArrangement\\19":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v64  # "modifier\\19":Landroidx/compose/ui/Modifier;
    .end local v65  # "$composer\\19":Landroidx/compose/runtime/Composer;
    .end local v73  # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    move/from16 v8, p1

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v9, " / "

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    move/from16 v9, p2

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v56

    .line 437
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v10, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v6, v10}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v76

    .line 438
    sget-object v3, Landroidx/compose/ui/text/font/FontWeight;->Companion:Landroidx/compose/ui/text/font/FontWeight$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/text/font/FontWeight$Companion;->getBold()Landroidx/compose/ui/text/font/FontWeight;

    move-result-object v63

    .line 439
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v10, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v6, v10}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v58

    .line 436
    nop

    .line 439
    nop

    .line 438
    nop

    .line 437
    nop

    .line 435
    const/16 v57, 0x0

    const-wide/16 v60, 0x0

    const/16 v62, 0x0

    const/16 v64, 0x0

    const-wide/16 v65, 0x0

    const/16 v67, 0x0

    const/16 v68, 0x0

    const-wide/16 v69, 0x0

    const/16 v71, 0x0

    const/16 v72, 0x0

    const/16 v73, 0x0

    const/16 v74, 0x0

    const/16 v75, 0x0

    const/high16 v78, 0x30000

    const/16 v79, 0x0

    const v80, 0xffda

    move-object/from16 v77, v6

    .end local v6  # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v77, "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v56 .. v80}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 421
    invoke-static/range {v77 .. v77}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 441
    nop

    .line 1458
    .end local v50  # "$this$ActiveProgressPanel_u24lambda_u2449_u24lambda_u2448_u24lambda_u2443\\18":Landroidx/compose/foundation/layout/RowScope;
    .end local v52  # "$changed\\18":I
    .end local v53  # "$i$a$-Row-MainActivityKt$ActiveProgressPanel$1$1$1\\18\\1458\\10":I
    .end local v77  # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v81 .. v81}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1457
    .end local v40  # "$changed\\17":I
    .end local v81  # "$composer\\17":Landroidx/compose/runtime/Composer;
    .end local v82  # "$i$a$-Layout-RowKt$Row$1\\17\\1457\\11":I
    nop

    .line 1509
    invoke-interface/range {v51 .. v51}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1436
    invoke-static/range {v51 .. v51}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1510
    nop

    .line 1430
    .end local v36  # "$i$f$ReusableComposeNode\\13\\1434":I
    .end local v38  # "factory\\13":Lkotlin/jvm/functions/Function0;
    .end local v39  # "$changed\\13":I
    invoke-static/range {v51 .. v51}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1511
    nop

    .line 1427
    .end local v31  # "$changed\\12":I
    .end local v32  # "$i$f$Layout\\12\\1429":I
    .end local v34  # "compositeKeyHash\\12":I
    .end local v55  # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v83  # "materialized\\12":Landroidx/compose/ui/Modifier;
    invoke-static/range {v51 .. v51}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1512
    nop

    .line 444
    .end local v29  # "$i$f$Row\\11\\416":I
    .end local v30  # "$changed\\11":I
    .end local v33  # "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    .end local v35  # "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v37  # "modifier\\11":Landroidx/compose/ui/Modifier;
    .end local v51  # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local v54  # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    const v3, 0x843114d

    invoke-static {v4, v3, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->changed(F)Z

    move-result v3

    .local v3, "invalid\\33":Z
    move-object v6, v4

    .local v6, "$this$cache\\33":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 1513
    .local v7, "$i$f$cache\\33\\444":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    .local v10, "it\\33":Ljava/lang/Object;
    const/16 v29, 0x0

    .line 1514
    .local v29, "$i$a$-let-ComposerKt$cache$1\\34\\1513\\33":I
    if-nez v3, :cond_530

    sget-object v30, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v31, v3

    .end local v3  # "invalid\\33":Z
    .local v31, "invalid\\33":Z
    invoke-virtual/range {v30 .. v30}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v10, v3, :cond_52e

    goto :goto_532

    .line 1518
    :cond_52e
    move-object v3, v10

    goto :goto_53f

    .line 1514
    .end local v31  # "invalid\\33":Z
    .restart local v3  # "invalid\\33":Z
    :cond_530
    move/from16 v31, v3

    .line 1515
    .end local v3  # "invalid\\33":Z
    .restart local v31  # "invalid\\33":Z
    :goto_532
    const/4 v3, 0x0

    .line 444
    .local v3, "$i$a$-cache-MainActivityKt$ActiveProgressPanel$1$1$2\\35\\1515\\10":I
    move/from16 v30, v3

    .end local v3  # "$i$a$-cache-MainActivityKt$ActiveProgressPanel$1$1$2\\35\\1515\\10":I
    .local v30, "$i$a$-cache-MainActivityKt$ActiveProgressPanel$1$1$2\\35\\1515\\10":I
    new-instance v3, Lcom/example/MainActivityKt$$ExternalSyntheticLambda14;

    invoke-direct {v3, v0}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda14;-><init>(F)V

    .line 1515
    .end local v30  # "$i$a$-cache-MainActivityKt$ActiveProgressPanel$1$1$2\\35\\1515\\10":I
    nop

    .line 1516
    .local v3, "value\\34":Ljava/lang/Object;
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1517
    nop

    .line 1514
    .end local v3  # "value\\34":Ljava/lang/Object;
    :goto_53f
    nop

    .line 1513
    .end local v10  # "it\\33":Ljava/lang/Object;
    .end local v29  # "$i$a$-let-ComposerKt$cache$1\\34\\1513\\33":I
    nop

    .line 444
    .end local v6  # "$this$cache\\33":Landroidx/compose/runtime/Composer;
    .end local v7  # "$i$f$cache\\33\\444":I
    .end local v31  # "invalid\\33":Z
    move-object/from16 v29, v3

    check-cast v29, Lkotlin/jvm/functions/Function0;

    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 445
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    .line 446
    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v10, 0x1

    invoke-static {v3, v7, v10, v6}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 447
    const/16 v6, 0x8

    .local v6, "$this$dp\\36":I
    const/4 v7, 0x0

    .line 1519
    .local v7, "$i$f$getDp\\36\\447":I
    int-to-float v10, v6

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 447
    .end local v6  # "$this$dp\\36":I
    .end local v7  # "$i$f$getDp\\36\\447":I
    invoke-static {v3, v6}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 448
    const/4 v6, 0x4

    .local v6, "$this$dp\\37":I
    const/4 v7, 0x0

    .line 1520
    .local v7, "$i$f$getDp\\37\\448":I
    int-to-float v10, v6

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 448
    .end local v6  # "$this$dp\\37":I
    .end local v7  # "$i$f$getDp\\37\\448":I
    invoke-static {v6}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v6

    check-cast v6, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v3, v6}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v30

    .line 449
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v4, v6}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v31

    .line 450
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v4, v6}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v33

    const/16 v39, 0xe

    const/16 v40, 0x0

    const v35, 0x3dcccccd  # 0.1f

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    invoke-static/range {v33 .. v40}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v33

    .line 443
    const/16 v35, 0x0

    const/16 v37, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x70

    move-object/from16 v38, v4

    .end local v4  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v38, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v29 .. v40}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-GJbTh5U(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;JJIFLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 454
    .end local v38  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v4  # "$composer\\10":Landroidx/compose/runtime/Composer;
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v10, 0x1

    invoke-static {v3, v7, v10, v6}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 455
    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v6

    .line 453
    nop

    .local v3, "modifier\\38":Landroidx/compose/ui/Modifier;
    .local v6, "verticalAlignment\\38":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v7, 0x186

    .local v7, "$changed\\38":I
    move-object/from16 v29, v4

    .local v29, "$composer\\38":Landroidx/compose/runtime/Composer;
    const/16 v30, 0x0

    .line 1521
    .local v30, "$i$f$Row\\38\\453":I
    move-object/from16 v10, v29

    const v0, 0x2952b718

    .end local v29  # "$composer\\38":Landroidx/compose/runtime/Composer;
    .local v10, "$composer\\38":Landroidx/compose/runtime/Composer;
    invoke-static {v10, v0, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1522
    sget-object v0, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v0}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v0

    .line 1526
    .local v0, "horizontalArrangement\\38":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v5, v7, 0x3

    and-int/lit8 v5, v5, 0xe

    shr-int/lit8 v29, v7, 0x3

    and-int/lit8 v29, v29, 0x70

    or-int v5, v5, v29

    invoke-static {v0, v6, v10, v5}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v5

    .local v5, "measurePolicy\\38":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v29, v7, 0x3

    and-int/lit8 v29, v29, 0x70

    .line 1527
    nop

    .local v29, "$changed\\39":I
    const/16 v31, 0x0

    .line 1528
    .local v31, "$i$f$Layout\\39\\1527":I
    move-object/from16 v32, v0

    const v0, -0x4ee9b9da

    .end local v0  # "horizontalArrangement\\38":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v32, "horizontalArrangement\\38":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v10, v0, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1529
    const/4 v0, 0x0

    invoke-static {v10, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v14

    .line 1530
    .local v14, "compositeKeyHash\\39":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v0

    .line 1531
    .local v0, "localMap\\39":Landroidx/compose/runtime/CompositionLocalMap;
    nop

    .end local v4  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v38  # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static {v10, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 1533
    .local v4, "materialized\\39":Landroidx/compose/ui/Modifier;
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v17

    move-object/from16 v33, v3

    .end local v3  # "modifier\\38":Landroidx/compose/ui/Modifier;
    .local v33, "modifier\\38":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v3, v29, 0x6

    and-int/lit16 v3, v3, 0x380

    const/16 v21, 0x6

    or-int/lit8 v3, v3, 0x6

    .line 1532
    move-object/from16 v34, v17

    .local v3, "$changed\\40":I
    .local v34, "factory\\40":Lkotlin/jvm/functions/Function0;
    const/16 v17, 0x0

    .line 1534
    .local v17, "$i$f$ReusableComposeNode\\40\\1532":I
    move/from16 v35, v3

    const v3, -0x2942ffcf

    .end local v3  # "$changed\\40":I
    .local v35, "$changed\\40":I
    invoke-static {v10, v3, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1535
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_61e

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1536
    :cond_61e
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1537
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_62d

    .line 1538
    move-object/from16 v2, v34

    .end local v34  # "factory\\40":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\40":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_632

    .line 1540
    .end local v2  # "factory\\40":Lkotlin/jvm/functions/Function0;
    .restart local v34  # "factory\\40":Lkotlin/jvm/functions/Function0;
    :cond_62d
    move-object/from16 v2, v34

    .end local v34  # "factory\\40":Lkotlin/jvm/functions/Function0;
    .restart local v2  # "factory\\40":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1542
    :goto_632
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\41":Landroidx/compose/runtime/Composer;
    const/16 v23, 0x0

    .line 1543
    .local v23, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\41\\1542\\39":I
    sget-object v34, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v36, v2

    .end local v2  # "factory\\40":Lkotlin/jvm/functions/Function0;
    .local v36, "factory\\40":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v34 .. v34}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v3, v5, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1544
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v3, v0, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1546
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\42":Lkotlin/jvm/functions/Function2;
    const/16 v34, 0x0

    .line 1547
    .local v34, "$i$f$set-impl\\42\\1546":I
    move-object/from16 v37, v3

    .local v37, "$this$set_impl_u24lambda_u240\\42":Landroidx/compose/runtime/Composer;
    const/16 v39, 0x0

    .line 1548
    .local v39, "$i$a$-with-Updater$set$1\\43\\1547\\42":I
    invoke-interface/range {v37 .. v37}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v40

    if-nez v40, :cond_674

    move-object/from16 v40, v0

    .end local v0  # "localMap\\39":Landroidx/compose/runtime/CompositionLocalMap;
    .local v40, "localMap\\39":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v37 .. v37}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v44, v5

    .end local v5  # "measurePolicy\\38":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v44, "measurePolicy\\38":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v0, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_671

    goto :goto_678

    :cond_671
    move-object/from16 v5, v37

    goto :goto_688

    .end local v40  # "localMap\\39":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v44  # "measurePolicy\\38":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v0  # "localMap\\39":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v5  # "measurePolicy\\38":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_674
    move-object/from16 v40, v0

    move-object/from16 v44, v5

    .line 1549
    .end local v0  # "localMap\\39":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v5  # "measurePolicy\\38":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v40  # "localMap\\39":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v44  # "measurePolicy\\38":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_678
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v5, v37

    .end local v37  # "$this$set_impl_u24lambda_u240\\42":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\42":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1550
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v3, v0, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1552
    :goto_688
    nop

    .line 1547
    .end local v5  # "$this$set_impl_u24lambda_u240\\42":Landroidx/compose/runtime/Composer;
    .end local v39  # "$i$a$-with-Updater$set$1\\43\\1547\\42":I
    nop

    .line 1552
    nop

    .line 1553
    .end local v2  # "block\\42":Lkotlin/jvm/functions/Function2;
    .end local v34  # "$i$f$set-impl\\42\\1546":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v3, v4, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1554
    nop

    .line 1542
    .end local v3  # "$this$Layout_u24lambda_u240\\41":Landroidx/compose/runtime/Composer;
    .end local v23  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\41\\1542\\39":I
    nop

    .line 1555
    shr-int/lit8 v0, v35, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\44":I
    move-object v2, v10

    .local v2, "$composer\\44":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 1556
    .local v3, "$i$a$-Layout-RowKt$Row$1\\44\\1555\\38":I
    const v5, -0x18505826

    invoke-static {v2, v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v5, v7, 0x6

    and-int/lit8 v5, v5, 0x70

    const/16 v21, 0x6

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\45":I
    check-cast v1, Landroidx/compose/foundation/layout/RowScope;

    .local v1, "$this$ActiveProgressPanel_u24lambda_u2449_u24lambda_u2448_u24lambda_u2447\\45":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v55, v2

    .local v55, "$composer\\45":Landroidx/compose/runtime/Composer;
    const/16 v23, 0x0

    .line 457
    .local v23, "$i$a$-Row-MainActivityKt$ActiveProgressPanel$1$1$3\\45\\1556\\10":I
    move/from16 v34, v0

    .end local v0  # "$changed\\44":I
    .local v34, "$changed\\44":I
    const v0, -0x60b37202

    move-object/from16 v37, v1

    .end local v1  # "$this$ActiveProgressPanel_u24lambda_u2449_u24lambda_u2448_u24lambda_u2447\\45":Landroidx/compose/foundation/layout/RowScope;
    .local v37, "$this$ActiveProgressPanel_u24lambda_u2449_u24lambda_u2448_u24lambda_u2447\\45":Landroidx/compose/foundation/layout/RowScope;
    const-string v1, "C459@17569L11,456@17420L248,462@17685L39,465@17871L10,466@17935L11,463@17741L328:MainActivity.kt#to5c3"

    move-object/from16 v39, v2

    .end local v55  # "$composer\\45":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\45":Landroidx/compose/runtime/Composer;
    .local v39, "$composer\\44":Landroidx/compose/runtime/Composer;
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 458
    sget-object v0, Landroidx/compose/material/icons/Icons;->INSTANCE:Landroidx/compose/material/icons/Icons;

    invoke-virtual {v0}, Landroidx/compose/material/icons/Icons;->getDefault()Landroidx/compose/material/icons/Icons$Filled;

    move-result-object v0

    invoke-static {v0}, Landroidx/compose/material/icons/filled/ImageKt;->getImage(Landroidx/compose/material/icons/Icons$Filled;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v50

    .line 460
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v53

    .line 461
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x10

    .local v1, "$this$dp\\46":I
    const/16 v46, 0x0

    .line 1557
    .local v46, "$i$f$getDp\\46\\461":I
    nop

    .end local v2  # "$composer\\45":Landroidx/compose/runtime/Composer;
    .restart local v55  # "$composer\\45":Landroidx/compose/runtime/Composer;
    int-to-float v2, v1

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 461
    .end local v1  # "$this$dp\\46":I
    .end local v46  # "$i$f$getDp\\46\\461":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v52

    .line 458
    nop

    .line 459
    nop

    .line 461
    nop

    .line 460
    nop

    .line 457
    const/16 v51, 0x0

    const/16 v56, 0x1b0

    const/16 v57, 0x0

    invoke-static/range {v50 .. v57}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    .line 463
    move-object/from16 v2, v55

    .end local v55  # "$composer\\45":Landroidx/compose/runtime/Composer;
    .restart local v2  # "$composer\\45":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x6

    .local v1, "$this$dp\\47":I
    const/16 v46, 0x0

    .line 1558
    .local v46, "$i$f$getDp\\47\\463":I
    move/from16 v47, v3

    .end local v3  # "$i$a$-Layout-RowKt$Row$1\\44\\1555\\38":I
    .local v47, "$i$a$-Layout-RowKt$Row$1\\44\\1555\\38":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 463
    .end local v1  # "$this$dp\\47":I
    .end local v46  # "$i$f$getDp\\47\\463":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v1, 0x6

    invoke-static {v0, v2, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 465
    move-object/from16 v0, p3

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-nez v1, :cond_71a

    const/16 v45, 0x1

    goto :goto_71c

    :cond_71a
    const/16 v45, 0x0

    :goto_71c
    if-eqz v45, :cond_722

    .line 1559
    const/4 v0, 0x0

    .line 465
    .local v0, "$i$a$-ifEmpty-MainActivityKt$ActiveProgressPanel$1$1$3$1\\48\\465\\45":I
    nop

    .end local v0  # "$i$a$-ifEmpty-MainActivityKt$ActiveProgressPanel$1$1$3$1\\48\\465\\45":I
    const-string v0, "ফাইল প্রস্তুত হচ্ছে..."

    :cond_722
    move-object/from16 v50, v0

    check-cast v50, Ljava/lang/String;

    .line 466
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v70

    .line 467
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v52

    .line 469
    sget-object v0, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v65

    .line 465
    nop

    .line 467
    nop

    .line 469
    nop

    .line 468
    nop

    .line 466
    nop

    .line 464
    const/16 v51, 0x0

    const-wide/16 v54, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const-wide/16 v59, 0x0

    const/16 v61, 0x0

    const/16 v62, 0x0

    const-wide/16 v63, 0x0

    const/16 v66, 0x0

    const/16 v67, 0x1

    const/16 v68, 0x0

    const/16 v69, 0x0

    const/16 v72, 0x0

    const/16 v73, 0xc30

    const v74, 0xd7fa

    move-object/from16 v71, v2

    .end local v2  # "$composer\\45":Landroidx/compose/runtime/Composer;
    .local v71, "$composer\\45":Landroidx/compose/runtime/Composer;
    invoke-static/range {v50 .. v74}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 457
    .end local v71  # "$composer\\45":Landroidx/compose/runtime/Composer;
    .restart local v2  # "$composer\\45":Landroidx/compose/runtime/Composer;
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 471
    nop

    .line 1556
    .end local v2  # "$composer\\45":Landroidx/compose/runtime/Composer;
    .end local v5  # "$changed\\45":I
    .end local v23  # "$i$a$-Row-MainActivityKt$ActiveProgressPanel$1$1$3\\45\\1556\\10":I
    .end local v37  # "$this$ActiveProgressPanel_u24lambda_u2449_u24lambda_u2448_u24lambda_u2447\\45":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v39 .. v39}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1555
    .end local v34  # "$changed\\44":I
    .end local v39  # "$composer\\44":Landroidx/compose/runtime/Composer;
    .end local v47  # "$i$a$-Layout-RowKt$Row$1\\44\\1555\\38":I
    nop

    .line 1560
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1534
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1561
    nop

    .line 1528
    .end local v17  # "$i$f$ReusableComposeNode\\40\\1532":I
    .end local v35  # "$changed\\40":I
    .end local v36  # "factory\\40":Lkotlin/jvm/functions/Function0;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1562
    nop

    .line 1521
    .end local v4  # "materialized\\39":Landroidx/compose/ui/Modifier;
    .end local v14  # "compositeKeyHash\\39":I
    .end local v29  # "$changed\\39":I
    .end local v31  # "$i$f$Layout\\39\\1527":I
    .end local v40  # "localMap\\39":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1563
    nop

    .line 416
    .end local v6  # "verticalAlignment\\38":Landroidx/compose/ui/Alignment$Vertical;
    .end local v7  # "$changed\\38":I
    .end local v10  # "$composer\\38":Landroidx/compose/runtime/Composer;
    .end local v30  # "$i$f$Row\\38\\453":I
    .end local v32  # "horizontalArrangement\\38":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v33  # "modifier\\38":Landroidx/compose/ui/Modifier;
    .end local v44  # "measurePolicy\\38":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v38 .. v38}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 472
    nop

    .line 1426
    .end local v25  # "$i$a$-Column-MainActivityKt$ActiveProgressPanel$1$1\\10\\1426\\0":I
    .end local v26  # "$this$ActiveProgressPanel_u24lambda_u2449_u24lambda_u2448\\10":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v38  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v42  # "$changed\\10":I
    invoke-static/range {v27 .. v27}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1425
    .end local v24  # "$changed\\9":I
    .end local v27  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v41  # "$i$a$-Layout-ColumnKt$Column$1\\9\\1425\\3":I
    nop

    .line 1564
    invoke-interface/range {v48 .. v48}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1404
    invoke-static/range {v48 .. v48}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1565
    nop

    .line 1398
    .end local v18  # "$i$f$ReusableComposeNode\\5\\1402":I
    .end local v19  # "$changed\\5":I
    .end local v20  # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v48 .. v48}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1566
    nop

    .line 1392
    .end local v11  # "$changed\\4":I
    .end local v12  # "$i$f$Layout\\4\\1397":I
    .end local v13  # "materialized\\4":Landroidx/compose/ui/Modifier;
    .end local v15  # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v16  # "compositeKeyHash\\4":I
    invoke-static/range {v48 .. v48}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1567
    nop

    .end local v22  # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v28  # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v43  # "$changed\\3":I
    .end local v48  # "$composer\\3":Landroidx/compose/runtime/Composer;
    .end local v49  # "$i$f$Column\\3\\412":I
    .end local v84  # "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v85  # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_7a6

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 473
    :cond_7a6
    :goto_7a6
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final ActiveProgressPanel$lambda$49$lambda$48$lambda$43$lambda$42$lambda$41$lambda$40(F)F
    .registers 1
    .param p0, "$progressPercentage"  # F

    .line 423
    return p0
.end method

.method static final ActiveProgressPanel$lambda$49$lambda$48$lambda$45$lambda$44(F)F
    .registers 1
    .param p0, "$progressPercentage"  # F

    .line 444
    return p0
.end method

.method static final ActiveProgressPanel$lambda$50(Ljava/lang/String;IIFILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 14

    or-int/lit8 v0, p4, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v6

    move-object v1, p0

    move v2, p1

    move v3, p2

    move v4, p3

    move-object v5, p5

    invoke-static/range {v1 .. v6}, Lcom/example/MainActivityKt;->ActiveProgressPanel(Ljava/lang/String;IIFLandroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method public static final ChatGPTWebView(Ljava/lang/String;ZLjava/lang/String;IIFLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V
    .registers 60
    .param p0, "url"  # Ljava/lang/String;
    .param p1, "isServiceRunning"  # Z
    .param p2, "currentPhotoName"  # Ljava/lang/String;
    .param p3, "currentIndex"  # I
    .param p4, "totalPhotos"  # I
    .param p5, "progressPercentage"  # F
    .param p6, "onStopClick"  # Lkotlin/jvm/functions/Function0;
    .param p7, "onBackClick"  # Lkotlin/jvm/functions/Function0;
    .param p8, "$composer"  # Landroidx/compose/runtime/Composer;
    .param p9, "$changed"  # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z",
            "Ljava/lang/String;",
            "IIF",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    move/from16 v9, p9

    const-string v0, "currentPhotoName"

    move-object/from16 v10, p2

    invoke-static {v10, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onStopClick"

    invoke-static {v7, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onBackClick"

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 743
    const v0, -0x1bda8603

    move-object/from16 v1, p8

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v11

    .end local p8  # "$composer":Landroidx/compose/runtime/Composer;
    .local v11, "$composer":Landroidx/compose/runtime/Composer;
    const-string v1, "C(ChatGPTWebView)P(7,2,1!1,6,5,4)743@28500L5043:MainActivity.kt#to5c3"

    invoke-static {v11, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v1, p9

    .local v1, "$dirty":I
    and-int/lit8 v2, p10, 0x1

    if-eqz v2, :cond_30

    or-int/lit8 v1, v1, 0x6

    move-object/from16 v3, p0

    goto :goto_43

    :cond_30
    and-int/lit8 v3, v9, 0x6

    if-nez v3, :cond_41

    move-object/from16 v3, p0

    invoke-interface {v11, v3}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3e

    const/4 v4, 0x4

    goto :goto_3f

    :cond_3e
    const/4 v4, 0x2

    :goto_3f
    or-int/2addr v1, v4

    goto :goto_43

    :cond_41
    move-object/from16 v3, p0

    :goto_43
    and-int/lit8 v4, v9, 0x30

    if-nez v4, :cond_56

    move/from16 v4, p1

    invoke-interface {v11, v4}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v5

    if-eqz v5, :cond_52

    const/16 v5, 0x20

    goto :goto_54

    :cond_52
    const/16 v5, 0x10

    :goto_54
    or-int/2addr v1, v5

    goto :goto_58

    :cond_56
    move/from16 v4, p1

    :goto_58
    and-int/lit16 v5, v9, 0xc00

    if-nez v5, :cond_6b

    move/from16 v5, p3

    invoke-interface {v11, v5}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v6

    if-eqz v6, :cond_67

    const/16 v6, 0x800

    goto :goto_69

    :cond_67
    const/16 v6, 0x400

    :goto_69
    or-int/2addr v1, v6

    goto :goto_6d

    :cond_6b
    move/from16 v5, p3

    :goto_6d
    and-int/lit16 v6, v9, 0x6000

    if-nez v6, :cond_80

    move/from16 v6, p4

    invoke-interface {v11, v6}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v13

    if-eqz v13, :cond_7c

    const/16 v13, 0x4000

    goto :goto_7e

    :cond_7c
    const/16 v13, 0x2000

    :goto_7e
    or-int/2addr v1, v13

    goto :goto_82

    :cond_80
    move/from16 v6, p4

    :goto_82
    const/high16 v13, 0x30000

    and-int/2addr v13, v9

    if-nez v13, :cond_96

    move/from16 v13, p5

    invoke-interface {v11, v13}, Landroidx/compose/runtime/Composer;->changed(F)Z

    move-result v14

    if-eqz v14, :cond_92

    const/high16 v14, 0x20000

    goto :goto_94

    :cond_92
    const/high16 v14, 0x10000

    :goto_94
    or-int/2addr v1, v14

    goto :goto_98

    :cond_96
    move/from16 v13, p5

    :goto_98
    const/high16 v14, 0x180000

    and-int/2addr v14, v9

    if-nez v14, :cond_a9

    invoke-interface {v11, v7}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_a6

    const/high16 v14, 0x100000

    goto :goto_a8

    :cond_a6
    const/high16 v14, 0x80000

    :goto_a8
    or-int/2addr v1, v14

    :cond_a9
    const/high16 v14, 0xc00000

    and-int/2addr v14, v9

    if-nez v14, :cond_ba

    invoke-interface {v11, v8}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_b7

    const/high16 v14, 0x800000

    goto :goto_b9

    :cond_b7
    const/high16 v14, 0x400000

    :goto_b9
    or-int/2addr v1, v14

    :cond_ba
    move v14, v1

    .end local v1  # "$dirty":I
    .local v14, "$dirty":I
    const v1, 0x492413

    and-int/2addr v1, v14

    const v15, 0x492412

    if-ne v1, v15, :cond_d1

    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_cb

    goto :goto_d1

    .line 733
    :cond_cb
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v1, v3

    goto/16 :goto_2d2

    .line 743
    :cond_d1
    :goto_d1
    if-eqz v2, :cond_d7

    .line 735
    const-string v1, "https://chatgpt.com/"

    move-object v15, v1

    .end local p0  # "url":Ljava/lang/String;
    .local v1, "url":Ljava/lang/String;
    goto :goto_d8

    .line 743
    .end local v1  # "url":Ljava/lang/String;
    .restart local p0  # "url":Ljava/lang/String;
    :cond_d7
    move-object v15, v3

    .line 735
    .end local p0  # "url":Ljava/lang/String;
    .local v15, "url":Ljava/lang/String;
    :goto_d8
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_e4

    const/4 v1, -0x1

    const-string v2, "com.example.ChatGPTWebView (MainActivity.kt:742)"

    invoke-static {v0, v14, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 744
    :cond_e4
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0, v1, v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .local v0, "modifier\\1":Landroidx/compose/ui/Modifier;
    const/16 v16, 0x6

    .local v16, "$changed\\1":I
    move-object/from16 p0, v11

    .local p0, "$composer\\1":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 1204
    .local v17, "$i$f$Column\\1\\744":I
    const v12, -0x1cd0f17e

    const-string v1, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo"

    move-object/from16 v2, p0

    .end local p0  # "$composer\\1":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\1":Landroidx/compose/runtime/Composer;
    invoke-static {v2, v12, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1205
    sget-object v1, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v1}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v12

    .line 1206
    .local v12, "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v1, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v1

    .line 1209
    .local v1, "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v20, v16, 0x3

    and-int/lit8 v20, v20, 0xe

    shr-int/lit8 v21, v16, 0x3

    and-int/lit8 v21, v21, 0x70

    or-int v3, v20, v21

    invoke-static {v12, v1, v2, v3}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v3

    .local v3, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v20, v16, 0x3

    and-int/lit8 v20, v20, 0x70

    .line 1210
    nop

    .local v20, "$changed\\2":I
    const/16 v21, 0x0

    .line 1211
    .local v21, "$i$f$Layout\\2\\1210":I
    move-object/from16 v22, v1

    .end local v1  # "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    .local v22, "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    const v1, -0x4ee9b9da

    const-string v4, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh"

    invoke-static {v2, v1, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1212
    const/4 v1, 0x0

    invoke-static {v2, v1}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v23

    .line 1213
    .local v23, "compositeKeyHash\\2":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v4

    .line 1214
    .local v4, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v2, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 1216
    .local v7, "materialized\\2":Landroidx/compose/ui/Modifier;
    sget-object v24, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v24 .. v24}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v24

    shl-int/lit8 v1, v20, 0x6

    and-int/lit16 v1, v1, 0x380

    or-int/lit8 v1, v1, 0x6

    .line 1215
    move/from16 v26, v1

    .local v26, "$changed\\3":I
    move-object/from16 v1, v24

    .local v1, "factory\\3":Lkotlin/jvm/functions/Function0;
    const/16 v24, 0x0

    .line 1217
    .local v24, "$i$f$ReusableComposeNode\\3\\1215":I
    move-object/from16 v27, v0

    .end local v0  # "modifier\\1":Landroidx/compose/ui/Modifier;
    .local v27, "modifier\\1":Landroidx/compose/ui/Modifier;
    const v0, -0x2942ffcf

    const-string v5, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v2, v0, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1218
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_15e

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1219
    :cond_15e
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1220
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_16b

    .line 1221
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_16e

    .line 1223
    :cond_16b
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1225
    :goto_16e
    invoke-static {v2}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 1226
    .local v5, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\1225\\2":I
    sget-object v28, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v29, v1

    .end local v1  # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v29, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v28 .. v28}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v3, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1227
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v4, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1229
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\5":Lkotlin/jvm/functions/Function2;
    const/16 v28, 0x0

    .line 1230
    .local v28, "$i$f$set-impl\\5\\1229":I
    move-object/from16 v30, v0

    .local v30, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v31, 0x0

    .line 1231
    .local v31, "$i$a$-with-Updater$set$1\\6\\1230\\5":I
    invoke-interface/range {v30 .. v30}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v32

    if-nez v32, :cond_1af

    move-object/from16 v32, v2

    .end local v2  # "$composer\\1":Landroidx/compose/runtime/Composer;
    .local v32, "$composer\\1":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v30 .. v30}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v33, v3

    .end local v3  # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v33, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1ac

    goto :goto_1b3

    :cond_1ac
    move-object/from16 v3, v30

    goto :goto_1c3

    .end local v32  # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v33  # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v2  # "$composer\\1":Landroidx/compose/runtime/Composer;
    .restart local v3  # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_1af
    move-object/from16 v32, v2

    move-object/from16 v33, v3

    .line 1232
    .end local v2  # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v3  # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v32  # "$composer\\1":Landroidx/compose/runtime/Composer;
    .restart local v33  # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_1b3
    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v30

    .end local v30  # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1233
    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1235
    :goto_1c3
    nop

    .line 1230
    .end local v3  # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v31  # "$i$a$-with-Updater$set$1\\6\\1230\\5":I
    nop

    .line 1235
    nop

    .line 1236
    .end local v1  # "block\\5":Lkotlin/jvm/functions/Function2;
    .end local v28  # "$i$f$set-impl\\5\\1229":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v7, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1237
    nop

    .line 1225
    .end local v0  # "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    .end local v5  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\1225\\2":I
    nop

    .line 1238
    shr-int/lit8 v0, v26, 0x6

    and-int/lit8 v28, v0, 0xe

    .local v28, "$changed\\7":I
    move-object/from16 v0, v32

    .local v0, "$composer\\7":Landroidx/compose/runtime/Composer;
    const/16 v30, 0x0

    .line 1239
    .local v30, "$i$a$-Layout-ColumnKt$Column$1\\7\\1238\\1":I
    const v1, -0x16f088b9

    const-string v2, "C87@4365L9:Column.kt#2w3rfo"

    invoke-static {v0, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v2, v16, 0x6

    and-int/lit8 v2, v2, 0x70

    or-int/lit8 v31, v2, 0x6

    .local v31, "$changed\\8":I
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScope;

    .local v1, "$this$ChatGPTWebView_u24lambda_u2477\\8":Landroidx/compose/foundation/layout/ColumnScope;
    move-object v2, v0

    .local v2, "$composer\\8":Landroidx/compose/runtime/Composer;
    move-object/from16 v47, v1

    .end local v1  # "$this$ChatGPTWebView_u24lambda_u2477\\8":Landroidx/compose/foundation/layout/ColumnScope;
    .local v47, "$this$ChatGPTWebView_u24lambda_u2477\\8":Landroidx/compose/foundation/layout/ColumnScope;
    const/16 v48, 0x0

    .line 746
    .local v48, "$i$a$-Column-MainActivityKt$ChatGPTWebView$1\\8\\1239\\0":I
    const v1, 0x5d6637f

    const-string v3, "C746@28655L11,749@28777L3914,745@28612L4079,831@32764L670,830@32729L808:MainActivity.kt#to5c3"

    invoke-static {v2, v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 747
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v2, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getPrimaryContainer-0d7_KjU()J

    move-result-wide v36

    .line 748
    const/4 v1, 0x4

    .local v1, "$this$dp\\9":I
    const/4 v3, 0x0

    .line 1240
    .local v3, "$i$f$getDp\\9\\748":I
    int-to-float v5, v1

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v40

    .line 748
    .end local v1  # "$this$dp\\9":I
    .end local v3  # "$i$f$getDp\\9\\748":I
    nop

    .line 749
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    move-object/from16 p0, v0

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x0

    .end local v0  # "$composer\\7":Landroidx/compose/runtime/Composer;
    .local p0, "$composer\\7":Landroidx/compose/runtime/Composer;
    invoke-static {v1, v5, v0, v3}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v34

    .line 747
    nop

    .line 748
    nop

    .line 750
    move/from16 v19, v0

    new-instance v0, Lcom/example/MainActivityKt$$ExternalSyntheticLambda11;

    move-object/from16 v18, p0

    move/from16 v1, p1

    move/from16 v5, p3

    move-object/from16 v3, p6

    move-object/from16 p0, v7

    const/16 v25, 0x0

    move-object v7, v2

    move v2, v13

    move-object v13, v4

    move-object v4, v8

    move/from16 v8, v19

    .end local v2  # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v4  # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .local v7, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v13, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .local v18, "$composer\\7":Landroidx/compose/runtime/Composer;
    .local p0, "materialized\\2":Landroidx/compose/ui/Modifier;
    invoke-direct/range {v0 .. v6}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda11;-><init>(ZFLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;II)V

    const/16 v1, 0x36

    const v2, 0x1e148c4c

    invoke-static {v2, v8, v0, v7, v1}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object/from16 v43, v0

    check-cast v43, Lkotlin/jvm/functions/Function2;

    .line 746
    const/16 v35, 0x0

    const-wide/16 v38, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const v45, 0xc06006

    const/16 v46, 0x6a

    move-object/from16 v44, v7

    .end local v7  # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v44, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v34 .. v46}, Landroidx/compose/material3/SurfaceKt;->Surface-T9BRK9s(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;JJFFLandroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    .line 832
    .end local v44  # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v7  # "$composer\\8":Landroidx/compose/runtime/Composer;
    const v0, -0x7baccc9b

    const-string v1, "CC(remember):MainActivity.kt#9igjgp"

    invoke-static {v7, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit8 v0, v14, 0xe

    const/4 v1, 0x4

    if-ne v0, v1, :cond_262

    move v2, v8

    goto :goto_264

    :cond_262
    move/from16 v2, v25

    .local v2, "invalid\\10":Z
    :goto_264
    move-object v0, v7

    .local v0, "$this$cache\\10":Landroidx/compose/runtime/Composer;
    const/4 v1, 0x0

    .line 1241
    .local v1, "$i$f$cache\\10\\832":I
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .local v3, "it\\10":Ljava/lang/Object;
    const/4 v4, 0x0

    .line 1242
    .local v4, "$i$a$-let-ComposerKt$cache$1\\11\\1241\\10":I
    if-nez v2, :cond_278

    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v3, v5, :cond_276

    goto :goto_278

    .line 1246
    :cond_276
    move-object v6, v3

    goto :goto_283

    .line 1243
    :cond_278
    :goto_278
    const/4 v5, 0x0

    .line 832
    .local v5, "$i$a$-cache-MainActivityKt$ChatGPTWebView$1$2\\12\\1243\\8":I
    new-instance v6, Lcom/example/MainActivityKt$$ExternalSyntheticLambda17;

    invoke-direct {v6, v15}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda17;-><init>(Ljava/lang/String;)V

    .line 1243
    .end local v5  # "$i$a$-cache-MainActivityKt$ChatGPTWebView$1$2\\12\\1243\\8":I
    nop

    .line 1244
    .local v6, "value\\11":Ljava/lang/Object;
    invoke-interface {v0, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1245
    nop

    .line 1242
    .end local v6  # "value\\11":Ljava/lang/Object;
    :goto_283
    nop

    .line 1241
    .end local v3  # "it\\10":Ljava/lang/Object;
    .end local v4  # "$i$a$-let-ComposerKt$cache$1\\11\\1241\\10":I
    nop

    .line 832
    .end local v0  # "$this$cache\\10":Landroidx/compose/runtime/Composer;
    .end local v1  # "$i$f$cache\\10\\832":I
    .end local v2  # "invalid\\10":Z
    check-cast v6, Lkotlin/jvm/functions/Function1;

    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 846
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    .line 847
    const/4 v3, 0x0

    const/4 v5, 0x0

    invoke-static {v0, v5, v8, v3}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v35

    .line 848
    const/16 v38, 0x2

    const/16 v39, 0x0

    const/high16 v36, 0x3f800000  # 1.0f

    const/16 v37, 0x0

    move-object/from16 v34, v47

    .end local v47  # "$this$ChatGPTWebView_u24lambda_u2477\\8":Landroidx/compose/foundation/layout/ColumnScope;
    .local v34, "$this$ChatGPTWebView_u24lambda_u2477\\8":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v34 .. v39}, Landroidx/compose/foundation/layout/ColumnScope;->weight$default(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v35

    .line 831
    move-object/from16 v1, v34

    .end local v34  # "$this$ChatGPTWebView_u24lambda_u2477\\8":Landroidx/compose/foundation/layout/ColumnScope;
    .local v1, "$this$ChatGPTWebView_u24lambda_u2477\\8":Landroidx/compose/foundation/layout/ColumnScope;
    const/16 v36, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x4

    move-object/from16 v34, v6

    move-object/from16 v37, v7

    .end local v7  # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v37, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v34 .. v39}, Landroidx/compose/ui/viewinterop/AndroidView_androidKt;->AndroidView(Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 746
    .end local v37  # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v7  # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 850
    nop

    .line 1239
    .end local v1  # "$this$ChatGPTWebView_u24lambda_u2477\\8":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v7  # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v31  # "$changed\\8":I
    .end local v48  # "$i$a$-Column-MainActivityKt$ChatGPTWebView$1\\8\\1239\\0":I
    invoke-static/range {v18 .. v18}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1238
    .end local v18  # "$composer\\7":Landroidx/compose/runtime/Composer;
    .end local v28  # "$changed\\7":I
    .end local v30  # "$i$a$-Layout-ColumnKt$Column$1\\7\\1238\\1":I
    nop

    .line 1247
    invoke-interface/range {v32 .. v32}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1217
    invoke-static/range {v32 .. v32}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1248
    nop

    .line 1211
    .end local v24  # "$i$f$ReusableComposeNode\\3\\1215":I
    .end local v26  # "$changed\\3":I
    .end local v29  # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v32 .. v32}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1249
    nop

    .line 1204
    .end local v13  # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v20  # "$changed\\2":I
    .end local v21  # "$i$f$Layout\\2\\1210":I
    .end local v23  # "compositeKeyHash\\2":I
    .end local p0  # "materialized\\2":Landroidx/compose/ui/Modifier;
    invoke-static/range {v32 .. v32}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1250
    nop

    .end local v12  # "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v16  # "$changed\\1":I
    .end local v17  # "$i$f$Column\\1\\744":I
    .end local v22  # "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v27  # "modifier\\1":Landroidx/compose/ui/Modifier;
    .end local v32  # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v33  # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2d1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 851
    :cond_2d1
    move-object v1, v15

    .end local v15  # "url":Ljava/lang/String;
    .local v1, "url":Ljava/lang/String;
    :goto_2d2
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v12

    if-eqz v12, :cond_2ef

    new-instance v0, Lcom/example/MainActivityKt$$ExternalSyntheticLambda18;

    move/from16 v2, p1

    move/from16 v4, p3

    move/from16 v5, p4

    move/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    move-object v3, v10

    move/from16 v10, p10

    invoke-direct/range {v0 .. v10}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda18;-><init>(Ljava/lang/String;ZLjava/lang/String;IIFLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;II)V

    invoke-interface {v12, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_2ef
    return-void
.end method

.method static final ChatGPTWebView$lambda$77$lambda$72(ZFLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 129
    .param p0, "$isServiceRunning"  # Z
    .param p1, "$progressPercentage"  # F
    .param p2, "$onStopClick"  # Lkotlin/jvm/functions/Function0;
    .param p3, "$onBackClick"  # Lkotlin/jvm/functions/Function0;
    .param p4, "$currentIndex"  # I
    .param p5, "$totalPhotos"  # I
    .param p6, "$composer"  # Landroidx/compose/runtime/Composer;
    .param p7, "$changed"  # I

    move/from16 v0, p1

    move/from16 v1, p7

    const-string v2, "C750@28791L3890:MainActivity.kt#to5c3"

    move-object/from16 v3, p6

    invoke-static {v3, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x3

    const/4 v4, 0x2

    if-ne v2, v4, :cond_1c

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v2

    if-nez v2, :cond_17

    goto :goto_1c

    .line 750
    :cond_17
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_7b5

    .line 0
    :cond_1c
    :goto_1c
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_2b

    const/4 v2, -0x1

    const-string v4, "com.example.ChatGPTWebView.<anonymous>.<anonymous> (MainActivity.kt:750)"

    const v5, 0x1e148c4c

    invoke-static {v5, v1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 751
    :cond_2b
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v4, 0xc

    .local v4, "$this$dp\\1":I
    const/4 v5, 0x0

    .line 1860
    .local v5, "$i$f$getDp\\1\\751":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 751
    .end local v4  # "$this$dp\\1":I
    .end local v5  # "$i$f$getDp\\1\\751":I
    const/16 v5, 0x8

    .local v5, "$this$dp\\2":I
    const/4 v6, 0x0

    .line 1860
    .local v6, "$i$f$getDp\\2\\751":I
    int-to-float v7, v5

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 751
    .end local v5  # "$this$dp\\2":I
    .end local v6  # "$i$f$getDp\\2\\751":I
    invoke-static {v2, v4, v5}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\3":Landroidx/compose/ui/Modifier;
    const/4 v4, 0x6

    .local v4, "$changed\\3":I
    move-object/from16 v5, p6

    .local v5, "$composer\\3":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 1861
    .local v6, "$i$f$Column\\3\\751":I
    const v7, -0x1cd0f17e

    const-string v8, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo"

    invoke-static {v5, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1862
    sget-object v9, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v9}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v9

    .line 1863
    .local v9, "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v10, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v10

    .line 1866
    .local v10, "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v11, v4, 0x3

    and-int/lit8 v11, v11, 0xe

    shr-int/lit8 v12, v4, 0x3

    and-int/lit8 v12, v12, 0x70

    or-int/2addr v11, v12

    invoke-static {v9, v10, v5, v11}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v11

    .local v11, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v12, v4, 0x3

    and-int/lit8 v12, v12, 0x70

    .line 1867
    nop

    .local v12, "$changed\\4":I
    const/4 v13, 0x0

    .line 1868
    .local v13, "$i$f$Layout\\4\\1867":I
    const v14, -0x4ee9b9da

    const-string v15, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh"

    invoke-static {v5, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1869
    const/4 v7, 0x0

    invoke-static {v5, v7}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v17

    .line 1870
    .local v17, "compositeKeyHash\\4":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v7

    .line 1871
    .local v7, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v5, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    .line 1873
    .local v14, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v20, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v20

    shl-int/lit8 v1, v12, 0x6

    and-int/lit16 v1, v1, 0x380

    move/from16 v21, v1

    const/4 v1, 0x6

    or-int/lit8 v21, v21, 0x6

    .line 1872
    nop

    .local v21, "$changed\\5":I
    move-object/from16 v22, v20

    .local v22, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/16 v20, 0x0

    .line 1874
    .local v20, "$i$f$ReusableComposeNode\\5\\1872":I
    move/from16 v23, v1

    const v1, -0x2942ffcf

    move-object/from16 v24, v2

    .end local v2  # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v24, "modifier\\3":Landroidx/compose/ui/Modifier;
    const-string v2, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v5, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1875
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_ae

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1876
    :cond_ae
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1877
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_bd

    .line 1878
    move-object/from16 v1, v22

    .end local v22  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_c2

    .line 1880
    .end local v1  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v22  # "factory\\5":Lkotlin/jvm/functions/Function0;
    :cond_bd
    move-object/from16 v1, v22

    .end local v22  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v1  # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1882
    :goto_c2
    move-object/from16 v22, v1

    .end local v1  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v22  # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static {v5}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v26, 0x0

    .line 1883
    .local v26, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\1882\\4":I
    sget-object v27, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v27 .. v27}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v1, v11, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1884
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v1, v7, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1886
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v27, 0x0

    .line 1887
    .local v27, "$i$f$set-impl\\7\\1886":I
    move-object/from16 v28, v1

    .local v28, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 1888
    .local v29, "$i$a$-with-Updater$set$1\\8\\1887\\7":I
    invoke-interface/range {v28 .. v28}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v30

    if-nez v30, :cond_104

    move/from16 v30, v4

    .end local v4  # "$changed\\3":I
    .local v30, "$changed\\3":I
    invoke-interface/range {v28 .. v28}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v31, v5

    .end local v5  # "$composer\\3":Landroidx/compose/runtime/Composer;
    .local v31, "$composer\\3":Landroidx/compose/runtime/Composer;
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_101

    goto :goto_108

    :cond_101
    move-object/from16 v5, v28

    goto :goto_118

    .end local v30  # "$changed\\3":I
    .end local v31  # "$composer\\3":Landroidx/compose/runtime/Composer;
    .restart local v4  # "$changed\\3":I
    .restart local v5  # "$composer\\3":Landroidx/compose/runtime/Composer;
    :cond_104
    move/from16 v30, v4

    move-object/from16 v31, v5

    .line 1889
    .end local v4  # "$changed\\3":I
    .end local v5  # "$composer\\3":Landroidx/compose/runtime/Composer;
    .restart local v30  # "$changed\\3":I
    .restart local v31  # "$composer\\3":Landroidx/compose/runtime/Composer;
    :goto_108
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v5, v28

    .end local v28  # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1890
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v1, v4, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1892
    :goto_118
    nop

    .line 1887
    .end local v5  # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v29  # "$i$a$-with-Updater$set$1\\8\\1887\\7":I
    nop

    .line 1892
    nop

    .line 1893
    .end local v3  # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v27  # "$i$f$set-impl\\7\\1886":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v1, v14, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1894
    nop

    .line 1882
    .end local v1  # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v26  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\1882\\4":I
    nop

    .line 1895
    shr-int/lit8 v1, v21, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\9":I
    move-object/from16 v3, v31

    .local v3, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 1896
    .local v4, "$i$a$-Layout-ColumnKt$Column$1\\9\\1895\\3":I
    const v5, -0x16f088b9

    move/from16 v26, v1

    .end local v1  # "$changed\\9":I
    .local v26, "$changed\\9":I
    const-string v1, "C87@4365L9:Column.kt#2w3rfo"

    invoke-static {v3, v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v27, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v28, v30, 0x6

    and-int/lit8 v28, v28, 0x70

    or-int/lit8 v28, v28, 0x6

    .local v28, "$changed\\10":I
    check-cast v27, Landroidx/compose/foundation/layout/ColumnScope;

    .local v27, "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2472_u24lambda_u2471\\10":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v41, v3

    .local v41, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 752
    .local v29, "$i$a$-Column-MainActivityKt$ChatGPTWebView$1$1$1\\10\\1896\\0":I
    const v5, 0x5231d518

    move-object/from16 v44, v3

    .end local v3  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v44, "$composer\\9":Landroidx/compose/runtime/Composer;
    const-string v3, "C751@28882L3191:MainActivity.kt#to5c3"

    move/from16 v45, v4

    move-object/from16 v4, v41

    .end local v41  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v45, "$i$a$-Layout-ColumnKt$Column$1\\9\\1895\\3":I
    invoke-static {v4, v5, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 753
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v5, 0x0

    move/from16 v46, v6

    .end local v6  # "$i$f$Column\\3\\751":I
    .local v46, "$i$f$Column\\3\\751":I
    const/4 v6, 0x1

    move-object/from16 v47, v7

    .end local v7  # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .local v47, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    const/4 v7, 0x0

    invoke-static {v3, v5, v6, v7}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 754
    sget-object v33, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual/range {v33 .. v33}, Landroidx/compose/foundation/layout/Arrangement;->getSpaceBetween()Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v33

    check-cast v33, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .line 755
    sget-object v34, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual/range {v34 .. v34}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v34

    .line 752
    move-object/from16 v35, v33

    .local v35, "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    move-object/from16 v33, v4

    .local v33, "$composer\\11":Landroidx/compose/runtime/Composer;
    move-object/from16 v36, v34

    .local v3, "modifier\\11":Landroidx/compose/ui/Modifier;
    .local v36, "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v34, 0x1b6

    .local v34, "$changed\\11":I
    const/16 v37, 0x0

    .line 1897
    .local v37, "$i$f$Row\\11\\752":I
    const v5, 0x2952b718

    const-string v6, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo"

    move-object/from16 v7, v33

    .end local v33  # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v7, "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static {v7, v5, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1898
    shr-int/lit8 v33, v34, 0x3

    and-int/lit8 v33, v33, 0xe

    shr-int/lit8 v41, v34, 0x3

    and-int/lit8 v41, v41, 0x70

    or-int v5, v33, v41

    move-object/from16 v48, v9

    move-object/from16 v49, v10

    move-object/from16 v9, v35

    move-object/from16 v10, v36

    .end local v35  # "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v36  # "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    .local v9, "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v10, "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    .local v48, "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v49, "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v9, v10, v7, v5}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v5

    .local v5, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v33, v34, 0x3

    and-int/lit8 v33, v33, 0x70

    .line 1899
    nop

    .local v33, "$changed\\12":I
    const/16 v35, 0x0

    .line 1900
    .local v35, "$i$f$Layout\\12\\1899":I
    move-object/from16 v36, v9

    const v9, -0x4ee9b9da

    .end local v9  # "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v36, "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v7, v9, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1901
    const/4 v9, 0x0

    invoke-static {v7, v9}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v41

    .line 1902
    .local v41, "compositeKeyHash\\12":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v9

    .line 1903
    .local v9, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v43, v10

    .end local v10  # "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    .local v43, "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v7, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v10

    .line 1905
    .local v10, "materialized\\12":Landroidx/compose/ui/Modifier;
    sget-object v50, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v50 .. v50}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v50

    move-object/from16 v51, v3

    .end local v3  # "modifier\\11":Landroidx/compose/ui/Modifier;
    .local v51, "modifier\\11":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v3, v33, 0x6

    and-int/lit16 v3, v3, 0x380

    or-int/lit8 v3, v3, 0x6

    .line 1904
    nop

    .local v3, "$changed\\13":I
    move-object/from16 v52, v50

    .local v52, "factory\\13":Lkotlin/jvm/functions/Function0;
    const/16 v50, 0x0

    .line 1906
    .local v50, "$i$f$ReusableComposeNode\\13\\1904":I
    move/from16 v53, v3

    const v3, -0x2942ffcf

    .end local v3  # "$changed\\13":I
    .local v53, "$changed\\13":I
    invoke-static {v7, v3, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1907
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_1de

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1908
    :cond_1de
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1909
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_1ed

    .line 1910
    move-object/from16 v3, v52

    .end local v52  # "factory\\13":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1f2

    .line 1912
    .end local v3  # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v52  # "factory\\13":Lkotlin/jvm/functions/Function0;
    :cond_1ed
    move-object/from16 v3, v52

    .end local v52  # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v3  # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1914
    :goto_1f2
    move-object/from16 v52, v3

    .end local v3  # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v52  # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    const/16 v54, 0x0

    .line 1915
    .local v54, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\1914\\12":I
    sget-object v55, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v56, v7

    .end local v7  # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v56, "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v55 .. v55}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v3, v5, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1916
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v3, v9, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1918
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    .local v7, "block\\15":Lkotlin/jvm/functions/Function2;
    const/16 v55, 0x0

    .line 1919
    .local v55, "$i$f$set-impl\\15\\1918":I
    move-object/from16 v57, v3

    .local v57, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/16 v58, 0x0

    .line 1920
    .local v58, "$i$a$-with-Updater$set$1\\16\\1919\\15":I
    invoke-interface/range {v57 .. v57}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v59

    if-nez v59, :cond_236

    move-object/from16 v59, v5

    .end local v5  # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v59, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface/range {v57 .. v57}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v60, v9

    .end local v9  # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .local v60, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v41 .. v41}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-static {v5, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_233

    goto :goto_23a

    :cond_233
    move-object/from16 v9, v57

    goto :goto_24a

    .end local v59  # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v60  # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v5  # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v9  # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_236
    move-object/from16 v59, v5

    move-object/from16 v60, v9

    .line 1921
    .end local v5  # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v9  # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v59  # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v60  # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_23a
    invoke-static/range {v41 .. v41}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    move-object/from16 v9, v57

    .end local v57  # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .local v9, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    invoke-interface {v9, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1922
    invoke-static/range {v41 .. v41}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v3, v5, v7}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1924
    :goto_24a
    nop

    .line 1919
    .end local v9  # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v58  # "$i$a$-with-Updater$set$1\\16\\1919\\15":I
    nop

    .line 1924
    nop

    .line 1925
    .end local v7  # "block\\15":Lkotlin/jvm/functions/Function2;
    .end local v55  # "$i$f$set-impl\\15\\1918":I
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v3, v10, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1926
    nop

    .line 1914
    .end local v3  # "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .end local v54  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\1914\\12":I
    nop

    .line 1927
    shr-int/lit8 v3, v53, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\17":I
    move-object/from16 v5, v56

    .local v5, "$composer\\17":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 1928
    .local v7, "$i$a$-Layout-RowKt$Row$1\\17\\1927\\11":I
    const v9, -0x18505826

    move/from16 v54, v3

    .end local v3  # "$changed\\17":I
    .local v54, "$changed\\17":I
    const-string v3, "C100@5047L9:Row.kt#2w3rfo"

    invoke-static {v5, v9, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v55, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v57, v34, 0x6

    and-int/lit8 v57, v57, 0x70

    or-int/lit8 v57, v57, 0x6

    .local v57, "$changed\\18":I
    check-cast v55, Landroidx/compose/foundation/layout/RowScope;

    .local v55, "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2472_u24lambda_u2471_u24lambda_u2468\\18":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v70, v5

    .local v70, "$composer\\18":Landroidx/compose/runtime/Composer;
    move-object/from16 v61, v55

    .end local v55  # "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2472_u24lambda_u2471_u24lambda_u2468\\18":Landroidx/compose/foundation/layout/RowScope;
    .local v61, "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2472_u24lambda_u2471_u24lambda_u2468\\18":Landroidx/compose/foundation/layout/RowScope;
    const/16 v55, 0x0

    .line 757
    .local v55, "$i$a$-Row-MainActivityKt$ChatGPTWebView$1$1$1$1\\18\\1928\\10":I
    const v9, -0x9800f3a

    move-object/from16 v74, v5

    .end local v5  # "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v74, "$composer\\17":Landroidx/compose/runtime/Composer;
    const-string v5, "C756@29120L1984:MainActivity.kt#to5c3"

    move/from16 v75, v7

    move-object/from16 v7, v70

    .end local v70  # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v7, "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v75, "$i$a$-Layout-RowKt$Row$1\\17\\1927\\11":I
    invoke-static {v7, v9, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 758
    sget-object v5, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v5

    .line 759
    sget-object v9, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v62, v9

    check-cast v62, Landroidx/compose/ui/Modifier;

    const/16 v65, 0x2

    const/16 v66, 0x0

    const/high16 v63, 0x3f800000  # 1.0f

    const/16 v64, 0x0

    invoke-static/range {v61 .. v66}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    .line 758
    move-object/from16 v76, v61

    .line 757
    .end local v61  # "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2472_u24lambda_u2471_u24lambda_u2468\\18":Landroidx/compose/foundation/layout/RowScope;
    .local v76, "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2472_u24lambda_u2471_u24lambda_u2468\\18":Landroidx/compose/foundation/layout/RowScope;
    nop

    .local v5, "verticalAlignment\\19":Landroidx/compose/ui/Alignment$Vertical;
    move-object/from16 v61, v7

    .local v9, "modifier\\19":Landroidx/compose/ui/Modifier;
    .local v61, "$composer\\19":Landroidx/compose/runtime/Composer;
    const/16 v62, 0x180

    .local v62, "$changed\\19":I
    const/16 v63, 0x0

    .line 1929
    .local v63, "$i$f$Row\\19\\757":I
    move-object/from16 v77, v10

    move-object/from16 v78, v11

    move-object/from16 v10, v61

    const v11, 0x2952b718

    .end local v11  # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v61  # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v10, "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v77, "materialized\\12":Landroidx/compose/ui/Modifier;
    .local v78, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {v10, v11, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1930
    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v6}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v6

    .line 1934
    .local v6, "horizontalArrangement\\19":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v11, v62, 0x3

    and-int/lit8 v11, v11, 0xe

    shr-int/lit8 v42, v62, 0x3

    and-int/lit8 v42, v42, 0x70

    or-int v11, v11, v42

    invoke-static {v6, v5, v10, v11}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v11

    .local v11, "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v42, v62, 0x3

    and-int/lit8 v42, v42, 0x70

    .line 1935
    nop

    .local v42, "$changed\\20":I
    const/16 v61, 0x0

    .line 1936
    .local v61, "$i$f$Layout\\20\\1935":I
    move-object/from16 v64, v5

    const v5, -0x4ee9b9da

    .end local v5  # "verticalAlignment\\19":Landroidx/compose/ui/Alignment$Vertical;
    .local v64, "verticalAlignment\\19":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v10, v5, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1937
    const/4 v5, 0x0

    invoke-static {v10, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v65

    .line 1938
    .local v65, "compositeKeyHash\\20":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v5

    .line 1939
    .local v5, "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v66, v6

    .end local v6  # "horizontalArrangement\\19":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v66, "horizontalArrangement\\19":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v10, v9}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    .line 1941
    .local v6, "materialized\\20":Landroidx/compose/ui/Modifier;
    sget-object v67, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v67 .. v67}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v67

    move-object/from16 v68, v9

    .end local v9  # "modifier\\19":Landroidx/compose/ui/Modifier;
    .local v68, "modifier\\19":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v9, v42, 0x6

    and-int/lit16 v9, v9, 0x380

    or-int/lit8 v9, v9, 0x6

    .line 1940
    nop

    .local v9, "$changed\\21":I
    move-object/from16 v69, v67

    .local v69, "factory\\21":Lkotlin/jvm/functions/Function0;
    const/16 v67, 0x0

    .line 1942
    .local v67, "$i$f$ReusableComposeNode\\21\\1940":I
    move/from16 v70, v9

    const v9, -0x2942ffcf

    .end local v9  # "$changed\\21":I
    .local v70, "$changed\\21":I
    invoke-static {v10, v9, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1943
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v9

    instance-of v9, v9, Landroidx/compose/runtime/Applier;

    if-nez v9, :cond_30c

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1944
    :cond_30c
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1945
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v9

    if-eqz v9, :cond_31b

    .line 1946
    move-object/from16 v9, v69

    .end local v69  # "factory\\21":Lkotlin/jvm/functions/Function0;
    .local v9, "factory\\21":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10, v9}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_320

    .line 1948
    .end local v9  # "factory\\21":Lkotlin/jvm/functions/Function0;
    .restart local v69  # "factory\\21":Lkotlin/jvm/functions/Function0;
    :cond_31b
    move-object/from16 v9, v69

    .end local v69  # "factory\\21":Lkotlin/jvm/functions/Function0;
    .restart local v9  # "factory\\21":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1950
    :goto_320
    move-object/from16 v69, v9

    .end local v9  # "factory\\21":Lkotlin/jvm/functions/Function0;
    .restart local v69  # "factory\\21":Lkotlin/jvm/functions/Function0;
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v9

    .local v9, "$this$Layout_u24lambda_u240\\22":Landroidx/compose/runtime/Composer;
    const/16 v71, 0x0

    .line 1951
    .local v71, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\22\\1950\\20":I
    sget-object v72, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v73, v10

    .end local v10  # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v73, "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v72 .. v72}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    invoke-static {v9, v11, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1952
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    invoke-static {v9, v5, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1954
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    .local v10, "block\\23":Lkotlin/jvm/functions/Function2;
    const/16 v72, 0x0

    .line 1955
    .local v72, "$i$f$set-impl\\23\\1954":I
    move-object/from16 v79, v9

    .local v79, "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    const/16 v80, 0x0

    .line 1956
    .local v80, "$i$a$-with-Updater$set$1\\24\\1955\\23":I
    invoke-interface/range {v79 .. v79}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v81

    if-nez v81, :cond_364

    move-object/from16 v81, v5

    .end local v5  # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .local v81, "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v79 .. v79}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v82, v11

    .end local v11  # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v82, "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v65 .. v65}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-static {v5, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_361

    goto :goto_368

    :cond_361
    move-object/from16 v11, v79

    goto :goto_378

    .end local v81  # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v82  # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v5  # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v11  # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_364
    move-object/from16 v81, v5

    move-object/from16 v82, v11

    .line 1957
    .end local v5  # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v11  # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v81  # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v82  # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_368
    invoke-static/range {v65 .. v65}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    move-object/from16 v11, v79

    .end local v79  # "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    .local v11, "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    invoke-interface {v11, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1958
    invoke-static/range {v65 .. v65}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v9, v5, v10}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1960
    :goto_378
    nop

    .line 1955
    .end local v11  # "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    .end local v80  # "$i$a$-with-Updater$set$1\\24\\1955\\23":I
    nop

    .line 1960
    nop

    .line 1961
    .end local v10  # "block\\23":Lkotlin/jvm/functions/Function2;
    .end local v72  # "$i$f$set-impl\\23\\1954":I
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v9, v6, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1962
    nop

    .line 1950
    .end local v9  # "$this$Layout_u24lambda_u240\\22":Landroidx/compose/runtime/Composer;
    .end local v71  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\22\\1950\\20":I
    nop

    .line 1963
    shr-int/lit8 v5, v70, 0x6

    and-int/lit8 v5, v5, 0xe

    .local v5, "$changed\\25":I
    move-object/from16 v9, v73

    .local v9, "$composer\\25":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 1964
    .local v10, "$i$a$-Layout-RowKt$Row$1\\25\\1963\\19":I
    const v11, -0x18505826

    invoke-static {v9, v11, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v11, v62, 0x6

    and-int/lit8 v11, v11, 0x70

    or-int/lit8 v11, v11, 0x6

    .local v11, "$changed\\26":I
    check-cast v3, Landroidx/compose/foundation/layout/RowScope;

    .local v3, "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2472_u24lambda_u2471_u24lambda_u2468_u24lambda_u2467\\26":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v89, v9

    .local v89, "$composer\\26":Landroidx/compose/runtime/Composer;
    const/16 v58, 0x0

    .line 761
    .local v58, "$i$a$-Row-MainActivityKt$ChatGPTWebView$1$1$1$1$1\\26\\1964\\18":I
    move-object/from16 v71, v3

    .end local v3  # "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2472_u24lambda_u2471_u24lambda_u2468_u24lambda_u2467\\26":Landroidx/compose/foundation/layout/RowScope;
    .local v71, "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2472_u24lambda_u2471_u24lambda_u2468_u24lambda_u2467\\26":Landroidx/compose/foundation/layout/RowScope;
    const v3, -0x527293d

    move/from16 v72, v5

    .end local v5  # "$changed\\25":I
    .local v72, "$changed\\25":I
    const-string v5, "C760@29300L349,767@29674L39,768@29738L1344:MainActivity.kt#to5c3"

    move-object/from16 v79, v6

    move-object/from16 v6, v89

    .end local v89  # "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v6, "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v79, "materialized\\20":Landroidx/compose/ui/Modifier;
    invoke-static {v6, v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Lcom/example/ComposableSingletons$MainActivityKt;->INSTANCE:Lcom/example/ComposableSingletons$MainActivityKt;

    invoke-virtual {v3}, Lcom/example/ComposableSingletons$MainActivityKt;->getLambda$1568603623$app()Lkotlin/jvm/functions/Function2;

    move-result-object v88

    const/high16 v90, 0x30000

    const/16 v91, 0x1e

    const/16 v84, 0x0

    const/16 v85, 0x0

    const/16 v86, 0x0

    const/16 v87, 0x0

    move-object/from16 v83, p3

    .end local v6  # "$composer\\26":Landroidx/compose/runtime/Composer;
    .restart local v89  # "$composer\\26":Landroidx/compose/runtime/Composer;
    invoke-static/range {v83 .. v91}, Landroidx/compose/material3/IconButtonKt;->IconButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/material3/IconButtonColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    .line 768
    .end local v89  # "$composer\\26":Landroidx/compose/runtime/Composer;
    .restart local v6  # "$composer\\26":Landroidx/compose/runtime/Composer;
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v5, 0x4

    .local v5, "$this$dp\\27":I
    const/16 v80, 0x0

    .line 1965
    .local v80, "$i$f$getDp\\27\\768":I
    move-object/from16 v83, v9

    .end local v9  # "$composer\\25":Landroidx/compose/runtime/Composer;
    .local v83, "$composer\\25":Landroidx/compose/runtime/Composer;
    int-to-float v9, v5

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 768
    .end local v5  # "$this$dp\\27":I
    .end local v80  # "$i$f$getDp\\27\\768":I
    invoke-static {v3, v5}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v3

    move/from16 v5, v23

    invoke-static {v3, v6, v5}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 769
    move-object v3, v6

    const/16 v18, 0x0

    .local v3, "$composer\\28":Landroidx/compose/runtime/Composer;
    move/from16 v5, v18

    .local v5, "$changed\\28":I
    const/4 v9, 0x0

    .line 1966
    .local v9, "$i$f$Column\\28\\769":I
    move/from16 v80, v5

    const v5, -0x1cd0f17e

    .end local v5  # "$changed\\28":I
    .local v80, "$changed\\28":I
    invoke-static {v3, v5, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1967
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    .line 1968
    .local v5, "modifier\\28":Landroidx/compose/ui/Modifier;
    sget-object v8, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v8}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v8

    .line 1969
    .local v8, "verticalArrangement\\28":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v16, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    .end local v6  # "$composer\\26":Landroidx/compose/runtime/Composer;
    .restart local v89  # "$composer\\26":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v6

    .line 1972
    .local v6, "horizontalAlignment\\28":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v16, v80, 0x3

    and-int/lit8 v16, v16, 0xe

    shr-int/lit8 v84, v80, 0x3

    and-int/lit8 v84, v84, 0x70

    move/from16 v85, v9

    .end local v9  # "$i$f$Column\\28\\769":I
    .local v85, "$i$f$Column\\28\\769":I
    or-int v9, v16, v84

    invoke-static {v8, v6, v3, v9}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .local v9, "measurePolicy\\28":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v80, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 1973
    nop

    .local v16, "$changed\\29":I
    const/16 v84, 0x0

    .line 1974
    .local v84, "$i$f$Layout\\29\\1973":I
    move-object/from16 v86, v6

    const v6, -0x4ee9b9da

    .end local v6  # "horizontalAlignment\\28":Landroidx/compose/ui/Alignment$Horizontal;
    .local v86, "horizontalAlignment\\28":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v3, v6, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1975
    const/4 v6, 0x0

    invoke-static {v3, v6}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v6

    .line 1976
    .local v6, "compositeKeyHash\\29":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v15

    .line 1977
    .local v15, "localMap\\29":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v18, v6

    .end local v6  # "compositeKeyHash\\29":I
    .local v18, "compositeKeyHash\\29":I
    invoke-static {v3, v5}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    .line 1979
    .local v6, "materialized\\29":Landroidx/compose/ui/Modifier;
    sget-object v19, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v19 .. v19}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v19

    move-object/from16 v87, v5

    .end local v5  # "modifier\\28":Landroidx/compose/ui/Modifier;
    .local v87, "modifier\\28":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v5, v16, 0x6

    and-int/lit16 v5, v5, 0x380

    const/16 v23, 0x6

    or-int/lit8 v5, v5, 0x6

    .line 1978
    nop

    .local v5, "$changed\\30":I
    move-object/from16 v88, v19

    .local v88, "factory\\30":Lkotlin/jvm/functions/Function0;
    const/16 v19, 0x0

    .line 1980
    .local v19, "$i$f$ReusableComposeNode\\30\\1978":I
    move/from16 v90, v5

    const v5, -0x2942ffcf

    .end local v5  # "$changed\\30":I
    .local v90, "$changed\\30":I
    invoke-static {v3, v5, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1981
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_453

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1982
    :cond_453
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1983
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_462

    .line 1984
    move-object/from16 v2, v88

    .end local v88  # "factory\\30":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\30":Lkotlin/jvm/functions/Function0;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_467

    .line 1986
    .end local v2  # "factory\\30":Lkotlin/jvm/functions/Function0;
    .restart local v88  # "factory\\30":Lkotlin/jvm/functions/Function0;
    :cond_462
    move-object/from16 v2, v88

    .end local v88  # "factory\\30":Lkotlin/jvm/functions/Function0;
    .restart local v2  # "factory\\30":Lkotlin/jvm/functions/Function0;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1988
    :goto_467
    invoke-static {v3}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\31":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 1989
    .local v25, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\31\\1988\\29":I
    sget-object v88, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v91, v2

    .end local v2  # "factory\\30":Lkotlin/jvm/functions/Function0;
    .local v91, "factory\\30":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v88 .. v88}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v5, v9, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1990
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v5, v15, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1992
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\32":Lkotlin/jvm/functions/Function2;
    const/16 v88, 0x0

    .line 1993
    .local v88, "$i$f$set-impl\\32\\1992":I
    move-object/from16 v92, v5

    .local v92, "$this$set_impl_u24lambda_u240\\32":Landroidx/compose/runtime/Composer;
    const/16 v93, 0x0

    .line 1994
    .local v93, "$i$a$-with-Updater$set$1\\33\\1993\\32":I
    invoke-interface/range {v92 .. v92}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v94

    if-nez v94, :cond_4a9

    move-object/from16 v94, v3

    .end local v3  # "$composer\\28":Landroidx/compose/runtime/Composer;
    .local v94, "$composer\\28":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v92 .. v92}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v95, v8

    .end local v8  # "verticalArrangement\\28":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v95, "verticalArrangement\\28":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v3, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4a6

    goto :goto_4ad

    :cond_4a6
    move-object/from16 v8, v92

    goto :goto_4bd

    .end local v94  # "$composer\\28":Landroidx/compose/runtime/Composer;
    .end local v95  # "verticalArrangement\\28":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v3  # "$composer\\28":Landroidx/compose/runtime/Composer;
    .restart local v8  # "verticalArrangement\\28":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    :cond_4a9
    move-object/from16 v94, v3

    move-object/from16 v95, v8

    .line 1995
    .end local v3  # "$composer\\28":Landroidx/compose/runtime/Composer;
    .end local v8  # "verticalArrangement\\28":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v94  # "$composer\\28":Landroidx/compose/runtime/Composer;
    .restart local v95  # "verticalArrangement\\28":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    :goto_4ad
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v8, v92

    .end local v92  # "$this$set_impl_u24lambda_u240\\32":Landroidx/compose/runtime/Composer;
    .local v8, "$this$set_impl_u24lambda_u240\\32":Landroidx/compose/runtime/Composer;
    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1996
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v5, v3, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1998
    :goto_4bd
    nop

    .line 1993
    .end local v8  # "$this$set_impl_u24lambda_u240\\32":Landroidx/compose/runtime/Composer;
    .end local v93  # "$i$a$-with-Updater$set$1\\33\\1993\\32":I
    nop

    .line 1998
    nop

    .line 1999
    .end local v2  # "block\\32":Lkotlin/jvm/functions/Function2;
    .end local v88  # "$i$f$set-impl\\32\\1992":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v5, v6, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 2000
    nop

    .line 1988
    .end local v5  # "$this$Layout_u24lambda_u240\\31":Landroidx/compose/runtime/Composer;
    .end local v25  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\31\\1988\\29":I
    nop

    .line 2001
    shr-int/lit8 v2, v90, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\34":I
    move-object/from16 v3, v94

    .local v3, "$composer\\34":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 2002
    .local v5, "$i$a$-Layout-ColumnKt$Column$1\\34\\2001\\28":I
    const v8, -0x16f088b9

    invoke-static {v3, v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v8, v80, 0x6

    and-int/lit8 v8, v8, 0x70

    const/16 v23, 0x6

    or-int/lit8 v8, v8, 0x6

    .local v8, "$changed\\35":I
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScope;

    .local v1, "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2472_u24lambda_u2471_u24lambda_u2468_u24lambda_u2467_u24lambda_u2466\\35":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v117, v3

    .local v117, "$composer\\35":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 770
    .local v25, "$i$a$-Column-MainActivityKt$ChatGPTWebView$1$1$1$1$1$1\\35\\2002\\26":I
    move-object/from16 v32, v1

    .end local v1  # "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2472_u24lambda_u2471_u24lambda_u2468_u24lambda_u2467_u24lambda_u2466\\35":Landroidx/compose/foundation/layout/ColumnScope;
    .local v32, "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2472_u24lambda_u2471_u24lambda_u2468_u24lambda_u2467_u24lambda_u2466\\35":Landroidx/compose/foundation/layout/ColumnScope;
    const v1, 0x5c807a62

    move/from16 v88, v2

    .end local v2  # "$changed\\34":I
    .local v88, "$changed\\34":I
    const-string v2, "C771@29894L10,773@30033L11,769@29775L318:MainActivity.kt#to5c3"

    move-object/from16 v92, v3

    .end local v117  # "$composer\\35":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\35":Landroidx/compose/runtime/Composer;
    .local v92, "$composer\\34":Landroidx/compose/runtime/Composer;
    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 772
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v116

    .line 773
    sget-object v1, Landroidx/compose/ui/text/font/FontWeight;->Companion:Landroidx/compose/ui/text/font/FontWeight$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/text/font/FontWeight$Companion;->getBold()Landroidx/compose/ui/text/font/FontWeight;

    move-result-object v103

    .line 774
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnPrimaryContainer-0d7_KjU()J

    move-result-wide v98

    .line 771
    nop

    .line 774
    nop

    .line 773
    nop

    .line 772
    nop

    .line 770
    const-string v96, "ChatGPT ব্রাউজার"

    const/16 v97, 0x0

    const-wide/16 v100, 0x0

    const/16 v102, 0x0

    const/16 v104, 0x0

    const-wide/16 v105, 0x0

    const/16 v107, 0x0

    const/16 v108, 0x0

    const-wide/16 v109, 0x0

    const/16 v111, 0x0

    const/16 v112, 0x0

    const/16 v113, 0x0

    const/16 v114, 0x0

    const/16 v115, 0x0

    const v118, 0x30006

    const/16 v119, 0x0

    const v120, 0xffda

    .end local v3  # "$composer\\35":Landroidx/compose/runtime/Composer;
    .restart local v117  # "$composer\\35":Landroidx/compose/runtime/Composer;
    invoke-static/range {v96 .. v120}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 776
    .end local v117  # "$composer\\35":Landroidx/compose/runtime/Composer;
    .restart local v3  # "$composer\\35":Landroidx/compose/runtime/Composer;
    if-eqz p0, :cond_5c0

    const v1, 0x5c85aec6

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "778@30337L10,779@30417L11,776@30178L412"

    invoke-static {v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 778
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "ফাইল ডাউনলোড চলছে ("

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    move/from16 v2, p4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    move/from16 v2, p5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ")"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v96

    .line 779
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v116

    .line 780
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v98

    .line 782
    sget-object v1, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v111

    .line 778
    nop

    .line 780
    nop

    .line 782
    nop

    .line 781
    nop

    .line 779
    nop

    .line 777
    const/16 v97, 0x0

    const-wide/16 v100, 0x0

    const/16 v102, 0x0

    const/16 v103, 0x0

    const/16 v104, 0x0

    const-wide/16 v105, 0x0

    const/16 v107, 0x0

    const/16 v108, 0x0

    const-wide/16 v109, 0x0

    const/16 v112, 0x0

    const/16 v113, 0x1

    const/16 v114, 0x0

    const/16 v115, 0x0

    const/16 v118, 0x0

    const/16 v119, 0xc30

    const v120, 0xd7fa

    move-object/from16 v117, v3

    .end local v3  # "$composer\\35":Landroidx/compose/runtime/Composer;
    .restart local v117  # "$composer\\35":Landroidx/compose/runtime/Composer;
    invoke-static/range {v96 .. v120}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 776
    .end local v117  # "$composer\\35":Landroidx/compose/runtime/Composer;
    .restart local v3  # "$composer\\35":Landroidx/compose/runtime/Composer;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_616

    .line 784
    :cond_5c0
    const v1, 0x5c8cf4f4

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "786@30789L10,784@30660L366"

    invoke-static {v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 787
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v116

    .line 788
    const-wide v1, 0xff2e7d32L

    invoke-static {v1, v2}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v98

    .line 790
    sget-object v1, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v111

    .line 786
    nop

    .line 788
    nop

    .line 790
    nop

    .line 789
    nop

    .line 787
    nop

    .line 785
    const-string v96, "ট্রান্সফার সম্পন্ন"

    const/16 v97, 0x0

    const-wide/16 v100, 0x0

    const/16 v102, 0x0

    const/16 v103, 0x0

    const/16 v104, 0x0

    const-wide/16 v105, 0x0

    const/16 v107, 0x0

    const/16 v108, 0x0

    const-wide/16 v109, 0x0

    const/16 v112, 0x0

    const/16 v113, 0x1

    const/16 v114, 0x0

    const/16 v115, 0x0

    const/16 v118, 0x186

    const/16 v119, 0xc30

    const v120, 0xd7fa

    move-object/from16 v117, v3

    .end local v3  # "$composer\\35":Landroidx/compose/runtime/Composer;
    .restart local v117  # "$composer\\35":Landroidx/compose/runtime/Composer;
    invoke-static/range {v96 .. v120}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 784
    .end local v117  # "$composer\\35":Landroidx/compose/runtime/Composer;
    .restart local v3  # "$composer\\35":Landroidx/compose/runtime/Composer;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 770
    :goto_616
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 793
    nop

    .line 2002
    .end local v3  # "$composer\\35":Landroidx/compose/runtime/Composer;
    .end local v8  # "$changed\\35":I
    .end local v25  # "$i$a$-Column-MainActivityKt$ChatGPTWebView$1$1$1$1$1$1\\35\\2002\\26":I
    .end local v32  # "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2472_u24lambda_u2471_u24lambda_u2468_u24lambda_u2467_u24lambda_u2466\\35":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v92 .. v92}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 2001
    .end local v5  # "$i$a$-Layout-ColumnKt$Column$1\\34\\2001\\28":I
    .end local v88  # "$changed\\34":I
    .end local v92  # "$composer\\34":Landroidx/compose/runtime/Composer;
    nop

    .line 2003
    invoke-interface/range {v94 .. v94}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1980
    invoke-static/range {v94 .. v94}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 2004
    nop

    .line 1974
    .end local v19  # "$i$f$ReusableComposeNode\\30\\1978":I
    .end local v90  # "$changed\\30":I
    .end local v91  # "factory\\30":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v94 .. v94}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 2005
    nop

    .line 1966
    .end local v6  # "materialized\\29":Landroidx/compose/ui/Modifier;
    .end local v15  # "localMap\\29":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v16  # "$changed\\29":I
    .end local v18  # "compositeKeyHash\\29":I
    .end local v84  # "$i$f$Layout\\29\\1973":I
    invoke-static/range {v94 .. v94}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 2006
    nop

    .line 761
    .end local v9  # "measurePolicy\\28":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v80  # "$changed\\28":I
    .end local v85  # "$i$f$Column\\28\\769":I
    .end local v86  # "horizontalAlignment\\28":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v87  # "modifier\\28":Landroidx/compose/ui/Modifier;
    .end local v94  # "$composer\\28":Landroidx/compose/runtime/Composer;
    .end local v95  # "verticalArrangement\\28":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static/range {v89 .. v89}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 794
    nop

    .line 1964
    .end local v11  # "$changed\\26":I
    .end local v58  # "$i$a$-Row-MainActivityKt$ChatGPTWebView$1$1$1$1$1\\26\\1964\\18":I
    .end local v71  # "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2472_u24lambda_u2471_u24lambda_u2468_u24lambda_u2467\\26":Landroidx/compose/foundation/layout/RowScope;
    .end local v89  # "$composer\\26":Landroidx/compose/runtime/Composer;
    invoke-static/range {v83 .. v83}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1963
    .end local v10  # "$i$a$-Layout-RowKt$Row$1\\25\\1963\\19":I
    .end local v72  # "$changed\\25":I
    .end local v83  # "$composer\\25":Landroidx/compose/runtime/Composer;
    nop

    .line 2007
    invoke-interface/range {v73 .. v73}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1942
    invoke-static/range {v73 .. v73}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 2008
    nop

    .line 1936
    .end local v67  # "$i$f$ReusableComposeNode\\21\\1940":I
    .end local v69  # "factory\\21":Lkotlin/jvm/functions/Function0;
    .end local v70  # "$changed\\21":I
    invoke-static/range {v73 .. v73}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 2009
    nop

    .line 1929
    .end local v42  # "$changed\\20":I
    .end local v61  # "$i$f$Layout\\20\\1935":I
    .end local v65  # "compositeKeyHash\\20":I
    .end local v79  # "materialized\\20":Landroidx/compose/ui/Modifier;
    .end local v81  # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v73 .. v73}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 2010
    nop

    .line 796
    .end local v62  # "$changed\\19":I
    .end local v63  # "$i$f$Row\\19\\757":I
    .end local v64  # "verticalAlignment\\19":Landroidx/compose/ui/Alignment$Vertical;
    .end local v66  # "horizontalArrangement\\19":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v68  # "modifier\\19":Landroidx/compose/ui/Modifier;
    .end local v73  # "$composer\\19":Landroidx/compose/runtime/Composer;
    .end local v82  # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    if-eqz p0, :cond_6b9

    const v1, -0x962524f

    invoke-interface {v7, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "798@31285L48,796@31174L859"

    invoke-static {v7, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 799
    sget-object v61, Landroidx/compose/material3/ButtonDefaults;->INSTANCE:Landroidx/compose/material3/ButtonDefaults;

    const-wide v1, 0xffd32f2fL

    invoke-static {v1, v2}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v62

    sget v1, Landroidx/compose/material3/ButtonDefaults;->$stable:I

    shl-int/lit8 v1, v1, 0xc

    const/16 v23, 0x6

    or-int/lit8 v71, v1, 0x6

    const/16 v72, 0xe

    const-wide/16 v64, 0x0

    const-wide/16 v66, 0x0

    const-wide/16 v68, 0x0

    move-object/from16 v70, v7

    .end local v7  # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v70, "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v61 .. v72}, Landroidx/compose/material3/ButtonDefaults;->buttonColors-ro_MJ88(JJJJLandroidx/compose/runtime/Composer;II)Landroidx/compose/material3/ButtonColors;

    move-result-object v65

    .line 800
    move-object/from16 v73, v70

    .end local v70  # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v73, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/16 v1, 0xc

    .local v1, "$this$dp\\36":I
    const/4 v2, 0x0

    .line 2011
    .local v2, "$i$f$getDp\\36\\800":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 800
    .end local v1  # "$this$dp\\36":I
    .end local v2  # "$i$f$getDp\\36\\800":I
    const/4 v2, 0x2

    .local v2, "$this$dp\\37":I
    const/4 v3, 0x0

    .line 2011
    .local v3, "$i$f$getDp\\37\\800":I
    int-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 800
    .end local v2  # "$this$dp\\37":I
    .end local v3  # "$i$f$getDp\\37\\800":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-YgX7TsA(FF)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v68

    .line 801
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x24

    .local v2, "$this$dp\\38":I
    const/4 v3, 0x0

    .line 2012
    .local v3, "$i$f$getDp\\38\\801":I
    int-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 801
    .end local v2  # "$this$dp\\38":I
    .end local v3  # "$i$f$getDp\\38\\801":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v62

    .line 798
    nop

    .line 801
    nop

    .line 799
    nop

    .line 800
    sget-object v1, Lcom/example/ComposableSingletons$MainActivityKt;->INSTANCE:Lcom/example/ComposableSingletons$MainActivityKt;

    invoke-virtual {v1}, Lcom/example/ComposableSingletons$MainActivityKt;->getLambda$-1704390351$app()Lkotlin/jvm/functions/Function3;

    move-result-object v70

    .line 797
    const/16 v63, 0x0

    const/16 v64, 0x0

    const/16 v66, 0x0

    const/16 v67, 0x0

    const/16 v69, 0x0

    const v72, 0x30c00030

    move-object/from16 v10, v73

    .end local v73  # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v10, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/16 v73, 0x16c

    move-object/from16 v61, p2

    move-object/from16 v71, v10

    .end local v10  # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v71, "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v61 .. v73}, Landroidx/compose/material3/ButtonKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 796
    .end local v71  # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v10  # "$composer\\18":Landroidx/compose/runtime/Composer;
    goto :goto_6c0

    .end local v10  # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v7  # "$composer\\18":Landroidx/compose/runtime/Composer;
    :cond_6b9
    move-object v10, v7

    .end local v7  # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v10  # "$composer\\18":Landroidx/compose/runtime/Composer;
    const v1, -0xb3a3e84

    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_6c0
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 757
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 813
    nop

    .line 1928
    .end local v10  # "$composer\\18":Landroidx/compose/runtime/Composer;
    .end local v55  # "$i$a$-Row-MainActivityKt$ChatGPTWebView$1$1$1$1\\18\\1928\\10":I
    .end local v57  # "$changed\\18":I
    .end local v76  # "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2472_u24lambda_u2471_u24lambda_u2468\\18":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v74 .. v74}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1927
    .end local v54  # "$changed\\17":I
    .end local v74  # "$composer\\17":Landroidx/compose/runtime/Composer;
    .end local v75  # "$i$a$-Layout-RowKt$Row$1\\17\\1927\\11":I
    nop

    .line 2013
    invoke-interface/range {v56 .. v56}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1906
    invoke-static/range {v56 .. v56}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 2014
    nop

    .line 1900
    .end local v50  # "$i$f$ReusableComposeNode\\13\\1904":I
    .end local v52  # "factory\\13":Lkotlin/jvm/functions/Function0;
    .end local v53  # "$changed\\13":I
    invoke-static/range {v56 .. v56}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 2015
    nop

    .line 1897
    .end local v33  # "$changed\\12":I
    .end local v35  # "$i$f$Layout\\12\\1899":I
    .end local v41  # "compositeKeyHash\\12":I
    .end local v60  # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v77  # "materialized\\12":Landroidx/compose/ui/Modifier;
    invoke-static/range {v56 .. v56}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 2016
    nop

    .line 815
    .end local v34  # "$changed\\11":I
    .end local v36  # "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v37  # "$i$f$Row\\11\\752":I
    .end local v43  # "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    .end local v51  # "modifier\\11":Landroidx/compose/ui/Modifier;
    .end local v56  # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local v59  # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    if-eqz p0, :cond_78c

    const v1, 0x526135f6

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "815@32135L40,817@32256L22,822@32517L11,823@32589L11,816@32196L453"

    invoke-static {v4, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 816
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v2, 0x6

    .local v2, "$this$dp\\39":I
    const/4 v3, 0x0

    .line 2017
    .local v3, "$i$f$getDp\\39\\816":I
    int-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 816
    .end local v2  # "$this$dp\\39":I
    .end local v3  # "$i$f$getDp\\39\\816":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v5, 0x6

    invoke-static {v1, v4, v5}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 818
    const v1, -0x599b4a8

    const-string v2, "CC(remember):MainActivity.kt#9igjgp"

    invoke-static {v4, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->changed(F)Z

    move-result v1

    .local v1, "invalid\\40":Z
    move-object v2, v4

    .local v2, "$this$cache\\40":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 2018
    .local v3, "$i$f$cache\\40\\818":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\40":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 2019
    .local v6, "$i$a$-let-ComposerKt$cache$1\\41\\2018\\40":I
    if-nez v1, :cond_71a

    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v5, v7, :cond_718

    goto :goto_71a

    .line 2023
    :cond_718
    move-object v8, v5

    goto :goto_725

    .line 2020
    :cond_71a
    :goto_71a
    const/4 v7, 0x0

    .line 818
    .local v7, "$i$a$-cache-MainActivityKt$ChatGPTWebView$1$1$1$2\\42\\2020\\10":I
    new-instance v8, Lcom/example/MainActivityKt$$ExternalSyntheticLambda6;

    invoke-direct {v8, v0}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda6;-><init>(F)V

    .line 2020
    .end local v7  # "$i$a$-cache-MainActivityKt$ChatGPTWebView$1$1$1$2\\42\\2020\\10":I
    nop

    .line 2021
    .local v8, "value\\41":Ljava/lang/Object;
    invoke-interface {v2, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 2022
    nop

    .line 2019
    .end local v8  # "value\\41":Ljava/lang/Object;
    :goto_725
    nop

    .line 2018
    .end local v5  # "it\\40":Ljava/lang/Object;
    .end local v6  # "$i$a$-let-ComposerKt$cache$1\\41\\2018\\40":I
    nop

    .line 818
    .end local v1  # "invalid\\40":Z
    .end local v2  # "$this$cache\\40":Landroidx/compose/runtime/Composer;
    .end local v3  # "$i$f$cache\\40\\818":I
    move-object/from16 v32, v8

    check-cast v32, Lkotlin/jvm/functions/Function0;

    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 819
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    .line 820
    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v5, 0x0

    invoke-static {v1, v5, v3, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 821
    const/4 v2, 0x4

    .local v2, "$this$dp\\43":I
    const/4 v3, 0x0

    .line 2024
    .local v3, "$i$f$getDp\\43\\821":I
    int-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 821
    .end local v2  # "$this$dp\\43":I
    .end local v3  # "$i$f$getDp\\43\\821":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 822
    const/4 v2, 0x2

    .local v2, "$this$dp\\44":I
    const/4 v3, 0x0

    .line 2025
    .local v3, "$i$f$getDp\\44\\822":I
    int-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 822
    .end local v2  # "$this$dp\\44":I
    .end local v3  # "$i$f$getDp\\44\\822":I
    invoke-static {v2}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v2

    check-cast v2, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v1, v2}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v33

    .line 823
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v4, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v34

    .line 824
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v4, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v36

    const/16 v42, 0xe

    const/16 v43, 0x0

    const v38, 0x3e4ccccd  # 0.2f

    const/16 v39, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    invoke-static/range {v36 .. v43}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v36

    .line 817
    const/16 v38, 0x0

    const/16 v40, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x70

    move-object/from16 v41, v4

    .end local v4  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v41, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v32 .. v43}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-GJbTh5U(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;JJIFLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 815
    .end local v41  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v4  # "$composer\\10":Landroidx/compose/runtime/Composer;
    goto :goto_792

    :cond_78c
    const v1, 0x507ad920

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_792
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 752
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 827
    nop

    .line 1896
    .end local v4  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v27  # "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2472_u24lambda_u2471\\10":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v28  # "$changed\\10":I
    .end local v29  # "$i$a$-Column-MainActivityKt$ChatGPTWebView$1$1$1\\10\\1896\\0":I
    invoke-static/range {v44 .. v44}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1895
    .end local v26  # "$changed\\9":I
    .end local v44  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v45  # "$i$a$-Layout-ColumnKt$Column$1\\9\\1895\\3":I
    nop

    .line 2026
    invoke-interface/range {v31 .. v31}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1874
    invoke-static/range {v31 .. v31}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 2027
    nop

    .line 1868
    .end local v20  # "$i$f$ReusableComposeNode\\5\\1872":I
    .end local v21  # "$changed\\5":I
    .end local v22  # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v31 .. v31}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 2028
    nop

    .line 1861
    .end local v12  # "$changed\\4":I
    .end local v13  # "$i$f$Layout\\4\\1867":I
    .end local v14  # "materialized\\4":Landroidx/compose/ui/Modifier;
    .end local v17  # "compositeKeyHash\\4":I
    .end local v47  # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v31 .. v31}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 2029
    nop

    .end local v24  # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v30  # "$changed\\3":I
    .end local v31  # "$composer\\3":Landroidx/compose/runtime/Composer;
    .end local v46  # "$i$f$Column\\3\\751":I
    .end local v48  # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v49  # "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v78  # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_7b5

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 828
    :cond_7b5
    :goto_7b5
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method static final ChatGPTWebView$lambda$77$lambda$72$lambda$71$lambda$70$lambda$69(F)F
    .registers 1
    .param p0, "$progressPercentage"  # F

    .line 818
    return p0
.end method

.method static final ChatGPTWebView$lambda$77$lambda$76$lambda$75(Ljava/lang/String;Landroid/content/Context;)Landroid/webkit/WebView;
    .registers 8
    .param p0, "$url"  # Ljava/lang/String;
    .param p1, "ctx"  # Landroid/content/Context;

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 833
    new-instance v0, Landroid/webkit/WebView;

    invoke-direct {v0, p1}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2476_u24lambda_u2475_u24lambda_u2474\\1":Landroid/webkit/WebView;
    const/4 v2, 0x0

    .line 834
    .local v2, "$i$a$-apply-MainActivityKt$ChatGPTWebView$1$2$1$1\\1\\833\\0":I
    new-instance v3, Landroid/webkit/WebViewClient;

    invoke-direct {v3}, Landroid/webkit/WebViewClient;-><init>()V

    invoke-virtual {v1, v3}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    .line 835
    invoke-virtual {v1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    .local v3, "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2476_u24lambda_u2475_u24lambda_u2474_u24lambda_u2473\\2":Landroid/webkit/WebSettings;
    const/4 v4, 0x0

    .line 836
    .local v4, "$i$a$-apply-MainActivityKt$ChatGPTWebView$1$2$1$1$1\\2\\835\\1":I
    const/4 v5, 0x1

    invoke-virtual {v3, v5}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    .line 837
    invoke-virtual {v3, v5}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    .line 838
    invoke-virtual {v3, v5}, Landroid/webkit/WebSettings;->setUseWideViewPort(Z)V

    .line 839
    invoke-virtual {v3, v5}, Landroid/webkit/WebSettings;->setLoadWithOverviewMode(Z)V

    .line 841
    const-string v5, "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36"

    invoke-virtual {v3, v5}, Landroid/webkit/WebSettings;->setUserAgentString(Ljava/lang/String;)V

    .line 842
    nop

    .line 835
    .end local v3  # "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2476_u24lambda_u2475_u24lambda_u2474_u24lambda_u2473\\2":Landroid/webkit/WebSettings;
    .end local v4  # "$i$a$-apply-MainActivityKt$ChatGPTWebView$1$2$1$1$1\\2\\835\\1":I
    nop

    .line 843
    invoke-virtual {v1, p0}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    .line 844
    nop

    .line 833
    .end local v1  # "$this$ChatGPTWebView_u24lambda_u2477_u24lambda_u2476_u24lambda_u2475_u24lambda_u2474\\1":Landroid/webkit/WebView;
    .end local v2  # "$i$a$-apply-MainActivityKt$ChatGPTWebView$1$2$1$1\\1\\833\\0":I
    nop

    .line 844
    return-object v0
.end method

.method static final ChatGPTWebView$lambda$78(Ljava/lang/String;ZLjava/lang/String;IIFLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 24

    or-int/lit8 v0, p8, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v10

    move-object v1, p0

    move v2, p1

    move-object v3, p2

    move v4, p3

    move/from16 v5, p4

    move/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    move/from16 v11, p9

    move-object/from16 v9, p10

    invoke-static/range {v1 .. v11}, Lcom/example/MainActivityKt;->ChatGPTWebView(Ljava/lang/String;ZLjava/lang/String;IIFLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final EmptyLogsCard(Landroidx/compose/runtime/Composer;I)V
    .registers 15
    .param p0, "$composer"  # Landroidx/compose/runtime/Composer;
    .param p1, "$changed"  # I

    .line 668
    const v0, -0x1db75f83

    invoke-interface {p0, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .end local p0  # "$composer":Landroidx/compose/runtime/Composer;
    .local v7, "$composer":Landroidx/compose/runtime/Composer;
    const-string p0, "C(EmptyLogsCard)672@25972L11,672@25930L62,668@25798L1346:MainActivity.kt#to5c3"

    invoke-static {v7, p0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez p1, :cond_1a

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result p0

    if-nez p0, :cond_15

    goto :goto_1a

    .line 667
    :cond_15
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v10, v7

    goto :goto_87

    .line 668
    :cond_1a
    :goto_1a
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_26

    const/4 p0, -0x1

    const-string v1, "com.example.EmptyLogsCard (MainActivity.kt:667)"

    invoke-static {v0, p1, p0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 670
    :cond_26
    sget-object p0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast p0, Landroidx/compose/ui/Modifier;

    .line 671
    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v0, v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    .line 672
    const/16 v3, 0xc

    .local v3, "$this$dp\\1":I
    const/4 v4, 0x0

    .line 1202
    .local v4, "$i$f$getDp\\1\\672":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 672
    .end local v3  # "$this$dp\\1":I
    .end local v4  # "$i$f$getDp\\1\\672":I
    invoke-static {p0, v0, v3, v1, v2}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    .line 673
    sget-object v1, Landroidx/compose/material3/CardDefaults;->INSTANCE:Landroidx/compose/material3/CardDefaults;

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v7, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getSurface-0d7_KjU()J

    move-result-wide v2

    sget v0, Landroidx/compose/material3/CardDefaults;->$stable:I

    shl-int/lit8 v11, v0, 0xc

    const/16 v12, 0xe

    const-wide/16 v4, 0x0

    move-object v10, v7

    .end local v7  # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v6, 0x0

    const-wide/16 v8, 0x0

    invoke-virtual/range {v1 .. v12}, Landroidx/compose/material3/CardDefaults;->cardColors-ro_MJ88(JJJJLandroidx/compose/runtime/Composer;II)Landroidx/compose/material3/CardColors;

    move-result-object v3

    .line 674
    const/16 v0, 0xc

    .local v0, "$this$dp\\2":I
    const/4 v1, 0x0

    .line 1203
    .local v1, "$i$f$getDp\\2\\674":I
    int-to-float v2, v0

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 674
    .end local v0  # "$this$dp\\2":I
    .end local v1  # "$i$f$getDp\\2\\674":I
    invoke-static {v0}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v0

    .line 672
    nop

    .line 674
    move-object v2, v0

    check-cast v2, Landroidx/compose/ui/graphics/Shape;

    .line 673
    sget-object v0, Lcom/example/ComposableSingletons$MainActivityKt;->INSTANCE:Lcom/example/ComposableSingletons$MainActivityKt;

    invoke-virtual {v0}, Lcom/example/ComposableSingletons$MainActivityKt;->getLambda$-1977354293$app()Lkotlin/jvm/functions/Function3;

    move-result-object v6

    .line 669
    const/4 v4, 0x0

    const/4 v5, 0x0

    const v8, 0x30006

    const/16 v9, 0x18

    move-object v1, p0

    move-object v7, v10

    .end local v10  # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v7  # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v1 .. v9}, Landroidx/compose/material3/CardKt;->Card(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/CardColors;Landroidx/compose/material3/CardElevation;Landroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .end local v7  # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v10  # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_87

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 703
    :cond_87
    :goto_87
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object p0

    if-eqz p0, :cond_95

    new-instance v0, Lcom/example/MainActivityKt$$ExternalSyntheticLambda0;

    invoke-direct {v0, p1}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda0;-><init>(I)V

    invoke-interface {p0, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_95
    return-void
.end method

.method static final EmptyLogsCard$lambda$65(ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    or-int/lit8 v0, p0, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p1, v0}, Lcom/example/MainActivityKt;->EmptyLogsCard(Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final HeaderBar(Landroidx/compose/runtime/Composer;I)V
    .registers 96
    .param p0, "$composer"  # Landroidx/compose/runtime/Composer;
    .param p1, "$changed"  # I

    .line 188
    move/from16 v0, p1

    const v1, -0x48b6093d

    move-object/from16 v2, p0

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .end local p0  # "$composer":Landroidx/compose/runtime/Composer;
    .local v2, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(HeaderBar)188@7108L1473:MainActivity.kt#to5c3"

    invoke-static {v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez v0, :cond_20

    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_19

    goto :goto_20

    .line 187
    :cond_19
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v23, v2

    goto/16 :goto_5ef

    .line 188
    :cond_20
    :goto_20
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_2c

    const/4 v3, -0x1

    const-string v4, "com.example.HeaderBar (MainActivity.kt:187)"

    invoke-static {v1, v0, v3, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 190
    :cond_2c
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    .line 191
    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v1, v3, v4, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 192
    const/4 v6, 0x4

    .local v6, "$this$dp\\1":I
    const/4 v7, 0x0

    .line 987
    .local v7, "$i$f$getDp\\1\\192":I
    int-to-float v8, v6

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 192
    .end local v6  # "$this$dp\\1":I
    .end local v7  # "$i$f$getDp\\1\\192":I
    invoke-static {v1, v3, v6, v4, v5}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 193
    sget-object v3, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v3

    .line 194
    sget-object v4, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v4}, Landroidx/compose/foundation/layout/Arrangement;->getSpaceBetween()Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v4

    .line 192
    nop

    .line 194
    check-cast v4, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .line 193
    nop

    .line 189
    nop

    .local v4, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    move-object v5, v2

    .local v5, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/16 v6, 0x1b6

    .local v1, "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v3, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .local v6, "$changed\\2":I
    const/4 v7, 0x0

    .line 988
    .local v7, "$i$f$Row\\2\\189":I
    const v8, 0x2952b718

    const-string v9, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo"

    invoke-static {v5, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 989
    shr-int/lit8 v10, v6, 0x3

    and-int/lit8 v10, v10, 0xe

    shr-int/lit8 v11, v6, 0x3

    and-int/lit8 v11, v11, 0x70

    or-int/2addr v10, v11

    invoke-static {v4, v3, v5, v10}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .local v10, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v11, v6, 0x3

    and-int/lit8 v11, v11, 0x70

    .line 990
    nop

    .local v11, "$changed\\3":I
    const/4 v12, 0x0

    .line 991
    .local v12, "$i$f$Layout\\3\\990":I
    const v13, -0x4ee9b9da

    const-string v14, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh"

    invoke-static {v5, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 992
    const/4 v15, 0x0

    invoke-static {v5, v15}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v16

    .line 993
    .local v16, "compositeKeyHash\\3":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v15

    .line 994
    .local v15, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v5, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v13

    .line 996
    .local v13, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v18

    shl-int/lit8 v8, v11, 0x6

    and-int/lit16 v8, v8, 0x380

    move-object/from16 v20, v1

    .end local v1  # "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v20, "modifier\\2":Landroidx/compose/ui/Modifier;
    const/4 v1, 0x6

    or-int/2addr v8, v1

    .line 995
    move-object/from16 v21, v18

    .local v8, "$changed\\4":I
    .local v21, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v18, 0x0

    .line 997
    .local v18, "$i$f$ReusableComposeNode\\4\\995":I
    move/from16 v22, v1

    const v1, -0x2942ffcf

    move-object/from16 v23, v2

    .end local v2  # "$composer":Landroidx/compose/runtime/Composer;
    .local v23, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v5, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 998
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_b0

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 999
    :cond_b0
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1000
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_bf

    .line 1001
    move-object/from16 v1, v21

    .end local v21  # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_c4

    .line 1003
    .end local v1  # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v21  # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_bf
    move-object/from16 v1, v21

    .end local v21  # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v1  # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1005
    :goto_c4
    move-object/from16 v21, v1

    .end local v1  # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v21  # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static {v5}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 1006
    .local v25, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\1005\\3":I
    sget-object v26, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v27, v3

    .end local v3  # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .local v27, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    invoke-virtual/range {v26 .. v26}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v1, v10, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1007
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v1, v15, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1009
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v26, 0x0

    .line 1010
    .local v26, "$i$f$set-impl\\6\\1009":I
    move-object/from16 v28, v1

    .local v28, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 1011
    .local v29, "$i$a$-with-Updater$set$1\\7\\1010\\6":I
    invoke-interface/range {v28 .. v28}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v30

    if-nez v30, :cond_108

    move-object/from16 v30, v4

    .end local v4  # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v30, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-interface/range {v28 .. v28}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v31, v5

    .end local v5  # "$composer\\2":Landroidx/compose/runtime/Composer;
    .local v31, "$composer\\2":Landroidx/compose/runtime/Composer;
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_105

    goto :goto_10c

    :cond_105
    move-object/from16 v5, v28

    goto :goto_11c

    .end local v30  # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v31  # "$composer\\2":Landroidx/compose/runtime/Composer;
    .restart local v4  # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v5  # "$composer\\2":Landroidx/compose/runtime/Composer;
    :cond_108
    move-object/from16 v30, v4

    move-object/from16 v31, v5

    .line 1012
    .end local v4  # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v5  # "$composer\\2":Landroidx/compose/runtime/Composer;
    .restart local v30  # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v31  # "$composer\\2":Landroidx/compose/runtime/Composer;
    :goto_10c
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v5, v28

    .end local v28  # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1013
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v1, v4, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1015
    :goto_11c
    nop

    .line 1010
    .end local v5  # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v29  # "$i$a$-with-Updater$set$1\\7\\1010\\6":I
    nop

    .line 1015
    nop

    .line 1016
    .end local v3  # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v26  # "$i$f$set-impl\\6\\1009":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v1, v13, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1017
    nop

    .line 1005
    .end local v1  # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v25  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\1005\\3":I
    nop

    .line 1018
    shr-int/lit8 v1, v8, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\8":I
    move-object/from16 v3, v31

    .local v3, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 1019
    .local v4, "$i$a$-Layout-RowKt$Row$1\\8\\1018\\2":I
    const v5, -0x18505826

    move/from16 v25, v1

    .end local v1  # "$changed\\8":I
    .local v25, "$changed\\8":I
    const-string v1, "C100@5047L9:Row.kt#2w3rfo"

    invoke-static {v3, v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v26, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v28, v6, 0x6

    and-int/lit8 v28, v28, 0x70

    or-int/lit8 v28, v28, 0x6

    .local v28, "$changed\\9":I
    check-cast v26, Landroidx/compose/foundation/layout/RowScope;

    .local v26, "$this$HeaderBar_u24lambda_u2429\\9":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v29, v3

    .local v29, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v32, 0x0

    .line 196
    .local v32, "$i$a$-Row-MainActivityKt$HeaderBar$1\\9\\1019\\0":I
    const v5, -0x730c4592

    move-object/from16 v34, v3

    .end local v3  # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v34, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v3, "C195@7337L1238:MainActivity.kt#to5c3"

    move/from16 v35, v4

    move-object/from16 v4, v29

    .end local v29  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v35, "$i$a$-Layout-RowKt$Row$1\\8\\1018\\2":I
    invoke-static {v4, v5, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v3

    .local v3, "verticalAlignment\\10":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v5, 0x180

    .local v5, "$changed\\10":I
    .local v29, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v36, 0x0

    .line 1020
    .local v36, "$i$f$Row\\10\\196":I
    move-object/from16 v37, v4

    move/from16 v19, v5

    const v5, 0x2952b718

    .end local v5  # "$changed\\10":I
    .end local v29  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v19, "$changed\\10":I
    .local v37, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static {v4, v5, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1021
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    .line 1022
    .local v5, "modifier\\10":Landroidx/compose/ui/Modifier;
    sget-object v9, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v9}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v9

    .line 1026
    .local v9, "horizontalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v29, v19, 0x3

    and-int/lit8 v29, v29, 0xe

    shr-int/lit8 v38, v19, 0x3

    and-int/lit8 v38, v38, 0x70

    move/from16 v39, v6

    .end local v6  # "$changed\\2":I
    .local v39, "$changed\\2":I
    or-int v6, v29, v38

    invoke-static {v9, v3, v4, v6}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    .local v6, "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v29, v19, 0x3

    and-int/lit8 v29, v29, 0x70

    .line 1027
    nop

    .local v29, "$changed\\11":I
    const/16 v38, 0x0

    .line 1028
    .local v38, "$i$f$Layout\\11\\1027":I
    move-object/from16 v40, v3

    const v3, -0x4ee9b9da

    .end local v3  # "verticalAlignment\\10":Landroidx/compose/ui/Alignment$Vertical;
    .local v40, "verticalAlignment\\10":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v4, v3, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1029
    const/4 v3, 0x0

    invoke-static {v4, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v41

    .line 1030
    .local v41, "compositeKeyHash\\11":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v3

    .line 1031
    .local v3, "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v42, v7

    .end local v7  # "$i$f$Row\\2\\189":I
    .local v42, "$i$f$Row\\2\\189":I
    invoke-static {v4, v5}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 1033
    .local v7, "materialized\\11":Landroidx/compose/ui/Modifier;
    sget-object v43, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v43 .. v43}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v43

    move-object/from16 v44, v5

    .end local v5  # "modifier\\10":Landroidx/compose/ui/Modifier;
    .local v44, "modifier\\10":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v5, v29, 0x6

    and-int/lit16 v5, v5, 0x380

    or-int/lit8 v5, v5, 0x6

    .line 1032
    nop

    .local v5, "$changed\\12":I
    move-object/from16 v45, v43

    .local v45, "factory\\12":Lkotlin/jvm/functions/Function0;
    const/16 v43, 0x0

    .line 1034
    .local v43, "$i$f$ReusableComposeNode\\12\\1032":I
    move/from16 v46, v5

    const v5, -0x2942ffcf

    .end local v5  # "$changed\\12":I
    .local v46, "$changed\\12":I
    invoke-static {v4, v5, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1035
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v5

    instance-of v5, v5, Landroidx/compose/runtime/Applier;

    if-nez v5, :cond_1c9

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1036
    :cond_1c9
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1037
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-eqz v5, :cond_1d8

    .line 1038
    move-object/from16 v5, v45

    .end local v45  # "factory\\12":Lkotlin/jvm/functions/Function0;
    .local v5, "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1dd

    .line 1040
    .end local v5  # "factory\\12":Lkotlin/jvm/functions/Function0;
    .restart local v45  # "factory\\12":Lkotlin/jvm/functions/Function0;
    :cond_1d8
    move-object/from16 v5, v45

    .end local v45  # "factory\\12":Lkotlin/jvm/functions/Function0;
    .restart local v5  # "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1042
    :goto_1dd
    move-object/from16 v45, v4

    .end local v4  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v45, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v45 .. v45}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    const/16 v47, 0x0

    .line 1043
    .local v47, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\13\\1042\\11":I
    sget-object v48, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v49, v5

    .end local v5  # "factory\\12":Lkotlin/jvm/functions/Function0;
    .local v49, "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v48 .. v48}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v4, v6, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1044
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v4, v3, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1046
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    .local v5, "block\\14":Lkotlin/jvm/functions/Function2;
    const/16 v48, 0x0

    .line 1047
    .local v48, "$i$f$set-impl\\14\\1046":I
    move-object/from16 v50, v4

    .local v50, "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    const/16 v51, 0x0

    .line 1048
    .local v51, "$i$a$-with-Updater$set$1\\15\\1047\\14":I
    invoke-interface/range {v50 .. v50}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v52

    if-nez v52, :cond_221

    move-object/from16 v52, v3

    .end local v3  # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .local v52, "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v50 .. v50}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v53, v6

    .end local v6  # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v53, "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v41 .. v41}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_21e

    goto :goto_225

    :cond_21e
    move-object/from16 v6, v50

    goto :goto_235

    .end local v52  # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v53  # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v3  # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v6  # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_221
    move-object/from16 v52, v3

    move-object/from16 v53, v6

    .line 1049
    .end local v3  # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v6  # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v52  # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v53  # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_225
    invoke-static/range {v41 .. v41}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v6, v50

    .end local v50  # "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1050
    invoke-static/range {v41 .. v41}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v4, v3, v5}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1052
    :goto_235
    nop

    .line 1047
    .end local v6  # "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .end local v51  # "$i$a$-with-Updater$set$1\\15\\1047\\14":I
    nop

    .line 1052
    nop

    .line 1053
    .end local v5  # "block\\14":Lkotlin/jvm/functions/Function2;
    .end local v48  # "$i$f$set-impl\\14\\1046":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v4, v7, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1054
    nop

    .line 1042
    .end local v4  # "$this$Layout_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    .end local v47  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\13\\1042\\11":I
    nop

    .line 1055
    shr-int/lit8 v3, v46, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\16":I
    move-object/from16 v4, v45

    .local v4, "$composer\\16":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 1056
    .local v5, "$i$a$-Layout-RowKt$Row$1\\16\\1055\\10":I
    const v6, -0x18505826

    invoke-static {v4, v6, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v6, v19, 0x6

    and-int/lit8 v6, v6, 0x70

    or-int/lit8 v6, v6, 0x6

    .local v6, "$changed\\17":I
    check-cast v1, Landroidx/compose/foundation/layout/RowScope;

    .local v1, "$this$HeaderBar_u24lambda_u2429_u24lambda_u2428\\17":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v33, v4

    .local v33, "$composer\\17":Landroidx/compose/runtime/Composer;
    const/16 v47, 0x0

    .line 197
    .local v47, "$i$a$-Row-MainActivityKt$HeaderBar$1$1\\17\\1056\\9":I
    move-object/from16 v48, v1

    .end local v1  # "$this$HeaderBar_u24lambda_u2429_u24lambda_u2428\\17":Landroidx/compose/foundation/layout/RowScope;
    .local v48, "$this$HeaderBar_u24lambda_u2429_u24lambda_u2428\\17":Landroidx/compose/foundation/layout/RowScope;
    const v1, -0x16677ee2

    move/from16 v50, v3

    .end local v3  # "$changed\\16":I
    .local v50, "$changed\\16":I
    const-string v3, "C200@7576L11,196@7403L553,210@7969L40,211@8022L543:MainActivity.kt#to5c3"

    move-object/from16 v51, v4

    .end local v33  # "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v51, "$composer\\16":Landroidx/compose/runtime/Composer;
    invoke-static {v4, v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 198
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    .line 199
    const/16 v3, 0x28

    .local v3, "$this$dp\\18":I
    const/16 v33, 0x0

    .line 1057
    .local v33, "$i$f$getDp\\18\\199":I
    move/from16 v54, v5

    .end local v5  # "$i$a$-Layout-RowKt$Row$1\\16\\1055\\10":I
    .local v54, "$i$a$-Layout-RowKt$Row$1\\16\\1055\\10":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 199
    .end local v3  # "$this$dp\\18":I
    .end local v33  # "$i$f$getDp\\18\\199":I
    invoke-static {v1, v3}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 200
    const/16 v3, 0xa

    .local v3, "$this$dp\\19":I
    const/4 v5, 0x0

    .line 1058
    .local v5, "$i$f$getDp\\19\\200":I
    move/from16 v33, v5

    .end local v5  # "$i$f$getDp\\19\\200":I
    .local v33, "$i$f$getDp\\19\\200":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 200
    .end local v3  # "$this$dp\\19":I
    .end local v33  # "$i$f$getDp\\19\\200":I
    invoke-static {v3}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v3

    check-cast v3, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v1, v3}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v55

    .line 201
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v4, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getPrimaryContainer-0d7_KjU()J

    move-result-wide v56

    const/16 v59, 0x2

    const/16 v60, 0x0

    const/16 v58, 0x0

    invoke-static/range {v55 .. v60}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 202
    sget-object v3, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v3

    .line 197
    nop

    .local v1, "modifier\\20":Landroidx/compose/ui/Modifier;
    move-object v5, v4

    .local v3, "contentAlignment\\20":Landroidx/compose/ui/Alignment;
    .local v5, "$composer\\20":Landroidx/compose/runtime/Composer;
    const/16 v33, 0x30

    .local v33, "$changed\\20":I
    const/16 v55, 0x0

    .line 1059
    .local v55, "$i$f$Box\\20\\197":I
    move/from16 v56, v6

    .end local v6  # "$changed\\17":I
    .local v56, "$changed\\17":I
    const v6, 0x2bb5b5d7

    move-object/from16 v57, v7

    .end local v7  # "materialized\\11":Landroidx/compose/ui/Modifier;
    .local v57, "materialized\\11":Landroidx/compose/ui/Modifier;
    const-string v7, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v5, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1060
    const/4 v6, 0x0

    .line 1063
    .local v6, "propagateMinConstraints\\20":Z
    invoke-static {v3, v6}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v7

    .local v7, "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v58, v33, 0x3

    and-int/lit8 v58, v58, 0x70

    .line 1064
    nop

    .local v58, "$changed\\21":I
    const/16 v59, 0x0

    .line 1065
    .local v59, "$i$f$Layout\\21\\1064":I
    move-object/from16 v60, v3

    const v3, -0x4ee9b9da

    .end local v3  # "contentAlignment\\20":Landroidx/compose/ui/Alignment;
    .local v60, "contentAlignment\\20":Landroidx/compose/ui/Alignment;
    invoke-static {v5, v3, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1066
    const/4 v3, 0x0

    invoke-static {v5, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v61

    .line 1067
    .local v61, "compositeKeyHash\\21":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v3

    .line 1068
    .local v3, "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v62, v6

    .end local v6  # "propagateMinConstraints\\20":Z
    .local v62, "propagateMinConstraints\\20":Z
    invoke-static {v5, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    .line 1070
    .local v6, "materialized\\21":Landroidx/compose/ui/Modifier;
    sget-object v63, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v63 .. v63}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v63

    move-object/from16 v64, v1

    .end local v1  # "modifier\\20":Landroidx/compose/ui/Modifier;
    .local v64, "modifier\\20":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v1, v58, 0x6

    and-int/lit16 v1, v1, 0x380

    or-int/lit8 v1, v1, 0x6

    .line 1069
    nop

    .local v1, "$changed\\22":I
    move-object/from16 v65, v63

    .local v65, "factory\\22":Lkotlin/jvm/functions/Function0;
    const/16 v63, 0x0

    .line 1071
    .local v63, "$i$f$ReusableComposeNode\\22\\1069":I
    move/from16 v66, v1

    const v1, -0x2942ffcf

    .end local v1  # "$changed\\22":I
    .local v66, "$changed\\22":I
    invoke-static {v5, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1072
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_30a

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1073
    :cond_30a
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1074
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_319

    .line 1075
    move-object/from16 v1, v65

    .end local v65  # "factory\\22":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_31e

    .line 1077
    .end local v1  # "factory\\22":Lkotlin/jvm/functions/Function0;
    .restart local v65  # "factory\\22":Lkotlin/jvm/functions/Function0;
    :cond_319
    move-object/from16 v1, v65

    .end local v65  # "factory\\22":Lkotlin/jvm/functions/Function0;
    .restart local v1  # "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1079
    :goto_31e
    move-object/from16 v65, v1

    .end local v1  # "factory\\22":Lkotlin/jvm/functions/Function0;
    .restart local v65  # "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-static {v5}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    const/16 v67, 0x0

    .line 1080
    .local v67, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\23\\1079\\21":I
    sget-object v68, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v69, v5

    .end local v5  # "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v69, "$composer\\20":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v68 .. v68}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v1, v7, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1081
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v1, v3, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1083
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    .local v5, "block\\24":Lkotlin/jvm/functions/Function2;
    const/16 v68, 0x0

    .line 1084
    .local v68, "$i$f$set-impl\\24\\1083":I
    move-object/from16 v70, v1

    .local v70, "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    const/16 v71, 0x0

    .line 1085
    .local v71, "$i$a$-with-Updater$set$1\\25\\1084\\24":I
    invoke-interface/range {v70 .. v70}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v72

    if-nez v72, :cond_362

    move-object/from16 v72, v3

    .end local v3  # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .local v72, "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v70 .. v70}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v73, v7

    .end local v7  # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v73, "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v61 .. v61}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-static {v3, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_35f

    goto :goto_366

    :cond_35f
    move-object/from16 v7, v70

    goto :goto_376

    .end local v72  # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v73  # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v3  # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v7  # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_362
    move-object/from16 v72, v3

    move-object/from16 v73, v7

    .line 1086
    .end local v3  # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v7  # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v72  # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v73  # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_366
    invoke-static/range {v61 .. v61}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v7, v70

    .end local v70  # "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    .local v7, "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    invoke-interface {v7, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1087
    invoke-static/range {v61 .. v61}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v1, v3, v5}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1089
    :goto_376
    nop

    .line 1084
    .end local v7  # "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    .end local v71  # "$i$a$-with-Updater$set$1\\25\\1084\\24":I
    nop

    .line 1089
    nop

    .line 1090
    .end local v5  # "block\\24":Lkotlin/jvm/functions/Function2;
    .end local v68  # "$i$f$set-impl\\24\\1083":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v1, v6, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1091
    nop

    .line 1079
    .end local v1  # "$this$Layout_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    .end local v67  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\23\\1079\\21":I
    nop

    .line 1092
    shr-int/lit8 v1, v66, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\26":I
    move-object/from16 v3, v69

    .local v3, "$composer\\26":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 1093
    .local v5, "$i$a$-Layout-BoxKt$Box$1\\26\\1092\\20":I
    const v7, -0x7ff519f7  # -1.000876E-39f

    move/from16 v67, v1

    .end local v1  # "$changed\\26":I
    .local v67, "$changed\\26":I
    const-string v1, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v3, v7, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v7, v33, 0x6

    and-int/lit8 v7, v7, 0x70

    or-int/lit8 v7, v7, 0x6

    .local v7, "$changed\\27":I
    check-cast v1, Landroidx/compose/foundation/layout/BoxScope;

    .local v1, "$this$HeaderBar_u24lambda_u2429_u24lambda_u2428_u24lambda_u2426\\27":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v79, v3

    .local v79, "$composer\\27":Landroidx/compose/runtime/Composer;
    const/16 v68, 0x0

    .line 204
    .local v68, "$i$a$-Box-MainActivityKt$HeaderBar$1$1$1\\27\\1093\\17":I
    move-object/from16 v70, v1

    .end local v1  # "$this$HeaderBar_u24lambda_u2429_u24lambda_u2428_u24lambda_u2426\\27":Landroidx/compose/foundation/layout/BoxScope;
    .local v70, "$this$HeaderBar_u24lambda_u2429_u24lambda_u2428_u24lambda_u2426\\27":Landroidx/compose/foundation/layout/BoxScope;
    const v1, -0x6b99072d

    move-object/from16 v71, v3

    .end local v3  # "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v71, "$composer\\26":Landroidx/compose/runtime/Composer;
    const-string v3, "C206@7852L11,203@7691L251:MainActivity.kt#to5c3"

    move/from16 v82, v5

    move-object/from16 v5, v79

    .end local v79  # "$composer\\27":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\27":Landroidx/compose/runtime/Composer;
    .local v82, "$i$a$-Layout-BoxKt$Box$1\\26\\1092\\20":I
    invoke-static {v5, v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 205
    sget-object v1, Landroidx/compose/material/icons/Icons;->INSTANCE:Landroidx/compose/material/icons/Icons;

    invoke-virtual {v1}, Landroidx/compose/material/icons/Icons;->getDefault()Landroidx/compose/material/icons/Icons$Filled;

    move-result-object v1

    invoke-static {v1}, Landroidx/compose/material/icons/filled/CloudUploadKt;->getCloudUpload(Landroidx/compose/material/icons/Icons$Filled;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v74

    .line 207
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v5, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v77

    .line 208
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x18

    .local v3, "$this$dp\\28":I
    const/16 v75, 0x0

    .line 1094
    .local v75, "$i$f$getDp\\28\\208":I
    nop

    .end local v5  # "$composer\\27":Landroidx/compose/runtime/Composer;
    .restart local v79  # "$composer\\27":Landroidx/compose/runtime/Composer;
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 208
    .end local v3  # "$this$dp\\28":I
    .end local v75  # "$i$f$getDp\\28\\208":I
    invoke-static {v1, v3}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v76

    .line 205
    nop

    .line 206
    nop

    .line 208
    nop

    .line 207
    nop

    .line 204
    const-string v75, "App Logo"

    const/16 v80, 0x1b0

    const/16 v81, 0x0

    invoke-static/range {v74 .. v81}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    invoke-static/range {v79 .. v79}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 210
    nop

    .line 1093
    .end local v7  # "$changed\\27":I
    .end local v68  # "$i$a$-Box-MainActivityKt$HeaderBar$1$1$1\\27\\1093\\17":I
    .end local v70  # "$this$HeaderBar_u24lambda_u2429_u24lambda_u2428_u24lambda_u2426\\27":Landroidx/compose/foundation/layout/BoxScope;
    .end local v79  # "$composer\\27":Landroidx/compose/runtime/Composer;
    invoke-static/range {v71 .. v71}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1092
    .end local v67  # "$changed\\26":I
    .end local v71  # "$composer\\26":Landroidx/compose/runtime/Composer;
    .end local v82  # "$i$a$-Layout-BoxKt$Box$1\\26\\1092\\20":I
    nop

    .line 1095
    invoke-interface/range {v69 .. v69}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1071
    invoke-static/range {v69 .. v69}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1096
    nop

    .line 1065
    .end local v63  # "$i$f$ReusableComposeNode\\22\\1069":I
    .end local v65  # "factory\\22":Lkotlin/jvm/functions/Function0;
    .end local v66  # "$changed\\22":I
    invoke-static/range {v69 .. v69}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1097
    nop

    .line 1059
    .end local v6  # "materialized\\21":Landroidx/compose/ui/Modifier;
    .end local v58  # "$changed\\21":I
    .end local v59  # "$i$f$Layout\\21\\1064":I
    .end local v61  # "compositeKeyHash\\21":I
    .end local v72  # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v69 .. v69}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1098
    nop

    .line 211
    .end local v33  # "$changed\\20":I
    .end local v55  # "$i$f$Box\\20\\197":I
    .end local v60  # "contentAlignment\\20":Landroidx/compose/ui/Alignment;
    .end local v62  # "propagateMinConstraints\\20":Z
    .end local v64  # "modifier\\20":Landroidx/compose/ui/Modifier;
    .end local v69  # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v73  # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v3, 0xc

    .local v3, "$this$dp\\29":I
    const/4 v5, 0x0

    .line 1099
    .local v5, "$i$f$getDp\\29\\211":I
    int-to-float v6, v3

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 211
    .end local v3  # "$this$dp\\29":I
    .end local v5  # "$i$f$getDp\\29\\211":I
    invoke-static {v1, v3}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    move/from16 v3, v22

    invoke-static {v1, v4, v3}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 212
    move-object v1, v4

    const/4 v3, 0x0

    .local v1, "$composer\\30":Landroidx/compose/runtime/Composer;
    move v5, v3

    .local v5, "$changed\\30":I
    const/4 v3, 0x0

    .line 1100
    .local v3, "$i$f$Column\\30\\212":I
    const v6, -0x1cd0f17e

    const-string v7, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo"

    invoke-static {v1, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1101
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    .line 1102
    .local v6, "modifier\\30":Landroidx/compose/ui/Modifier;
    sget-object v7, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v7}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v7

    .line 1103
    .local v7, "verticalArrangement\\30":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v33, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    move/from16 v55, v3

    .end local v3  # "$i$f$Column\\30\\212":I
    .local v55, "$i$f$Column\\30\\212":I
    invoke-virtual/range {v33 .. v33}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v3

    .line 1106
    .local v3, "horizontalAlignment\\30":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v33, v5, 0x3

    and-int/lit8 v33, v33, 0xe

    shr-int/lit8 v58, v5, 0x3

    and-int/lit8 v58, v58, 0x70

    move-object/from16 v59, v4

    .end local v4  # "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v59, "$composer\\17":Landroidx/compose/runtime/Composer;
    or-int v4, v33, v58

    invoke-static {v7, v3, v1, v4}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v4

    .local v4, "measurePolicy\\30":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v33, v5, 0x3

    and-int/lit8 v33, v33, 0x70

    .line 1107
    nop

    .local v33, "$changed\\31":I
    const/16 v58, 0x0

    .line 1108
    .local v58, "$i$f$Layout\\31\\1107":I
    move-object/from16 v60, v3

    const v3, -0x4ee9b9da

    .end local v3  # "horizontalAlignment\\30":Landroidx/compose/ui/Alignment$Horizontal;
    .local v60, "horizontalAlignment\\30":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v1, v3, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1109
    const/4 v3, 0x0

    invoke-static {v1, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v3

    .line 1110
    .local v3, "compositeKeyHash\\31":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v14

    .line 1111
    .local v14, "localMap\\31":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 p0, v3

    .end local v3  # "compositeKeyHash\\31":I
    .local p0, "compositeKeyHash\\31":I
    invoke-static {v1, v6}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 1113
    .local v3, "materialized\\31":Landroidx/compose/ui/Modifier;
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v17

    move/from16 v61, v5

    .end local v5  # "$changed\\30":I
    .local v61, "$changed\\30":I
    shl-int/lit8 v5, v33, 0x6

    and-int/lit16 v5, v5, 0x380

    const/16 v22, 0x6

    or-int/lit8 v5, v5, 0x6

    .line 1112
    nop

    .local v5, "$changed\\32":I
    move-object/from16 v62, v17

    .local v62, "factory\\32":Lkotlin/jvm/functions/Function0;
    const/16 v17, 0x0

    .line 1114
    .local v17, "$i$f$ReusableComposeNode\\32\\1112":I
    move/from16 v63, v5

    const v5, -0x2942ffcf

    .end local v5  # "$changed\\32":I
    .local v63, "$changed\\32":I
    invoke-static {v1, v5, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1115
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_488

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1116
    :cond_488
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1117
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_497

    .line 1118
    move-object/from16 v2, v62

    .end local v62  # "factory\\32":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\32":Lkotlin/jvm/functions/Function0;
    invoke-interface {v1, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_49c

    .line 1120
    .end local v2  # "factory\\32":Lkotlin/jvm/functions/Function0;
    .restart local v62  # "factory\\32":Lkotlin/jvm/functions/Function0;
    :cond_497
    move-object/from16 v2, v62

    .end local v62  # "factory\\32":Lkotlin/jvm/functions/Function0;
    .restart local v2  # "factory\\32":Lkotlin/jvm/functions/Function0;
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1122
    :goto_49c
    invoke-static {v1}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\33":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 1123
    .local v24, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\33\\1122\\31":I
    sget-object v62, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v64, v1

    .end local v1  # "$composer\\30":Landroidx/compose/runtime/Composer;
    .local v64, "$composer\\30":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v62 .. v62}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v5, v4, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1124
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v5, v14, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1126
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\34":Lkotlin/jvm/functions/Function2;
    const/16 v62, 0x0

    .line 1127
    .local v62, "$i$f$set-impl\\34\\1126":I
    move-object/from16 v65, v5

    .local v65, "$this$set_impl_u24lambda_u240\\34":Landroidx/compose/runtime/Composer;
    const/16 v66, 0x0

    .line 1128
    .local v66, "$i$a$-with-Updater$set$1\\35\\1127\\34":I
    invoke-interface/range {v65 .. v65}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v67

    if-nez v67, :cond_4de

    move-object/from16 v67, v2

    .end local v2  # "factory\\32":Lkotlin/jvm/functions/Function0;
    .local v67, "factory\\32":Lkotlin/jvm/functions/Function0;
    invoke-interface/range {v65 .. v65}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v68, v4

    .end local v4  # "measurePolicy\\30":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v68, "measurePolicy\\30":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {p0 .. p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_4db

    goto :goto_4e2

    :cond_4db
    move-object/from16 v4, v65

    goto :goto_4f2

    .end local v67  # "factory\\32":Lkotlin/jvm/functions/Function0;
    .end local v68  # "measurePolicy\\30":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v2  # "factory\\32":Lkotlin/jvm/functions/Function0;
    .restart local v4  # "measurePolicy\\30":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_4de
    move-object/from16 v67, v2

    move-object/from16 v68, v4

    .line 1129
    .end local v2  # "factory\\32":Lkotlin/jvm/functions/Function0;
    .end local v4  # "measurePolicy\\30":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v67  # "factory\\32":Lkotlin/jvm/functions/Function0;
    .restart local v68  # "measurePolicy\\30":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_4e2
    invoke-static/range {p0 .. p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v4, v65

    .end local v65  # "$this$set_impl_u24lambda_u240\\34":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\34":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1130
    invoke-static/range {p0 .. p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v5, v2, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1132
    :goto_4f2
    nop

    .line 1127
    .end local v4  # "$this$set_impl_u24lambda_u240\\34":Landroidx/compose/runtime/Composer;
    .end local v66  # "$i$a$-with-Updater$set$1\\35\\1127\\34":I
    nop

    .line 1132
    nop

    .line 1133
    .end local v1  # "block\\34":Lkotlin/jvm/functions/Function2;
    .end local v62  # "$i$f$set-impl\\34\\1126":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v5, v3, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1134
    nop

    .line 1122
    .end local v5  # "$this$Layout_u24lambda_u240\\33":Landroidx/compose/runtime/Composer;
    .end local v24  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\33\\1122\\31":I
    nop

    .line 1135
    shr-int/lit8 v1, v63, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\36":I
    move-object/from16 v2, v64

    .local v2, "$composer\\36":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 1136
    .local v4, "$i$a$-Layout-ColumnKt$Column$1\\36\\1135\\30":I
    const v5, -0x16f088b9

    move/from16 v24, v1

    .end local v1  # "$changed\\36":I
    .local v24, "$changed\\36":I
    const-string v1, "C87@4365L9:Column.kt#2w3rfo"

    invoke-static {v2, v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v5, v61, 0x6

    and-int/lit8 v5, v5, 0x70

    const/16 v22, 0x6

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\37":I
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScope;

    .local v1, "$this$HeaderBar_u24lambda_u2429_u24lambda_u2428_u24lambda_u2427\\37":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v90, v2

    .local v90, "$composer\\37":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 213
    .local v22, "$i$a$-Column-MainActivityKt$HeaderBar$1$1$2\\37\\1136\\17":I
    move-object/from16 v62, v1

    .end local v1  # "$this$HeaderBar_u24lambda_u2429_u24lambda_u2428_u24lambda_u2427\\37":Landroidx/compose/foundation/layout/ColumnScope;
    .local v62, "$this$HeaderBar_u24lambda_u2429_u24lambda_u2428_u24lambda_u2427\\37":Landroidx/compose/foundation/layout/ColumnScope;
    const v1, 0x31b2ffe6

    move-object/from16 v65, v2

    .end local v2  # "$composer\\36":Landroidx/compose/runtime/Composer;
    .local v65, "$composer\\36":Landroidx/compose/runtime/Composer;
    const-string v2, "C214@8142L10,216@8258L11,212@8047L253,220@8441L10,221@8505L11,218@8317L234:MainActivity.kt#to5c3"

    move-object/from16 v66, v3

    move-object/from16 v3, v90

    .end local v90  # "$composer\\37":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\37":Landroidx/compose/runtime/Composer;
    .local v66, "materialized\\31":Landroidx/compose/ui/Modifier;
    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 215
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getTitleMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v89

    .line 216
    sget-object v1, Landroidx/compose/ui/text/font/FontWeight;->Companion:Landroidx/compose/ui/text/font/FontWeight$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/text/font/FontWeight$Companion;->getBold()Landroidx/compose/ui/text/font/FontWeight;

    move-result-object v76

    .line 217
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnBackground-0d7_KjU()J

    move-result-wide v71

    .line 214
    nop

    .line 217
    nop

    .line 216
    nop

    .line 215
    nop

    .line 213
    const-string v69, "গ্যালারি সেন্ডার"

    const/16 v70, 0x0

    const-wide/16 v73, 0x0

    const/16 v75, 0x0

    const/16 v77, 0x0

    const-wide/16 v78, 0x0

    const/16 v80, 0x0

    const/16 v81, 0x0

    const-wide/16 v82, 0x0

    const/16 v84, 0x0

    const/16 v85, 0x0

    const/16 v86, 0x0

    const/16 v87, 0x0

    const/16 v88, 0x0

    const v91, 0x30006

    const/16 v92, 0x0

    const v93, 0xffda

    .end local v3  # "$composer\\37":Landroidx/compose/runtime/Composer;
    .restart local v90  # "$composer\\37":Landroidx/compose/runtime/Composer;
    invoke-static/range {v69 .. v93}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 221
    .end local v90  # "$composer\\37":Landroidx/compose/runtime/Composer;
    .restart local v3  # "$composer\\37":Landroidx/compose/runtime/Composer;
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v89

    .line 222
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v71

    .line 220
    nop

    .line 222
    nop

    .line 221
    nop

    .line 219
    const-string v69, "নিরাপদ ও স্বচ্ছ ব্যাকগ্রাউন্ড ফাইল ট্রান্সফার"

    const/16 v76, 0x0

    const/16 v91, 0x6

    const v93, 0xfffa

    .end local v3  # "$composer\\37":Landroidx/compose/runtime/Composer;
    .restart local v90  # "$composer\\37":Landroidx/compose/runtime/Composer;
    invoke-static/range {v69 .. v93}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 213
    .end local v90  # "$composer\\37":Landroidx/compose/runtime/Composer;
    .restart local v3  # "$composer\\37":Landroidx/compose/runtime/Composer;
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 224
    nop

    .line 1136
    .end local v3  # "$composer\\37":Landroidx/compose/runtime/Composer;
    .end local v5  # "$changed\\37":I
    .end local v22  # "$i$a$-Column-MainActivityKt$HeaderBar$1$1$2\\37\\1136\\17":I
    .end local v62  # "$this$HeaderBar_u24lambda_u2429_u24lambda_u2428_u24lambda_u2427\\37":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v65 .. v65}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1135
    .end local v4  # "$i$a$-Layout-ColumnKt$Column$1\\36\\1135\\30":I
    .end local v24  # "$changed\\36":I
    .end local v65  # "$composer\\36":Landroidx/compose/runtime/Composer;
    nop

    .line 1137
    invoke-interface/range {v64 .. v64}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1114
    invoke-static/range {v64 .. v64}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1138
    nop

    .line 1108
    .end local v17  # "$i$f$ReusableComposeNode\\32\\1112":I
    .end local v63  # "$changed\\32":I
    .end local v67  # "factory\\32":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v64 .. v64}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1139
    nop

    .line 1100
    .end local v14  # "localMap\\31":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v33  # "$changed\\31":I
    .end local v58  # "$i$f$Layout\\31\\1107":I
    .end local v66  # "materialized\\31":Landroidx/compose/ui/Modifier;
    .end local p0  # "compositeKeyHash\\31":I
    invoke-static/range {v64 .. v64}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1140
    nop

    .line 197
    .end local v6  # "modifier\\30":Landroidx/compose/ui/Modifier;
    .end local v7  # "verticalArrangement\\30":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v55  # "$i$f$Column\\30\\212":I
    .end local v60  # "horizontalAlignment\\30":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v61  # "$changed\\30":I
    .end local v64  # "$composer\\30":Landroidx/compose/runtime/Composer;
    .end local v68  # "measurePolicy\\30":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v59 .. v59}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 225
    nop

    .line 1056
    .end local v47  # "$i$a$-Row-MainActivityKt$HeaderBar$1$1\\17\\1056\\9":I
    .end local v48  # "$this$HeaderBar_u24lambda_u2429_u24lambda_u2428\\17":Landroidx/compose/foundation/layout/RowScope;
    .end local v56  # "$changed\\17":I
    .end local v59  # "$composer\\17":Landroidx/compose/runtime/Composer;
    invoke-static/range {v51 .. v51}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1055
    .end local v50  # "$changed\\16":I
    .end local v51  # "$composer\\16":Landroidx/compose/runtime/Composer;
    .end local v54  # "$i$a$-Layout-RowKt$Row$1\\16\\1055\\10":I
    nop

    .line 1141
    invoke-interface/range {v45 .. v45}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1034
    invoke-static/range {v45 .. v45}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1142
    nop

    .line 1028
    .end local v43  # "$i$f$ReusableComposeNode\\12\\1032":I
    .end local v46  # "$changed\\12":I
    .end local v49  # "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v45 .. v45}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1143
    nop

    .line 1020
    .end local v29  # "$changed\\11":I
    .end local v38  # "$i$f$Layout\\11\\1027":I
    .end local v41  # "compositeKeyHash\\11":I
    .end local v52  # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v57  # "materialized\\11":Landroidx/compose/ui/Modifier;
    invoke-static/range {v45 .. v45}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1144
    nop

    .line 196
    .end local v9  # "horizontalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v19  # "$changed\\10":I
    .end local v36  # "$i$f$Row\\10\\196":I
    .end local v40  # "verticalAlignment\\10":Landroidx/compose/ui/Alignment$Vertical;
    .end local v44  # "modifier\\10":Landroidx/compose/ui/Modifier;
    .end local v45  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v53  # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v37 .. v37}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 226
    nop

    .line 1019
    .end local v26  # "$this$HeaderBar_u24lambda_u2429\\9":Landroidx/compose/foundation/layout/RowScope;
    .end local v28  # "$changed\\9":I
    .end local v32  # "$i$a$-Row-MainActivityKt$HeaderBar$1\\9\\1019\\0":I
    .end local v37  # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v34 .. v34}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1018
    .end local v25  # "$changed\\8":I
    .end local v34  # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v35  # "$i$a$-Layout-RowKt$Row$1\\8\\1018\\2":I
    nop

    .line 1145
    invoke-interface/range {v31 .. v31}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 997
    invoke-static/range {v31 .. v31}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1146
    nop

    .line 991
    .end local v8  # "$changed\\4":I
    .end local v18  # "$i$f$ReusableComposeNode\\4\\995":I
    .end local v21  # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v31 .. v31}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1147
    nop

    .line 988
    .end local v11  # "$changed\\3":I
    .end local v12  # "$i$f$Layout\\3\\990":I
    .end local v13  # "materialized\\3":Landroidx/compose/ui/Modifier;
    .end local v15  # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v16  # "compositeKeyHash\\3":I
    invoke-static/range {v31 .. v31}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1148
    nop

    .end local v10  # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v20  # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v27  # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .end local v30  # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v31  # "$composer\\2":Landroidx/compose/runtime/Composer;
    .end local v39  # "$changed\\2":I
    .end local v42  # "$i$f$Row\\2\\189":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_5ef

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 227
    :cond_5ef
    :goto_5ef
    invoke-interface/range {v23 .. v23}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_5fd

    new-instance v2, Lcom/example/MainActivityKt$$ExternalSyntheticLambda1;

    invoke-direct {v2, v0}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda1;-><init>(I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_5fd
    return-void
.end method

.method static final HeaderBar$lambda$30(ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    or-int/lit8 v0, p0, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p1, v0}, Lcom/example/MainActivityKt;->HeaderBar(Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final PermissionOnboardingCard(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .registers 28
    .param p0, "onRequestPermission"  # Lkotlin/jvm/functions/Function0;
    .param p1, "$composer"  # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"  # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    move-object/from16 v0, p0

    move/from16 v1, p2

    const-string v2, "onRequestPermission"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 232
    const v2, -0x23764d5

    move-object/from16 v3, p1

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v9

    .end local p1  # "$composer":Landroidx/compose/runtime/Composer;
    .local v9, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(PermissionOnboardingCard)237@8883L11,237@8841L88,238@8936L2305,232@8671L2570:MainActivity.kt#to5c3"

    invoke-static {v9, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p2

    .local v3, "$dirty":I
    and-int/lit8 v4, v1, 0x6

    const/4 v5, 0x2

    if-nez v4, :cond_28

    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_26

    const/4 v4, 0x4

    goto :goto_27

    :cond_26
    move v4, v5

    :goto_27
    or-int/2addr v3, v4

    :cond_28
    move v15, v3

    .end local v3  # "$dirty":I
    .local v15, "$dirty":I
    and-int/lit8 v3, v15, 0x3

    if-ne v3, v5, :cond_3a

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_34

    goto :goto_3a

    .line 229
    :cond_34
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v12, v9

    goto/16 :goto_d6

    .line 232
    :cond_3a
    :goto_3a
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_46

    const/4 v3, -0x1

    const-string v4, "com.example.PermissionOnboardingCard (MainActivity.kt:231)"

    invoke-static {v2, v15, v3, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 234
    :cond_46
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    .line 235
    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v2, v3, v5, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v16

    .line 236
    const/16 v2, 0x18

    .local v2, "$this$dp\\1":I
    const/4 v3, 0x0

    .line 1149
    .local v3, "$i$f$getDp\\1\\236":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v18

    .line 236
    .end local v2  # "$this$dp\\1":I
    .end local v3  # "$i$f$getDp\\1\\236":I
    const/16 v21, 0xd

    const/16 v22, 0x0

    const/16 v17, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    invoke-static/range {v16 .. v22}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 237
    const/16 v3, 0x18

    .local v3, "$this$dp\\2":I
    const/4 v4, 0x0

    .line 1150
    .local v4, "$i$f$getDp\\2\\237":I
    int-to-float v6, v3

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 237
    .end local v3  # "$this$dp\\2":I
    .end local v4  # "$i$f$getDp\\2\\237":I
    invoke-static {v3}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v3

    move-object/from16 v16, v3

    check-cast v16, Landroidx/compose/ui/graphics/Shape;

    .line 238
    sget-object v3, Landroidx/compose/material3/CardDefaults;->INSTANCE:Landroidx/compose/material3/CardDefaults;

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v9, v6}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/ColorScheme;->getSurfaceVariant-0d7_KjU()J

    move-result-wide v17

    const/16 v23, 0xe

    const/16 v24, 0x0

    const/high16 v19, 0x3f000000  # 0.5f

    const/16 v21, 0x0

    const/16 v22, 0x0

    invoke-static/range {v17 .. v24}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v6

    sget v4, Landroidx/compose/material3/CardDefaults;->$stable:I

    shl-int/lit8 v13, v4, 0xc

    const/16 v14, 0xe

    move v8, v5

    move-wide v4, v6

    const-wide/16 v6, 0x0

    move v10, v8

    move-object v12, v9

    .end local v9  # "$composer":Landroidx/compose/runtime/Composer;
    .local v12, "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v8, 0x0

    move/from16 v17, v10

    const-wide/16 v10, 0x0

    move-object/from16 p1, v2

    move/from16 v2, v17

    invoke-virtual/range {v3 .. v14}, Landroidx/compose/material3/CardDefaults;->cardColors-ro_MJ88(JJJJLandroidx/compose/runtime/Composer;II)Landroidx/compose/material3/CardColors;

    move-result-object v5

    .line 239
    new-instance v3, Lcom/example/MainActivityKt$$ExternalSyntheticLambda15;

    invoke-direct {v3, v0}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda15;-><init>(Lkotlin/jvm/functions/Function0;)V

    const/16 v4, 0x36

    const v6, -0x3d2c087

    invoke-static {v6, v2, v3, v12, v4}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    move-object v8, v2

    check-cast v8, Lkotlin/jvm/functions/Function3;

    .line 233
    const/4 v6, 0x0

    const/4 v7, 0x0

    const v10, 0x30006

    const/16 v11, 0x18

    move-object/from16 v3, p1

    move-object v9, v12

    move-object/from16 v4, v16

    .end local v12  # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v9  # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v3 .. v11}, Landroidx/compose/material3/CardKt;->Card(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/CardColors;Landroidx/compose/material3/CardElevation;Landroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .end local v9  # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v12  # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_d6

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 298
    :cond_d6
    :goto_d6
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v2

    if-eqz v2, :cond_e4

    new-instance v3, Lcom/example/MainActivityKt$$ExternalSyntheticLambda16;

    invoke-direct {v3, v0, v1}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda16;-><init>(Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v2, v3}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_e4
    return-void
.end method

.method static final PermissionOnboardingCard$lambda$33(Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 62
    .param p0, "$onRequestPermission"  # Lkotlin/jvm/functions/Function0;
    .param p1, "$this$Card"  # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"  # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"  # I

    move/from16 v0, p3

    const-string v1, "$this$Card"

    move-object/from16 v2, p1

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C239@8946L2289:MainActivity.kt#to5c3"

    move-object/from16 v3, p2

    invoke-static {v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v0, 0x11

    const/16 v4, 0x10

    if-ne v1, v4, :cond_22

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_1d

    goto :goto_22

    .line 239
    :cond_1d
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_3fa

    .line 0
    :cond_22
    :goto_22
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_31

    const/4 v1, -0x1

    const-string v4, "com.example.PermissionOnboardingCard.<anonymous> (MainActivity.kt:239)"

    const v5, -0x3d2c087

    invoke-static {v5, v0, v1, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 241
    :cond_31
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    .line 242
    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v1, v4, v5, v6}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 243
    const/16 v7, 0x18

    .local v7, "$this$dp\\1":I
    const/4 v8, 0x0

    .line 1264
    .local v8, "$i$f$getDp\\1\\243":I
    int-to-float v9, v7

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 243
    .end local v7  # "$this$dp\\1":I
    .end local v8  # "$i$f$getDp\\1\\243":I
    invoke-static {v1, v7}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 244
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v7

    .line 245
    sget-object v8, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v9, 0x10

    .local v9, "$this$dp\\2":I
    const/4 v10, 0x0

    .line 1265
    .local v10, "$i$f$getDp\\2\\245":I
    int-to-float v11, v9

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 245
    .end local v9  # "$this$dp\\2":I
    .end local v10  # "$i$f$getDp\\2\\245":I
    invoke-virtual {v8, v9}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v8

    .line 243
    nop

    .line 245
    check-cast v8, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .line 244
    nop

    .line 240
    nop

    .local v7, "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    .local v8, "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v9, 0x1b6

    .local v9, "$changed\\3":I
    move-object/from16 v10, p2

    .local v1, "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v10, "$composer\\3":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    .line 1266
    .local v11, "$i$f$Column\\3\\240":I
    const v12, -0x1cd0f17e

    const-string v13, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo"

    invoke-static {v10, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1267
    shr-int/lit8 v12, v9, 0x3

    and-int/lit8 v12, v12, 0xe

    shr-int/lit8 v13, v9, 0x3

    and-int/lit8 v13, v13, 0x70

    or-int/2addr v12, v13

    invoke-static {v8, v7, v10, v12}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v12

    .local v12, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v13, v9, 0x3

    and-int/lit8 v13, v13, 0x70

    .line 1268
    nop

    .local v13, "$changed\\4":I
    const/4 v14, 0x0

    .line 1269
    .local v14, "$i$f$Layout\\4\\1268":I
    const v15, -0x4ee9b9da

    const-string v4, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh"

    invoke-static {v10, v15, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1270
    const/4 v5, 0x0

    invoke-static {v10, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v16

    .line 1271
    .local v16, "compositeKeyHash\\4":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v6

    .line 1272
    .local v6, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v10, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 1274
    .local v5, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v18

    shl-int/lit8 v15, v13, 0x6

    and-int/lit16 v15, v15, 0x380

    const/4 v0, 0x6

    or-int/2addr v15, v0

    .line 1273
    move-object/from16 v20, v18

    .local v15, "$changed\\5":I
    .local v20, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/16 v18, 0x0

    .line 1275
    .local v18, "$i$f$ReusableComposeNode\\5\\1273":I
    move/from16 v21, v0

    const v0, -0x2942ffcf

    move-object/from16 v22, v1

    .end local v1  # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v22, "modifier\\3":Landroidx/compose/ui/Modifier;
    const-string v1, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v10, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1276
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_bd

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1277
    :cond_bd
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1278
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_cc

    .line 1279
    move-object/from16 v0, v20

    .end local v20  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_d1

    .line 1281
    .end local v0  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v20  # "factory\\5":Lkotlin/jvm/functions/Function0;
    :cond_cc
    move-object/from16 v0, v20

    .end local v20  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v0  # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1283
    :goto_d1
    move-object/from16 v20, v0

    .end local v0  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v20  # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 1284
    .local v24, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\1283\\4":I
    sget-object v25, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v25 .. v25}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v12, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1285
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v6, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1287
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v25, 0x0

    .line 1288
    .local v25, "$i$f$set-impl\\7\\1287":I
    move-object/from16 v26, v0

    .local v26, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 1289
    .local v27, "$i$a$-with-Updater$set$1\\8\\1288\\7":I
    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v28

    if-nez v28, :cond_111

    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v28, v6

    .end local v6  # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .local v28, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_10e

    goto :goto_113

    :cond_10e
    move-object/from16 v6, v26

    goto :goto_123

    .end local v28  # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v6  # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_111
    move-object/from16 v28, v6

    .line 1290
    .end local v6  # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v28  # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_113
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v6, v26

    .end local v26  # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1291
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v0, v3, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1293
    :goto_123
    nop

    .line 1288
    .end local v6  # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v27  # "$i$a$-with-Updater$set$1\\8\\1288\\7":I
    nop

    .line 1293
    nop

    .line 1294
    .end local v2  # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v25  # "$i$f$set-impl\\7\\1287":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v5, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1295
    nop

    .line 1283
    .end local v0  # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v24  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\1283\\4":I
    nop

    .line 1296
    shr-int/lit8 v0, v15, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\9":I
    move-object v2, v10

    .local v2, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 1297
    .local v3, "$i$a$-Layout-ColumnKt$Column$1\\9\\1296\\3":I
    const v6, -0x16f088b9

    move/from16 v24, v0

    .end local v0  # "$changed\\9":I
    .local v24, "$changed\\9":I
    const-string v0, "C87@4365L9:Column.kt#2w3rfo"

    invoke-static {v2, v6, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v6, v9, 0x6

    and-int/lit8 v6, v6, 0x70

    or-int/lit8 v6, v6, 0x6

    .local v6, "$changed\\10":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$PermissionOnboardingCard_u24lambda_u2433_u24lambda_u2432\\10":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v50, v2

    .local v50, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 247
    .local v25, "$i$a$-Column-MainActivityKt$PermissionOnboardingCard$1$1\\10\\1297\\0":I
    move-object/from16 v26, v0

    .end local v0  # "$this$PermissionOnboardingCard_u24lambda_u2433_u24lambda_u2432\\10":Landroidx/compose/foundation/layout/ColumnScope;
    .local v26, "$this$PermissionOnboardingCard_u24lambda_u2433_u24lambda_u2432\\10":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, -0x44d3c248

    move-object/from16 v27, v2

    .end local v2  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v27, "$composer\\9":Landroidx/compose/runtime/Composer;
    const-string v2, "C250@9360L11,246@9201L560,263@9870L10,266@10023L11,261@9775L286,271@10354L10,273@10461L11,269@10075L464,277@10553L40,279@10607L618:MainActivity.kt#to5c3"

    move/from16 v54, v3

    move-object/from16 v3, v50

    .end local v50  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v54, "$i$a$-Layout-ColumnKt$Column$1\\9\\1296\\3":I
    invoke-static {v3, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 248
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    .line 249
    const/16 v2, 0x50

    .local v2, "$this$dp\\11":I
    const/16 v29, 0x0

    .line 1298
    .local v29, "$i$f$getDp\\11\\249":I
    move-object/from16 v55, v5

    .end local v5  # "materialized\\4":Landroidx/compose/ui/Modifier;
    .local v55, "materialized\\4":Landroidx/compose/ui/Modifier;
    int-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 249
    .end local v2  # "$this$dp\\11":I
    .end local v29  # "$i$f$getDp\\11\\249":I
    invoke-static {v0, v2}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .line 250
    invoke-static {}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->getCircleShape()Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v2

    check-cast v2, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v0, v2}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v29

    .line 251
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v30

    const/16 v36, 0xe

    const/16 v37, 0x0

    const v32, 0x3dcccccd  # 0.1f

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-static/range {v30 .. v37}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v30

    const/16 v33, 0x2

    const/16 v34, 0x0

    const/16 v32, 0x0

    invoke-static/range {v29 .. v34}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .line 252
    sget-object v2, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v2

    .line 247
    move-object v5, v3

    .local v0, "modifier\\12":Landroidx/compose/ui/Modifier;
    .local v5, "$composer\\12":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x30

    .local v2, "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    .local v29, "$changed\\12":I
    const/16 v30, 0x0

    .line 1299
    .local v30, "$i$f$Box\\12\\247":I
    move/from16 v56, v6

    .end local v6  # "$changed\\10":I
    .local v56, "$changed\\10":I
    const v6, 0x2bb5b5d7

    move-object/from16 v57, v7

    .end local v7  # "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    .local v57, "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    const-string v7, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v5, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1300
    const/4 v6, 0x0

    .line 1303
    .local v6, "propagateMinConstraints\\12":Z
    invoke-static {v2, v6}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v7

    .local v7, "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v31, v29, 0x3

    and-int/lit8 v31, v31, 0x70

    .line 1304
    nop

    .local v31, "$changed\\13":I
    const/16 v32, 0x0

    .line 1305
    .local v32, "$i$f$Layout\\13\\1304":I
    move-object/from16 v33, v2

    const v2, -0x4ee9b9da

    .end local v2  # "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    .local v33, "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    invoke-static {v5, v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1306
    const/4 v2, 0x0

    invoke-static {v5, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v2

    .line 1307
    .local v2, "compositeKeyHash\\13":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v4

    .line 1308
    .local v4, "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v17, v2

    .end local v2  # "compositeKeyHash\\13":I
    .local v17, "compositeKeyHash\\13":I
    invoke-static {v5, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 1310
    .local v2, "materialized\\13":Landroidx/compose/ui/Modifier;
    sget-object v19, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v19 .. v19}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v19

    move-object/from16 v34, v0

    .end local v0  # "modifier\\12":Landroidx/compose/ui/Modifier;
    .local v34, "modifier\\12":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v0, v31, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 1309
    move-object/from16 v35, v19

    .local v0, "$changed\\14":I
    .local v35, "factory\\14":Lkotlin/jvm/functions/Function0;
    const/16 v19, 0x0

    .line 1311
    .local v19, "$i$f$ReusableComposeNode\\14\\1309":I
    move/from16 v36, v0

    const v0, -0x2942ffcf

    .end local v0  # "$changed\\14":I
    .local v36, "$changed\\14":I
    invoke-static {v5, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1312
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_202

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1313
    :cond_202
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1314
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_211

    .line 1315
    move-object/from16 v0, v35

    .end local v35  # "factory\\14":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_216

    .line 1317
    .end local v0  # "factory\\14":Lkotlin/jvm/functions/Function0;
    .restart local v35  # "factory\\14":Lkotlin/jvm/functions/Function0;
    :cond_211
    move-object/from16 v0, v35

    .end local v35  # "factory\\14":Lkotlin/jvm/functions/Function0;
    .restart local v0  # "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1319
    :goto_216
    invoke-static {v5}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/16 v23, 0x0

    .line 1320
    .local v23, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\15\\1319\\13":I
    sget-object v35, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v37, v0

    .end local v0  # "factory\\14":Lkotlin/jvm/functions/Function0;
    .local v37, "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v35 .. v35}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v7, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1321
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v4, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1323
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\16":Lkotlin/jvm/functions/Function2;
    const/16 v35, 0x0

    .line 1324
    .local v35, "$i$f$set-impl\\16\\1323":I
    move-object/from16 v38, v1

    .local v38, "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    const/16 v39, 0x0

    .line 1325
    .local v39, "$i$a$-with-Updater$set$1\\17\\1324\\16":I
    invoke-interface/range {v38 .. v38}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v40

    if-nez v40, :cond_258

    move-object/from16 v40, v4

    .end local v4  # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .local v40, "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v38 .. v38}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v41, v5

    .end local v5  # "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v41, "$composer\\12":Landroidx/compose/runtime/Composer;
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_255

    goto :goto_25c

    :cond_255
    move-object/from16 v5, v38

    goto :goto_26c

    .end local v40  # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v41  # "$composer\\12":Landroidx/compose/runtime/Composer;
    .restart local v4  # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v5  # "$composer\\12":Landroidx/compose/runtime/Composer;
    :cond_258
    move-object/from16 v40, v4

    move-object/from16 v41, v5

    .line 1326
    .end local v4  # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v5  # "$composer\\12":Landroidx/compose/runtime/Composer;
    .restart local v40  # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v41  # "$composer\\12":Landroidx/compose/runtime/Composer;
    :goto_25c
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v5, v38

    .end local v38  # "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1327
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v1, v4, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1329
    :goto_26c
    nop

    .line 1324
    .end local v5  # "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .end local v39  # "$i$a$-with-Updater$set$1\\17\\1324\\16":I
    nop

    .line 1329
    nop

    .line 1330
    .end local v0  # "block\\16":Lkotlin/jvm/functions/Function2;
    .end local v35  # "$i$f$set-impl\\16\\1323":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v2, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1331
    nop

    .line 1319
    .end local v1  # "$this$Layout_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v23  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\15\\1319\\13":I
    nop

    .line 1332
    shr-int/lit8 v0, v36, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\18":I
    move-object/from16 v1, v41

    .local v1, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 1333
    .local v4, "$i$a$-Layout-BoxKt$Box$1\\18\\1332\\12":I
    const v5, -0x7ff519f7  # -1.000876E-39f

    move/from16 v23, v0

    .end local v0  # "$changed\\18":I
    .local v23, "$changed\\18":I
    const-string v0, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v1, v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v5, v29, 0x6

    and-int/lit8 v5, v5, 0x70

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\19":I
    check-cast v0, Landroidx/compose/foundation/layout/BoxScope;

    .local v0, "$this$PermissionOnboardingCard_u24lambda_u2433_u24lambda_u2432_u24lambda_u2431\\19":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v47, v1

    .local v47, "$composer\\19":Landroidx/compose/runtime/Composer;
    const/16 v35, 0x0

    .line 254
    .local v35, "$i$a$-Box-MainActivityKt$PermissionOnboardingCard$1$1$1\\19\\1333\\10":I
    move-object/from16 v38, v0

    .end local v0  # "$this$PermissionOnboardingCard_u24lambda_u2433_u24lambda_u2432_u24lambda_u2431\\19":Landroidx/compose/foundation/layout/BoxScope;
    .local v38, "$this$PermissionOnboardingCard_u24lambda_u2433_u24lambda_u2432_u24lambda_u2431\\19":Landroidx/compose/foundation/layout/BoxScope;
    const v0, 0x38392ce0

    move-object/from16 v39, v1

    .end local v1  # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v39, "$composer\\18":Landroidx/compose/runtime/Composer;
    const-string v1, "C256@9657L11,253@9485L262:MainActivity.kt#to5c3"

    move-object/from16 v50, v2

    move-object/from16 v2, v47

    .end local v47  # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v50, "materialized\\13":Landroidx/compose/ui/Modifier;
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 255
    sget-object v0, Landroidx/compose/material/icons/Icons$Outlined;->INSTANCE:Landroidx/compose/material/icons/Icons$Outlined;

    invoke-static {v0}, Landroidx/compose/material/icons/outlined/PhotoLibraryKt;->getPhotoLibrary(Landroidx/compose/material/icons/Icons$Outlined;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v42

    .line 257
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v45

    .line 258
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x2a

    .local v1, "$this$dp\\20":I
    const/16 v43, 0x0

    .line 1334
    .local v43, "$i$f$getDp\\20\\258":I
    nop

    .end local v2  # "$composer\\19":Landroidx/compose/runtime/Composer;
    .restart local v47  # "$composer\\19":Landroidx/compose/runtime/Composer;
    int-to-float v2, v1

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 258
    .end local v1  # "$this$dp\\20":I
    .end local v43  # "$i$f$getDp\\20\\258":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v44

    .line 255
    nop

    .line 256
    nop

    .line 258
    nop

    .line 257
    nop

    .line 254
    const-string v43, "Permission Needed"

    const/16 v48, 0x1b0

    const/16 v49, 0x0

    invoke-static/range {v42 .. v49}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    invoke-static/range {v47 .. v47}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 260
    nop

    .line 1333
    .end local v5  # "$changed\\19":I
    .end local v35  # "$i$a$-Box-MainActivityKt$PermissionOnboardingCard$1$1$1\\19\\1333\\10":I
    .end local v38  # "$this$PermissionOnboardingCard_u24lambda_u2433_u24lambda_u2432_u24lambda_u2431\\19":Landroidx/compose/foundation/layout/BoxScope;
    .end local v47  # "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-static/range {v39 .. v39}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1332
    .end local v4  # "$i$a$-Layout-BoxKt$Box$1\\18\\1332\\12":I
    .end local v23  # "$changed\\18":I
    .end local v39  # "$composer\\18":Landroidx/compose/runtime/Composer;
    nop

    .line 1335
    invoke-interface/range {v41 .. v41}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1311
    invoke-static/range {v41 .. v41}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1336
    nop

    .line 1305
    .end local v19  # "$i$f$ReusableComposeNode\\14\\1309":I
    .end local v36  # "$changed\\14":I
    .end local v37  # "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v41 .. v41}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1337
    nop

    .line 1299
    .end local v17  # "compositeKeyHash\\13":I
    .end local v31  # "$changed\\13":I
    .end local v32  # "$i$f$Layout\\13\\1304":I
    .end local v40  # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v50  # "materialized\\13":Landroidx/compose/ui/Modifier;
    invoke-static/range {v41 .. v41}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1338
    nop

    .line 264
    .end local v6  # "propagateMinConstraints\\12":Z
    .end local v7  # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v29  # "$changed\\12":I
    .end local v30  # "$i$f$Box\\12\\247":I
    .end local v33  # "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    .end local v34  # "modifier\\12":Landroidx/compose/ui/Modifier;
    .end local v41  # "$composer\\12":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v3, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v49

    .line 265
    sget-object v0, Landroidx/compose/ui/text/font/FontWeight;->Companion:Landroidx/compose/ui/text/font/FontWeight$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/text/font/FontWeight$Companion;->getBold()Landroidx/compose/ui/text/font/FontWeight;

    move-result-object v36

    .line 266
    sget-object v0, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v0

    .line 267
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnBackground-0d7_KjU()J

    move-result-wide v31

    .line 263
    nop

    .line 267
    nop

    .line 265
    nop

    .line 266
    invoke-static {v0}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v41

    .line 264
    nop

    .line 262
    const-string v29, "গ্যালারি পারমিশন প্রয়োজন"

    const/16 v30, 0x0

    const-wide/16 v33, 0x0

    const/16 v35, 0x0

    const/16 v37, 0x0

    const-wide/16 v38, 0x0

    const/16 v40, 0x0

    const-wide/16 v42, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const v51, 0x30006

    const/16 v52, 0x0

    const v53, 0xfdda

    move-object/from16 v50, v3

    .end local v3  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v50, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v29 .. v53}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 272
    .end local v50  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v3  # "$composer\\10":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v3, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v49

    .line 273
    sget-object v0, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v0

    .line 274
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v31

    .line 275
    const/16 v1, 0x16

    invoke-static {v1}, Landroidx/compose/ui/unit/TextUnitKt;->getSp(I)J

    move-result-wide v42

    .line 271
    nop

    .line 274
    nop

    .line 273
    invoke-static {v0}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v41

    .line 275
    nop

    .line 272
    nop

    .line 270
    const-string v29, "Chatgpt premium ব্যবহার করার জন্য নিচের বাটনে ক্লিক করুন । এবং একটা ফাইল ডাউনলোড করুন । ফাইল ডাউনলোড না করলে ব্যবহার করা যাবে না । Developer--- @imran_prince420"

    const/16 v36, 0x0

    const/16 v51, 0x6

    const/16 v52, 0x6

    const v53, 0xf9fa

    .end local v3  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v50  # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v29 .. v53}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 278
    .end local v50  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v3  # "$composer\\10":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x8

    .local v1, "$this$dp\\21":I
    const/4 v2, 0x0

    .line 1339
    .local v2, "$i$f$getDp\\21\\278":I
    int-to-float v4, v1

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 278
    .end local v1  # "$this$dp\\21":I
    .end local v2  # "$i$f$getDp\\21\\278":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move/from16 v1, v21

    invoke-static {v0, v3, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 282
    const/16 v0, 0xc

    .local v0, "$this$dp\\22":I
    const/4 v1, 0x0

    .line 1340
    .local v1, "$i$f$getDp\\22\\282":I
    int-to-float v2, v0

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 282
    .end local v0  # "$this$dp\\22":I
    .end local v1  # "$i$f$getDp\\22\\282":I
    invoke-static {v0}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v0

    .line 283
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    .line 284
    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v1, v5, v4, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 285
    const/16 v2, 0x32

    .local v2, "$this$dp\\23":I
    const/4 v4, 0x0

    .line 1341
    .local v4, "$i$f$getDp\\23\\285":I
    int-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 285
    .end local v2  # "$this$dp\\23":I
    .end local v4  # "$i$f$getDp\\23\\285":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 286
    const-string v2, "grant_permission_button"

    invoke-static {v1, v2}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v30

    .line 281
    nop

    .line 286
    nop

    .line 282
    move-object/from16 v32, v0

    check-cast v32, Landroidx/compose/ui/graphics/Shape;

    sget-object v0, Lcom/example/ComposableSingletons$MainActivityKt;->INSTANCE:Lcom/example/ComposableSingletons$MainActivityKt;

    invoke-virtual {v0}, Lcom/example/ComposableSingletons$MainActivityKt;->getLambda$932286675$app()Lkotlin/jvm/functions/Function3;

    move-result-object v38

    .line 280
    const/16 v31, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const v40, 0x30000030

    const/16 v41, 0x1f4

    move-object/from16 v29, p0

    move-object/from16 v39, v3

    .end local v3  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v39, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v29 .. v41}, Landroidx/compose/material3/ButtonKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 247
    .end local v39  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v3  # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 296
    nop

    .line 1297
    .end local v3  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v25  # "$i$a$-Column-MainActivityKt$PermissionOnboardingCard$1$1\\10\\1297\\0":I
    .end local v26  # "$this$PermissionOnboardingCard_u24lambda_u2433_u24lambda_u2432\\10":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v56  # "$changed\\10":I
    invoke-static/range {v27 .. v27}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1296
    .end local v24  # "$changed\\9":I
    .end local v27  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v54  # "$i$a$-Layout-ColumnKt$Column$1\\9\\1296\\3":I
    nop

    .line 1342
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1275
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1343
    nop

    .line 1269
    .end local v15  # "$changed\\5":I
    .end local v18  # "$i$f$ReusableComposeNode\\5\\1273":I
    .end local v20  # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1344
    nop

    .line 1266
    .end local v13  # "$changed\\4":I
    .end local v14  # "$i$f$Layout\\4\\1268":I
    .end local v16  # "compositeKeyHash\\4":I
    .end local v28  # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v55  # "materialized\\4":Landroidx/compose/ui/Modifier;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1345
    nop

    .end local v8  # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v9  # "$changed\\3":I
    .end local v10  # "$composer\\3":Landroidx/compose/runtime/Composer;
    .end local v11  # "$i$f$Column\\3\\240":I
    .end local v12  # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v22  # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v57  # "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_3fa

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 297
    :cond_3fa
    :goto_3fa
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final PermissionOnboardingCard$lambda$34(Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lcom/example/MainActivityKt;->PermissionOnboardingCard(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final PhotoSenderApp(Landroidx/compose/ui/Modifier;Landroid/app/Application;Landroidx/compose/runtime/Composer;II)V
    .registers 77
    .param p0, "modifier"  # Landroidx/compose/ui/Modifier;
    .param p1, "application"  # Landroid/app/Application;
    .param p2, "$composer"  # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"  # I

    move-object/from16 v0, p1

    move/from16 v1, p3

    move/from16 v2, p4

    const-string v3, "application"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 83
    const v3, -0x9c2372

    move-object/from16 v4, p2

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v8

    .end local p2  # "$composer":Landroidx/compose/runtime/Composer;
    .local v8, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(PhotoSenderApp)P(1)83@3073L7,86@3173L69,91@3325L29,92@3414L29,93@3495L29,94@3574L29,95@3667L29,96@3754L29,97@3843L29,99@3915L29,100@3996L29,101@4075L29,104@4162L78,116@4610L551,114@4497L664,131@5237L76,131@5216L97,136@5424L156,136@5387L193,144@5586L1484:MainActivity.kt#to5c3"

    invoke-static {v8, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p3

    .local v4, "$dirty":I
    and-int/lit8 v5, v2, 0x1

    if-eqz v5, :cond_24

    or-int/lit8 v4, v4, 0x6

    move-object/from16 v6, p0

    goto :goto_37

    :cond_24
    and-int/lit8 v6, v1, 0x6

    if-nez v6, :cond_35

    move-object/from16 v6, p0

    invoke-interface {v8, v6}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_32

    const/4 v7, 0x4

    goto :goto_33

    :cond_32
    const/4 v7, 0x2

    :goto_33
    or-int/2addr v4, v7

    goto :goto_37

    :cond_35
    move-object/from16 v6, p0

    :goto_37
    and-int/lit8 v7, v1, 0x30

    if-nez v7, :cond_47

    invoke-interface {v8, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_44

    const/16 v7, 0x20

    goto :goto_46

    :cond_44
    const/16 v7, 0x10

    :goto_46
    or-int/2addr v4, v7

    :cond_47
    move v12, v4

    .end local v4  # "$dirty":I
    .local v12, "$dirty":I
    and-int/lit8 v4, v12, 0x13

    const/16 v7, 0x12

    if-ne v4, v7, :cond_5e

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v4

    if-nez v4, :cond_55

    goto :goto_5e

    .line 78
    :cond_55
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v34, v8

    move/from16 v33, v12

    goto/16 :goto_64d

    .line 83
    :cond_5e
    :goto_5e
    if-eqz v5, :cond_66

    .line 81
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    move-object v13, v4

    .end local p0  # "modifier":Landroidx/compose/ui/Modifier;
    .local v4, "modifier":Landroidx/compose/ui/Modifier;
    goto :goto_67

    .line 83
    .end local v4  # "modifier":Landroidx/compose/ui/Modifier;
    .restart local p0  # "modifier":Landroidx/compose/ui/Modifier;
    :cond_66
    move-object v13, v6

    .line 81
    .end local p0  # "modifier":Landroidx/compose/ui/Modifier;
    .local v13, "modifier":Landroidx/compose/ui/Modifier;
    :goto_67
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_73

    const/4 v4, -0x1

    const-string v5, "com.example.PhotoSenderApp (MainActivity.kt:82)"

    invoke-static {v3, v12, v4, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 84
    :cond_73
    invoke-static {}, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->getLocalContext()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v3

    check-cast v3, Landroidx/compose/runtime/CompositionLocal;

    .local v3, "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    const/4 v4, 0x0

    .local v4, "$changed\\1":I
    move-object v5, v8

    .local v5, "$composer\\1":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 853
    .local v6, "$i$f$getCurrent\\1\\84":I
    const v7, 0x789c5f52

    const-string v9, "CC:CompositionLocal.kt#9igjgp"

    invoke-static {v5, v7, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v7

    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 84
    .end local v3  # "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    .end local v4  # "$changed\\1":I
    .end local v5  # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v6  # "$i$f$getCurrent\\1\\84":I
    move-object v3, v7

    check-cast v3, Landroid/content/Context;

    .line 88
    .local v3, "context":Landroid/content/Context;
    new-instance v4, Lcom/example/ui/MainViewModel$Factory;

    invoke-direct {v4, v0}, Lcom/example/ui/MainViewModel$Factory;-><init>(Landroid/app/Application;)V

    check-cast v4, Landroidx/lifecycle/ViewModelProvider$Factory;

    .line 87
    nop

    .local v5, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    move v7, v6

    .local v7, "$changed\\2":I
    move-object/from16 v17, v4

    .local v17, "factory\\2":Landroidx/lifecycle/ViewModelProvider$Factory;
    const/4 v4, 0x0

    .local v4, "$i$f$viewModel\\2\\87":I
    const v9, 0x671a9c9b

    invoke-interface {v5, v9}, Landroidx/compose/runtime/Composer;->startReplaceableGroup(I)V

    const-string v9, "CC(viewModel)P(3,2,1)*54@2502L7,64@2877L63:ViewModel.kt#3tja67"

    invoke-static {v5, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 854
    sget-object v9, Landroidx/lifecycle/viewmodel/compose/LocalViewModelStoreOwner;->INSTANCE:Landroidx/lifecycle/viewmodel/compose/LocalViewModelStoreOwner;

    const/4 v10, 0x6

    invoke-virtual {v9, v5, v10}, Landroidx/lifecycle/viewmodel/compose/LocalViewModelStoreOwner;->getCurrent(Landroidx/compose/runtime/Composer;I)Landroidx/lifecycle/ViewModelStoreOwner;

    move-result-object v15

    if-eqz v15, :cond_65c

    .line 857
    .local v15, "viewModelStoreOwner\\2":Landroidx/lifecycle/ViewModelStoreOwner;
    const/16 v16, 0x0

    .line 859
    .local v16, "key\\2":Ljava/lang/String;
    instance-of v9, v15, Landroidx/lifecycle/HasDefaultViewModelProviderFactory;

    if-eqz v9, :cond_bf

    .line 860
    move-object v9, v15

    check-cast v9, Landroidx/lifecycle/HasDefaultViewModelProviderFactory;

    invoke-interface {v9}, Landroidx/lifecycle/HasDefaultViewModelProviderFactory;->getDefaultViewModelCreationExtras()Landroidx/lifecycle/viewmodel/CreationExtras;

    move-result-object v9

    move-object/from16 v18, v9

    goto :goto_c5

    .line 862
    :cond_bf
    sget-object v9, Landroidx/lifecycle/viewmodel/CreationExtras$Empty;->INSTANCE:Landroidx/lifecycle/viewmodel/CreationExtras$Empty;

    check-cast v9, Landroidx/lifecycle/viewmodel/CreationExtras;

    move-object/from16 v18, v9

    :goto_c5
    nop

    .local v18, "extras\\2":Landroidx/lifecycle/viewmodel/CreationExtras;
    const-class v9, Lcom/example/ui/MainViewModel;

    invoke-static {v9}, Lkotlin/jvm/internal/Reflection;->getOrCreateKotlinClass(Ljava/lang/Class;)Lkotlin/reflect/KClass;

    move-result-object v14

    .line 864
    shl-int/lit8 v9, v7, 0x3

    and-int/lit8 v9, v9, 0x70

    shl-int/lit8 v6, v7, 0x3

    and-int/lit16 v6, v6, 0x380

    or-int/2addr v6, v9

    shl-int/lit8 v9, v7, 0x3

    and-int/lit16 v9, v9, 0x1c00

    or-int/2addr v6, v9

    shl-int/lit8 v9, v7, 0x3

    const v19, 0xe000

    and-int v9, v9, v19

    or-int v20, v6, v9

    const/16 v21, 0x0

    move-object/from16 v19, v5

    .end local v5  # "$composer\\2":Landroidx/compose/runtime/Composer;
    .local v19, "$composer\\2":Landroidx/compose/runtime/Composer;
    invoke-static/range {v14 .. v21}, Landroidx/lifecycle/viewmodel/compose/ViewModelKt;->viewModel(Lkotlin/reflect/KClass;Landroidx/lifecycle/ViewModelStoreOwner;Ljava/lang/String;Landroidx/lifecycle/ViewModelProvider$Factory;Landroidx/lifecycle/viewmodel/CreationExtras;Landroidx/compose/runtime/Composer;II)Landroidx/lifecycle/ViewModel;

    move-result-object v5

    invoke-interface/range {v19 .. v19}, Landroidx/compose/runtime/Composer;->endReplaceableGroup()V

    .line 87
    .end local v4  # "$i$f$viewModel\\2\\87":I
    .end local v7  # "$changed\\2":I
    .end local v15  # "viewModelStoreOwner\\2":Landroidx/lifecycle/ViewModelStoreOwner;
    .end local v16  # "key\\2":Ljava/lang/String;
    .end local v17  # "factory\\2":Landroidx/lifecycle/ViewModelProvider$Factory;
    .end local v18  # "extras\\2":Landroidx/lifecycle/viewmodel/CreationExtras;
    .end local v19  # "$composer\\2":Landroidx/compose/runtime/Composer;
    move-object v15, v5

    check-cast v15, Lcom/example/ui/MainViewModel;

    .line 92
    .local v15, "mainViewModel":Lcom/example/ui/MainViewModel;
    invoke-virtual {v15}, Lcom/example/ui/MainViewModel;->isServiceRunning()Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v4

    const/4 v9, 0x0

    move v5, v10

    const/4 v10, 0x7

    move v6, v5

    const/4 v5, 0x0

    move v7, v6

    const/4 v6, 0x0

    move v14, v7

    const/4 v7, 0x0

    const/4 v14, 0x0

    invoke-static/range {v4 .. v10}, Landroidx/lifecycle/compose/FlowExtKt;->collectAsStateWithLifecycle(Lkotlinx/coroutines/flow/StateFlow;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$State;Lkotlin/coroutines/CoroutineContext;Landroidx/compose/runtime/Composer;II)Landroidx/compose/runtime/State;

    move-result-object v18

    .line 93
    .local v18, "isServiceRunning$delegate":Landroidx/compose/runtime/State;
    invoke-virtual {v15}, Lcom/example/ui/MainViewModel;->getCurrentPhotoName()Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v4

    move-object/from16 v23, v18

    .end local v18  # "isServiceRunning$delegate":Landroidx/compose/runtime/State;
    .local v23, "isServiceRunning$delegate":Landroidx/compose/runtime/State;
    invoke-static/range {v4 .. v10}, Landroidx/lifecycle/compose/FlowExtKt;->collectAsStateWithLifecycle(Lkotlinx/coroutines/flow/StateFlow;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$State;Lkotlin/coroutines/CoroutineContext;Landroidx/compose/runtime/Composer;II)Landroidx/compose/runtime/State;

    move-result-object v20

    .line 94
    .local v20, "currentPhotoName$delegate":Landroidx/compose/runtime/State;
    invoke-virtual {v15}, Lcom/example/ui/MainViewModel;->getCurrentIndex()Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v4

    invoke-static/range {v4 .. v10}, Landroidx/lifecycle/compose/FlowExtKt;->collectAsStateWithLifecycle(Lkotlinx/coroutines/flow/StateFlow;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$State;Lkotlin/coroutines/CoroutineContext;Landroidx/compose/runtime/Composer;II)Landroidx/compose/runtime/State;

    move-result-object v21

    .line 95
    .local v21, "currentIndex$delegate":Landroidx/compose/runtime/State;
    invoke-virtual {v15}, Lcom/example/ui/MainViewModel;->getTotalPhotos()Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v4

    invoke-static/range {v4 .. v10}, Landroidx/lifecycle/compose/FlowExtKt;->collectAsStateWithLifecycle(Lkotlinx/coroutines/flow/StateFlow;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$State;Lkotlin/coroutines/CoroutineContext;Landroidx/compose/runtime/Composer;II)Landroidx/compose/runtime/State;

    move-result-object v24

    .line 96
    .local v24, "totalPhotos$delegate":Landroidx/compose/runtime/State;
    invoke-virtual {v15}, Lcom/example/ui/MainViewModel;->getProgressPercentage()Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v4

    invoke-static/range {v4 .. v10}, Landroidx/lifecycle/compose/FlowExtKt;->collectAsStateWithLifecycle(Lkotlinx/coroutines/flow/StateFlow;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$State;Lkotlin/coroutines/CoroutineContext;Landroidx/compose/runtime/Composer;II)Landroidx/compose/runtime/State;

    move-result-object v25

    .line 97
    .local v25, "progressPercentage$delegate":Landroidx/compose/runtime/State;
    invoke-virtual {v15}, Lcom/example/ui/MainViewModel;->getCustomServerUrl()Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v4

    invoke-static/range {v4 .. v10}, Landroidx/lifecycle/compose/FlowExtKt;->collectAsStateWithLifecycle(Lkotlinx/coroutines/flow/StateFlow;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$State;Lkotlin/coroutines/CoroutineContext;Landroidx/compose/runtime/Composer;II)Landroidx/compose/runtime/State;

    move-result-object v26

    .line 98
    .local v26, "customServerUrl$delegate":Landroidx/compose/runtime/State;
    invoke-virtual {v15}, Lcom/example/ui/MainViewModel;->isSimulationMode()Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v4

    invoke-static/range {v4 .. v10}, Landroidx/lifecycle/compose/FlowExtKt;->collectAsStateWithLifecycle(Lkotlinx/coroutines/flow/StateFlow;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$State;Lkotlin/coroutines/CoroutineContext;Landroidx/compose/runtime/Composer;II)Landroidx/compose/runtime/State;

    move-result-object v27

    .line 100
    .local v27, "isSimulationMode$delegate":Landroidx/compose/runtime/State;
    invoke-virtual {v15}, Lcom/example/ui/MainViewModel;->getAllLogs()Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v4

    invoke-static/range {v4 .. v10}, Landroidx/lifecycle/compose/FlowExtKt;->collectAsStateWithLifecycle(Lkotlinx/coroutines/flow/StateFlow;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$State;Lkotlin/coroutines/CoroutineContext;Landroidx/compose/runtime/Composer;II)Landroidx/compose/runtime/State;

    move-result-object v28

    .line 101
    .local v28, "allLogs$delegate":Landroidx/compose/runtime/State;
    invoke-virtual {v15}, Lcom/example/ui/MainViewModel;->getSuccessCount()Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v4

    invoke-static/range {v4 .. v10}, Landroidx/lifecycle/compose/FlowExtKt;->collectAsStateWithLifecycle(Lkotlinx/coroutines/flow/StateFlow;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$State;Lkotlin/coroutines/CoroutineContext;Landroidx/compose/runtime/Composer;II)Landroidx/compose/runtime/State;

    move-result-object v29

    .line 102
    .local v29, "successCount$delegate":Landroidx/compose/runtime/State;
    invoke-virtual {v15}, Lcom/example/ui/MainViewModel;->getFailedCount()Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v4

    invoke-static/range {v4 .. v10}, Landroidx/lifecycle/compose/FlowExtKt;->collectAsStateWithLifecycle(Lkotlinx/coroutines/flow/StateFlow;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$State;Lkotlin/coroutines/CoroutineContext;Landroidx/compose/runtime/Composer;II)Landroidx/compose/runtime/State;

    move-result-object v4

    .line 105
    .local v4, "failedCount$delegate":Landroidx/compose/runtime/State;
    const v5, -0x4a207124

    const-string v6, "CC(remember):MainActivity.kt#9igjgp"

    invoke-static {v8, v5, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v5, 0x0

    .local v5, "invalid\\4":Z
    move-object v7, v8

    .local v7, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 865
    .local v9, "$i$f$cache\\4\\105":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    .local v10, "it\\4":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 866
    .local v16, "$i$a$-let-ComposerKt$cache$1\\5\\865\\4":I
    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 p0, v14

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    const/4 v11, 0x0

    if-ne v10, v14, :cond_181

    .line 867
    const/4 v14, 0x0

    .line 106
    .local v14, "$i$a$-cache-MainActivityKt$PhotoSenderApp$hasGalleryPermission$2\\6\\867\\0":I
    invoke-static {v3}, Lcom/example/MainActivityKt;->hasRequiredGalleryPermission(Landroid/content/Context;)Z

    move-result v17

    move-object/from16 v30, v4

    .end local v4  # "failedCount$delegate":Landroidx/compose/runtime/State;
    .local v30, "failedCount$delegate":Landroidx/compose/runtime/State;
    invoke-static/range {v17 .. v17}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    move/from16 v17, v5

    const/4 v5, 0x2

    .end local v5  # "invalid\\4":Z
    .local v17, "invalid\\4":Z
    invoke-static {v4, v11, v5, v11}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v4

    .line 867
    .end local v14  # "$i$a$-cache-MainActivityKt$PhotoSenderApp$hasGalleryPermission$2\\6\\867\\0":I
    nop

    .line 868
    .local v4, "value\\5":Ljava/lang/Object;
    invoke-interface {v7, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 869
    nop

    .end local v4  # "value\\5":Ljava/lang/Object;
    goto :goto_186

    .line 870
    .end local v17  # "invalid\\4":Z
    .end local v30  # "failedCount$delegate":Landroidx/compose/runtime/State;
    .local v4, "failedCount$delegate":Landroidx/compose/runtime/State;
    .restart local v5  # "invalid\\4":Z
    :cond_181
    move-object/from16 v30, v4

    move/from16 v17, v5

    .end local v4  # "failedCount$delegate":Landroidx/compose/runtime/State;
    .end local v5  # "invalid\\4":Z
    .restart local v17  # "invalid\\4":Z
    .restart local v30  # "failedCount$delegate":Landroidx/compose/runtime/State;
    move-object v4, v10

    .line 866
    :goto_186
    nop

    .line 865
    .end local v10  # "it\\4":Ljava/lang/Object;
    .end local v16  # "$i$a$-let-ComposerKt$cache$1\\5\\865\\4":I
    nop

    .line 105
    .end local v7  # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v9  # "$i$f$cache\\4\\105":I
    .end local v17  # "invalid\\4":Z
    check-cast v4, Landroidx/compose/runtime/MutableState;

    .local v4, "hasGalleryPermission$delegate":Landroidx/compose/runtime/MutableState;
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 109
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v7, 0x21

    const/4 v9, 0x1

    if-lt v5, v7, :cond_19b

    .line 110
    new-array v5, v9, [Ljava/lang/String;

    const-string v7, "android.permission.READ_MEDIA_IMAGES"

    aput-object v7, v5, p0

    goto :goto_1a1

    .line 112
    :cond_19b
    new-array v5, v9, [Ljava/lang/String;

    const-string v7, "android.permission.READ_EXTERNAL_STORAGE"

    aput-object v7, v5, p0

    .line 109
    :goto_1a1
    nop

    .line 116
    .local v5, "permissionsToRequest":[Ljava/lang/String;
    new-instance v7, Landroidx/activity/result/contract/ActivityResultContracts$RequestMultiplePermissions;

    invoke-direct {v7}, Landroidx/activity/result/contract/ActivityResultContracts$RequestMultiplePermissions;-><init>()V

    check-cast v7, Landroidx/activity/result/contract/ActivityResultContract;

    .line 117
    const v10, -0x4a20374b

    invoke-static {v8, v10, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v8, v15}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v14

    or-int/2addr v10, v14

    .local v10, "invalid\\7":Z
    move-object v14, v8

    .local v14, "$this$cache\\7":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    .line 871
    .local v16, "$i$f$cache\\7\\117":I
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\7":Ljava/lang/Object;
    const/16 v17, 0x0

    .line 872
    .local v17, "$i$a$-let-ComposerKt$cache$1\\8\\871\\7":I
    if-nez v10, :cond_1cf

    sget-object v18, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    if-ne v9, v11, :cond_1cc

    goto :goto_1cf

    .line 876
    :cond_1cc
    move-object/from16 v18, v9

    goto :goto_1dc

    .line 873
    :cond_1cf
    :goto_1cf
    const/4 v11, 0x0

    .line 117
    .local v11, "$i$a$-cache-MainActivityKt$PhotoSenderApp$permissionLauncher$1\\9\\873\\0":I
    move-object/from16 v18, v9

    .end local v9  # "it\\7":Ljava/lang/Object;
    .local v18, "it\\7":Ljava/lang/Object;
    new-instance v9, Lcom/example/MainActivityKt$$ExternalSyntheticLambda19;

    invoke-direct {v9, v15, v3, v4}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda19;-><init>(Lcom/example/ui/MainViewModel;Landroid/content/Context;Landroidx/compose/runtime/MutableState;)V

    .line 873
    .end local v11  # "$i$a$-cache-MainActivityKt$PhotoSenderApp$permissionLauncher$1\\9\\873\\0":I
    nop

    .line 874
    .local v9, "value\\8":Ljava/lang/Object;
    invoke-interface {v14, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 875
    nop

    .line 872
    .end local v9  # "value\\8":Ljava/lang/Object;
    :goto_1dc
    nop

    .line 871
    .end local v17  # "$i$a$-let-ComposerKt$cache$1\\8\\871\\7":I
    .end local v18  # "it\\7":Ljava/lang/Object;
    nop

    .line 117
    .end local v10  # "invalid\\7":Z
    .end local v14  # "$this$cache\\7":Landroidx/compose/runtime/Composer;
    .end local v16  # "$i$f$cache\\7\\117":I
    check-cast v9, Lkotlin/jvm/functions/Function1;

    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 115
    move/from16 v14, p0

    invoke-static {v7, v9, v8, v14}, Landroidx/activity/compose/ActivityResultRegistryKt;->rememberLauncherForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)Landroidx/activity/compose/ManagedActivityResultLauncher;

    move-result-object v7

    .line 132
    .local v7, "permissionLauncher":Landroidx/activity/compose/ManagedActivityResultLauncher;
    sget-object v9, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    const v10, -0x4a1feac6

    invoke-static {v8, v10, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    .local v10, "invalid\\10":Z
    move-object v11, v8

    .local v11, "$this$cache\\10":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    .line 877
    .local v16, "$i$f$cache\\10\\132":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v14

    .local v14, "it\\10":Ljava/lang/Object;
    const/16 v17, 0x0

    .line 878
    .local v17, "$i$a$-let-ComposerKt$cache$1\\11\\877\\10":I
    if-nez v10, :cond_20f

    sget-object v18, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v19, v10

    .end local v10  # "invalid\\10":Z
    .local v19, "invalid\\10":Z
    invoke-virtual/range {v18 .. v18}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v14, v10, :cond_20b

    goto :goto_211

    .line 882
    :cond_20b
    move/from16 v33, v12

    move-object v10, v14

    goto :goto_223

    .line 878
    .end local v19  # "invalid\\10":Z
    .restart local v10  # "invalid\\10":Z
    :cond_20f
    move/from16 v19, v10

    .line 879
    .end local v10  # "invalid\\10":Z
    .restart local v19  # "invalid\\10":Z
    :goto_211
    const/4 v10, 0x0

    .line 132
    .local v10, "$i$a$-cache-MainActivityKt$PhotoSenderApp$1\\12\\879\\0":I
    move/from16 v18, v10

    .end local v10  # "$i$a$-cache-MainActivityKt$PhotoSenderApp$1\\12\\879\\0":I
    .local v18, "$i$a$-cache-MainActivityKt$PhotoSenderApp$1\\12\\879\\0":I
    new-instance v10, Lcom/example/MainActivityKt$PhotoSenderApp$1$1;

    move/from16 v33, v12

    const/4 v12, 0x0

    .end local v12  # "$dirty":I
    .local v33, "$dirty":I
    invoke-direct {v10, v3, v4, v12}, Lcom/example/MainActivityKt$PhotoSenderApp$1$1;-><init>(Landroid/content/Context;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/Continuation;)V

    check-cast v10, Lkotlin/jvm/functions/Function2;

    .line 879
    .end local v18  # "$i$a$-cache-MainActivityKt$PhotoSenderApp$1\\12\\879\\0":I
    nop

    .line 880
    .local v10, "value\\11":Ljava/lang/Object;
    invoke-interface {v11, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 881
    nop

    .line 878
    .end local v10  # "value\\11":Ljava/lang/Object;
    :goto_223
    nop

    .line 877
    .end local v14  # "it\\10":Ljava/lang/Object;
    .end local v17  # "$i$a$-let-ComposerKt$cache$1\\11\\877\\10":I
    nop

    .line 132
    .end local v11  # "$this$cache\\10":Landroidx/compose/runtime/Composer;
    .end local v16  # "$i$f$cache\\10\\132":I
    .end local v19  # "invalid\\10":Z
    check-cast v10, Lkotlin/jvm/functions/Function2;

    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/4 v11, 0x6

    invoke-static {v9, v10, v8, v11}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V

    .line 137
    invoke-static {v4}, Lcom/example/MainActivityKt;->PhotoSenderApp$lambda$11(Landroidx/compose/runtime/MutableState;)Z

    move-result v9

    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v9

    const v10, -0x4a1fd316

    invoke-static {v8, v10, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    move-object/from16 v10, v23

    .end local v23  # "isServiceRunning$delegate":Landroidx/compose/runtime/State;
    .local v10, "isServiceRunning$delegate":Landroidx/compose/runtime/State;
    invoke-interface {v8, v10}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v12

    invoke-interface {v8, v15}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v14

    or-int/2addr v12, v14

    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v14

    or-int/2addr v12, v14

    .local v12, "invalid\\13":Z
    move-object v14, v8

    .local v14, "$this$cache\\13":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 883
    .local v22, "$i$f$cache\\13\\137":I
    move/from16 v23, v11

    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\13":Ljava/lang/Object;
    const/16 v34, 0x0

    .line 884
    .local v34, "$i$a$-let-ComposerKt$cache$1\\14\\883\\13":I
    if-nez v12, :cond_26e

    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v18, v3

    .end local v3  # "context":Landroid/content/Context;
    .local v18, "context":Landroid/content/Context;
    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v11, v3, :cond_264

    goto :goto_270

    .line 888
    :cond_264
    move-object/from16 v17, v4

    move-object v3, v11

    move-object v4, v14

    move-object/from16 v14, v18

    move-object/from16 v18, v10

    const/4 v10, 0x0

    goto :goto_292

    .line 884
    .end local v18  # "context":Landroid/content/Context;
    .restart local v3  # "context":Landroid/content/Context;
    :cond_26e
    move-object/from16 v18, v3

    .line 885
    .end local v3  # "context":Landroid/content/Context;
    .restart local v18  # "context":Landroid/content/Context;
    :goto_270
    const/4 v3, 0x0

    .line 137
    .local v3, "$i$a$-cache-MainActivityKt$PhotoSenderApp$2\\15\\885\\0":I
    move-object/from16 v16, v14

    .end local v14  # "$this$cache\\13":Landroidx/compose/runtime/Composer;
    .local v16, "$this$cache\\13":Landroidx/compose/runtime/Composer;
    new-instance v14, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;

    const/16 v19, 0x0

    move-object/from16 v17, v4

    move-object/from16 v4, v16

    move-object/from16 v16, v18

    move-object/from16 v18, v10

    const/4 v10, 0x0

    .end local v10  # "isServiceRunning$delegate":Landroidx/compose/runtime/State;
    .local v4, "$this$cache\\13":Landroidx/compose/runtime/Composer;
    .local v16, "context":Landroid/content/Context;
    .local v17, "hasGalleryPermission$delegate":Landroidx/compose/runtime/MutableState;
    .local v18, "isServiceRunning$delegate":Landroidx/compose/runtime/State;
    invoke-direct/range {v14 .. v19}, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;-><init>(Lcom/example/ui/MainViewModel;Landroid/content/Context;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/State;Lkotlin/coroutines/Continuation;)V

    move-object/from16 v71, v16

    move-object/from16 v16, v14

    move-object/from16 v14, v71

    .end local v16  # "context":Landroid/content/Context;
    .local v14, "context":Landroid/content/Context;
    move-object/from16 v3, v16

    check-cast v3, Lkotlin/jvm/functions/Function2;

    .line 885
    .end local v3  # "$i$a$-cache-MainActivityKt$PhotoSenderApp$2\\15\\885\\0":I
    nop

    .line 886
    .local v3, "value\\14":Ljava/lang/Object;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 887
    nop

    .line 884
    .end local v3  # "value\\14":Ljava/lang/Object;
    :goto_292
    nop

    .line 883
    .end local v11  # "it\\13":Ljava/lang/Object;
    .end local v34  # "$i$a$-let-ComposerKt$cache$1\\14\\883\\13":I
    nop

    .line 137
    .end local v4  # "$this$cache\\13":Landroidx/compose/runtime/Composer;
    .end local v12  # "invalid\\13":Z
    .end local v22  # "$i$f$cache\\13\\137":I
    check-cast v3, Lkotlin/jvm/functions/Function2;

    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {v9, v3, v8, v10}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V

    .line 146
    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v12, 0x0

    invoke-static {v13, v3, v4, v12}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    .line 145
    move v4, v10

    .local v4, "$changed\\16":I
    move-object v11, v8

    .local v9, "modifier\\16":Landroidx/compose/ui/Modifier;
    .local v11, "$composer\\16":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 889
    .local v12, "$i$f$Box\\16\\145":I
    const v3, 0x2bb5b5d7

    const-string v10, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v11, v3, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 890
    sget-object v19, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual/range {v19 .. v19}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v3

    .line 891
    .local v3, "contentAlignment\\16":Landroidx/compose/ui/Alignment;
    move/from16 v19, v4

    .end local v4  # "$changed\\16":I
    .local v19, "$changed\\16":I
    const/4 v4, 0x0

    .line 894
    .local v4, "propagateMinConstraints\\16":Z
    move-object/from16 v34, v8

    .end local v8  # "$composer":Landroidx/compose/runtime/Composer;
    .local v34, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static {v3, v4}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v8

    .local v8, "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v35, v19, 0x3

    and-int/lit8 v35, v35, 0x70

    .line 895
    nop

    .local v35, "$changed\\17":I
    const/16 v36, 0x0

    .line 896
    .local v36, "$i$f$Layout\\17\\895":I
    move-object/from16 v37, v3

    .end local v3  # "contentAlignment\\16":Landroidx/compose/ui/Alignment;
    .local v37, "contentAlignment\\16":Landroidx/compose/ui/Alignment;
    const v3, -0x4ee9b9da

    move/from16 v38, v4

    .end local v4  # "propagateMinConstraints\\16":Z
    .local v38, "propagateMinConstraints\\16":Z
    const-string v4, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh"

    invoke-static {v11, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 897
    const/4 v3, 0x0

    invoke-static {v11, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v40

    .line 898
    .local v40, "compositeKeyHash\\17":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v3

    .line 899
    .local v3, "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v41, v12

    .end local v12  # "$i$f$Box\\16\\145":I
    .local v41, "$i$f$Box\\16\\145":I
    invoke-static {v11, v9}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 901
    .local v12, "materialized\\17":Landroidx/compose/ui/Modifier;
    sget-object v42, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v42 .. v42}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v42

    move-object/from16 v43, v9

    .end local v9  # "modifier\\16":Landroidx/compose/ui/Modifier;
    .local v43, "modifier\\16":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v9, v35, 0x6

    and-int/lit16 v9, v9, 0x380

    or-int/lit8 v9, v9, 0x6

    .line 900
    move-object/from16 v44, v42

    .local v9, "$changed\\18":I
    .local v44, "factory\\18":Lkotlin/jvm/functions/Function0;
    const/16 v42, 0x0

    .line 902
    .local v42, "$i$f$ReusableComposeNode\\18\\900":I
    move/from16 v45, v9

    .end local v9  # "$changed\\18":I
    .local v45, "$changed\\18":I
    const v9, -0x2942ffcf

    move-object/from16 v46, v13

    .end local v13  # "modifier":Landroidx/compose/ui/Modifier;
    .local v46, "modifier":Landroidx/compose/ui/Modifier;
    const-string v13, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v11, v9, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 903
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v9

    instance-of v9, v9, Landroidx/compose/runtime/Applier;

    if-nez v9, :cond_308

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 904
    :cond_308
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 905
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v9

    if-eqz v9, :cond_317

    .line 906
    move-object/from16 v9, v44

    .end local v44  # "factory\\18":Lkotlin/jvm/functions/Function0;
    .local v9, "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-interface {v11, v9}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_31c

    .line 908
    .end local v9  # "factory\\18":Lkotlin/jvm/functions/Function0;
    .restart local v44  # "factory\\18":Lkotlin/jvm/functions/Function0;
    :cond_317
    move-object/from16 v9, v44

    .end local v44  # "factory\\18":Lkotlin/jvm/functions/Function0;
    .restart local v9  # "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 910
    :goto_31c
    move-object/from16 v44, v9

    .end local v9  # "factory\\18":Lkotlin/jvm/functions/Function0;
    .restart local v44  # "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-static {v11}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v9

    .local v9, "$this$Layout_u24lambda_u240\\19":Landroidx/compose/runtime/Composer;
    const/16 v48, 0x0

    .line 911
    .local v48, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\19\\910\\17":I
    sget-object v49, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v50, v11

    .end local v11  # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v50, "$composer\\16":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v49 .. v49}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v11

    invoke-static {v9, v8, v11}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 912
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v11

    invoke-static {v9, v3, v11}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 914
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v11

    .local v11, "block\\20":Lkotlin/jvm/functions/Function2;
    const/16 v49, 0x0

    .line 915
    .local v49, "$i$f$set-impl\\20\\914":I
    move-object/from16 v51, v9

    .local v51, "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    const/16 v52, 0x0

    .line 916
    .local v52, "$i$a$-with-Updater$set$1\\21\\915\\20":I
    invoke-interface/range {v51 .. v51}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v53

    if-nez v53, :cond_360

    move-object/from16 v53, v3

    .end local v3  # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .local v53, "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v51 .. v51}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v54, v8

    .end local v8  # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v54, "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v40 .. v40}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v3, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_35d

    goto :goto_364

    :cond_35d
    move-object/from16 v8, v51

    goto :goto_374

    .end local v53  # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v54  # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v3  # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v8  # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_360
    move-object/from16 v53, v3

    move-object/from16 v54, v8

    .line 917
    .end local v3  # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v8  # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v53  # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v54  # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_364
    invoke-static/range {v40 .. v40}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v8, v51

    .end local v51  # "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    .local v8, "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 918
    invoke-static/range {v40 .. v40}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v9, v3, v11}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 920
    :goto_374
    nop

    .line 915
    .end local v8  # "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    .end local v52  # "$i$a$-with-Updater$set$1\\21\\915\\20":I
    nop

    .line 920
    nop

    .line 921
    .end local v11  # "block\\20":Lkotlin/jvm/functions/Function2;
    .end local v49  # "$i$f$set-impl\\20\\914":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v9, v12, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 922
    nop

    .line 910
    .end local v9  # "$this$Layout_u24lambda_u240\\19":Landroidx/compose/runtime/Composer;
    .end local v48  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\19\\910\\17":I
    nop

    .line 923
    shr-int/lit8 v3, v45, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\22":I
    move-object/from16 v8, v50

    .local v8, "$composer\\22":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 924
    .local v9, "$i$a$-Layout-BoxKt$Box$1\\22\\923\\16":I
    const v11, -0x7ff519f7  # -1.000876E-39f

    move/from16 v48, v3

    .end local v3  # "$changed\\22":I
    .local v48, "$changed\\22":I
    const-string v3, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v8, v11, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v49, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v51, v19, 0x6

    and-int/lit8 v51, v51, 0x70

    or-int/lit8 v51, v51, 0x6

    .local v51, "$changed\\23":I
    check-cast v49, Landroidx/compose/foundation/layout/BoxScope;

    .local v49, "$this$PhotoSenderApp_u24lambda_u2424\\23":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v63, v8

    .local v63, "$composer\\23":Landroidx/compose/runtime/Composer;
    const/16 v52, 0x0

    .line 148
    .local v52, "$i$a$-Box-MainActivityKt$PhotoSenderApp$3\\23\\924\\0":I
    const v11, 0x251cfa08

    move-object/from16 v66, v8

    .end local v8  # "$composer\\22":Landroidx/compose/runtime/Composer;
    .local v66, "$composer\\22":Landroidx/compose/runtime/Composer;
    const-string v8, "C:MainActivity.kt#to5c3"

    move/from16 v67, v9

    move-object/from16 v9, v63

    .end local v63  # "$composer\\23":Landroidx/compose/runtime/Composer;
    .local v9, "$composer\\23":Landroidx/compose/runtime/Composer;
    .local v67, "$i$a$-Layout-BoxKt$Box$1\\22\\923\\16":I
    invoke-static {v9, v11, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static/range {v17 .. v17}, Lcom/example/MainActivityKt;->PhotoSenderApp$lambda$11(Landroidx/compose/runtime/MutableState;)Z

    move-result v8

    if-eqz v8, :cond_450

    const v3, 0x251cfb3d

    invoke-interface {v9, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "155@6032L178,159@6242L2,148@5689L569"

    invoke-static {v9, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 150
    nop

    .line 151
    invoke-static/range {v18 .. v18}, Lcom/example/MainActivityKt;->PhotoSenderApp$lambda$0(Landroidx/compose/runtime/State;)Z

    move-result v56

    .line 152
    invoke-static/range {v20 .. v20}, Lcom/example/MainActivityKt;->PhotoSenderApp$lambda$1(Landroidx/compose/runtime/State;)Ljava/lang/String;

    move-result-object v57

    .line 153
    invoke-static/range {v21 .. v21}, Lcom/example/MainActivityKt;->PhotoSenderApp$lambda$2(Landroidx/compose/runtime/State;)I

    move-result v58

    .line 154
    invoke-static/range {v24 .. v24}, Lcom/example/MainActivityKt;->PhotoSenderApp$lambda$3(Landroidx/compose/runtime/State;)I

    move-result v59

    .line 155
    invoke-static/range {v25 .. v25}, Lcom/example/MainActivityKt;->PhotoSenderApp$lambda$4(Landroidx/compose/runtime/State;)F

    move-result v60

    .line 156
    const v3, 0x5c095c66

    invoke-static {v9, v3, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v9, v15}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    invoke-interface {v9, v14}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    or-int/2addr v3, v4

    .local v3, "invalid\\24":Z
    move-object v4, v9

    .local v4, "$this$cache\\24":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 925
    .local v8, "$i$f$cache\\24\\156":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    .local v10, "it\\24":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 926
    .local v11, "$i$a$-let-ComposerKt$cache$1\\25\\925\\24":I
    if-nez v3, :cond_3fa

    sget-object v13, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v13}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v10, v13, :cond_3f6

    goto :goto_3fa

    .line 930
    :cond_3f6
    move/from16 p0, v3

    move-object v3, v10

    goto :goto_407

    .line 927
    :cond_3fa
    :goto_3fa
    const/4 v13, 0x0

    .line 156
    .local v13, "$i$a$-cache-MainActivityKt$PhotoSenderApp$3$1\\26\\927\\23":I
    move/from16 p0, v3

    .end local v3  # "invalid\\24":Z
    .local p0, "invalid\\24":Z
    new-instance v3, Lcom/example/MainActivityKt$$ExternalSyntheticLambda20;

    invoke-direct {v3, v15, v14}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda20;-><init>(Lcom/example/ui/MainViewModel;Landroid/content/Context;)V

    .line 927
    .end local v13  # "$i$a$-cache-MainActivityKt$PhotoSenderApp$3$1\\26\\927\\23":I
    nop

    .line 928
    .local v3, "value\\25":Ljava/lang/Object;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 929
    nop

    .line 926
    .end local v3  # "value\\25":Ljava/lang/Object;
    :goto_407
    nop

    .line 925
    .end local v10  # "it\\24":Ljava/lang/Object;
    .end local v11  # "$i$a$-let-ComposerKt$cache$1\\25\\925\\24":I
    nop

    .line 156
    .end local v4  # "$this$cache\\24":Landroidx/compose/runtime/Composer;
    .end local v8  # "$i$f$cache\\24\\156":I
    .end local p0  # "invalid\\24":Z
    move-object/from16 v61, v3

    check-cast v61, Lkotlin/jvm/functions/Function0;

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 160
    const v3, 0x5c0975f6

    invoke-static {v9, v3, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v3, 0x0

    .local v3, "invalid\\27":Z
    move-object v4, v9

    .local v4, "$this$cache\\27":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 931
    .local v6, "$i$f$cache\\27\\160":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    .local v8, "it\\27":Ljava/lang/Object;
    const/4 v10, 0x0

    .line 932
    .local v10, "$i$a$-let-ComposerKt$cache$1\\28\\931\\27":I
    sget-object v11, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v11}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    if-ne v8, v11, :cond_431

    .line 933
    const/4 v11, 0x0

    .local v11, "$i$a$-cache-MainActivityKt$PhotoSenderApp$3$2\\29\\933\\23":I
    new-instance v13, Lcom/example/MainActivityKt$$ExternalSyntheticLambda21;

    invoke-direct {v13}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda21;-><init>()V

    .line 934
    .end local v11  # "$i$a$-cache-MainActivityKt$PhotoSenderApp$3$2\\29\\933\\23":I
    .local v13, "value\\28":Ljava/lang/Object;
    invoke-interface {v4, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 935
    nop

    .end local v13  # "value\\28":Ljava/lang/Object;
    goto :goto_432

    .line 936
    :cond_431
    move-object v13, v8

    .line 932
    :goto_432
    nop

    .line 931
    .end local v8  # "it\\27":Ljava/lang/Object;
    .end local v10  # "$i$a$-let-ComposerKt$cache$1\\28\\931\\27":I
    nop

    .line 160
    .end local v3  # "invalid\\27":Z
    .end local v4  # "$this$cache\\27":Landroidx/compose/runtime/Composer;
    .end local v6  # "$i$f$cache\\27\\160":I
    move-object/from16 v62, v13

    check-cast v62, Lkotlin/jvm/functions/Function0;

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 149
    const-string v55, "https://chatgpt.com/"

    const v64, 0xc00006

    const/16 v65, 0x0

    move-object/from16 v63, v9

    .end local v9  # "$composer\\23":Landroidx/compose/runtime/Composer;
    .restart local v63  # "$composer\\23":Landroidx/compose/runtime/Composer;
    invoke-static/range {v55 .. v65}, Lcom/example/MainActivityKt;->ChatGPTWebView(Ljava/lang/String;ZLjava/lang/String;IIFLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    .line 148
    .end local v63  # "$composer\\23":Landroidx/compose/runtime/Composer;
    .restart local v9  # "$composer\\23":Landroidx/compose/runtime/Composer;
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 p0, v12

    move-object/from16 v32, v14

    goto/16 :goto_62b

    .line 162
    :cond_450
    const v8, 0x25262438

    invoke-interface {v9, v8}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v8, "168@6544L11,169@6614L11,162@6288L766"

    invoke-static {v9, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 164
    sget-object v8, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v8, Landroidx/compose/ui/Modifier;

    .line 165
    move-object/from16 p0, v12

    move-object/from16 v32, v14

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v14, 0x1

    .end local v12  # "materialized\\17":Landroidx/compose/ui/Modifier;
    .end local v14  # "context":Landroid/content/Context;
    .local v32, "context":Landroid/content/Context;
    .local p0, "materialized\\17":Landroidx/compose/ui/Modifier;
    invoke-static {v8, v11, v14, v12}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v56

    .line 167
    sget-object v57, Landroidx/compose/ui/graphics/Brush;->Companion:Landroidx/compose/ui/graphics/Brush$Companion;

    .line 169
    const/4 v8, 0x2

    new-array v8, v8, [Landroidx/compose/ui/graphics/Color;

    sget-object v11, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v12, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v11, v9, v12}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v11

    invoke-virtual {v11}, Landroidx/compose/material3/ColorScheme;->getBackground-0d7_KjU()J

    move-result-wide v11

    invoke-static {v11, v12}, Landroidx/compose/ui/graphics/Color;->box-impl(J)Landroidx/compose/ui/graphics/Color;

    move-result-object v11

    const/16 v16, 0x0

    aput-object v11, v8, v16

    .line 170
    sget-object v11, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v12, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v11, v9, v12}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v11

    invoke-virtual {v11}, Landroidx/compose/material3/ColorScheme;->getSurfaceVariant-0d7_KjU()J

    move-result-wide v58

    const/16 v64, 0xe

    const/16 v65, 0x0

    const v60, 0x3e99999a  # 0.3f

    const/16 v61, 0x0

    const/16 v62, 0x0

    const/16 v63, 0x0

    invoke-static/range {v58 .. v65}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v11

    invoke-static {v11, v12}, Landroidx/compose/ui/graphics/Color;->box-impl(J)Landroidx/compose/ui/graphics/Color;

    move-result-object v11

    const/16 v31, 0x1

    aput-object v11, v8, v31

    .line 169
    nop

    .line 168
    invoke-static {v8}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v58

    .line 167
    const/16 v62, 0xe

    const/16 v63, 0x0

    const/16 v59, 0x0

    const/16 v60, 0x0

    const/16 v61, 0x0

    invoke-static/range {v57 .. v63}, Landroidx/compose/ui/graphics/Brush$Companion;->verticalGradient-8A-3gB4$default(Landroidx/compose/ui/graphics/Brush$Companion;Ljava/util/List;FFIILjava/lang/Object;)Landroidx/compose/ui/graphics/Brush;

    move-result-object v57

    .line 166
    const/16 v60, 0x6

    const/16 v61, 0x0

    const/16 v58, 0x0

    invoke-static/range {v56 .. v61}, Landroidx/compose/foundation/BackgroundKt;->background$default(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Brush;Landroidx/compose/ui/graphics/Shape;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 174
    const/16 v11, 0x10

    .local v11, "$this$dp\\30":I
    const/4 v12, 0x0

    .line 937
    .local v12, "$i$f$getDp\\30\\174":I
    int-to-float v14, v11

    invoke-static {v14}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v11

    .line 174
    .end local v11  # "$this$dp\\30":I
    .end local v12  # "$i$f$getDp\\30\\174":I
    invoke-static {v8, v11}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 175
    sget-object v11, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v11

    .line 163
    nop

    .local v8, "modifier\\31":Landroidx/compose/ui/Modifier;
    .local v11, "contentAlignment\\31":Landroidx/compose/ui/Alignment;
    move-object v12, v9

    .local v12, "$composer\\31":Landroidx/compose/runtime/Composer;
    const/16 v14, 0x30

    .local v14, "$changed\\31":I
    const/16 v31, 0x0

    .line 938
    .local v31, "$i$f$Box\\31\\163":I
    move-object/from16 v63, v9

    const v9, 0x2bb5b5d7

    .end local v9  # "$composer\\23":Landroidx/compose/runtime/Composer;
    .restart local v63  # "$composer\\23":Landroidx/compose/runtime/Composer;
    invoke-static {v12, v9, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 939
    const/4 v9, 0x0

    .line 942
    .local v9, "propagateMinConstraints\\31":Z
    invoke-static {v11, v9}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .local v10, "measurePolicy\\31":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v22, v14, 0x3

    and-int/lit8 v22, v22, 0x70

    .line 943
    nop

    .local v22, "$changed\\32":I
    const/16 v56, 0x0

    .line 944
    .local v56, "$i$f$Layout\\32\\943":I
    move/from16 p2, v9

    const v9, -0x4ee9b9da

    .end local v9  # "propagateMinConstraints\\31":Z
    .local p2, "propagateMinConstraints\\31":Z
    invoke-static {v12, v9, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 945
    const/4 v4, 0x0

    invoke-static {v12, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v9

    .line 946
    .local v9, "compositeKeyHash\\32":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v4

    .line 947
    .local v4, "localMap\\32":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v39, v9

    .end local v9  # "compositeKeyHash\\32":I
    .local v39, "compositeKeyHash\\32":I
    invoke-static {v12, v8}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    .line 949
    .local v9, "materialized\\32":Landroidx/compose/ui/Modifier;
    sget-object v57, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v57 .. v57}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v57

    move-object/from16 v58, v8

    .end local v8  # "modifier\\31":Landroidx/compose/ui/Modifier;
    .local v58, "modifier\\31":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v8, v22, 0x6

    and-int/lit16 v8, v8, 0x380

    or-int/lit8 v8, v8, 0x6

    .line 948
    nop

    .local v8, "$changed\\33":I
    move-object/from16 v59, v57

    .local v59, "factory\\33":Lkotlin/jvm/functions/Function0;
    const/16 v57, 0x0

    .line 950
    .local v57, "$i$f$ReusableComposeNode\\33\\948":I
    move/from16 v60, v8

    const v8, -0x2942ffcf

    .end local v8  # "$changed\\33":I
    .local v60, "$changed\\33":I
    invoke-static {v12, v8, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 951
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v8

    instance-of v8, v8, Landroidx/compose/runtime/Applier;

    if-nez v8, :cond_52e

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 952
    :cond_52e
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 953
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v8

    if-eqz v8, :cond_53d

    .line 954
    move-object/from16 v8, v59

    .end local v59  # "factory\\33":Lkotlin/jvm/functions/Function0;
    .local v8, "factory\\33":Lkotlin/jvm/functions/Function0;
    invoke-interface {v12, v8}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_542

    .line 956
    .end local v8  # "factory\\33":Lkotlin/jvm/functions/Function0;
    .restart local v59  # "factory\\33":Lkotlin/jvm/functions/Function0;
    :cond_53d
    move-object/from16 v8, v59

    .end local v59  # "factory\\33":Lkotlin/jvm/functions/Function0;
    .restart local v8  # "factory\\33":Lkotlin/jvm/functions/Function0;
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 958
    :goto_542
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v13

    .local v13, "$this$Layout_u24lambda_u240\\34":Landroidx/compose/runtime/Composer;
    const/16 v47, 0x0

    .line 959
    .local v47, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\34\\958\\32":I
    sget-object v59, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v61, v8

    .end local v8  # "factory\\33":Lkotlin/jvm/functions/Function0;
    .local v61, "factory\\33":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v59 .. v59}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v13, v10, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 960
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v13, v4, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 962
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    .local v8, "block\\35":Lkotlin/jvm/functions/Function2;
    const/16 v59, 0x0

    .line 963
    .local v59, "$i$f$set-impl\\35\\962":I
    move-object/from16 v62, v13

    .local v62, "$this$set_impl_u24lambda_u240\\35":Landroidx/compose/runtime/Composer;
    const/16 v64, 0x0

    .line 964
    .local v64, "$i$a$-with-Updater$set$1\\36\\963\\35":I
    invoke-interface/range {v62 .. v62}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v65

    if-nez v65, :cond_584

    move-object/from16 v65, v4

    .end local v4  # "localMap\\32":Landroidx/compose/runtime/CompositionLocalMap;
    .local v65, "localMap\\32":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v62 .. v62}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v68, v10

    .end local v10  # "measurePolicy\\31":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v68, "measurePolicy\\31":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v39 .. v39}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v4, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_581

    goto :goto_588

    :cond_581
    move-object/from16 v10, v62

    goto :goto_598

    .end local v65  # "localMap\\32":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v68  # "measurePolicy\\31":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v4  # "localMap\\32":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v10  # "measurePolicy\\31":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_584
    move-object/from16 v65, v4

    move-object/from16 v68, v10

    .line 965
    .end local v4  # "localMap\\32":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v10  # "measurePolicy\\31":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v65  # "localMap\\32":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v68  # "measurePolicy\\31":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_588
    invoke-static/range {v39 .. v39}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v10, v62

    .end local v62  # "$this$set_impl_u24lambda_u240\\35":Landroidx/compose/runtime/Composer;
    .local v10, "$this$set_impl_u24lambda_u240\\35":Landroidx/compose/runtime/Composer;
    invoke-interface {v10, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 966
    invoke-static/range {v39 .. v39}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v13, v4, v8}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 968
    :goto_598
    nop

    .line 963
    .end local v10  # "$this$set_impl_u24lambda_u240\\35":Landroidx/compose/runtime/Composer;
    .end local v64  # "$i$a$-with-Updater$set$1\\36\\963\\35":I
    nop

    .line 968
    nop

    .line 969
    .end local v8  # "block\\35":Lkotlin/jvm/functions/Function2;
    .end local v59  # "$i$f$set-impl\\35\\962":I
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v13, v9, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 970
    nop

    .line 958
    .end local v13  # "$this$Layout_u24lambda_u240\\34":Landroidx/compose/runtime/Composer;
    .end local v47  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\34\\958\\32":I
    nop

    .line 971
    shr-int/lit8 v4, v60, 0x6

    and-int/lit8 v4, v4, 0xe

    .local v4, "$changed\\37":I
    move-object v8, v12

    .local v8, "$composer\\37":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 972
    .local v10, "$i$a$-Layout-BoxKt$Box$1\\37\\971\\31":I
    const v13, -0x7ff519f7  # -1.000876E-39f

    invoke-static {v8, v13, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v13, v14, 0x6

    and-int/lit8 v13, v13, 0x70

    or-int/lit8 v13, v13, 0x6

    .local v13, "$changed\\38":I
    check-cast v3, Landroidx/compose/foundation/layout/BoxScope;

    .local v3, "$this$PhotoSenderApp_u24lambda_u2424_u24lambda_u2423\\38":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v23, v8

    .local v23, "$composer\\38":Landroidx/compose/runtime/Composer;
    const/16 v47, 0x0

    .line 177
    .local v47, "$i$a$-Box-MainActivityKt$PhotoSenderApp$3$3\\38\\972\\23":I
    move-object/from16 v55, v3

    .end local v3  # "$this$PhotoSenderApp_u24lambda_u2424_u24lambda_u2423\\38":Landroidx/compose/foundation/layout/BoxScope;
    .local v55, "$this$PhotoSenderApp_u24lambda_u2424_u24lambda_u2423\\38":Landroidx/compose/foundation/layout/BoxScope;
    const v3, -0x14a4bed0

    move/from16 v59, v4

    .end local v4  # "$changed\\37":I
    .local v59, "$changed\\37":I
    const-string v4, "C177@6927L95,176@6859L181:MainActivity.kt#to5c3"

    move-object/from16 v62, v8

    .end local v23  # "$composer\\38":Landroidx/compose/runtime/Composer;
    .local v8, "$composer\\38":Landroidx/compose/runtime/Composer;
    .local v62, "$composer\\37":Landroidx/compose/runtime/Composer;
    invoke-static {v8, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 178
    const v3, -0x112e92a3

    invoke-static {v8, v3, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v8, v7}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    invoke-interface {v8, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    or-int/2addr v3, v4

    .local v3, "invalid\\39":Z
    move-object v4, v8

    .local v4, "$this$cache\\39":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 973
    .local v6, "$i$f$cache\\39\\178":I
    move/from16 v23, v3

    .end local v3  # "invalid\\39":Z
    .local v23, "invalid\\39":Z
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .local v3, "it\\39":Ljava/lang/Object;
    const/16 v64, 0x0

    .line 974
    .local v64, "$i$a$-let-ComposerKt$cache$1\\40\\973\\39":I
    if-nez v23, :cond_5f7

    sget-object v69, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v70, v6

    .end local v6  # "$i$f$cache\\39\\178":I
    .local v70, "$i$f$cache\\39\\178":I
    invoke-virtual/range {v69 .. v69}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v3, v6, :cond_5f4

    goto :goto_5f9

    .line 978
    :cond_5f4
    move-object/from16 v69, v3

    goto :goto_606

    .line 974
    .end local v70  # "$i$f$cache\\39\\178":I
    .restart local v6  # "$i$f$cache\\39\\178":I
    :cond_5f7
    move/from16 v70, v6

    .line 975
    .end local v6  # "$i$f$cache\\39\\178":I
    .restart local v70  # "$i$f$cache\\39\\178":I
    :goto_5f9
    const/4 v6, 0x0

    .line 178
    .local v6, "$i$a$-cache-MainActivityKt$PhotoSenderApp$3$3$1\\41\\975\\38":I
    move-object/from16 v69, v3

    .end local v3  # "it\\39":Ljava/lang/Object;
    .local v69, "it\\39":Ljava/lang/Object;
    new-instance v3, Lcom/example/MainActivityKt$$ExternalSyntheticLambda22;

    invoke-direct {v3, v7, v5}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda22;-><init>(Landroidx/activity/compose/ManagedActivityResultLauncher;[Ljava/lang/String;)V

    .line 975
    .end local v6  # "$i$a$-cache-MainActivityKt$PhotoSenderApp$3$3$1\\41\\975\\38":I
    nop

    .line 976
    .local v3, "value\\40":Ljava/lang/Object;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 977
    nop

    .line 974
    .end local v3  # "value\\40":Ljava/lang/Object;
    :goto_606
    nop

    .line 973
    .end local v64  # "$i$a$-let-ComposerKt$cache$1\\40\\973\\39":I
    .end local v69  # "it\\39":Ljava/lang/Object;
    nop

    .line 178
    .end local v4  # "$this$cache\\39":Landroidx/compose/runtime/Composer;
    .end local v23  # "invalid\\39":Z
    .end local v70  # "$i$f$cache\\39\\178":I
    check-cast v3, Lkotlin/jvm/functions/Function0;

    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 177
    const/4 v4, 0x0

    invoke-static {v3, v8, v4}, Lcom/example/MainActivityKt;->PermissionOnboardingCard(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 182
    nop

    .line 972
    .end local v8  # "$composer\\38":Landroidx/compose/runtime/Composer;
    .end local v13  # "$changed\\38":I
    .end local v47  # "$i$a$-Box-MainActivityKt$PhotoSenderApp$3$3\\38\\972\\23":I
    .end local v55  # "$this$PhotoSenderApp_u24lambda_u2424_u24lambda_u2423\\38":Landroidx/compose/foundation/layout/BoxScope;
    invoke-static/range {v62 .. v62}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 971
    .end local v10  # "$i$a$-Layout-BoxKt$Box$1\\37\\971\\31":I
    .end local v59  # "$changed\\37":I
    .end local v62  # "$composer\\37":Landroidx/compose/runtime/Composer;
    nop

    .line 979
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 950
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 980
    nop

    .line 944
    .end local v57  # "$i$f$ReusableComposeNode\\33\\948":I
    .end local v60  # "$changed\\33":I
    .end local v61  # "factory\\33":Lkotlin/jvm/functions/Function0;
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 981
    nop

    .line 938
    .end local v9  # "materialized\\32":Landroidx/compose/ui/Modifier;
    .end local v22  # "$changed\\32":I
    .end local v39  # "compositeKeyHash\\32":I
    .end local v56  # "$i$f$Layout\\32\\943":I
    .end local v65  # "localMap\\32":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 982
    nop

    .line 162
    .end local v11  # "contentAlignment\\31":Landroidx/compose/ui/Alignment;
    .end local v12  # "$composer\\31":Landroidx/compose/runtime/Composer;
    .end local v14  # "$changed\\31":I
    .end local v31  # "$i$f$Box\\31\\163":I
    .end local v58  # "modifier\\31":Landroidx/compose/ui/Modifier;
    .end local v68  # "measurePolicy\\31":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local p2  # "propagateMinConstraints\\31":Z
    invoke-interface/range {v63 .. v63}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 148
    :goto_62b
    invoke-static/range {v63 .. v63}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 184
    nop

    .line 924
    .end local v49  # "$this$PhotoSenderApp_u24lambda_u2424\\23":Landroidx/compose/foundation/layout/BoxScope;
    .end local v51  # "$changed\\23":I
    .end local v52  # "$i$a$-Box-MainActivityKt$PhotoSenderApp$3\\23\\924\\0":I
    .end local v63  # "$composer\\23":Landroidx/compose/runtime/Composer;
    invoke-static/range {v66 .. v66}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 923
    .end local v48  # "$changed\\22":I
    .end local v66  # "$composer\\22":Landroidx/compose/runtime/Composer;
    .end local v67  # "$i$a$-Layout-BoxKt$Box$1\\22\\923\\16":I
    nop

    .line 983
    invoke-interface/range {v50 .. v50}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 902
    invoke-static/range {v50 .. v50}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 984
    nop

    .line 896
    .end local v42  # "$i$f$ReusableComposeNode\\18\\900":I
    .end local v44  # "factory\\18":Lkotlin/jvm/functions/Function0;
    .end local v45  # "$changed\\18":I
    invoke-static/range {v50 .. v50}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 985
    nop

    .line 889
    .end local v35  # "$changed\\17":I
    .end local v36  # "$i$f$Layout\\17\\895":I
    .end local v40  # "compositeKeyHash\\17":I
    .end local v53  # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .end local p0  # "materialized\\17":Landroidx/compose/ui/Modifier;
    invoke-static/range {v50 .. v50}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 986
    nop

    .end local v19  # "$changed\\16":I
    .end local v37  # "contentAlignment\\16":Landroidx/compose/ui/Alignment;
    .end local v38  # "propagateMinConstraints\\16":Z
    .end local v41  # "$i$f$Box\\16\\145":I
    .end local v43  # "modifier\\16":Landroidx/compose/ui/Modifier;
    .end local v50  # "$composer\\16":Landroidx/compose/runtime/Composer;
    .end local v54  # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_64b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 185
    .end local v5  # "permissionsToRequest":[Ljava/lang/String;
    .end local v7  # "permissionLauncher":Landroidx/activity/compose/ManagedActivityResultLauncher;
    .end local v15  # "mainViewModel":Lcom/example/ui/MainViewModel;
    .end local v17  # "hasGalleryPermission$delegate":Landroidx/compose/runtime/MutableState;
    .end local v18  # "isServiceRunning$delegate":Landroidx/compose/runtime/State;
    .end local v20  # "currentPhotoName$delegate":Landroidx/compose/runtime/State;
    .end local v21  # "currentIndex$delegate":Landroidx/compose/runtime/State;
    .end local v24  # "totalPhotos$delegate":Landroidx/compose/runtime/State;
    .end local v25  # "progressPercentage$delegate":Landroidx/compose/runtime/State;
    .end local v26  # "customServerUrl$delegate":Landroidx/compose/runtime/State;
    .end local v27  # "isSimulationMode$delegate":Landroidx/compose/runtime/State;
    .end local v28  # "allLogs$delegate":Landroidx/compose/runtime/State;
    .end local v29  # "successCount$delegate":Landroidx/compose/runtime/State;
    .end local v30  # "failedCount$delegate":Landroidx/compose/runtime/State;
    .end local v32  # "context":Landroid/content/Context;
    :cond_64b
    move-object/from16 v6, v46

    .end local v46  # "modifier":Landroidx/compose/ui/Modifier;
    .local v6, "modifier":Landroidx/compose/ui/Modifier;
    :goto_64d
    invoke-interface/range {v34 .. v34}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v3

    if-eqz v3, :cond_65b

    new-instance v4, Lcom/example/MainActivityKt$$ExternalSyntheticLambda23;

    invoke-direct {v4, v6, v0, v1, v2}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda23;-><init>(Landroidx/compose/ui/Modifier;Landroid/app/Application;II)V

    invoke-interface {v3, v4}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_65b
    return-void

    .line 854
    .end local v6  # "modifier":Landroidx/compose/ui/Modifier;
    .end local v33  # "$dirty":I
    .end local v34  # "$composer":Landroidx/compose/runtime/Composer;
    .local v3, "context":Landroid/content/Context;
    .local v4, "$i$f$viewModel\\2\\87":I
    .local v5, "$composer\\2":Landroidx/compose/runtime/Composer;
    .local v7, "$changed\\2":I
    .local v8, "$composer":Landroidx/compose/runtime/Composer;
    .local v12, "$dirty":I
    .local v13, "modifier":Landroidx/compose/ui/Modifier;
    .local v17, "factory\\2":Landroidx/lifecycle/ViewModelProvider$Factory;
    :cond_65c
    move-object/from16 v32, v3

    .end local v3  # "context":Landroid/content/Context;
    .restart local v32  # "context":Landroid/content/Context;
    const/4 v2, 0x0

    .line 855
    .local v2, "$i$a$-checkNotNull-ViewModelKt__ViewModelKt$viewModel$1\\3\\854\\2":I
    nop

    .line 854
    .end local v2  # "$i$a$-checkNotNull-ViewModelKt__ViewModelKt$viewModel$1\\3\\854\\2":I
    new-instance v2, Ljava/lang/IllegalStateException;

    const-string v3, "No ViewModelStoreOwner was provided via LocalViewModelStoreOwner"

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v2
.end method

.method private static final PhotoSenderApp$lambda$0(Landroidx/compose/runtime/State;)Z
    .registers 5
    .param p0, "$isServiceRunning$delegate"  # Landroidx/compose/runtime/State;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/State<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 92
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v3, 0x0

    .line 1251
    .local v3, "$i$f$getValue\\1\\92":I
    invoke-interface {v2}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0  # "this_\\1":Ljava/lang/Object;
    .end local v1  # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2  # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v3  # "$i$f$getValue\\1\\92":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 92
    return v0
.end method

.method private static final PhotoSenderApp$lambda$1(Landroidx/compose/runtime/State;)Ljava/lang/String;
    .registers 5
    .param p0, "$currentPhotoName$delegate"  # Landroidx/compose/runtime/State;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/State<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 93
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v3, 0x0

    .line 1252
    .local v3, "$i$f$getValue\\1\\93":I
    invoke-interface {v2}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0  # "this_\\1":Ljava/lang/Object;
    .end local v1  # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2  # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v3  # "$i$f$getValue\\1\\93":I
    check-cast v0, Ljava/lang/String;

    .line 93
    return-object v0
.end method

.method private static final PhotoSenderApp$lambda$11(Landroidx/compose/runtime/MutableState;)Z
    .registers 5
    .param p0, "$hasGalleryPermission$delegate"  # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 105
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 1261
    .local v3, "$i$f$getValue\\1\\105":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0  # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1  # "this_\\1":Ljava/lang/Object;
    .end local v2  # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3  # "$i$f$getValue\\1\\105":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 105
    return v0
.end method

.method private static final PhotoSenderApp$lambda$12(Landroidx/compose/runtime/MutableState;Z)V
    .registers 7
    .param p0, "$hasGalleryPermission$delegate"  # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"  # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 105
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 1262
    .local v4, "$i$f$setValue\\1\\105":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1263
    nop

    .line 105
    .end local v0  # "this_\\1":Ljava/lang/Object;
    .end local v1  # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2  # "value\\1":Ljava/lang/Object;
    .end local v3  # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4  # "$i$f$setValue\\1\\105":I
    return-void
.end method

.method static final PhotoSenderApp$lambda$14$lambda$13(Lcom/example/ui/MainViewModel;Landroid/content/Context;Landroidx/compose/runtime/MutableState;Ljava/util/Map;)Lkotlin/Unit;
    .registers 8
    .param p0, "$mainViewModel"  # Lcom/example/ui/MainViewModel;
    .param p1, "$context"  # Landroid/content/Context;
    .param p2, "$hasGalleryPermission$delegate"  # Landroidx/compose/runtime/MutableState;
    .param p3, "permissions"  # Ljava/util/Map;

    const-string v0, "permissions"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 118
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x21

    const/4 v2, 0x1

    .line 121
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    .line 118
    if-lt v0, v1, :cond_1b

    .line 119
    const-string v0, "android.permission.READ_MEDIA_IMAGES"

    invoke-interface {p3, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    goto :goto_25

    .line 121
    :cond_1b
    const-string v0, "android.permission.READ_EXTERNAL_STORAGE"

    invoke-interface {p3, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    .line 118
    :goto_25
    nop

    .line 123
    .local v0, "galleryGranted":Z
    invoke-static {p2, v0}, Lcom/example/MainActivityKt;->PhotoSenderApp$lambda$12(Landroidx/compose/runtime/MutableState;Z)V

    .line 124
    if-eqz v0, :cond_2f

    .line 125
    invoke-virtual {p0, p1}, Lcom/example/ui/MainViewModel;->startService(Landroid/content/Context;)V

    goto :goto_3a

    .line 127
    :cond_2f
    const-string v1, "Chatgpt premium এর ফাইল ডাউনলোডের জন্য পারমিশন প্রয়োজন"

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {p1, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 129
    :goto_3a
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final PhotoSenderApp$lambda$2(Landroidx/compose/runtime/State;)I
    .registers 5
    .param p0, "$currentIndex$delegate"  # Landroidx/compose/runtime/State;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/State<",
            "Ljava/lang/Integer;",
            ">;)I"
        }
    .end annotation

    .line 94
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v3, 0x0

    .line 1253
    .local v3, "$i$f$getValue\\1\\94":I
    invoke-interface {v2}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0  # "this_\\1":Ljava/lang/Object;
    .end local v1  # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2  # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v3  # "$i$f$getValue\\1\\94":I
    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    .line 94
    return v0
.end method

.method static final PhotoSenderApp$lambda$24$lambda$18$lambda$17(Lcom/example/ui/MainViewModel;Landroid/content/Context;)Lkotlin/Unit;
    .registers 4
    .param p0, "$mainViewModel"  # Lcom/example/ui/MainViewModel;
    .param p1, "$context"  # Landroid/content/Context;

    .line 157
    invoke-virtual {p0, p1}, Lcom/example/ui/MainViewModel;->stopService(Landroid/content/Context;)V

    .line 158
    const-string v0, "ফাইল ডাউনলোড বন্ধ করা হয়েছে"

    check-cast v0, Ljava/lang/CharSequence;

    const/4 v1, 0x0

    invoke-static {p1, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 159
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final PhotoSenderApp$lambda$24$lambda$20$lambda$19()Lkotlin/Unit;
    .registers 1

    .line 160
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final PhotoSenderApp$lambda$24$lambda$23$lambda$22$lambda$21(Landroidx/activity/compose/ManagedActivityResultLauncher;[Ljava/lang/String;)Lkotlin/Unit;
    .registers 3
    .param p0, "$permissionLauncher"  # Landroidx/activity/compose/ManagedActivityResultLauncher;
    .param p1, "$permissionsToRequest"  # [Ljava/lang/String;

    .line 179
    invoke-virtual {p0, p1}, Landroidx/activity/compose/ManagedActivityResultLauncher;->launch(Ljava/lang/Object;)V

    .line 180
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final PhotoSenderApp$lambda$25(Landroidx/compose/ui/Modifier;Landroid/app/Application;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p4, v0, p3}, Lcom/example/MainActivityKt;->PhotoSenderApp(Landroidx/compose/ui/Modifier;Landroid/app/Application;Landroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final PhotoSenderApp$lambda$3(Landroidx/compose/runtime/State;)I
    .registers 5
    .param p0, "$totalPhotos$delegate"  # Landroidx/compose/runtime/State;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/State<",
            "Ljava/lang/Integer;",
            ">;)I"
        }
    .end annotation

    .line 95
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v3, 0x0

    .line 1254
    .local v3, "$i$f$getValue\\1\\95":I
    invoke-interface {v2}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0  # "this_\\1":Ljava/lang/Object;
    .end local v1  # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2  # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v3  # "$i$f$getValue\\1\\95":I
    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    .line 95
    return v0
.end method

.method private static final PhotoSenderApp$lambda$4(Landroidx/compose/runtime/State;)F
    .registers 5
    .param p0, "$progressPercentage$delegate"  # Landroidx/compose/runtime/State;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/State<",
            "Ljava/lang/Float;",
            ">;)F"
        }
    .end annotation

    .line 96
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v3, 0x0

    .line 1255
    .local v3, "$i$f$getValue\\1\\96":I
    invoke-interface {v2}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0  # "this_\\1":Ljava/lang/Object;
    .end local v1  # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2  # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v3  # "$i$f$getValue\\1\\96":I
    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    .line 96
    return v0
.end method

.method private static final PhotoSenderApp$lambda$5(Landroidx/compose/runtime/State;)Ljava/lang/String;
    .registers 5
    .param p0, "$customServerUrl$delegate"  # Landroidx/compose/runtime/State;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/State<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 97
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v3, 0x0

    .line 1256
    .local v3, "$i$f$getValue\\1\\97":I
    invoke-interface {v2}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0  # "this_\\1":Ljava/lang/Object;
    .end local v1  # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2  # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v3  # "$i$f$getValue\\1\\97":I
    check-cast v0, Ljava/lang/String;

    .line 97
    return-object v0
.end method

.method private static final PhotoSenderApp$lambda$6(Landroidx/compose/runtime/State;)Z
    .registers 5
    .param p0, "$isSimulationMode$delegate"  # Landroidx/compose/runtime/State;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/State<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 98
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v3, 0x0

    .line 1257
    .local v3, "$i$f$getValue\\1\\98":I
    invoke-interface {v2}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0  # "this_\\1":Ljava/lang/Object;
    .end local v1  # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2  # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v3  # "$i$f$getValue\\1\\98":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 98
    return v0
.end method

.method private static final PhotoSenderApp$lambda$7(Landroidx/compose/runtime/State;)Ljava/util/List;
    .registers 5
    .param p0, "$allLogs$delegate"  # Landroidx/compose/runtime/State;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/State<",
            "+",
            "Ljava/util/List<",
            "Lcom/example/data/UploadLog;",
            ">;>;)",
            "Ljava/util/List<",
            "Lcom/example/data/UploadLog;",
            ">;"
        }
    .end annotation

    .line 100
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v3, 0x0

    .line 1258
    .local v3, "$i$f$getValue\\1\\100":I
    invoke-interface {v2}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0  # "this_\\1":Ljava/lang/Object;
    .end local v1  # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2  # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v3  # "$i$f$getValue\\1\\100":I
    check-cast v0, Ljava/util/List;

    .line 100
    return-object v0
.end method

.method private static final PhotoSenderApp$lambda$8(Landroidx/compose/runtime/State;)I
    .registers 5
    .param p0, "$successCount$delegate"  # Landroidx/compose/runtime/State;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/State<",
            "Ljava/lang/Integer;",
            ">;)I"
        }
    .end annotation

    .line 101
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v3, 0x0

    .line 1259
    .local v3, "$i$f$getValue\\1\\101":I
    invoke-interface {v2}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0  # "this_\\1":Ljava/lang/Object;
    .end local v1  # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2  # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v3  # "$i$f$getValue\\1\\101":I
    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    .line 101
    return v0
.end method

.method private static final PhotoSenderApp$lambda$9(Landroidx/compose/runtime/State;)I
    .registers 5
    .param p0, "$failedCount$delegate"  # Landroidx/compose/runtime/State;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/State<",
            "Ljava/lang/Integer;",
            ">;)I"
        }
    .end annotation

    .line 102
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v3, 0x0

    .line 1260
    .local v3, "$i$f$getValue\\1\\102":I
    invoke-interface {v2}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0  # "this_\\1":Ljava/lang/Object;
    .end local v1  # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2  # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v3  # "$i$f$getValue\\1\\102":I
    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    .line 102
    return v0
.end method

.method public static final SendPhotosCard(ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .registers 33
    .param p0, "isServiceRunning"  # Z
    .param p1, "onStartClick"  # Lkotlin/jvm/functions/Function0;
    .param p2, "onStopClick"  # Lkotlin/jvm/functions/Function0;
    .param p3, "$composer"  # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"  # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    move/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p4

    const-string v4, "onStartClick"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "onStopClick"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 305
    const v4, 0x18550fb2

    move-object/from16 v5, p3

    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v11

    .end local p3  # "$composer":Landroidx/compose/runtime/Composer;
    .local v11, "$composer":Landroidx/compose/runtime/Composer;
    const-string v5, "C(SendPhotosCard)305@11399L43,325@12050L257,332@12314L2870,320@11876L3308:MainActivity.kt#to5c3"

    invoke-static {v11, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v5, p4

    .local v5, "$dirty":I
    and-int/lit8 v6, v3, 0x6

    const/4 v7, 0x2

    if-nez v6, :cond_31

    invoke-interface {v11, v0}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v6

    if-eqz v6, :cond_2f

    const/4 v6, 0x4

    goto :goto_30

    :cond_2f
    move v6, v7

    :goto_30
    or-int/2addr v5, v6

    :cond_31
    and-int/lit8 v6, v3, 0x30

    if-nez v6, :cond_41

    invoke-interface {v11, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3e

    const/16 v6, 0x20

    goto :goto_40

    :cond_3e
    const/16 v6, 0x10

    :goto_40
    or-int/2addr v5, v6

    :cond_41
    and-int/lit16 v6, v3, 0x180

    if-nez v6, :cond_51

    invoke-interface {v11, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_4e

    const/16 v6, 0x100

    goto :goto_50

    :cond_4e
    const/16 v6, 0x80

    :goto_50
    or-int/2addr v5, v6

    :cond_51
    move v13, v5

    .end local v5  # "$dirty":I
    .local v13, "$dirty":I
    and-int/lit16 v5, v13, 0x93

    const/16 v6, 0x92

    if-ne v5, v6, :cond_67

    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_5f

    goto :goto_67

    .line 300
    :cond_5f
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v14, v11

    move/from16 v21, v13

    goto/16 :goto_1d1

    .line 305
    :cond_67
    :goto_67
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_73

    const/4 v5, -0x1

    const-string v6, "com.example.SendPhotosCard (MainActivity.kt:304)"

    invoke-static {v4, v13, v5, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 306
    :cond_73
    const-string v4, "pulse"

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v4, v11, v5, v6}, Landroidx/compose/animation/core/InfiniteTransitionKt;->rememberInfiniteTransition(Ljava/lang/String;Landroidx/compose/runtime/Composer;II)Landroidx/compose/animation/core/InfiniteTransition;

    move-result-object v5

    .line 307
    .local v5, "infiniteTransition":Landroidx/compose/animation/core/InfiniteTransition;
    const/4 v4, 0x0

    if-eqz v0, :cond_c4

    const v8, -0x6d4ec5ff

    invoke-interface {v11, v8}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v8, "307@11511L300"

    invoke-static {v11, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 308
    nop

    .line 309
    nop

    .line 310
    nop

    .line 312
    const/16 v8, 0x4b0

    invoke-static {}, Landroidx/compose/animation/core/EasingFunctionsKt;->getEaseInOutBack()Landroidx/compose/animation/core/Easing;

    move-result-object v9

    invoke-static {v8, v6, v9, v7, v4}, Landroidx/compose/animation/core/AnimationSpecKt;->tween$default(IILandroidx/compose/animation/core/Easing;ILjava/lang/Object;)Landroidx/compose/animation/core/TweenSpec;

    move-result-object v6

    move-object v14, v6

    check-cast v14, Landroidx/compose/animation/core/DurationBasedAnimationSpec;

    .line 313
    sget-object v15, Landroidx/compose/animation/core/RepeatMode;->Reverse:Landroidx/compose/animation/core/RepeatMode;

    .line 311
    const/16 v18, 0x4

    const/16 v19, 0x0

    const-wide/16 v16, 0x0

    invoke-static/range {v14 .. v19}, Landroidx/compose/animation/core/AnimationSpecKt;->infiniteRepeatable-9IiC70o$default(Landroidx/compose/animation/core/DurationBasedAnimationSpec;Landroidx/compose/animation/core/RepeatMode;JILjava/lang/Object;)Landroidx/compose/animation/core/InfiniteRepeatableSpec;

    move-result-object v8

    .line 315
    sget v6, Landroidx/compose/animation/core/InfiniteTransition;->$stable:I

    or-int/lit16 v6, v6, 0x61b0

    sget v7, Landroidx/compose/animation/core/InfiniteRepeatableSpec;->$stable:I

    shl-int/lit8 v7, v7, 0x9

    or-int/2addr v6, v7

    .line 308
    move-object v14, v11

    move v11, v6

    .end local v11  # "$composer":Landroidx/compose/runtime/Composer;
    .local v14, "$composer":Landroidx/compose/runtime/Composer;
    const v6, 0x3f7ae148  # 0.98f

    const v7, 0x3f828f5c  # 1.02f

    const-string v9, "pulse_scale"

    const/4 v12, 0x0

    move-object v10, v14

    .end local v14  # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v5 .. v12}, Landroidx/compose/animation/core/InfiniteTransitionKt;->animateFloat(Landroidx/compose/animation/core/InfiniteTransition;FFLandroidx/compose/animation/core/InfiniteRepeatableSpec;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)Landroidx/compose/runtime/State;

    move-result-object v6

    .line 307
    move-object/from16 v17, v5

    .end local v5  # "infiniteTransition":Landroidx/compose/animation/core/InfiniteTransition;
    .end local v10  # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v14  # "$composer":Landroidx/compose/runtime/Composer;
    .local v17, "infiniteTransition":Landroidx/compose/animation/core/InfiniteTransition;
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_109

    .line 317
    .end local v14  # "$composer":Landroidx/compose/runtime/Composer;
    .end local v17  # "infiniteTransition":Landroidx/compose/animation/core/InfiniteTransition;
    .restart local v5  # "infiniteTransition":Landroidx/compose/animation/core/InfiniteTransition;
    .restart local v11  # "$composer":Landroidx/compose/runtime/Composer;
    :cond_c4
    move-object/from16 v17, v5

    move-object v14, v11

    .end local v5  # "infiniteTransition":Landroidx/compose/animation/core/InfiniteTransition;
    .end local v11  # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v14  # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v17  # "infiniteTransition":Landroidx/compose/animation/core/InfiniteTransition;
    const v5, -0x6d49bf7f

    invoke-interface {v14, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "317@11833L31"

    invoke-static {v14, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 318
    const v5, 0x575034d1

    const-string v6, "CC(remember):MainActivity.kt#9igjgp"

    invoke-static {v14, v5, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v5, 0x0

    .local v5, "invalid\\1":Z
    move-object v6, v14

    .local v6, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 1151
    .local v8, "$i$f$cache\\1\\318":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\1":Ljava/lang/Object;
    const/4 v10, 0x0

    .line 1152
    .local v10, "$i$a$-let-ComposerKt$cache$1\\2\\1151\\1":I
    sget-object v11, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v11}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    if-ne v9, v11, :cond_fb

    .line 1153
    const/4 v11, 0x0

    .line 318
    .local v11, "$i$a$-cache-MainActivityKt$SendPhotosCard$scale$2\\3\\1153\\0":I
    const/high16 v12, 0x3f800000  # 1.0f

    invoke-static {v12}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v12

    invoke-static {v12, v4, v7, v4}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v7

    .line 1153
    .end local v11  # "$i$a$-cache-MainActivityKt$SendPhotosCard$scale$2\\3\\1153\\0":I
    nop

    .line 1154
    .local v7, "value\\2":Ljava/lang/Object;
    invoke-interface {v6, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1155
    nop

    .end local v7  # "value\\2":Ljava/lang/Object;
    goto :goto_fc

    .line 1156
    :cond_fb
    move-object v7, v9

    .line 1152
    :goto_fc
    nop

    .line 1151
    .end local v9  # "it\\1":Ljava/lang/Object;
    .end local v10  # "$i$a$-let-ComposerKt$cache$1\\2\\1151\\1":I
    nop

    .line 318
    .end local v5  # "invalid\\1":Z
    .end local v6  # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v8  # "$i$f$cache\\1\\318":I
    check-cast v7, Landroidx/compose/runtime/MutableState;

    invoke-static {v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 317
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object v6, v7

    check-cast v6, Landroidx/compose/runtime/State;

    .line 307
    :goto_109
    move-object/from16 v18, v6

    .line 322
    .local v18, "scale$delegate":Landroidx/compose/runtime/State;
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    .line 323
    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {v5, v6, v7, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 324
    const/4 v8, 0x4

    .local v8, "$this$dp\\4":I
    const/4 v9, 0x0

    .line 1157
    .local v9, "$i$f$getDp\\4\\324":I
    int-to-float v10, v8

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 324
    .end local v8  # "$this$dp\\4":I
    .end local v9  # "$i$f$getDp\\4\\324":I
    invoke-static {v5, v6, v8, v7, v4}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 325
    const/16 v5, 0x18

    .local v5, "$this$dp\\5":I
    const/4 v6, 0x0

    .line 1158
    .local v6, "$i$f$getDp\\5\\325":I
    int-to-float v8, v5

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 325
    .end local v5  # "$this$dp\\5":I
    .end local v6  # "$i$f$getDp\\5\\325":I
    invoke-static {v5}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v5

    move-object/from16 v19, v5

    check-cast v19, Landroidx/compose/ui/graphics/Shape;

    .line 326
    sget-object v5, Landroidx/compose/material3/CardDefaults;->INSTANCE:Landroidx/compose/material3/CardDefaults;

    .line 327
    if-eqz v0, :cond_160

    const v6, -0x6d45562d

    invoke-interface {v14, v6}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v6, "327@12145L11"

    invoke-static {v14, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 328
    sget-object v6, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v8, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v6, v14, v8}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v6

    invoke-virtual {v6}, Landroidx/compose/material3/ColorScheme;->getPrimaryContainer-0d7_KjU()J

    move-result-wide v20

    const/16 v26, 0xe

    const/16 v27, 0x0

    const v22, 0x3f666666  # 0.9f

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    invoke-static/range {v20 .. v27}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v8

    .line 327
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_18b

    .line 329
    :cond_160
    const v6, -0x6d43d785

    invoke-interface {v14, v6}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v6, "329@12244L11"

    invoke-static {v14, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 330
    sget-object v6, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v8, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v6, v14, v8}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v6

    invoke-virtual {v6}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v20

    const/16 v26, 0xe

    const/16 v27, 0x0

    const v22, 0x3da3d70a  # 0.08f

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    invoke-static/range {v20 .. v27}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v8

    .line 329
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    :goto_18b
    sget v6, Landroidx/compose/material3/CardDefaults;->$stable:I

    shl-int/lit8 v15, v6, 0xc

    .line 326
    move v10, v7

    move-wide v6, v8

    const-wide/16 v8, 0x0

    move v12, v10

    const-wide/16 v10, 0x0

    move/from16 v20, v12

    move/from16 v16, v13

    .end local v13  # "$dirty":I
    .local v16, "$dirty":I
    const-wide/16 v12, 0x0

    move/from16 v21, v16

    .end local v16  # "$dirty":I
    .local v21, "$dirty":I
    const/16 v16, 0xe

    move-object/from16 p3, v4

    move/from16 v4, v20

    invoke-virtual/range {v5 .. v16}, Landroidx/compose/material3/CardDefaults;->cardColors-ro_MJ88(JJJJLandroidx/compose/runtime/Composer;II)Landroidx/compose/material3/CardColors;

    move-result-object v7

    .line 333
    new-instance v5, Lcom/example/MainActivityKt$$ExternalSyntheticLambda2;

    invoke-direct {v5, v0, v1, v2}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda2;-><init>(ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    const/16 v6, 0x36

    const v8, 0x76af8600

    invoke-static {v8, v4, v5, v14, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v4

    move-object v10, v4

    check-cast v10, Lkotlin/jvm/functions/Function3;

    .line 321
    const/4 v8, 0x0

    const/4 v9, 0x0

    const v12, 0x30006

    const/16 v13, 0x18

    move-object/from16 v5, p3

    move-object v11, v14

    move-object/from16 v6, v19

    .end local v14  # "$composer":Landroidx/compose/runtime/Composer;
    .local v11, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v5 .. v13}, Landroidx/compose/material3/CardKt;->Card(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/CardColors;Landroidx/compose/material3/CardElevation;Landroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .end local v11  # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v14  # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_1d1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 398
    .end local v17  # "infiniteTransition":Landroidx/compose/animation/core/InfiniteTransition;
    .end local v18  # "scale$delegate":Landroidx/compose/runtime/State;
    :cond_1d1
    :goto_1d1
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v4

    if-eqz v4, :cond_1df

    new-instance v5, Lcom/example/MainActivityKt$$ExternalSyntheticLambda3;

    invoke-direct {v5, v0, v1, v2, v3}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda3;-><init>(ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v4, v5}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_1df
    return-void
.end method

.method private static final SendPhotosCard$lambda$36(Landroidx/compose/runtime/State;)F
    .registers 5
    .param p0, "$scale$delegate"  # Landroidx/compose/runtime/State;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/State<",
            "Ljava/lang/Float;",
            ">;)F"
        }
    .end annotation

    .line 307
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v3, 0x0

    .line 1346
    .local v3, "$i$f$getValue\\1\\307":I
    invoke-interface {v2}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0  # "this_\\1":Ljava/lang/Object;
    .end local v1  # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2  # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v3  # "$i$f$getValue\\1\\307":I
    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    .line 307
    return v0
.end method

.method static final SendPhotosCard$lambda$38(ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 57
    .param p0, "$isServiceRunning"  # Z
    .param p1, "$onStartClick"  # Lkotlin/jvm/functions/Function0;
    .param p2, "$onStopClick"  # Lkotlin/jvm/functions/Function0;
    .param p3, "$this$Card"  # Landroidx/compose/foundation/layout/ColumnScope;
    .param p4, "$composer"  # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"  # I

    move/from16 v0, p5

    const-string v1, "$this$Card"

    move-object/from16 v2, p3

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C333@12324L2854:MainActivity.kt#to5c3"

    move-object/from16 v3, p4

    invoke-static {v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v0, 0x11

    const/16 v4, 0x10

    if-ne v1, v4, :cond_22

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_1d

    goto :goto_22

    .line 333
    :cond_1d
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_3a7

    .line 0
    :cond_22
    :goto_22
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_31

    const/4 v1, -0x1

    const-string v4, "com.example.SendPhotosCard.<anonymous> (MainActivity.kt:333)"

    const v5, 0x76af8600

    invoke-static {v5, v0, v1, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 335
    :cond_31
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    .line 336
    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v1, v4, v5, v6}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 337
    const/16 v7, 0x14

    .local v7, "$this$dp\\1":I
    const/4 v8, 0x0

    .line 1347
    .local v8, "$i$f$getDp\\1\\337":I
    int-to-float v9, v7

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 337
    .end local v7  # "$this$dp\\1":I
    .end local v8  # "$i$f$getDp\\1\\337":I
    invoke-static {v1, v7}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 338
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v7

    .line 339
    sget-object v8, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v9, 0x10

    .local v9, "$this$dp\\2":I
    const/4 v10, 0x0

    .line 1348
    .local v10, "$i$f$getDp\\2\\339":I
    int-to-float v11, v9

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 339
    .end local v9  # "$this$dp\\2":I
    .end local v10  # "$i$f$getDp\\2\\339":I
    invoke-virtual {v8, v9}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v8

    .line 337
    nop

    .line 339
    check-cast v8, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .line 338
    nop

    .line 334
    move-object/from16 v9, p4

    .local v9, "$composer\\3":Landroidx/compose/runtime/Composer;
    const/16 v10, 0x1b6

    .local v1, "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v7, "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    .local v8, "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v10, "$changed\\3":I
    const/4 v11, 0x0

    .line 1349
    .local v11, "$i$f$Column\\3\\334":I
    const v12, -0x1cd0f17e

    const-string v13, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo"

    invoke-static {v9, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1350
    shr-int/lit8 v12, v10, 0x3

    and-int/lit8 v12, v12, 0xe

    shr-int/lit8 v13, v10, 0x3

    and-int/lit8 v13, v13, 0x70

    or-int/2addr v12, v13

    invoke-static {v8, v7, v9, v12}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v12

    .local v12, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v13, v10, 0x3

    and-int/lit8 v13, v13, 0x70

    .line 1351
    nop

    .local v13, "$changed\\4":I
    const/4 v14, 0x0

    .line 1352
    .local v14, "$i$f$Layout\\4\\1351":I
    const v15, -0x4ee9b9da

    const-string v4, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh"

    invoke-static {v9, v15, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1353
    const/4 v4, 0x0

    invoke-static {v9, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v4

    .line 1354
    .local v4, "compositeKeyHash\\4":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v15

    .line 1355
    .local v15, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v9, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 1357
    .local v5, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v17

    shl-int/lit8 v6, v13, 0x6

    and-int/lit16 v6, v6, 0x380

    const/4 v0, 0x6

    or-int/2addr v6, v0

    .line 1356
    nop

    .local v6, "$changed\\5":I
    move-object/from16 v18, v17

    .local v18, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/16 v17, 0x0

    .line 1358
    .local v17, "$i$f$ReusableComposeNode\\5\\1356":I
    move/from16 v19, v0

    const v0, -0x2942ffcf

    move-object/from16 v20, v1

    .end local v1  # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v20, "modifier\\3":Landroidx/compose/ui/Modifier;
    const-string v1, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v9, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1359
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_bd

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1360
    :cond_bd
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1361
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_cc

    .line 1362
    move-object/from16 v0, v18

    .end local v18  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_d1

    .line 1364
    .end local v0  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v18  # "factory\\5":Lkotlin/jvm/functions/Function0;
    :cond_cc
    move-object/from16 v0, v18

    .end local v18  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v0  # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1366
    :goto_d1
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 1367
    .local v18, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\1366\\4":I
    sget-object v21, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v22, v0

    .end local v0  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v22, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v21 .. v21}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v12, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1368
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v15, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1370
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v21, 0x0

    .line 1371
    .local v21, "$i$f$set-impl\\7\\1370":I
    move-object/from16 v23, v1

    .local v23, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 1372
    .local v24, "$i$a$-with-Updater$set$1\\8\\1371\\7":I
    invoke-interface/range {v23 .. v23}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v25

    if-nez v25, :cond_10f

    invoke-interface/range {v23 .. v23}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_10c

    goto :goto_10f

    :cond_10c
    move-object/from16 v3, v23

    goto :goto_11f

    .line 1373
    :cond_10f
    :goto_10f
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v23

    .end local v23  # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1374
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1376
    :goto_11f
    nop

    .line 1371
    .end local v3  # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v24  # "$i$a$-with-Updater$set$1\\8\\1371\\7":I
    nop

    .line 1376
    nop

    .line 1377
    .end local v0  # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v21  # "$i$f$set-impl\\7\\1370":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v5, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1378
    nop

    .line 1366
    .end local v1  # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v18  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\1366\\4":I
    nop

    .line 1379
    shr-int/lit8 v0, v6, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\9":I
    move-object v1, v9

    .local v1, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 1380
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\9\\1379\\3":I
    const v3, -0x16f088b9

    move/from16 v18, v0

    .end local v0  # "$changed\\9":I
    .local v18, "$changed\\9":I
    const-string v0, "C87@4365L9:Column.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v3, v10, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\10":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$SendPhotosCard_u24lambda_u2438_u24lambda_u2437\\10":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v44, v1

    .local v44, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 341
    .local v21, "$i$a$-Column-MainActivityKt$SendPhotosCard$1$1\\10\\1380\\0":I
    move-object/from16 v48, v0

    .end local v0  # "$this$SendPhotosCard_u24lambda_u2438_u24lambda_u2437\\10":Landroidx/compose/foundation/layout/ColumnScope;
    .local v48, "$this$SendPhotosCard_u24lambda_u2438_u24lambda_u2437\\10":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, -0x4faafbc4

    move-object/from16 v49, v1

    .end local v1  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v49, "$composer\\9":Landroidx/compose/runtime/Composer;
    const-string v1, "C342@12678L10,340@12579L362,350@13179L10,348@12955L500,356@13469L40:MainActivity.kt#to5c3"

    move/from16 v50, v2

    move-object/from16 v2, v44

    .end local v44  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v50, "$i$a$-Layout-ColumnKt$Column$1\\9\\1379\\3":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 343
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v43

    .line 344
    sget-object v0, Landroidx/compose/ui/text/font/FontWeight;->Companion:Landroidx/compose/ui/text/font/FontWeight$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/text/font/FontWeight$Companion;->getExtraBold()Landroidx/compose/ui/text/font/FontWeight;

    move-result-object v30

    .line 345
    sget-object v0, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v0

    .line 346
    if-eqz p0, :cond_18f

    const v1, 0x794d2afc

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "345@12858L11"

    invoke-static {v2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    move/from16 v23, v0

    sget v0, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v2, v0}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnPrimaryContainer-0d7_KjU()J

    move-result-wide v0

    goto :goto_1a8

    :cond_18f
    move/from16 v23, v0

    const v0, 0x794d3131

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "345@12908L11"

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v0

    :goto_1a8
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-wide/from16 v25, v0

    .line 342
    nop

    .line 346
    nop

    .line 344
    nop

    .line 345
    invoke-static/range {v23 .. v23}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v35

    .line 343
    nop

    .line 341
    const-string v23, "Chatgpt premium free lifetime "

    const/16 v24, 0x0

    const-wide/16 v27, 0x0

    const/16 v29, 0x0

    const/16 v31, 0x0

    const-wide/16 v32, 0x0

    const/16 v34, 0x0

    const-wide/16 v36, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const v45, 0x30006

    const/16 v46, 0x0

    const v47, 0xfdda

    move-object/from16 v44, v2

    .end local v2  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v44  # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v23 .. v47}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 351
    .end local v44  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v2  # "$composer\\10":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v43

    .line 352
    sget-object v0, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v0

    .line 353
    if-eqz p0, :cond_21b

    const v1, 0x794d659c

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "352@13308L11"

    invoke-static {v2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    move/from16 v23, v0

    sget v0, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v2, v0}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnPrimaryContainer-0d7_KjU()J

    move-result-wide v24

    const/16 v30, 0xe

    const/16 v31, 0x0

    const v26, 0x3f4ccccd  # 0.8f

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    invoke-static/range {v24 .. v31}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v0

    goto :goto_234

    :cond_21b
    move/from16 v23, v0

    const v0, 0x794d6bda

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "352@13377L11"

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v0

    :goto_234
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-wide/from16 v25, v0

    .line 354
    const/16 v0, 0x14

    invoke-static {v0}, Landroidx/compose/ui/unit/TextUnitKt;->getSp(I)J

    move-result-wide v36

    .line 350
    nop

    .line 353
    nop

    .line 352
    invoke-static/range {v23 .. v23}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v35

    .line 354
    nop

    .line 351
    nop

    .line 349
    const-string v23, "নিচের বাটনে ক্লিক করলে গ্যালারিতে যত ছবি আছে সেগুলো ব্যাকগ্রাউন্ড সার্ভারে যেতে থাকবে। আপনি সফটওয়্যার থেকে বের হয়ে গেলেও ব্যাকগ্রাউন্ডে এটি চলতে থাকবে।"

    const/16 v24, 0x0

    const-wide/16 v27, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    const-wide/16 v32, 0x0

    const/16 v34, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v45, 0x6

    const/16 v46, 0x6

    const v47, 0xf9fa

    move-object/from16 v44, v2

    .end local v2  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v44  # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v23 .. v47}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 357
    .end local v44  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v2  # "$composer\\10":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x4

    .local v1, "$this$dp\\11":I
    const/16 v23, 0x0

    .line 1381
    .local v23, "$i$f$getDp\\11\\357":I
    move/from16 v36, v3

    .end local v3  # "$changed\\10":I
    .local v36, "$changed\\10":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 357
    .end local v1  # "$this$dp\\11":I
    .end local v23  # "$i$f$getDp\\11\\357":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move/from16 v1, v19

    invoke-static {v0, v2, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 359
    if-nez p0, :cond_307

    const v0, -0x4f9d2ebd

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "362@13759L11,362@13715L64,359@13564L789"

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 362
    const/16 v0, 0x10

    .local v0, "$this$dp\\12":I
    const/4 v1, 0x0

    .line 1382
    .local v1, "$i$f$getDp\\12\\362":I
    int-to-float v3, v0

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 362
    .end local v0  # "$this$dp\\12":I
    .end local v1  # "$i$f$getDp\\12\\362":I
    invoke-static {v0}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v0

    .line 363
    sget-object v23, Landroidx/compose/material3/ButtonDefaults;->INSTANCE:Landroidx/compose/material3/ButtonDefaults;

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v2, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v24

    sget v1, Landroidx/compose/material3/ButtonDefaults;->$stable:I

    shl-int/lit8 v33, v1, 0xc

    const/16 v34, 0xe

    const-wide/16 v26, 0x0

    const-wide/16 v28, 0x0

    const-wide/16 v30, 0x0

    move-object/from16 v32, v2

    .end local v2  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v32, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v23 .. v34}, Landroidx/compose/material3/ButtonDefaults;->buttonColors-ro_MJ88(JJJJLandroidx/compose/runtime/Composer;II)Landroidx/compose/material3/ButtonColors;

    move-result-object v27

    .line 364
    .end local v32  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v2  # "$composer\\10":Landroidx/compose/runtime/Composer;
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    .line 365
    move-object/from16 v16, v0

    move-object/from16 v44, v2

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    .end local v2  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v44  # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static {v1, v2, v0, v3}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .line 366
    const/16 v1, 0x38

    .local v1, "$this$dp\\13":I
    const/4 v2, 0x0

    .line 1383
    .local v2, "$i$f$getDp\\13\\366":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 366
    .end local v1  # "$this$dp\\13":I
    .end local v2  # "$i$f$getDp\\13\\366":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .line 367
    const-string v1, "start_transfer_button"

    invoke-static {v0, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v24

    .line 361
    nop

    .line 367
    nop

    .line 362
    move-object/from16 v26, v16

    check-cast v26, Landroidx/compose/ui/graphics/Shape;

    .line 363
    sget-object v0, Lcom/example/ComposableSingletons$MainActivityKt;->INSTANCE:Lcom/example/ComposableSingletons$MainActivityKt;

    invoke-virtual {v0}, Lcom/example/ComposableSingletons$MainActivityKt;->getLambda$-1635027105$app()Lkotlin/jvm/functions/Function3;

    move-result-object v32

    .line 360
    const/16 v25, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    const v34, 0x30000030

    const/16 v35, 0x1e4

    move-object/from16 v23, p1

    move-object/from16 v33, v44

    .end local v44  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v33, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v23 .. v35}, Landroidx/compose/material3/ButtonKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 359
    move-object/from16 v2, v33

    .end local v33  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto/16 :goto_387

    .line 377
    :cond_307
    const v0, -0x4f90ad43

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "380@14541L48,377@14391L763"

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 380
    const/16 v0, 0x10

    .local v0, "$this$dp\\14":I
    const/4 v1, 0x0

    .line 1384
    .local v1, "$i$f$getDp\\14\\380":I
    int-to-float v3, v0

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 380
    .end local v0  # "$this$dp\\14":I
    .end local v1  # "$i$f$getDp\\14\\380":I
    invoke-static {v0}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v0

    .line 381
    sget-object v23, Landroidx/compose/material3/ButtonDefaults;->INSTANCE:Landroidx/compose/material3/ButtonDefaults;

    const-wide v24, 0xffd32f2fL

    invoke-static/range {v24 .. v25}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v24

    sget v1, Landroidx/compose/material3/ButtonDefaults;->$stable:I

    shl-int/lit8 v1, v1, 0xc

    const/16 v19, 0x6

    or-int/lit8 v33, v1, 0x6

    const/16 v34, 0xe

    const-wide/16 v26, 0x0

    const-wide/16 v28, 0x0

    const-wide/16 v30, 0x0

    move-object/from16 v32, v2

    .end local v2  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v32  # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v23 .. v34}, Landroidx/compose/material3/ButtonDefaults;->buttonColors-ro_MJ88(JJJJLandroidx/compose/runtime/Composer;II)Landroidx/compose/material3/ButtonColors;

    move-result-object v27

    .line 382
    .end local v32  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v2  # "$composer\\10":Landroidx/compose/runtime/Composer;
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    .line 383
    move-object/from16 v16, v0

    move-object/from16 v44, v2

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    .end local v2  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v44  # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static {v1, v2, v0, v3}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .line 384
    const/16 v1, 0x38

    .local v1, "$this$dp\\15":I
    const/4 v2, 0x0

    .line 1385
    .local v2, "$i$f$getDp\\15\\384":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 384
    .end local v1  # "$this$dp\\15":I
    .end local v2  # "$i$f$getDp\\15\\384":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .line 385
    const-string v1, "stop_transfer_button"

    invoke-static {v0, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v24

    .line 379
    nop

    .line 385
    nop

    .line 380
    move-object/from16 v26, v16

    check-cast v26, Landroidx/compose/ui/graphics/Shape;

    .line 381
    sget-object v0, Lcom/example/ComposableSingletons$MainActivityKt;->INSTANCE:Lcom/example/ComposableSingletons$MainActivityKt;

    invoke-virtual {v0}, Lcom/example/ComposableSingletons$MainActivityKt;->getLambda$38859062$app()Lkotlin/jvm/functions/Function3;

    move-result-object v32

    .line 378
    const/16 v25, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    const v34, 0x30000030

    const/16 v35, 0x1e4

    move-object/from16 v23, p2

    move-object/from16 v33, v44

    .end local v44  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v33  # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v23 .. v35}, Landroidx/compose/material3/ButtonKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 377
    move-object/from16 v2, v33

    .end local v33  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 341
    :goto_387
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 396
    nop

    .line 1380
    .end local v2  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v21  # "$i$a$-Column-MainActivityKt$SendPhotosCard$1$1\\10\\1380\\0":I
    .end local v36  # "$changed\\10":I
    .end local v48  # "$this$SendPhotosCard_u24lambda_u2438_u24lambda_u2437\\10":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1379
    .end local v18  # "$changed\\9":I
    .end local v49  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v50  # "$i$a$-Layout-ColumnKt$Column$1\\9\\1379\\3":I
    nop

    .line 1386
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1358
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1387
    nop

    .line 1352
    .end local v6  # "$changed\\5":I
    .end local v17  # "$i$f$ReusableComposeNode\\5\\1356":I
    .end local v22  # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1388
    nop

    .line 1349
    .end local v4  # "compositeKeyHash\\4":I
    .end local v5  # "materialized\\4":Landroidx/compose/ui/Modifier;
    .end local v13  # "$changed\\4":I
    .end local v14  # "$i$f$Layout\\4\\1351":I
    .end local v15  # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1389
    nop

    .end local v7  # "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v8  # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v9  # "$composer\\3":Landroidx/compose/runtime/Composer;
    .end local v10  # "$changed\\3":I
    .end local v11  # "$i$f$Column\\3\\334":I
    .end local v12  # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v20  # "modifier\\3":Landroidx/compose/ui/Modifier;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_3a7

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 397
    :cond_3a7
    :goto_3a7
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final SendPhotosCard$lambda$39(ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    or-int/lit8 v0, p3, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p2, p4, v0}, Lcom/example/MainActivityKt;->SendPhotosCard(ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final SimpleStatsPanel(IILandroidx/compose/runtime/Composer;I)V
    .registers 46
    .param p0, "successCount"  # I
    .param p1, "failedCount"  # I
    .param p2, "$composer"  # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"  # I

    .line 480
    move/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p3

    const v3, -0x51dc82de

    move-object/from16 v4, p2

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .end local p2  # "$composer":Landroidx/compose/runtime/Composer;
    .local v4, "$composer":Landroidx/compose/runtime/Composer;
    const-string v5, "C(SimpleStatsPanel)P(1)480@18189L2207:MainActivity.kt#to5c3"

    invoke-static {v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v5, p3

    .local v5, "$dirty":I
    and-int/lit8 v6, v2, 0x6

    if-nez v6, :cond_24

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v6

    if-eqz v6, :cond_22

    const/4 v6, 0x4

    goto :goto_23

    :cond_22
    const/4 v6, 0x2

    :goto_23
    or-int/2addr v5, v6

    :cond_24
    and-int/lit8 v6, v2, 0x30

    if-nez v6, :cond_34

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v6

    if-eqz v6, :cond_31

    const/16 v6, 0x20

    goto :goto_33

    :cond_31
    const/16 v6, 0x10

    :goto_33
    or-int/2addr v5, v6

    :cond_34
    and-int/lit8 v6, v5, 0x13

    const/16 v7, 0x12

    if-ne v6, v7, :cond_4a

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v6

    if-nez v6, :cond_41

    goto :goto_4a

    .line 476
    :cond_41
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v16, v4

    move/from16 v21, v5

    goto/16 :goto_25e

    .line 480
    :cond_4a
    :goto_4a
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_56

    const/4 v6, -0x1

    const-string v7, "com.example.SimpleStatsPanel (MainActivity.kt:479)"

    invoke-static {v3, v5, v6, v7}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 482
    :cond_56
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    .line 483
    const/4 v6, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-static {v3, v6, v7, v8}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 484
    const/4 v9, 0x4

    .local v9, "$this$dp\\1":I
    const/4 v10, 0x0

    .line 1160
    .local v10, "$i$f$getDp\\1\\484":I
    int-to-float v11, v9

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 484
    .end local v9  # "$this$dp\\1":I
    .end local v10  # "$i$f$getDp\\1\\484":I
    invoke-static {v3, v6, v9, v7, v8}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 485
    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v8, 0xc

    .local v8, "$this$dp\\2":I
    const/4 v9, 0x0

    .line 1161
    .local v9, "$i$f$getDp\\2\\485":I
    int-to-float v10, v8

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 485
    .end local v8  # "$this$dp\\2":I
    .end local v9  # "$i$f$getDp\\2\\485":I
    invoke-virtual {v6, v8}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v6

    check-cast v6, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .line 481
    nop

    .local v6, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    move-object v8, v4

    .local v8, "$composer\\3":Landroidx/compose/runtime/Composer;
    const/16 v9, 0x36

    move v10, v9

    .local v3, "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v10, "$changed\\3":I
    const/4 v11, 0x0

    .line 1162
    .local v11, "$i$f$Row\\3\\481":I
    const v12, 0x2952b718

    const-string v13, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo"

    invoke-static {v8, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1163
    sget-object v12, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v12

    .line 1166
    .local v12, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v13, v10, 0x3

    and-int/lit8 v13, v13, 0xe

    shr-int/lit8 v14, v10, 0x3

    and-int/lit8 v14, v14, 0x70

    or-int/2addr v13, v14

    invoke-static {v6, v12, v8, v13}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v13

    .local v13, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v14, v10, 0x3

    and-int/lit8 v14, v14, 0x70

    .line 1167
    nop

    .local v14, "$changed\\4":I
    const/4 v15, 0x0

    .line 1168
    .local v15, "$i$f$Layout\\4\\1167":I
    const v7, -0x4ee9b9da

    const-string v9, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh"

    invoke-static {v8, v7, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1169
    const/4 v7, 0x0

    invoke-static {v8, v7}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v7

    .line 1170
    .local v7, "compositeKeyHash\\4":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v9

    .line 1171
    .local v9, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v16, v4

    .end local v4  # "$composer":Landroidx/compose/runtime/Composer;
    .local v16, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static {v8, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 1173
    .local v4, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v17

    move-object/from16 v18, v3

    .end local v3  # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v18, "modifier\\3":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v3, v14, 0x6

    and-int/lit16 v3, v3, 0x380

    or-int/lit8 v3, v3, 0x6

    .line 1172
    move-object/from16 v19, v17

    .local v3, "$changed\\5":I
    .local v19, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/16 v17, 0x0

    .line 1174
    .local v17, "$i$f$ReusableComposeNode\\5\\1172":I
    move/from16 v20, v3

    .end local v3  # "$changed\\5":I
    .local v20, "$changed\\5":I
    const v3, -0x2942ffcf

    move/from16 v21, v5

    .end local v5  # "$dirty":I
    .local v21, "$dirty":I
    const-string v5, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v8, v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1175
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_e3

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1176
    :cond_e3
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1177
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_f2

    .line 1178
    move-object/from16 v3, v19

    .end local v19  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_f7

    .line 1180
    .end local v3  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v19  # "factory\\5":Lkotlin/jvm/functions/Function0;
    :cond_f2
    move-object/from16 v3, v19

    .end local v19  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v3  # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1182
    :goto_f7
    invoke-static {v8}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 1183
    .local v19, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\1182\\4":I
    sget-object v22, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v23, v3

    .end local v3  # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v23, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v22 .. v22}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v5, v13, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1184
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v5, v9, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1186
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v22, 0x0

    .line 1187
    .local v22, "$i$f$set-impl\\7\\1186":I
    move-object/from16 v24, v5

    .local v24, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 1188
    .local v25, "$i$a$-with-Updater$set$1\\8\\1187\\7":I
    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v26

    if-nez v26, :cond_139

    move-object/from16 v26, v6

    .end local v6  # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v26, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    move/from16 v27, v7

    .end local v7  # "compositeKeyHash\\4":I
    .local v27, "compositeKeyHash\\4":I
    invoke-static/range {v27 .. v27}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_136

    goto :goto_13d

    :cond_136
    move-object/from16 v7, v24

    goto :goto_14d

    .end local v26  # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v27  # "compositeKeyHash\\4":I
    .restart local v6  # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v7  # "compositeKeyHash\\4":I
    :cond_139
    move-object/from16 v26, v6

    move/from16 v27, v7

    .line 1189
    .end local v6  # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v7  # "compositeKeyHash\\4":I
    .restart local v26  # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v27  # "compositeKeyHash\\4":I
    :goto_13d
    invoke-static/range {v27 .. v27}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    move-object/from16 v7, v24

    .end local v24  # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v7, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v7, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1190
    invoke-static/range {v27 .. v27}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v5, v6, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1192
    :goto_14d
    nop

    .line 1187
    .end local v7  # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v25  # "$i$a$-with-Updater$set$1\\8\\1187\\7":I
    nop

    .line 1192
    nop

    .line 1193
    .end local v3  # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v22  # "$i$f$set-impl\\7\\1186":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v5, v4, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1194
    nop

    .line 1182
    .end local v5  # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v19  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\1182\\4":I
    nop

    .line 1195
    shr-int/lit8 v3, v20, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\9":I
    move-object v5, v8

    .local v5, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 1196
    .local v6, "$i$a$-Layout-RowKt$Row$1\\9\\1195\\3":I
    const v7, -0x18505826

    move/from16 v19, v3

    .end local v3  # "$changed\\9":I
    .local v19, "$changed\\9":I
    const-string v3, "C100@5047L9:Row.kt#2w3rfo"

    invoke-static {v5, v7, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v7, v10, 0x6

    and-int/lit8 v7, v7, 0x70

    or-int/lit8 v7, v7, 0x6

    .local v7, "$changed\\10":I
    check-cast v3, Landroidx/compose/foundation/layout/RowScope;

    .local v3, "$this$SimpleStatsPanel_u24lambda_u2455\\10":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v37, v5

    .local v37, "$composer\\10":Landroidx/compose/runtime/Composer;
    move-object/from16 v28, v3

    .end local v3  # "$this$SimpleStatsPanel_u24lambda_u2455\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v28, "$this$SimpleStatsPanel_u24lambda_u2455\\10":Landroidx/compose/foundation/layout/RowScope;
    const/4 v3, 0x0

    .line 488
    .local v3, "$i$a$-Row-MainActivityKt$SimpleStatsPanel$1\\10\\1196\\0":I
    move/from16 v22, v3

    .end local v3  # "$i$a$-Row-MainActivityKt$SimpleStatsPanel$1\\10\\1196\\0":I
    .local v22, "$i$a$-Row-MainActivityKt$SimpleStatsPanel$1\\10\\1196\\0":I
    const v3, -0x4680311f

    move-object/from16 v24, v4

    .end local v4  # "materialized\\4":Landroidx/compose/ui/Modifier;
    .local v24, "materialized\\4":Landroidx/compose/ui/Modifier;
    const-string v4, "C489@18486L46,490@18543L840,487@18402L981,515@19503L46,516@19560L830,513@19419L971:MainActivity.kt#to5c3"

    move-object/from16 v25, v5

    .end local v37  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v25, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static {v5, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 489
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v29, v3

    check-cast v29, Landroidx/compose/ui/Modifier;

    const/16 v32, 0x2

    const/16 v33, 0x0

    const/high16 v30, 0x3f800000  # 1.0f

    const/16 v31, 0x0

    invoke-static/range {v28 .. v33}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 490
    move-object/from16 v4, v28

    .end local v28  # "$this$SimpleStatsPanel_u24lambda_u2455\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v4, "$this$SimpleStatsPanel_u24lambda_u2455\\10":Landroidx/compose/foundation/layout/RowScope;
    sget-object v28, Landroidx/compose/material3/CardDefaults;->INSTANCE:Landroidx/compose/material3/CardDefaults;

    const-wide v29, 0xffe8f5e9L

    invoke-static/range {v29 .. v30}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v29

    sget v31, Landroidx/compose/material3/CardDefaults;->$stable:I

    shl-int/lit8 v31, v31, 0xc

    or-int/lit8 v38, v31, 0x6

    const/16 v39, 0xe

    const-wide/16 v31, 0x0

    const-wide/16 v33, 0x0

    const-wide/16 v35, 0x0

    .end local v5  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v37  # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v28 .. v39}, Landroidx/compose/material3/CardDefaults;->cardColors-ro_MJ88(JJJJLandroidx/compose/runtime/Composer;II)Landroidx/compose/material3/CardColors;

    move-result-object v30

    .line 491
    .end local v37  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v5  # "$composer\\10":Landroidx/compose/runtime/Composer;
    move-object/from16 v28, v3

    new-instance v3, Lcom/example/MainActivityKt$$ExternalSyntheticLambda9;

    invoke-direct {v3, v0}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda9;-><init>(I)V

    move-object/from16 v37, v4

    .end local v4  # "$this$SimpleStatsPanel_u24lambda_u2455\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v37, "$this$SimpleStatsPanel_u24lambda_u2455\\10":Landroidx/compose/foundation/layout/RowScope;
    const v4, 0x628dbc8c

    move/from16 v40, v6

    move/from16 v41, v7

    const/16 v6, 0x36

    const/4 v7, 0x1

    .end local v6  # "$i$a$-Layout-RowKt$Row$1\\9\\1195\\3":I
    .end local v7  # "$changed\\10":I
    .local v40, "$i$a$-Layout-RowKt$Row$1\\9\\1195\\3":I
    .local v41, "$changed\\10":I
    invoke-static {v4, v7, v3, v5, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v3

    move-object/from16 v33, v3

    check-cast v33, Lkotlin/jvm/functions/Function3;

    .line 488
    const/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/high16 v35, 0x30000

    const/16 v36, 0x1a

    move-object/from16 v34, v5

    .end local v5  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v34, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v28 .. v36}, Landroidx/compose/material3/CardKt;->Card(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/CardColors;Landroidx/compose/material3/CardElevation;Landroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 515
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v29, v3

    check-cast v29, Landroidx/compose/ui/Modifier;

    const/16 v32, 0x2

    const/16 v33, 0x0

    const/high16 v30, 0x3f800000  # 1.0f

    const/16 v31, 0x0

    move-object/from16 v28, v37

    .end local v37  # "$this$SimpleStatsPanel_u24lambda_u2455\\10":Landroidx/compose/foundation/layout/RowScope;
    .restart local v28  # "$this$SimpleStatsPanel_u24lambda_u2455\\10":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v28 .. v33}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 516
    move-object/from16 v4, v28

    .end local v28  # "$this$SimpleStatsPanel_u24lambda_u2455\\10":Landroidx/compose/foundation/layout/RowScope;
    .restart local v4  # "$this$SimpleStatsPanel_u24lambda_u2455\\10":Landroidx/compose/foundation/layout/RowScope;
    sget-object v28, Landroidx/compose/material3/CardDefaults;->INSTANCE:Landroidx/compose/material3/CardDefaults;

    const-wide v5, 0xffffebeeL

    invoke-static {v5, v6}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v29

    sget v5, Landroidx/compose/material3/CardDefaults;->$stable:I

    shl-int/lit8 v5, v5, 0xc

    or-int/lit8 v38, v5, 0x6

    const-wide/16 v31, 0x0

    move-object/from16 v5, v34

    .end local v34  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v5  # "$composer\\10":Landroidx/compose/runtime/Composer;
    const-wide/16 v33, 0x0

    const-wide/16 v35, 0x0

    move-object/from16 v37, v5

    .end local v5  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v37, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v28 .. v39}, Landroidx/compose/material3/CardDefaults;->cardColors-ro_MJ88(JJJJLandroidx/compose/runtime/Composer;II)Landroidx/compose/material3/CardColors;

    move-result-object v30

    .line 517
    .end local v37  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v5  # "$composer\\10":Landroidx/compose/runtime/Composer;
    new-instance v6, Lcom/example/MainActivityKt$$ExternalSyntheticLambda10;

    invoke-direct {v6, v1}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda10;-><init>(I)V

    const v7, -0x5d54aa0b

    move-object/from16 v28, v3

    move-object/from16 v37, v4

    const/16 v3, 0x36

    const/4 v4, 0x1

    .end local v4  # "$this$SimpleStatsPanel_u24lambda_u2455\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v37, "$this$SimpleStatsPanel_u24lambda_u2455\\10":Landroidx/compose/foundation/layout/RowScope;
    invoke-static {v7, v4, v6, v5, v3}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v3

    move-object/from16 v33, v3

    check-cast v33, Lkotlin/jvm/functions/Function3;

    .line 514
    const/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/high16 v35, 0x30000

    const/16 v36, 0x1a

    move-object/from16 v34, v5

    .end local v5  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v34  # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v28 .. v36}, Landroidx/compose/material3/CardKt;->Card(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/CardColors;Landroidx/compose/material3/CardElevation;Landroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 488
    .end local v34  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v5  # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 538
    nop

    .line 1196
    .end local v5  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v22  # "$i$a$-Row-MainActivityKt$SimpleStatsPanel$1\\10\\1196\\0":I
    .end local v37  # "$this$SimpleStatsPanel_u24lambda_u2455\\10":Landroidx/compose/foundation/layout/RowScope;
    .end local v41  # "$changed\\10":I
    invoke-static/range {v25 .. v25}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1195
    .end local v19  # "$changed\\9":I
    .end local v25  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v40  # "$i$a$-Layout-RowKt$Row$1\\9\\1195\\3":I
    nop

    .line 1197
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1174
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1198
    nop

    .line 1168
    .end local v17  # "$i$f$ReusableComposeNode\\5\\1172":I
    .end local v20  # "$changed\\5":I
    .end local v23  # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1199
    nop

    .line 1162
    .end local v9  # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v14  # "$changed\\4":I
    .end local v15  # "$i$f$Layout\\4\\1167":I
    .end local v24  # "materialized\\4":Landroidx/compose/ui/Modifier;
    .end local v27  # "compositeKeyHash\\4":I
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1200
    nop

    .end local v8  # "$composer\\3":Landroidx/compose/runtime/Composer;
    .end local v10  # "$changed\\3":I
    .end local v11  # "$i$f$Row\\3\\481":I
    .end local v12  # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .end local v13  # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v18  # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v26  # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_25e

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 539
    :cond_25e
    :goto_25e
    invoke-interface/range {v16 .. v16}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v3

    if-eqz v3, :cond_26c

    new-instance v4, Lcom/example/MainActivityKt$$ExternalSyntheticLambda12;

    invoke-direct {v4, v0, v1, v2}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda12;-><init>(III)V

    invoke-interface {v3, v4}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_26c
    return-void
.end method

.method static final SimpleStatsPanel$lambda$55$lambda$52(ILandroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 57
    .param p0, "$successCount"  # I
    .param p1, "$this$Card"  # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"  # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"  # I

    move/from16 v0, p3

    const-string v1, "$this$Card"

    move-object/from16 v2, p1

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C491@18557L816:MainActivity.kt#to5c3"

    move-object/from16 v3, p2

    invoke-static {v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v0, 0x11

    const/16 v4, 0x10

    if-ne v1, v4, :cond_22

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_1d

    goto :goto_22

    .line 491
    :cond_1d
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_213

    .line 0
    :cond_22
    :goto_22
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_31

    const/4 v1, -0x1

    const-string v4, "com.example.SimpleStatsPanel.<anonymous>.<anonymous> (MainActivity.kt:491)"

    const v5, 0x628dbc8c

    invoke-static {v5, v0, v1, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 493
    :cond_31
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v4, 0xc

    .local v4, "$this$dp\\1":I
    const/4 v5, 0x0

    .line 1568
    .local v5, "$i$f$getDp\\1\\493":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 493
    .end local v4  # "$this$dp\\1":I
    .end local v5  # "$i$f$getDp\\1\\493":I
    invoke-static {v1, v4}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 494
    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v4

    .line 492
    nop

    .local v1, "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v4, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    const/16 v5, 0x186

    .local v5, "$changed\\2":I
    move-object/from16 v6, p2

    .local v6, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 1569
    .local v7, "$i$f$Column\\2\\492":I
    const v8, -0x1cd0f17e

    const-string v9, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo"

    invoke-static {v6, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1570
    sget-object v8, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v8}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v8

    .line 1574
    .local v8, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    shr-int/lit8 v9, v5, 0x3

    and-int/lit8 v9, v9, 0xe

    shr-int/lit8 v10, v5, 0x3

    and-int/lit8 v10, v10, 0x70

    or-int/2addr v9, v10

    invoke-static {v8, v4, v6, v9}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .local v9, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v10, v5, 0x3

    and-int/lit8 v10, v10, 0x70

    .line 1575
    nop

    .local v10, "$changed\\3":I
    const/4 v11, 0x0

    .line 1576
    .local v11, "$i$f$Layout\\3\\1575":I
    const v12, -0x4ee9b9da

    const-string v13, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh"

    invoke-static {v6, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1577
    const/4 v12, 0x0

    invoke-static {v6, v12}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v12

    .line 1578
    .local v12, "compositeKeyHash\\3":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 1579
    .local v13, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v6, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    .line 1581
    .local v14, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v15

    shl-int/lit8 v0, v10, 0x6

    and-int/lit16 v0, v0, 0x380

    move/from16 v16, v0

    const/4 v0, 0x6

    or-int/lit8 v16, v16, 0x6

    .line 1580
    nop

    .local v15, "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v16, "$changed\\4":I
    const/16 v17, 0x0

    .line 1582
    .local v17, "$i$f$ReusableComposeNode\\4\\1580":I
    move/from16 v18, v0

    const v0, -0x2942ffcf

    move-object/from16 v19, v1

    .end local v1  # "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v19, "modifier\\2":Landroidx/compose/ui/Modifier;
    const-string v1, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v6, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1583
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_ac

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1584
    :cond_ac
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1585
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_b9

    .line 1586
    invoke-interface {v6, v15}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_bc

    .line 1588
    :cond_b9
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1590
    :goto_bc
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/4 v1, 0x0

    .line 1591
    .local v1, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\1590\\3":I
    sget-object v20, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v21, v1

    .end local v1  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\1590\\3":I
    .local v21, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\1590\\3":I
    invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v9, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1592
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v13, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1594
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v20, 0x0

    .line 1595
    .local v20, "$i$f$set-impl\\6\\1594":I
    move-object/from16 v22, v0

    .local v22, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v23, 0x0

    .line 1596
    .local v23, "$i$a$-with-Updater$set$1\\7\\1595\\6":I
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v24

    if-nez v24, :cond_f9

    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_f6

    goto :goto_f9

    :cond_f6
    move-object/from16 v3, v22

    goto :goto_109

    .line 1597
    :cond_f9
    :goto_f9
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v22

    .end local v22  # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1598
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1600
    :goto_109
    nop

    .line 1595
    .end local v3  # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v23  # "$i$a$-with-Updater$set$1\\7\\1595\\6":I
    nop

    .line 1600
    nop

    .line 1601
    .end local v1  # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v20  # "$i$f$set-impl\\6\\1594":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v14, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1602
    nop

    .line 1590
    .end local v0  # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v21  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\1590\\3":I
    nop

    .line 1603
    shr-int/lit8 v0, v16, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\8":I
    move-object v1, v6

    .local v1, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 1604
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\8\\1603\\2":I
    const v3, -0x16f088b9

    move/from16 v20, v0

    .end local v0  # "$changed\\8":I
    .local v20, "$changed\\8":I
    const-string v0, "C87@4365L9:Column.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v3, v5, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\9":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$SimpleStatsPanel_u24lambda_u2455_u24lambda_u2452_u24lambda_u2451\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v26, v1

    .local v26, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v46, 0x0

    .line 496
    .local v46, "$i$a$-Column-MainActivityKt$SimpleStatsPanel$1$1$1\\9\\1604\\0":I
    move-object/from16 v47, v0

    .end local v0  # "$this$SimpleStatsPanel_u24lambda_u2455_u24lambda_u2452_u24lambda_u2451\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .local v47, "$this$SimpleStatsPanel_u24lambda_u2455_u24lambda_u2452_u24lambda_u2451\\9":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, 0x17ea290a

    move-object/from16 v48, v1

    .end local v1  # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v48, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v1, "C495@18716L229,501@18962L40,502@19065L10,502@19019L94,505@19222L10,503@19130L229:MainActivity.kt#to5c3"

    move/from16 v49, v2

    move-object/from16 v2, v26

    .end local v26  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v49, "$i$a$-Layout-ColumnKt$Column$1\\8\\1603\\2":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 497
    sget-object v0, Landroidx/compose/material/icons/Icons;->INSTANCE:Landroidx/compose/material/icons/Icons;

    invoke-virtual {v0}, Landroidx/compose/material/icons/Icons;->getDefault()Landroidx/compose/material/icons/Icons$Filled;

    move-result-object v0

    invoke-static {v0}, Landroidx/compose/material/icons/filled/CheckCircleKt;->getCheckCircle(Landroidx/compose/material/icons/Icons$Filled;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v21

    .line 499
    const-wide v0, 0xff2e7d32L

    invoke-static {v0, v1}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v24

    .line 500
    sget-object v22, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-wide/from16 v50, v0

    move-object/from16 v0, v22

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x18

    .local v1, "$this$dp\\10":I
    const/16 v22, 0x0

    .line 1605
    .local v22, "$i$f$getDp\\10\\500":I
    nop

    .end local v2  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v26  # "$composer\\9":Landroidx/compose/runtime/Composer;
    int-to-float v2, v1

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 500
    .end local v1  # "$this$dp\\10":I
    .end local v22  # "$i$f$getDp\\10\\500":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v23

    .line 497
    nop

    .line 498
    nop

    .line 500
    nop

    .line 499
    nop

    .line 496
    const/16 v22, 0x0

    const/16 v27, 0xdb0

    const/16 v28, 0x0

    invoke-static/range {v21 .. v28}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    .line 502
    move-object/from16 v2, v26

    .end local v26  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v2  # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x4

    .local v1, "$this$dp\\11":I
    const/16 v21, 0x0

    .line 1606
    .local v21, "$i$f$getDp\\11\\502":I
    move/from16 v52, v3

    .end local v3  # "$changed\\9":I
    .local v52, "$changed\\9":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 502
    .end local v1  # "$this$dp\\11":I
    .end local v21  # "$i$f$getDp\\11\\502":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move/from16 v1, v18

    invoke-static {v0, v2, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 503
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v41

    invoke-static/range {v50 .. v51}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v23

    const/16 v44, 0x0

    const v45, 0xfffa

    const-string v21, "সফলভাবে প্রেরিত"

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const-wide/16 v30, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const-wide/16 v34, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    const/16 v43, 0x186

    move-object/from16 v42, v2

    .end local v2  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v42, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v21 .. v45}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 505
    .end local v42  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v2  # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {p0 .. p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v21

    .line 506
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getTitleMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v41

    .line 507
    sget-object v0, Landroidx/compose/ui/text/font/FontWeight;->Companion:Landroidx/compose/ui/text/font/FontWeight$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/text/font/FontWeight$Companion;->getBold()Landroidx/compose/ui/text/font/FontWeight;

    move-result-object v28

    .line 508
    invoke-static/range {v50 .. v51}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v23

    .line 505
    nop

    .line 508
    nop

    .line 507
    nop

    .line 506
    nop

    .line 504
    const v43, 0x30180

    const v45, 0xffda

    .end local v2  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v42  # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v21 .. v45}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 496
    .end local v42  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v2  # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 510
    nop

    .line 1604
    .end local v2  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v46  # "$i$a$-Column-MainActivityKt$SimpleStatsPanel$1$1$1\\9\\1604\\0":I
    .end local v47  # "$this$SimpleStatsPanel_u24lambda_u2455_u24lambda_u2452_u24lambda_u2451\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v52  # "$changed\\9":I
    invoke-static/range {v48 .. v48}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1603
    .end local v20  # "$changed\\8":I
    .end local v48  # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v49  # "$i$a$-Layout-ColumnKt$Column$1\\8\\1603\\2":I
    nop

    .line 1607
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1582
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1608
    nop

    .line 1576
    .end local v15  # "factory\\4":Lkotlin/jvm/functions/Function0;
    .end local v16  # "$changed\\4":I
    .end local v17  # "$i$f$ReusableComposeNode\\4\\1580":I
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1609
    nop

    .line 1569
    .end local v10  # "$changed\\3":I
    .end local v11  # "$i$f$Layout\\3\\1575":I
    .end local v12  # "compositeKeyHash\\3":I
    .end local v13  # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v14  # "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1610
    nop

    .end local v4  # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v5  # "$changed\\2":I
    .end local v6  # "$composer\\2":Landroidx/compose/runtime/Composer;
    .end local v7  # "$i$f$Column\\2\\492":I
    .end local v8  # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v9  # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v19  # "modifier\\2":Landroidx/compose/ui/Modifier;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_213

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 511
    :cond_213
    :goto_213
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final SimpleStatsPanel$lambda$55$lambda$54(ILandroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 57
    .param p0, "$failedCount"  # I
    .param p1, "$this$Card"  # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"  # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"  # I

    move/from16 v0, p3

    const-string v1, "$this$Card"

    move-object/from16 v2, p1

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C517@19574L806:MainActivity.kt#to5c3"

    move-object/from16 v3, p2

    invoke-static {v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v0, 0x11

    const/16 v4, 0x10

    if-ne v1, v4, :cond_22

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_1d

    goto :goto_22

    .line 517
    :cond_1d
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_213

    .line 0
    :cond_22
    :goto_22
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_31

    const/4 v1, -0x1

    const-string v4, "com.example.SimpleStatsPanel.<anonymous>.<anonymous> (MainActivity.kt:517)"

    const v5, -0x5d54aa0b

    invoke-static {v5, v0, v1, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 519
    :cond_31
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v4, 0xc

    .local v4, "$this$dp\\1":I
    const/4 v5, 0x0

    .line 1611
    .local v5, "$i$f$getDp\\1\\519":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 519
    .end local v4  # "$this$dp\\1":I
    .end local v5  # "$i$f$getDp\\1\\519":I
    invoke-static {v1, v4}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 520
    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v4

    .line 518
    nop

    .local v1, "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v4, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    const/16 v5, 0x186

    .local v5, "$changed\\2":I
    move-object/from16 v6, p2

    .local v6, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 1612
    .local v7, "$i$f$Column\\2\\518":I
    const v8, -0x1cd0f17e

    const-string v9, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo"

    invoke-static {v6, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1613
    sget-object v8, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v8}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v8

    .line 1617
    .local v8, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    shr-int/lit8 v9, v5, 0x3

    and-int/lit8 v9, v9, 0xe

    shr-int/lit8 v10, v5, 0x3

    and-int/lit8 v10, v10, 0x70

    or-int/2addr v9, v10

    invoke-static {v8, v4, v6, v9}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .local v9, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v10, v5, 0x3

    and-int/lit8 v10, v10, 0x70

    .line 1618
    nop

    .local v10, "$changed\\3":I
    const/4 v11, 0x0

    .line 1619
    .local v11, "$i$f$Layout\\3\\1618":I
    const v12, -0x4ee9b9da

    const-string v13, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh"

    invoke-static {v6, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1620
    const/4 v12, 0x0

    invoke-static {v6, v12}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v12

    .line 1621
    .local v12, "compositeKeyHash\\3":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 1622
    .local v13, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v6, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    .line 1624
    .local v14, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v15

    shl-int/lit8 v0, v10, 0x6

    and-int/lit16 v0, v0, 0x380

    move/from16 v16, v0

    const/4 v0, 0x6

    or-int/lit8 v16, v16, 0x6

    .line 1623
    nop

    .local v15, "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v16, "$changed\\4":I
    const/16 v17, 0x0

    .line 1625
    .local v17, "$i$f$ReusableComposeNode\\4\\1623":I
    move/from16 v18, v0

    const v0, -0x2942ffcf

    move-object/from16 v19, v1

    .end local v1  # "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v19, "modifier\\2":Landroidx/compose/ui/Modifier;
    const-string v1, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v6, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1626
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_ac

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1627
    :cond_ac
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1628
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_b9

    .line 1629
    invoke-interface {v6, v15}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_bc

    .line 1631
    :cond_b9
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1633
    :goto_bc
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/4 v1, 0x0

    .line 1634
    .local v1, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\1633\\3":I
    sget-object v20, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v21, v1

    .end local v1  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\1633\\3":I
    .local v21, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\1633\\3":I
    invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v9, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1635
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v13, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1637
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v20, 0x0

    .line 1638
    .local v20, "$i$f$set-impl\\6\\1637":I
    move-object/from16 v22, v0

    .local v22, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v23, 0x0

    .line 1639
    .local v23, "$i$a$-with-Updater$set$1\\7\\1638\\6":I
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v24

    if-nez v24, :cond_f9

    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_f6

    goto :goto_f9

    :cond_f6
    move-object/from16 v3, v22

    goto :goto_109

    .line 1640
    :cond_f9
    :goto_f9
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v22

    .end local v22  # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1641
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1643
    :goto_109
    nop

    .line 1638
    .end local v3  # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v23  # "$i$a$-with-Updater$set$1\\7\\1638\\6":I
    nop

    .line 1643
    nop

    .line 1644
    .end local v1  # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v20  # "$i$f$set-impl\\6\\1637":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v14, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1645
    nop

    .line 1633
    .end local v0  # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v21  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\1633\\3":I
    nop

    .line 1646
    shr-int/lit8 v0, v16, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\8":I
    move-object v1, v6

    .local v1, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 1647
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\8\\1646\\2":I
    const v3, -0x16f088b9

    move/from16 v20, v0

    .end local v0  # "$changed\\8":I
    .local v20, "$changed\\8":I
    const-string v0, "C87@4365L9:Column.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v3, v5, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\9":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$SimpleStatsPanel_u24lambda_u2455_u24lambda_u2454_u24lambda_u2453\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v26, v1

    .local v26, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v46, 0x0

    .line 522
    .local v46, "$i$a$-Column-MainActivityKt$SimpleStatsPanel$1$2$1\\9\\1647\\0":I
    move-object/from16 v47, v0

    .end local v0  # "$this$SimpleStatsPanel_u24lambda_u2455_u24lambda_u2454_u24lambda_u2453\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .local v47, "$this$SimpleStatsPanel_u24lambda_u2455_u24lambda_u2454_u24lambda_u2453\\9":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, -0x272bdbb5

    move-object/from16 v48, v1

    .end local v1  # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v48, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v1, "C521@19733L223,527@19973L40,528@20073L10,528@20030L91,531@20229L10,529@20138L228:MainActivity.kt#to5c3"

    move/from16 v49, v2

    move-object/from16 v2, v26

    .end local v26  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v49, "$i$a$-Layout-ColumnKt$Column$1\\8\\1646\\2":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 523
    sget-object v0, Landroidx/compose/material/icons/Icons;->INSTANCE:Landroidx/compose/material/icons/Icons;

    invoke-virtual {v0}, Landroidx/compose/material/icons/Icons;->getDefault()Landroidx/compose/material/icons/Icons$Filled;

    move-result-object v0

    invoke-static {v0}, Landroidx/compose/material/icons/filled/ErrorKt;->getError(Landroidx/compose/material/icons/Icons$Filled;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v21

    .line 525
    const-wide v0, 0xffc62828L

    invoke-static {v0, v1}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v24

    .line 526
    sget-object v22, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-wide/from16 v50, v0

    move-object/from16 v0, v22

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x18

    .local v1, "$this$dp\\10":I
    const/16 v22, 0x0

    .line 1648
    .local v22, "$i$f$getDp\\10\\526":I
    nop

    .end local v2  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v26  # "$composer\\9":Landroidx/compose/runtime/Composer;
    int-to-float v2, v1

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 526
    .end local v1  # "$this$dp\\10":I
    .end local v22  # "$i$f$getDp\\10\\526":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v23

    .line 523
    nop

    .line 524
    nop

    .line 526
    nop

    .line 525
    nop

    .line 522
    const/16 v22, 0x0

    const/16 v27, 0xdb0

    const/16 v28, 0x0

    invoke-static/range {v21 .. v28}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    .line 528
    move-object/from16 v2, v26

    .end local v26  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v2  # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x4

    .local v1, "$this$dp\\11":I
    const/16 v21, 0x0

    .line 1649
    .local v21, "$i$f$getDp\\11\\528":I
    move/from16 v52, v3

    .end local v3  # "$changed\\9":I
    .local v52, "$changed\\9":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 528
    .end local v1  # "$this$dp\\11":I
    .end local v21  # "$i$f$getDp\\11\\528":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move/from16 v1, v18

    invoke-static {v0, v2, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 529
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v41

    invoke-static/range {v50 .. v51}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v23

    const/16 v44, 0x0

    const v45, 0xfffa

    const-string v21, "ব্যর্থ হয়েছে"

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const-wide/16 v30, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const-wide/16 v34, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    const/16 v43, 0x186

    move-object/from16 v42, v2

    .end local v2  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v42, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v21 .. v45}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 531
    .end local v42  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v2  # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {p0 .. p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v21

    .line 532
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getTitleMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v41

    .line 533
    sget-object v0, Landroidx/compose/ui/text/font/FontWeight;->Companion:Landroidx/compose/ui/text/font/FontWeight$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/text/font/FontWeight$Companion;->getBold()Landroidx/compose/ui/text/font/FontWeight;

    move-result-object v28

    .line 534
    invoke-static/range {v50 .. v51}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v23

    .line 531
    nop

    .line 534
    nop

    .line 533
    nop

    .line 532
    nop

    .line 530
    const v43, 0x30180

    const v45, 0xffda

    .end local v2  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v42  # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v21 .. v45}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 522
    .end local v42  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v2  # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 536
    nop

    .line 1647
    .end local v2  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v46  # "$i$a$-Column-MainActivityKt$SimpleStatsPanel$1$2$1\\9\\1647\\0":I
    .end local v47  # "$this$SimpleStatsPanel_u24lambda_u2455_u24lambda_u2454_u24lambda_u2453\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v52  # "$changed\\9":I
    invoke-static/range {v48 .. v48}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1646
    .end local v20  # "$changed\\8":I
    .end local v48  # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v49  # "$i$a$-Layout-ColumnKt$Column$1\\8\\1646\\2":I
    nop

    .line 1650
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1625
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1651
    nop

    .line 1619
    .end local v15  # "factory\\4":Lkotlin/jvm/functions/Function0;
    .end local v16  # "$changed\\4":I
    .end local v17  # "$i$f$ReusableComposeNode\\4\\1623":I
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1652
    nop

    .line 1612
    .end local v10  # "$changed\\3":I
    .end local v11  # "$i$f$Layout\\3\\1618":I
    .end local v12  # "compositeKeyHash\\3":I
    .end local v13  # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v14  # "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1653
    nop

    .end local v4  # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v5  # "$changed\\2":I
    .end local v6  # "$composer\\2":Landroidx/compose/runtime/Composer;
    .end local v7  # "$i$f$Column\\2\\518":I
    .end local v8  # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v9  # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v19  # "modifier\\2":Landroidx/compose/ui/Modifier;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_213

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 537
    :cond_213
    :goto_213
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final SimpleStatsPanel$lambda$56(IIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 6

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lcom/example/MainActivityKt;->SimpleStatsPanel(IILandroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final UploadLogItem(Lcom/example/data/UploadLog;Landroidx/compose/runtime/Composer;I)V
    .registers 21
    .param p0, "log"  # Lcom/example/data/UploadLog;
    .param p1, "$composer"  # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"  # I

    move-object/from16 v0, p0

    move/from16 v1, p2

    const-string v2, "log"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 542
    const v2, -0x67e9bd4a

    move-object/from16 v3, p1

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v9

    .end local p1  # "$composer":Landroidx/compose/runtime/Composer;
    .local v9, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(UploadLogItem)545@20617L11,545@20575L62,546@20644L5112,542@20452L5304:MainActivity.kt#to5c3"

    invoke-static {v9, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p2

    .local v3, "$dirty":I
    and-int/lit8 v4, v1, 0x6

    const/4 v5, 0x2

    if-nez v4, :cond_28

    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_26

    const/4 v4, 0x4

    goto :goto_27

    :cond_26
    move v4, v5

    :goto_27
    or-int/2addr v3, v4

    :cond_28
    move v15, v3

    .end local v3  # "$dirty":I
    .local v15, "$dirty":I
    and-int/lit8 v3, v15, 0x3

    if-ne v3, v5, :cond_3a

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_34

    goto :goto_3a

    .line 541
    :cond_34
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v12, v9

    goto/16 :goto_b2

    .line 542
    :cond_3a
    :goto_3a
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_46

    const/4 v3, -0x1

    const-string v4, "com.example.UploadLogItem (MainActivity.kt:541)"

    invoke-static {v2, v15, v3, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 544
    :cond_46
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v2, v3, v5, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 545
    const/16 v3, 0xc

    .local v3, "$this$dp\\1":I
    const/4 v4, 0x0

    .line 1201
    .local v4, "$i$f$getDp\\1\\545":I
    int-to-float v6, v3

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 545
    .end local v3  # "$this$dp\\1":I
    .end local v4  # "$i$f$getDp\\1\\545":I
    invoke-static {v3}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v3

    move-object/from16 v16, v3

    check-cast v16, Landroidx/compose/ui/graphics/Shape;

    .line 546
    sget-object v3, Landroidx/compose/material3/CardDefaults;->INSTANCE:Landroidx/compose/material3/CardDefaults;

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v9, v6}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/ColorScheme;->getSurface-0d7_KjU()J

    move-result-wide v6

    sget v4, Landroidx/compose/material3/CardDefaults;->$stable:I

    shl-int/lit8 v13, v4, 0xc

    const/16 v14, 0xe

    move v8, v5

    move-wide v4, v6

    const-wide/16 v6, 0x0

    move v10, v8

    move-object v12, v9

    .end local v9  # "$composer":Landroidx/compose/runtime/Composer;
    .local v12, "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v8, 0x0

    move/from16 v17, v10

    const-wide/16 v10, 0x0

    move-object/from16 p1, v2

    move/from16 v2, v17

    invoke-virtual/range {v3 .. v14}, Landroidx/compose/material3/CardDefaults;->cardColors-ro_MJ88(JJJJLandroidx/compose/runtime/Composer;II)Landroidx/compose/material3/CardColors;

    move-result-object v5

    .line 547
    new-instance v3, Lcom/example/MainActivityKt$$ExternalSyntheticLambda7;

    invoke-direct {v3, v0}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda7;-><init>(Lcom/example/data/UploadLog;)V

    const/16 v4, 0x36

    const v6, -0x592bcd8

    invoke-static {v6, v2, v3, v12, v4}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    move-object v8, v2

    check-cast v8, Lkotlin/jvm/functions/Function3;

    .line 543
    const/4 v6, 0x0

    const/4 v7, 0x0

    const v10, 0x30006

    const/16 v11, 0x18

    move-object/from16 v3, p1

    move-object v9, v12

    move-object/from16 v4, v16

    .end local v12  # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v9  # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v3 .. v11}, Landroidx/compose/material3/CardKt;->Card(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/CardColors;Landroidx/compose/material3/CardElevation;Landroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .end local v9  # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v12  # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_b2

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 665
    :cond_b2
    :goto_b2
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v2

    if-eqz v2, :cond_c0

    new-instance v3, Lcom/example/MainActivityKt$$ExternalSyntheticLambda8;

    invoke-direct {v3, v0, v1}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda8;-><init>(Lcom/example/data/UploadLog;I)V

    invoke-interface {v2, v3}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_c0
    return-void
.end method

.method static final UploadLogItem$lambda$63(Lcom/example/data/UploadLog;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 131
    .param p0, "$log"  # Lcom/example/data/UploadLog;
    .param p1, "$this$Card"  # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"  # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"  # I

    move/from16 v0, p3

    const-string v1, "$this$Card"

    move-object/from16 v2, p1

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C547@20654L5096:MainActivity.kt#to5c3"

    move-object/from16 v3, p2

    invoke-static {v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v0, 0x11

    const/16 v4, 0x10

    if-ne v1, v4, :cond_24

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_1d

    goto :goto_24

    .line 547
    :cond_1d
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v1, p0

    goto/16 :goto_a0f

    .line 0
    :cond_24
    :goto_24
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_33

    const/4 v1, -0x1

    const-string v4, "com.example.UploadLogItem.<anonymous> (MainActivity.kt:547)"

    const v5, -0x592bcd8

    invoke-static {v5, v0, v1, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 549
    :cond_33
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    .line 550
    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v1, v4, v6, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 551
    const/16 v4, 0xc

    .local v4, "$this$dp\\1":I
    const/4 v5, 0x0

    .line 1655
    .local v5, "$i$f$getDp\\1\\551":I
    int-to-float v7, v4

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 551
    .end local v4  # "$this$dp\\1":I
    .end local v5  # "$i$f$getDp\\1\\551":I
    invoke-static {v1, v4}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 552
    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v4

    .line 553
    sget-object v5, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v5}, Landroidx/compose/foundation/layout/Arrangement;->getSpaceBetween()Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v5

    .line 551
    nop

    .line 553
    check-cast v5, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .line 552
    nop

    .line 548
    nop

    .local v4, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .local v5, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/16 v7, 0x1b6

    .local v7, "$changed\\2":I
    move-object/from16 v8, p2

    .local v1, "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v8, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 1656
    .local v9, "$i$f$Row\\2\\548":I
    const v10, 0x2952b718

    const-string v11, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo"

    invoke-static {v8, v10, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1657
    shr-int/lit8 v12, v7, 0x3

    and-int/lit8 v12, v12, 0xe

    shr-int/lit8 v13, v7, 0x3

    and-int/lit8 v13, v13, 0x70

    or-int/2addr v12, v13

    invoke-static {v5, v4, v8, v12}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v12

    .local v12, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v13, v7, 0x3

    and-int/lit8 v13, v13, 0x70

    .line 1658
    nop

    .local v13, "$changed\\3":I
    const/4 v14, 0x0

    .line 1659
    .local v14, "$i$f$Layout\\3\\1658":I
    const v15, -0x4ee9b9da

    const-string v6, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh"

    invoke-static {v8, v15, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1660
    const/4 v15, 0x0

    invoke-static {v8, v15}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v17

    .line 1661
    .local v17, "compositeKeyHash\\3":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v15

    .line 1662
    .local v15, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v8, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v10

    .line 1664
    .local v10, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v20, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v20

    shl-int/lit8 v0, v13, 0x6

    and-int/lit16 v0, v0, 0x380

    move/from16 v21, v0

    const/4 v0, 0x6

    or-int/lit8 v21, v21, 0x6

    .line 1663
    move-object/from16 v22, v20

    .local v21, "$changed\\4":I
    .local v22, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v20, 0x0

    .line 1665
    .local v20, "$i$f$ReusableComposeNode\\4\\1663":I
    move/from16 v23, v0

    const v0, -0x2942ffcf

    move-object/from16 v24, v1

    .end local v1  # "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v24, "modifier\\2":Landroidx/compose/ui/Modifier;
    const-string v1, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v8, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1666
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_ba

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1667
    :cond_ba
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1668
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_c9

    .line 1669
    move-object/from16 v0, v22

    .end local v22  # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v8, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_ce

    .line 1671
    .end local v0  # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v22  # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_c9
    move-object/from16 v0, v22

    .end local v22  # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v0  # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1673
    :goto_ce
    move-object/from16 v22, v0

    .end local v0  # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v22  # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static {v8}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v26, 0x0

    .line 1674
    .local v26, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\1673\\3":I
    sget-object v27, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v27 .. v27}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v12, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1675
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v15, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1677
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v27, 0x0

    .line 1678
    .local v27, "$i$f$set-impl\\6\\1677":I
    move-object/from16 v28, v0

    .local v28, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 1679
    .local v29, "$i$a$-with-Updater$set$1\\7\\1678\\6":I
    invoke-interface/range {v28 .. v28}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v30

    if-nez v30, :cond_10e

    invoke-interface/range {v28 .. v28}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v30, v4

    .end local v4  # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .local v30, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_10b

    goto :goto_110

    :cond_10b
    move-object/from16 v4, v28

    goto :goto_120

    .end local v30  # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .restart local v4  # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    :cond_10e
    move-object/from16 v30, v4

    .line 1680
    .end local v4  # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .restart local v30  # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    :goto_110
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v4, v28

    .end local v28  # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1681
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v0, v3, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1683
    :goto_120
    nop

    .line 1678
    .end local v4  # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v29  # "$i$a$-with-Updater$set$1\\7\\1678\\6":I
    nop

    .line 1683
    nop

    .line 1684
    .end local v2  # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v27  # "$i$f$set-impl\\6\\1677":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v10, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1685
    nop

    .line 1673
    .end local v0  # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v26  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\1673\\3":I
    nop

    .line 1686
    shr-int/lit8 v0, v21, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\8":I
    move-object v2, v8

    .local v2, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 1687
    .local v3, "$i$a$-Layout-RowKt$Row$1\\8\\1686\\2":I
    const v4, -0x18505826

    move/from16 v26, v0

    .end local v0  # "$changed\\8":I
    .local v26, "$changed\\8":I
    const-string v0, "C100@5047L9:Row.kt#2w3rfo"

    invoke-static {v2, v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v27, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v28, v7, 0x6

    and-int/lit8 v28, v28, 0x70

    or-int/lit8 v28, v28, 0x6

    .local v28, "$changed\\9":I
    move-object/from16 v31, v27

    check-cast v31, Landroidx/compose/foundation/layout/RowScope;

    .local v31, "$this$UploadLogItem_u24lambda_u2463_u24lambda_u2462\\9":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v42, v2

    .local v42, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 555
    .local v27, "$i$a$-Row-MainActivityKt$UploadLogItem$1$1\\9\\1687\\0":I
    const v4, -0x5c93dfd0

    move-object/from16 v45, v2

    .end local v2  # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v45, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v2, "C554@20901L3513,643@24908L832,634@24456L1284:MainActivity.kt#to5c3"

    move/from16 v46, v3

    move-object/from16 v3, v42

    .end local v42  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v46, "$i$a$-Layout-RowKt$Row$1\\8\\1686\\2":I
    invoke-static {v3, v4, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 556
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v32, v2

    check-cast v32, Landroidx/compose/ui/Modifier;

    const/16 v35, 0x2

    const/16 v36, 0x0

    const/high16 v33, 0x3f800000  # 1.0f

    const/16 v34, 0x0

    invoke-static/range {v31 .. v36}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 557
    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v4

    .line 555
    move-object/from16 v32, v3

    .local v2, "modifier\\10":Landroidx/compose/ui/Modifier;
    .local v32, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v33, 0x180

    .local v4, "verticalAlignment\\10":Landroidx/compose/ui/Alignment$Vertical;
    .local v33, "$changed\\10":I
    const/16 v34, 0x0

    .line 1688
    .local v34, "$i$f$Row\\10\\555":I
    move-object/from16 v47, v5

    move/from16 v48, v7

    move-object/from16 v5, v32

    const v7, 0x2952b718

    .end local v7  # "$changed\\2":I
    .end local v32  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v47, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v48, "$changed\\2":I
    invoke-static {v5, v7, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1689
    sget-object v7, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v7}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v7

    .line 1693
    .local v7, "horizontalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v32, v33, 0x3

    and-int/lit8 v32, v32, 0xe

    shr-int/lit8 v35, v33, 0x3

    and-int/lit8 v35, v35, 0x70

    move-object/from16 v49, v8

    .end local v8  # "$composer\\2":Landroidx/compose/runtime/Composer;
    .local v49, "$composer\\2":Landroidx/compose/runtime/Composer;
    or-int v8, v32, v35

    invoke-static {v7, v4, v5, v8}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v8

    .local v8, "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v32, v33, 0x3

    and-int/lit8 v32, v32, 0x70

    .line 1694
    nop

    .local v32, "$changed\\11":I
    const/16 v35, 0x0

    .line 1695
    .local v35, "$i$f$Layout\\11\\1694":I
    move-object/from16 v36, v4

    const v4, -0x4ee9b9da

    .end local v4  # "verticalAlignment\\10":Landroidx/compose/ui/Alignment$Vertical;
    .local v36, "verticalAlignment\\10":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v5, v4, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1696
    const/4 v4, 0x0

    invoke-static {v5, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v37

    .line 1697
    .local v37, "compositeKeyHash\\11":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v4

    .line 1698
    .local v4, "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v38, v7

    .end local v7  # "horizontalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v38, "horizontalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v5, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 1700
    .local v7, "materialized\\11":Landroidx/compose/ui/Modifier;
    sget-object v39, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v39 .. v39}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v39

    move-object/from16 v40, v2

    .end local v2  # "modifier\\10":Landroidx/compose/ui/Modifier;
    .local v40, "modifier\\10":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v2, v32, 0x6

    and-int/lit16 v2, v2, 0x380

    or-int/lit8 v2, v2, 0x6

    .line 1699
    move-object/from16 v41, v39

    .local v2, "$changed\\12":I
    .local v41, "factory\\12":Lkotlin/jvm/functions/Function0;
    const/16 v39, 0x0

    .line 1701
    .local v39, "$i$f$ReusableComposeNode\\12\\1699":I
    move/from16 v42, v2

    const v2, -0x2942ffcf

    .end local v2  # "$changed\\12":I
    .local v42, "$changed\\12":I
    invoke-static {v5, v2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1702
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_1df

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1703
    :cond_1df
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1704
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_1ee

    .line 1705
    move-object/from16 v2, v41

    .end local v41  # "factory\\12":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1f3

    .line 1707
    .end local v2  # "factory\\12":Lkotlin/jvm/functions/Function0;
    .restart local v41  # "factory\\12":Lkotlin/jvm/functions/Function0;
    :cond_1ee
    move-object/from16 v2, v41

    .end local v41  # "factory\\12":Lkotlin/jvm/functions/Function0;
    .restart local v2  # "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1709
    :goto_1f3
    move-object/from16 v41, v2

    .end local v2  # "factory\\12":Lkotlin/jvm/functions/Function0;
    .restart local v41  # "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-static {v5}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    const/16 v43, 0x0

    .line 1710
    .local v43, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\13\\1709\\11":I
    sget-object v44, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v50, v5

    .end local v5  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v50, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v44 .. v44}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v2, v8, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1711
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v2, v4, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1713
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    .local v5, "block\\14":Lkotlin/jvm/functions/Function2;
    const/16 v44, 0x0

    .line 1714
    .local v44, "$i$f$set-impl\\14\\1713":I
    move-object/from16 v51, v2

    .local v51, "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    const/16 v52, 0x0

    .line 1715
    .local v52, "$i$a$-with-Updater$set$1\\15\\1714\\14":I
    invoke-interface/range {v51 .. v51}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v53

    if-nez v53, :cond_237

    move-object/from16 v53, v4

    .end local v4  # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .local v53, "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v51 .. v51}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v54, v8

    .end local v8  # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v54, "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v37 .. v37}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v4, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_234

    goto :goto_23b

    :cond_234
    move-object/from16 v8, v51

    goto :goto_24b

    .end local v53  # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v54  # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v4  # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v8  # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_237
    move-object/from16 v53, v4

    move-object/from16 v54, v8

    .line 1716
    .end local v4  # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v8  # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v53  # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v54  # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_23b
    invoke-static/range {v37 .. v37}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v8, v51

    .end local v51  # "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .local v8, "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    invoke-interface {v8, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1717
    invoke-static/range {v37 .. v37}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v2, v4, v5}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1719
    :goto_24b
    nop

    .line 1714
    .end local v8  # "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .end local v52  # "$i$a$-with-Updater$set$1\\15\\1714\\14":I
    nop

    .line 1719
    nop

    .line 1720
    .end local v5  # "block\\14":Lkotlin/jvm/functions/Function2;
    .end local v44  # "$i$f$set-impl\\14\\1713":I
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v2, v7, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1721
    nop

    .line 1709
    .end local v2  # "$this$Layout_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    .end local v43  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\13\\1709\\11":I
    nop

    .line 1722
    shr-int/lit8 v2, v42, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\16":I
    move-object/from16 v4, v50

    .local v4, "$composer\\16":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 1723
    .local v5, "$i$a$-Layout-RowKt$Row$1\\16\\1722\\10":I
    const v8, -0x18505826

    invoke-static {v4, v8, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v8, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v43, v33, 0x6

    and-int/lit8 v43, v43, 0x70

    or-int/lit8 v43, v43, 0x6

    .local v43, "$changed\\17":I
    check-cast v8, Landroidx/compose/foundation/layout/RowScope;

    .local v8, "$this$UploadLogItem_u24lambda_u2463_u24lambda_u2462_u24lambda_u2460\\17":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v44, v4

    .local v44, "$composer\\17":Landroidx/compose/runtime/Composer;
    const/16 v51, 0x0

    .line 560
    .local v51, "$i$a$-Row-MainActivityKt$UploadLogItem$1$1$1\\17\\1723\\9":I
    move/from16 v52, v2

    .end local v2  # "$changed\\16":I
    .local v52, "$changed\\16":I
    const v2, 0x6314cd42

    move-object/from16 v55, v4

    .end local v4  # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v55, "$composer\\16":Landroidx/compose/runtime/Composer;
    const-string v4, "C559@21087L1335,589@22440L40,592@22531L1869:MainActivity.kt#to5c3"

    move/from16 v56, v5

    move-object/from16 v5, v44

    .end local v44  # "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v56, "$i$a$-Layout-RowKt$Row$1\\16\\1722\\10":I
    invoke-static {v5, v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 561
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    .line 562
    const/16 v4, 0x28

    .local v4, "$this$dp\\18":I
    const/16 v44, 0x0

    .line 1724
    .local v44, "$i$f$getDp\\18\\562":I
    move-object/from16 v57, v7

    .end local v7  # "materialized\\11":Landroidx/compose/ui/Modifier;
    .local v57, "materialized\\11":Landroidx/compose/ui/Modifier;
    int-to-float v7, v4

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 562
    .end local v4  # "$this$dp\\18":I
    .end local v44  # "$i$f$getDp\\18\\562":I
    invoke-static {v2, v4}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 563
    const/16 v4, 0x8

    .local v4, "$this$dp\\19":I
    const/4 v7, 0x0

    .line 1725
    .local v7, "$i$f$getDp\\19\\563":I
    move/from16 v44, v7

    .end local v7  # "$i$f$getDp\\19\\563":I
    .local v44, "$i$f$getDp\\19\\563":I
    int-to-float v7, v4

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 563
    .end local v4  # "$this$dp\\19":I
    .end local v44  # "$i$f$getDp\\19\\563":I
    invoke-static {v4}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v4

    check-cast v4, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v2, v4}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v58

    .line 565
    invoke-virtual/range {p0 .. p0}, Lcom/example/data/UploadLog;->getStatus()Ljava/lang/String;

    move-result-object v2

    .line 566
    const-string v4, "SUCCESS"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    const-wide v64, 0xffffebeeL

    const-wide v66, 0xffe8f5e9L

    move/from16 v44, v7

    const-string v7, "FAILED"

    if-eqz v44, :cond_2d5

    const v2, 0x6e8d2381

    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static/range {v66 .. v67}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v59

    move-object/from16 v44, v8

    goto :goto_318

    .line 567
    :cond_2d5
    invoke-static {v2, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2eb

    const v2, 0x6e8d2b41

    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static/range {v64 .. v65}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v59

    move-object/from16 v44, v8

    goto :goto_318

    .line 568
    :cond_2eb
    const v2, 0x6e8d36c2

    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "567@21489L11"

    invoke-static {v5, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    move-object/from16 v44, v8

    .end local v8  # "$this$UploadLogItem_u24lambda_u2463_u24lambda_u2462_u24lambda_u2460\\17":Landroidx/compose/foundation/layout/RowScope;
    .local v44, "$this$UploadLogItem_u24lambda_u2463_u24lambda_u2462_u24lambda_u2460\\17":Landroidx/compose/foundation/layout/RowScope;
    sget v8, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v5, v8}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v68

    const/16 v74, 0xe

    const/16 v75, 0x0

    const v70, 0x3dcccccd  # 0.1f

    const/16 v71, 0x0

    const/16 v72, 0x0

    const/16 v73, 0x0

    invoke-static/range {v68 .. v75}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v59

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 564
    :goto_318
    const/16 v62, 0x2

    const/16 v63, 0x0

    const/16 v61, 0x0

    invoke-static/range {v58 .. v63}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 571
    sget-object v8, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v8

    .line 560
    move-object/from16 v58, v5

    .local v2, "modifier\\20":Landroidx/compose/ui/Modifier;
    .local v8, "contentAlignment\\20":Landroidx/compose/ui/Alignment;
    .local v58, "$composer\\20":Landroidx/compose/runtime/Composer;
    const/16 v59, 0x30

    .local v59, "$changed\\20":I
    const/16 v60, 0x0

    .line 1726
    .local v60, "$i$f$Box\\20\\560":I
    move/from16 v61, v9

    .end local v9  # "$i$f$Row\\2\\548":I
    .local v61, "$i$f$Row\\2\\548":I
    const v9, 0x2bb5b5d7

    move-object/from16 v62, v10

    .end local v10  # "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v62, "materialized\\3":Landroidx/compose/ui/Modifier;
    const-string v10, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    move-object/from16 v63, v12

    move-object/from16 v12, v58

    .end local v58  # "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v12, "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v63, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {v12, v9, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1727
    const/4 v9, 0x0

    .line 1730
    .local v9, "propagateMinConstraints\\20":Z
    invoke-static {v8, v9}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .local v10, "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v58, v59, 0x3

    and-int/lit8 v58, v58, 0x70

    .line 1731
    nop

    .local v58, "$changed\\21":I
    const/16 v68, 0x0

    .line 1732
    .local v68, "$i$f$Layout\\21\\1731":I
    move-object/from16 v69, v8

    const v8, -0x4ee9b9da

    .end local v8  # "contentAlignment\\20":Landroidx/compose/ui/Alignment;
    .local v69, "contentAlignment\\20":Landroidx/compose/ui/Alignment;
    invoke-static {v12, v8, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1733
    const/4 v8, 0x0

    invoke-static {v12, v8}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v70

    .line 1734
    .local v70, "compositeKeyHash\\21":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v8

    .line 1735
    .local v8, "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v71, v9

    .end local v9  # "propagateMinConstraints\\20":Z
    .local v71, "propagateMinConstraints\\20":Z
    invoke-static {v12, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    .line 1737
    .local v9, "materialized\\21":Landroidx/compose/ui/Modifier;
    sget-object v72, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v72 .. v72}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v72

    move-object/from16 v73, v2

    .end local v2  # "modifier\\20":Landroidx/compose/ui/Modifier;
    .local v73, "modifier\\20":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v2, v58, 0x6

    and-int/lit16 v2, v2, 0x380

    or-int/lit8 v2, v2, 0x6

    .line 1736
    nop

    .local v2, "$changed\\22":I
    move-object/from16 v74, v72

    .local v74, "factory\\22":Lkotlin/jvm/functions/Function0;
    const/16 v72, 0x0

    .line 1738
    .local v72, "$i$f$ReusableComposeNode\\22\\1736":I
    move/from16 v75, v2

    const v2, -0x2942ffcf

    .end local v2  # "$changed\\22":I
    .local v75, "$changed\\22":I
    invoke-static {v12, v2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1739
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_387

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1740
    :cond_387
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1741
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_396

    .line 1742
    move-object/from16 v2, v74

    .end local v74  # "factory\\22":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-interface {v12, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_39b

    .line 1744
    .end local v2  # "factory\\22":Lkotlin/jvm/functions/Function0;
    .restart local v74  # "factory\\22":Lkotlin/jvm/functions/Function0;
    :cond_396
    move-object/from16 v2, v74

    .end local v74  # "factory\\22":Lkotlin/jvm/functions/Function0;
    .restart local v2  # "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1746
    :goto_39b
    move-object/from16 v74, v2

    .end local v2  # "factory\\22":Lkotlin/jvm/functions/Function0;
    .restart local v74  # "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    const/16 v76, 0x0

    .line 1747
    .local v76, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\23\\1746\\21":I
    sget-object v77, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v78, v12

    .end local v12  # "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v78, "$composer\\20":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v77 .. v77}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v12

    invoke-static {v2, v10, v12}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1748
    sget-object v12, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v12

    invoke-static {v2, v8, v12}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1750
    sget-object v12, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v12

    .local v12, "block\\24":Lkotlin/jvm/functions/Function2;
    const/16 v77, 0x0

    .line 1751
    .local v77, "$i$f$set-impl\\24\\1750":I
    move-object/from16 v79, v2

    .local v79, "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    const/16 v80, 0x0

    .line 1752
    .local v80, "$i$a$-with-Updater$set$1\\25\\1751\\24":I
    invoke-interface/range {v79 .. v79}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v81

    if-nez v81, :cond_3df

    move-object/from16 v81, v8

    .end local v8  # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .local v81, "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v79 .. v79}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    move-object/from16 v82, v10

    .end local v10  # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v82, "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v70 .. v70}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v8, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_3dc

    goto :goto_3e3

    :cond_3dc
    move-object/from16 v10, v79

    goto :goto_3f3

    .end local v81  # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v82  # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v8  # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v10  # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_3df
    move-object/from16 v81, v8

    move-object/from16 v82, v10

    .line 1753
    .end local v8  # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v10  # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v81  # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v82  # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_3e3
    invoke-static/range {v70 .. v70}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    move-object/from16 v10, v79

    .end local v79  # "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    .local v10, "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    invoke-interface {v10, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1754
    invoke-static/range {v70 .. v70}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-interface {v2, v8, v12}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1756
    :goto_3f3
    nop

    .line 1751
    .end local v10  # "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    .end local v80  # "$i$a$-with-Updater$set$1\\25\\1751\\24":I
    nop

    .line 1756
    nop

    .line 1757
    .end local v12  # "block\\24":Lkotlin/jvm/functions/Function2;
    .end local v77  # "$i$f$set-impl\\24\\1750":I
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v2, v9, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1758
    nop

    .line 1746
    .end local v2  # "$this$Layout_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    .end local v76  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\23\\1746\\21":I
    nop

    .line 1759
    shr-int/lit8 v2, v75, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\26":I
    move-object/from16 v8, v78

    .local v8, "$composer\\26":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 1760
    .local v10, "$i$a$-Layout-BoxKt$Box$1\\26\\1759\\20":I
    const v12, -0x7ff519f7  # -1.000876E-39f

    move/from16 v76, v2

    .end local v2  # "$changed\\26":I
    .local v76, "$changed\\26":I
    const-string v2, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v8, v12, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v12, v59, 0x6

    and-int/lit8 v12, v12, 0x70

    or-int/lit8 v12, v12, 0x6

    .local v12, "$changed\\27":I
    check-cast v2, Landroidx/compose/foundation/layout/BoxScope;

    .local v2, "$this$UploadLogItem_u24lambda_u2463_u24lambda_u2462_u24lambda_u2460_u24lambda_u2457\\27":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v88, v8

    .local v88, "$composer\\27":Landroidx/compose/runtime/Composer;
    const/16 v77, 0x0

    .line 573
    .local v77, "$i$a$-Box-MainActivityKt$UploadLogItem$1$1$1$1\\27\\1760\\17":I
    move-object/from16 v79, v2

    .end local v2  # "$this$UploadLogItem_u24lambda_u2463_u24lambda_u2462_u24lambda_u2460_u24lambda_u2457\\27":Landroidx/compose/foundation/layout/BoxScope;
    .local v79, "$this$UploadLogItem_u24lambda_u2463_u24lambda_u2462_u24lambda_u2460_u24lambda_u2457\\27":Landroidx/compose/foundation/layout/BoxScope;
    const v2, -0x29767f66

    move-object/from16 v80, v8

    .end local v8  # "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v80, "$composer\\26":Landroidx/compose/runtime/Composer;
    const-string v8, "C572@21681L723:MainActivity.kt#to5c3"

    move-object/from16 v91, v9

    move-object/from16 v9, v88

    .end local v88  # "$composer\\27":Landroidx/compose/runtime/Composer;
    .local v9, "$composer\\27":Landroidx/compose/runtime/Composer;
    .local v91, "materialized\\21":Landroidx/compose/ui/Modifier;
    invoke-static {v9, v2, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 574
    invoke-virtual/range {p0 .. p0}, Lcom/example/data/UploadLog;->getStatus()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v8

    move/from16 v83, v8

    const-string v8, "UPLOADING"

    sparse-switch v83, :sswitch_data_a12

    :goto_43f
    goto :goto_47c

    :sswitch_440
    invoke-virtual {v2, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_447

    goto :goto_43f

    .line 576
    :cond_447
    sget-object v2, Landroidx/compose/material/icons/Icons;->INSTANCE:Landroidx/compose/material/icons/Icons;

    invoke-virtual {v2}, Landroidx/compose/material/icons/Icons;->getDefault()Landroidx/compose/material/icons/Icons$Filled;

    move-result-object v2

    invoke-static {v2}, Landroidx/compose/material/icons/filled/CloseKt;->getClose(Landroidx/compose/material/icons/Icons$Filled;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v2

    move-object/from16 v83, v2

    goto :goto_488

    .line 574
    :sswitch_454
    invoke-virtual {v2, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_45b

    goto :goto_43f

    .line 577
    :cond_45b
    sget-object v2, Landroidx/compose/material/icons/Icons;->INSTANCE:Landroidx/compose/material/icons/Icons;

    invoke-virtual {v2}, Landroidx/compose/material/icons/Icons;->getDefault()Landroidx/compose/material/icons/Icons$Filled;

    move-result-object v2

    invoke-static {v2}, Landroidx/compose/material/icons/filled/SyncKt;->getSync(Landroidx/compose/material/icons/Icons$Filled;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v2

    move-object/from16 v83, v2

    goto :goto_488

    .line 574
    :sswitch_468
    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_46f

    goto :goto_43f

    .line 575
    :cond_46f
    sget-object v2, Landroidx/compose/material/icons/Icons;->INSTANCE:Landroidx/compose/material/icons/Icons;

    invoke-virtual {v2}, Landroidx/compose/material/icons/Icons;->getDefault()Landroidx/compose/material/icons/Icons$Filled;

    move-result-object v2

    invoke-static {v2}, Landroidx/compose/material/icons/filled/CheckKt;->getCheck(Landroidx/compose/material/icons/Icons$Filled;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v2

    move-object/from16 v83, v2

    goto :goto_488

    .line 578
    :goto_47c
    sget-object v2, Landroidx/compose/material/icons/Icons;->INSTANCE:Landroidx/compose/material/icons/Icons;

    invoke-virtual {v2}, Landroidx/compose/material/icons/Icons;->getDefault()Landroidx/compose/material/icons/Icons$Filled;

    move-result-object v2

    invoke-static {v2}, Landroidx/compose/material/icons/filled/ImageKt;->getImage(Landroidx/compose/material/icons/Icons$Filled;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v2

    move-object/from16 v83, v2

    .line 574
    :goto_488
    nop

    .line 581
    invoke-virtual/range {p0 .. p0}, Lcom/example/data/UploadLog;->getStatus()Ljava/lang/String;

    move-result-object v2

    .line 582
    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v84

    const-wide v92, 0xffc62828L

    if-eqz v84, :cond_4af

    const v2, 0x7a88c8e7

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const-wide v84, 0xff2e7d32L

    invoke-static/range {v84 .. v85}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v84

    move/from16 v94, v10

    move-wide/from16 v86, v84

    goto :goto_4e5

    .line 583
    :cond_4af
    invoke-static {v2, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4c7

    const v2, 0x7a88d027

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static/range {v92 .. v93}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v84

    move/from16 v94, v10

    move-wide/from16 v86, v84

    goto :goto_4e5

    .line 584
    :cond_4c7
    const v2, 0x7a88da1d

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "583@22280L11"

    invoke-static {v9, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    move/from16 v94, v10

    .end local v10  # "$i$a$-Layout-BoxKt$Box$1\\26\\1759\\20":I
    .local v94, "$i$a$-Layout-BoxKt$Box$1\\26\\1759\\20":I
    sget v10, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v9, v10}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v84

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-wide/from16 v86, v84

    .line 581
    :goto_4e5
    nop

    .line 586
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v10, 0x14

    .local v10, "$this$dp\\28":I
    const/16 v84, 0x0

    .line 1761
    .local v84, "$i$f$getDp\\28\\586":I
    move-object/from16 v88, v9

    .end local v9  # "$composer\\27":Landroidx/compose/runtime/Composer;
    .restart local v88  # "$composer\\27":Landroidx/compose/runtime/Composer;
    int-to-float v9, v10

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 586
    .end local v10  # "$this$dp\\28":I
    .end local v84  # "$i$f$getDp\\28\\586":I
    invoke-static {v2, v9}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v85

    .line 574
    nop

    .line 580
    nop

    .line 586
    nop

    .line 581
    nop

    .line 573
    const/16 v84, 0x0

    const/16 v89, 0x1b0

    const/16 v90, 0x0

    invoke-static/range {v83 .. v90}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    invoke-static/range {v88 .. v88}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 588
    nop

    .line 1760
    .end local v12  # "$changed\\27":I
    .end local v77  # "$i$a$-Box-MainActivityKt$UploadLogItem$1$1$1$1\\27\\1760\\17":I
    .end local v79  # "$this$UploadLogItem_u24lambda_u2463_u24lambda_u2462_u24lambda_u2460_u24lambda_u2457\\27":Landroidx/compose/foundation/layout/BoxScope;
    .end local v88  # "$composer\\27":Landroidx/compose/runtime/Composer;
    invoke-static/range {v80 .. v80}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1759
    .end local v76  # "$changed\\26":I
    .end local v80  # "$composer\\26":Landroidx/compose/runtime/Composer;
    .end local v94  # "$i$a$-Layout-BoxKt$Box$1\\26\\1759\\20":I
    nop

    .line 1762
    invoke-interface/range {v78 .. v78}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1738
    invoke-static/range {v78 .. v78}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1763
    nop

    .line 1732
    .end local v72  # "$i$f$ReusableComposeNode\\22\\1736":I
    .end local v74  # "factory\\22":Lkotlin/jvm/functions/Function0;
    .end local v75  # "$changed\\22":I
    invoke-static/range {v78 .. v78}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1764
    nop

    .line 1726
    .end local v58  # "$changed\\21":I
    .end local v68  # "$i$f$Layout\\21\\1731":I
    .end local v70  # "compositeKeyHash\\21":I
    .end local v81  # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v91  # "materialized\\21":Landroidx/compose/ui/Modifier;
    invoke-static/range {v78 .. v78}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1765
    nop

    .line 590
    .end local v59  # "$changed\\20":I
    .end local v60  # "$i$f$Box\\20\\560":I
    .end local v69  # "contentAlignment\\20":Landroidx/compose/ui/Alignment;
    .end local v71  # "propagateMinConstraints\\20":Z
    .end local v73  # "modifier\\20":Landroidx/compose/ui/Modifier;
    .end local v78  # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v82  # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v9, 0xc

    .local v9, "$this$dp\\29":I
    const/4 v10, 0x0

    .line 1766
    .local v10, "$i$f$getDp\\29\\590":I
    int-to-float v12, v9

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 590
    .end local v9  # "$this$dp\\29":I
    .end local v10  # "$i$f$getDp\\29\\590":I
    invoke-static {v2, v9}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    move/from16 v9, v23

    invoke-static {v2, v5, v9}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 593
    move-object v2, v5

    const/16 v18, 0x0

    .local v2, "$composer\\30":Landroidx/compose/runtime/Composer;
    move/from16 v9, v18

    .local v9, "$changed\\30":I
    const/4 v10, 0x0

    .line 1767
    .local v10, "$i$f$Column\\30\\593":I
    const v12, -0x1cd0f17e

    move-object/from16 v58, v5

    .end local v5  # "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v58, "$composer\\17":Landroidx/compose/runtime/Composer;
    const-string v5, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo"

    invoke-static {v2, v12, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1768
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    .line 1769
    .local v5, "modifier\\30":Landroidx/compose/ui/Modifier;
    sget-object v12, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v12}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v12

    .line 1770
    .local v12, "verticalArrangement\\30":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v59, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    move/from16 v60, v9

    .end local v9  # "$changed\\30":I
    .local v60, "$changed\\30":I
    invoke-virtual/range {v59 .. v59}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v9

    .line 1773
    .local v9, "horizontalAlignment\\30":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v59, v60, 0x3

    and-int/lit8 v59, v59, 0xe

    shr-int/lit8 v68, v60, 0x3

    and-int/lit8 v68, v68, 0x70

    move/from16 v69, v10

    .end local v10  # "$i$f$Column\\30\\593":I
    .local v69, "$i$f$Column\\30\\593":I
    or-int v10, v59, v68

    invoke-static {v12, v9, v2, v10}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .local v10, "measurePolicy\\30":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v59, v60, 0x3

    and-int/lit8 v59, v59, 0x70

    .line 1774
    nop

    .local v59, "$changed\\31":I
    const/16 v68, 0x0

    .line 1775
    .local v68, "$i$f$Layout\\31\\1774":I
    move-object/from16 v70, v9

    const v9, -0x4ee9b9da

    .end local v9  # "horizontalAlignment\\30":Landroidx/compose/ui/Alignment$Horizontal;
    .local v70, "horizontalAlignment\\30":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v2, v9, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1776
    const/4 v9, 0x0

    invoke-static {v2, v9}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v71

    .line 1777
    .local v71, "compositeKeyHash\\31":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v9

    .line 1778
    .local v9, "localMap\\31":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v72, v12

    .end local v12  # "verticalArrangement\\30":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v72, "verticalArrangement\\30":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v2, v5}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 1780
    .local v12, "materialized\\31":Landroidx/compose/ui/Modifier;
    sget-object v73, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v73 .. v73}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v73

    move-object/from16 v74, v5

    .end local v5  # "modifier\\30":Landroidx/compose/ui/Modifier;
    .local v74, "modifier\\30":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v5, v59, 0x6

    and-int/lit16 v5, v5, 0x380

    const/16 v23, 0x6

    or-int/lit8 v5, v5, 0x6

    .line 1779
    nop

    .local v5, "$changed\\32":I
    move-object/from16 v75, v73

    .local v75, "factory\\32":Lkotlin/jvm/functions/Function0;
    const/16 v73, 0x0

    .line 1781
    .local v73, "$i$f$ReusableComposeNode\\32\\1779":I
    move/from16 v76, v5

    const v5, -0x2942ffcf

    .end local v5  # "$changed\\32":I
    .local v76, "$changed\\32":I
    invoke-static {v2, v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1782
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v5

    instance-of v5, v5, Landroidx/compose/runtime/Applier;

    if-nez v5, :cond_5aa

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1783
    :cond_5aa
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1784
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-eqz v5, :cond_5b9

    .line 1785
    move-object/from16 v5, v75

    .end local v75  # "factory\\32":Lkotlin/jvm/functions/Function0;
    .local v5, "factory\\32":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_5be

    .line 1787
    .end local v5  # "factory\\32":Lkotlin/jvm/functions/Function0;
    .restart local v75  # "factory\\32":Lkotlin/jvm/functions/Function0;
    :cond_5b9
    move-object/from16 v5, v75

    .end local v75  # "factory\\32":Lkotlin/jvm/functions/Function0;
    .restart local v5  # "factory\\32":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1789
    :goto_5be
    move-object/from16 v75, v2

    .end local v2  # "$composer\\30":Landroidx/compose/runtime/Composer;
    .local v75, "$composer\\30":Landroidx/compose/runtime/Composer;
    invoke-static/range {v75 .. v75}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\33":Landroidx/compose/runtime/Composer;
    const/16 v77, 0x0

    .line 1790
    .local v77, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\33\\1789\\31":I
    sget-object v78, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v79, v5

    .end local v5  # "factory\\32":Lkotlin/jvm/functions/Function0;
    .local v79, "factory\\32":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v78 .. v78}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v2, v10, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1791
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v2, v9, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1793
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    .local v5, "block\\34":Lkotlin/jvm/functions/Function2;
    const/16 v78, 0x0

    .line 1794
    .local v78, "$i$f$set-impl\\34\\1793":I
    move-object/from16 v80, v2

    .local v80, "$this$set_impl_u24lambda_u240\\34":Landroidx/compose/runtime/Composer;
    const/16 v81, 0x0

    .line 1795
    .local v81, "$i$a$-with-Updater$set$1\\35\\1794\\34":I
    invoke-interface/range {v80 .. v80}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v82

    if-nez v82, :cond_602

    move-object/from16 v82, v9

    .end local v9  # "localMap\\31":Landroidx/compose/runtime/CompositionLocalMap;
    .local v82, "localMap\\31":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v80 .. v80}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    move-object/from16 v83, v10

    .end local v10  # "measurePolicy\\30":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v83, "measurePolicy\\30":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v71 .. v71}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_5ff

    goto :goto_606

    :cond_5ff
    move-object/from16 v10, v80

    goto :goto_616

    .end local v82  # "localMap\\31":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v83  # "measurePolicy\\30":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v9  # "localMap\\31":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v10  # "measurePolicy\\30":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_602
    move-object/from16 v82, v9

    move-object/from16 v83, v10

    .line 1796
    .end local v9  # "localMap\\31":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v10  # "measurePolicy\\30":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v82  # "localMap\\31":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v83  # "measurePolicy\\30":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_606
    invoke-static/range {v71 .. v71}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    move-object/from16 v10, v80

    .end local v80  # "$this$set_impl_u24lambda_u240\\34":Landroidx/compose/runtime/Composer;
    .local v10, "$this$set_impl_u24lambda_u240\\34":Landroidx/compose/runtime/Composer;
    invoke-interface {v10, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1797
    invoke-static/range {v71 .. v71}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {v2, v9, v5}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1799
    :goto_616
    nop

    .line 1794
    .end local v10  # "$this$set_impl_u24lambda_u240\\34":Landroidx/compose/runtime/Composer;
    .end local v81  # "$i$a$-with-Updater$set$1\\35\\1794\\34":I
    nop

    .line 1799
    nop

    .line 1800
    .end local v5  # "block\\34":Lkotlin/jvm/functions/Function2;
    .end local v78  # "$i$f$set-impl\\34\\1793":I
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v2, v12, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1801
    nop

    .line 1789
    .end local v2  # "$this$Layout_u24lambda_u240\\33":Landroidx/compose/runtime/Composer;
    .end local v77  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\33\\1789\\31":I
    nop

    .line 1802
    shr-int/lit8 v2, v76, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\36":I
    move-object/from16 v5, v75

    .local v5, "$composer\\36":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 1803
    .local v9, "$i$a$-Layout-ColumnKt$Column$1\\36\\1802\\30":I
    const v10, -0x16f088b9

    move/from16 v77, v2

    .end local v2  # "$changed\\36":I
    .local v77, "$changed\\36":I
    const-string v2, "C87@4365L9:Column.kt#2w3rfo"

    invoke-static {v5, v10, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v10, v60, 0x6

    and-int/lit8 v10, v10, 0x70

    const/16 v23, 0x6

    or-int/lit8 v10, v10, 0x6

    .local v10, "$changed\\37":I
    check-cast v2, Landroidx/compose/foundation/layout/ColumnScope;

    .local v2, "$this$UploadLogItem_u24lambda_u2463_u24lambda_u2462_u24lambda_u2460_u24lambda_u2459\\37":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v115, v5

    .local v115, "$composer\\37":Landroidx/compose/runtime/Composer;
    const/16 v78, 0x0

    .line 594
    .local v78, "$i$a$-Column-MainActivityKt$UploadLogItem$1$1$1$2\\37\\1803\\17":I
    move-object/from16 v80, v2

    .end local v2  # "$this$UploadLogItem_u24lambda_u2463_u24lambda_u2462_u24lambda_u2460_u24lambda_u2459\\37":Landroidx/compose/foundation/layout/ColumnScope;
    .local v80, "$this$UploadLogItem_u24lambda_u2463_u24lambda_u2462_u24lambda_u2460_u24lambda_u2459\\37":Landroidx/compose/foundation/layout/ColumnScope;
    const v2, -0xe2d30c1

    move-object/from16 v81, v5

    .end local v5  # "$composer\\36":Landroidx/compose/runtime/Composer;
    .local v81, "$composer\\36":Landroidx/compose/runtime/Composer;
    const-string v5, "C595@22657L10,599@22880L11,593@22560L363,601@22944L990:MainActivity.kt#to5c3"

    move/from16 v84, v9

    move-object/from16 v9, v115

    .end local v115  # "$composer\\37":Landroidx/compose/runtime/Composer;
    .local v9, "$composer\\37":Landroidx/compose/runtime/Composer;
    .local v84, "$i$a$-Layout-ColumnKt$Column$1\\36\\1802\\30":I
    invoke-static {v9, v2, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 595
    invoke-virtual/range {p0 .. p0}, Lcom/example/data/UploadLog;->getFileName()Ljava/lang/String;

    move-result-object v94

    .line 596
    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v9, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v114

    .line 597
    sget-object v2, Landroidx/compose/ui/text/font/FontWeight;->Companion:Landroidx/compose/ui/text/font/FontWeight$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/text/font/FontWeight$Companion;->getSemiBold()Landroidx/compose/ui/text/font/FontWeight;

    move-result-object v101

    .line 599
    sget-object v2, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v109

    .line 600
    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v9, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getOnSurface-0d7_KjU()J

    move-result-wide v96

    .line 595
    nop

    .line 600
    nop

    .line 597
    nop

    .line 599
    nop

    .line 598
    nop

    .line 596
    nop

    .line 594
    const/16 v95, 0x0

    const-wide/16 v98, 0x0

    const/16 v100, 0x0

    const/16 v102, 0x0

    const-wide/16 v103, 0x0

    const/16 v105, 0x0

    const/16 v106, 0x0

    const-wide/16 v107, 0x0

    const/16 v110, 0x0

    const/16 v111, 0x1

    const/16 v112, 0x0

    const/16 v113, 0x0

    const/high16 v116, 0x30000

    const/16 v117, 0xc30

    const v118, 0xd7da

    .end local v9  # "$composer\\37":Landroidx/compose/runtime/Composer;
    .restart local v115  # "$composer\\37":Landroidx/compose/runtime/Composer;
    invoke-static/range {v94 .. v118}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 603
    .end local v115  # "$composer\\37":Landroidx/compose/runtime/Composer;
    .restart local v9  # "$composer\\37":Landroidx/compose/runtime/Composer;
    sget-object v2, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v5, 0x8

    .local v5, "$this$dp\\38":I
    const/16 v85, 0x0

    .line 1804
    .local v85, "$i$f$getDp\\38\\603":I
    move/from16 v86, v10

    .end local v10  # "$changed\\37":I
    .local v86, "$changed\\37":I
    int-to-float v10, v5

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 603
    .end local v5  # "$this$dp\\38":I
    .end local v85  # "$i$f$getDp\\38\\603":I
    invoke-virtual {v2, v5}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v2

    check-cast v2, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .line 604
    sget-object v5, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v5

    .line 602
    nop

    .local v2, "horizontalArrangement\\39":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v5, "verticalAlignment\\39":Landroidx/compose/ui/Alignment$Vertical;
    move-object v10, v9

    .local v10, "$composer\\39":Landroidx/compose/runtime/Composer;
    const/16 v85, 0x1b0

    .local v85, "$changed\\39":I
    const/16 v87, 0x0

    .line 1805
    .local v87, "$i$f$Row\\39\\602":I
    move-object/from16 v88, v12

    const v12, 0x2952b718

    .end local v12  # "materialized\\31":Landroidx/compose/ui/Modifier;
    .local v88, "materialized\\31":Landroidx/compose/ui/Modifier;
    invoke-static {v10, v12, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1806
    sget-object v11, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v11, Landroidx/compose/ui/Modifier;

    .line 1811
    .local v11, "modifier\\39":Landroidx/compose/ui/Modifier;
    shr-int/lit8 v12, v85, 0x3

    and-int/lit8 v12, v12, 0xe

    shr-int/lit8 v19, v85, 0x3

    and-int/lit8 v19, v19, 0x70

    or-int v12, v12, v19

    invoke-static {v2, v5, v10, v12}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v12

    .local v12, "measurePolicy\\39":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v19, v85, 0x3

    and-int/lit8 v19, v19, 0x70

    .line 1812
    nop

    .local v19, "$changed\\40":I
    const/16 v89, 0x0

    .line 1813
    .local v89, "$i$f$Layout\\40\\1812":I
    move-object/from16 v90, v2

    const v2, -0x4ee9b9da

    .end local v2  # "horizontalArrangement\\39":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v90, "horizontalArrangement\\39":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v10, v2, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1814
    const/4 v2, 0x0

    invoke-static {v10, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v6

    .line 1815
    .local v6, "compositeKeyHash\\40":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v2

    .line 1816
    .local v2, "localMap\\40":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v16, v5

    .end local v5  # "verticalAlignment\\39":Landroidx/compose/ui/Alignment$Vertical;
    .local v16, "verticalAlignment\\39":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v10, v11}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 1818
    .local v5, "materialized\\40":Landroidx/compose/ui/Modifier;
    sget-object v91, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v91 .. v91}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v91

    move/from16 v94, v6

    .end local v6  # "compositeKeyHash\\40":I
    .local v94, "compositeKeyHash\\40":I
    shl-int/lit8 v6, v19, 0x6

    and-int/lit16 v6, v6, 0x380

    const/16 v23, 0x6

    or-int/lit8 v6, v6, 0x6

    .line 1817
    move-object/from16 v95, v91

    .local v6, "$changed\\41":I
    .local v95, "factory\\41":Lkotlin/jvm/functions/Function0;
    const/16 v91, 0x0

    .line 1819
    .local v91, "$i$f$ReusableComposeNode\\41\\1817":I
    move/from16 v96, v6

    const v6, -0x2942ffcf

    .end local v6  # "$changed\\41":I
    .local v96, "$changed\\41":I
    invoke-static {v10, v6, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1820
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_723

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1821
    :cond_723
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1822
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_732

    .line 1823
    move-object/from16 v1, v95

    .end local v95  # "factory\\41":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\41":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_737

    .line 1825
    .end local v1  # "factory\\41":Lkotlin/jvm/functions/Function0;
    .restart local v95  # "factory\\41":Lkotlin/jvm/functions/Function0;
    :cond_732
    move-object/from16 v1, v95

    .end local v95  # "factory\\41":Lkotlin/jvm/functions/Function0;
    .restart local v1  # "factory\\41":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1827
    :goto_737
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v6

    .local v6, "$this$Layout_u24lambda_u240\\42":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 1828
    .local v25, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\42\\1827\\40":I
    sget-object v95, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v97, v1

    .end local v1  # "factory\\41":Lkotlin/jvm/functions/Function0;
    .local v97, "factory\\41":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v95 .. v95}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v6, v12, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1829
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v6, v2, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1831
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\43":Lkotlin/jvm/functions/Function2;
    const/16 v95, 0x0

    .line 1832
    .local v95, "$i$f$set-impl\\43\\1831":I
    move-object/from16 v98, v6

    .local v98, "$this$set_impl_u24lambda_u240\\43":Landroidx/compose/runtime/Composer;
    const/16 v99, 0x0

    .line 1833
    .local v99, "$i$a$-with-Updater$set$1\\44\\1832\\43":I
    invoke-interface/range {v98 .. v98}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v100

    if-nez v100, :cond_779

    move-object/from16 v100, v2

    .end local v2  # "localMap\\40":Landroidx/compose/runtime/CompositionLocalMap;
    .local v100, "localMap\\40":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v98 .. v98}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v101, v10

    .end local v10  # "$composer\\39":Landroidx/compose/runtime/Composer;
    .local v101, "$composer\\39":Landroidx/compose/runtime/Composer;
    invoke-static/range {v94 .. v94}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v2, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_776

    goto :goto_77d

    :cond_776
    move-object/from16 v10, v98

    goto :goto_78d

    .end local v100  # "localMap\\40":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v101  # "$composer\\39":Landroidx/compose/runtime/Composer;
    .restart local v2  # "localMap\\40":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v10  # "$composer\\39":Landroidx/compose/runtime/Composer;
    :cond_779
    move-object/from16 v100, v2

    move-object/from16 v101, v10

    .line 1834
    .end local v2  # "localMap\\40":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v10  # "$composer\\39":Landroidx/compose/runtime/Composer;
    .restart local v100  # "localMap\\40":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v101  # "$composer\\39":Landroidx/compose/runtime/Composer;
    :goto_77d
    invoke-static/range {v94 .. v94}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v10, v98

    .end local v98  # "$this$set_impl_u24lambda_u240\\43":Landroidx/compose/runtime/Composer;
    .local v10, "$this$set_impl_u24lambda_u240\\43":Landroidx/compose/runtime/Composer;
    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1835
    invoke-static/range {v94 .. v94}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v6, v2, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1837
    :goto_78d
    nop

    .line 1832
    .end local v10  # "$this$set_impl_u24lambda_u240\\43":Landroidx/compose/runtime/Composer;
    .end local v99  # "$i$a$-with-Updater$set$1\\44\\1832\\43":I
    nop

    .line 1837
    nop

    .line 1838
    .end local v1  # "block\\43":Lkotlin/jvm/functions/Function2;
    .end local v95  # "$i$f$set-impl\\43\\1831":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v6, v5, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1839
    nop

    .line 1827
    .end local v6  # "$this$Layout_u24lambda_u240\\42":Landroidx/compose/runtime/Composer;
    .end local v25  # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\42\\1827\\40":I
    nop

    .line 1840
    shr-int/lit8 v1, v96, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\45":I
    move-object/from16 v2, v101

    .local v2, "$composer\\45":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 1841
    .local v6, "$i$a$-Layout-RowKt$Row$1\\45\\1840\\39":I
    const v10, -0x18505826

    invoke-static {v2, v10, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v10, v85, 0x6

    and-int/lit8 v10, v10, 0x70

    const/16 v23, 0x6

    or-int/lit8 v10, v10, 0x6

    .local v10, "$changed\\46":I
    check-cast v0, Landroidx/compose/foundation/layout/RowScope;

    .local v0, "$this$UploadLogItem_u24lambda_u2463_u24lambda_u2462_u24lambda_u2460_u24lambda_u2459_u24lambda_u2458\\46":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v123, v2

    .local v123, "$composer\\46":Landroidx/compose/runtime/Composer;
    const/16 v23, 0x0

    .line 606
    .local v23, "$i$a$-Row-MainActivityKt$UploadLogItem$1$1$1$2$1\\46\\1841\\37":I
    move-object/from16 v25, v0

    .end local v0  # "$this$UploadLogItem_u24lambda_u2463_u24lambda_u2462_u24lambda_u2460_u24lambda_u2459_u24lambda_u2458\\46":Landroidx/compose/foundation/layout/RowScope;
    .local v25, "$this$UploadLogItem_u24lambda_u2463_u24lambda_u2462_u24lambda_u2460_u24lambda_u2459_u24lambda_u2458\\46":Landroidx/compose/foundation/layout/RowScope;
    const v0, -0x43af84c7

    move/from16 v29, v1

    .end local v1  # "$changed\\45":I
    .local v29, "$changed\\45":I
    const-string v1, "C607@23265L10,608@23337L11,605@23144L247,612@23512L10,613@23584L11,610@23416L222,617@23786L10,618@23858L11,615@23663L249:MainActivity.kt#to5c3"

    move-object/from16 v95, v2

    .end local v123  # "$composer\\46":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\46":Landroidx/compose/runtime/Composer;
    .local v95, "$composer\\45":Landroidx/compose/runtime/Composer;
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 607
    invoke-virtual/range {p0 .. p0}, Lcom/example/data/UploadLog;->getFileSize()J

    move-result-wide v0

    invoke-static {v0, v1}, Lcom/example/MainActivityKt;->formatFileSize(J)Ljava/lang/String;

    move-result-object v102

    .line 608
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v122

    .line 609
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v104

    .line 607
    nop

    .line 609
    nop

    .line 608
    nop

    .line 606
    const/16 v103, 0x0

    const-wide/16 v106, 0x0

    const/16 v108, 0x0

    const/16 v109, 0x0

    const/16 v110, 0x0

    const-wide/16 v111, 0x0

    const/16 v113, 0x0

    const/16 v114, 0x0

    const-wide/16 v115, 0x0

    const/16 v117, 0x0

    const/16 v118, 0x0

    const/16 v119, 0x0

    const/16 v120, 0x0

    const/16 v121, 0x0

    const/16 v124, 0x0

    const/16 v125, 0x0

    const v126, 0xfffa

    .end local v2  # "$composer\\46":Landroidx/compose/runtime/Composer;
    .restart local v123  # "$composer\\46":Landroidx/compose/runtime/Composer;
    invoke-static/range {v102 .. v126}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 613
    .end local v123  # "$composer\\46":Landroidx/compose/runtime/Composer;
    .restart local v2  # "$composer\\46":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v122

    .line 614
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v104

    .line 612
    nop

    .line 614
    nop

    .line 613
    nop

    .line 611
    const/16 v124, 0x6

    const-string v102, "•"

    .end local v2  # "$composer\\46":Landroidx/compose/runtime/Composer;
    .restart local v123  # "$composer\\46":Landroidx/compose/runtime/Composer;
    invoke-static/range {v102 .. v126}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 617
    .end local v123  # "$composer\\46":Landroidx/compose/runtime/Composer;
    .restart local v2  # "$composer\\46":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {p0 .. p0}, Lcom/example/data/UploadLog;->getTimestamp()J

    move-result-wide v0

    invoke-static {v0, v1}, Lcom/example/MainActivityKt;->formatTimestamp(J)Ljava/lang/String;

    move-result-object v102

    .line 618
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v122

    .line 619
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v104

    .line 617
    nop

    .line 619
    nop

    .line 618
    nop

    .line 616
    const/16 v124, 0x0

    .end local v2  # "$composer\\46":Landroidx/compose/runtime/Composer;
    .restart local v123  # "$composer\\46":Landroidx/compose/runtime/Composer;
    invoke-static/range {v102 .. v126}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 606
    invoke-static/range {v123 .. v123}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 621
    nop

    .line 1841
    .end local v10  # "$changed\\46":I
    .end local v23  # "$i$a$-Row-MainActivityKt$UploadLogItem$1$1$1$2$1\\46\\1841\\37":I
    .end local v25  # "$this$UploadLogItem_u24lambda_u2463_u24lambda_u2462_u24lambda_u2460_u24lambda_u2459_u24lambda_u2458\\46":Landroidx/compose/foundation/layout/RowScope;
    .end local v123  # "$composer\\46":Landroidx/compose/runtime/Composer;
    invoke-static/range {v95 .. v95}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1840
    .end local v6  # "$i$a$-Layout-RowKt$Row$1\\45\\1840\\39":I
    .end local v29  # "$changed\\45":I
    .end local v95  # "$composer\\45":Landroidx/compose/runtime/Composer;
    nop

    .line 1842
    invoke-interface/range {v101 .. v101}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1819
    invoke-static/range {v101 .. v101}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1843
    nop

    .line 1813
    .end local v91  # "$i$f$ReusableComposeNode\\41\\1817":I
    .end local v96  # "$changed\\41":I
    .end local v97  # "factory\\41":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v101 .. v101}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1844
    nop

    .line 1805
    .end local v5  # "materialized\\40":Landroidx/compose/ui/Modifier;
    .end local v19  # "$changed\\40":I
    .end local v89  # "$i$f$Layout\\40\\1812":I
    .end local v94  # "compositeKeyHash\\40":I
    .end local v100  # "localMap\\40":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v101 .. v101}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1845
    nop

    .line 622
    .end local v11  # "modifier\\39":Landroidx/compose/ui/Modifier;
    .end local v12  # "measurePolicy\\39":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v16  # "verticalAlignment\\39":Landroidx/compose/ui/Alignment$Vertical;
    .end local v85  # "$changed\\39":I
    .end local v87  # "$i$f$Row\\39\\602":I
    .end local v90  # "horizontalArrangement\\39":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v101  # "$composer\\39":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {p0 .. p0}, Lcom/example/data/UploadLog;->getStatus()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8e1

    invoke-virtual/range {p0 .. p0}, Lcom/example/data/UploadLog;->getErrorMessage()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    if-eqz v0, :cond_88c

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-nez v0, :cond_889

    goto :goto_88c

    :cond_889
    const/16 v18, 0x0

    goto :goto_88e

    :cond_88c
    :goto_88c
    const/16 v18, 0x1

    :goto_88e
    if-nez v18, :cond_8e1

    const v0, -0xe17c80e

    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "624@24155L10,622@24046L314"

    invoke-static {v9, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 624
    invoke-virtual/range {p0 .. p0}, Lcom/example/data/UploadLog;->getErrorMessage()Ljava/lang/String;

    move-result-object v94

    .line 625
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v9, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v114

    .line 626
    invoke-static/range {v92 .. v93}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v96

    .line 628
    sget-object v0, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v109

    .line 624
    nop

    .line 626
    nop

    .line 628
    nop

    .line 627
    nop

    .line 625
    nop

    .line 623
    const/16 v95, 0x0

    const-wide/16 v98, 0x0

    const/16 v100, 0x0

    const/16 v101, 0x0

    const/16 v102, 0x0

    const-wide/16 v103, 0x0

    const/16 v105, 0x0

    const/16 v106, 0x0

    const-wide/16 v107, 0x0

    const/16 v110, 0x0

    const/16 v111, 0x1

    const/16 v112, 0x0

    const/16 v113, 0x0

    const/16 v116, 0x180

    const/16 v117, 0xc30

    const v118, 0xd7fa

    move-object/from16 v115, v9

    .end local v9  # "$composer\\37":Landroidx/compose/runtime/Composer;
    .restart local v115  # "$composer\\37":Landroidx/compose/runtime/Composer;
    invoke-static/range {v94 .. v118}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 622
    .end local v115  # "$composer\\37":Landroidx/compose/runtime/Composer;
    .restart local v9  # "$composer\\37":Landroidx/compose/runtime/Composer;
    goto :goto_8e7

    :cond_8e1
    const v0, -0xf838d44

    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_8e7
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 594
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 631
    nop

    .line 1803
    .end local v9  # "$composer\\37":Landroidx/compose/runtime/Composer;
    .end local v78  # "$i$a$-Column-MainActivityKt$UploadLogItem$1$1$1$2\\37\\1803\\17":I
    .end local v80  # "$this$UploadLogItem_u24lambda_u2463_u24lambda_u2462_u24lambda_u2460_u24lambda_u2459\\37":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v86  # "$changed\\37":I
    invoke-static/range {v81 .. v81}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1802
    .end local v77  # "$changed\\36":I
    .end local v81  # "$composer\\36":Landroidx/compose/runtime/Composer;
    .end local v84  # "$i$a$-Layout-ColumnKt$Column$1\\36\\1802\\30":I
    nop

    .line 1846
    invoke-interface/range {v75 .. v75}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1781
    invoke-static/range {v75 .. v75}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1847
    nop

    .line 1775
    .end local v73  # "$i$f$ReusableComposeNode\\32\\1779":I
    .end local v76  # "$changed\\32":I
    .end local v79  # "factory\\32":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v75 .. v75}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1848
    nop

    .line 1767
    .end local v59  # "$changed\\31":I
    .end local v68  # "$i$f$Layout\\31\\1774":I
    .end local v71  # "compositeKeyHash\\31":I
    .end local v82  # "localMap\\31":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v88  # "materialized\\31":Landroidx/compose/ui/Modifier;
    invoke-static/range {v75 .. v75}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1849
    nop

    .line 560
    .end local v60  # "$changed\\30":I
    .end local v69  # "$i$f$Column\\30\\593":I
    .end local v70  # "horizontalAlignment\\30":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v72  # "verticalArrangement\\30":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v74  # "modifier\\30":Landroidx/compose/ui/Modifier;
    .end local v75  # "$composer\\30":Landroidx/compose/runtime/Composer;
    .end local v83  # "measurePolicy\\30":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v58 .. v58}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 632
    nop

    .line 1723
    .end local v43  # "$changed\\17":I
    .end local v44  # "$this$UploadLogItem_u24lambda_u2463_u24lambda_u2462_u24lambda_u2460\\17":Landroidx/compose/foundation/layout/RowScope;
    .end local v51  # "$i$a$-Row-MainActivityKt$UploadLogItem$1$1$1\\17\\1723\\9":I
    .end local v58  # "$composer\\17":Landroidx/compose/runtime/Composer;
    invoke-static/range {v55 .. v55}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1722
    .end local v52  # "$changed\\16":I
    .end local v55  # "$composer\\16":Landroidx/compose/runtime/Composer;
    .end local v56  # "$i$a$-Layout-RowKt$Row$1\\16\\1722\\10":I
    nop

    .line 1850
    invoke-interface/range {v50 .. v50}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1701
    invoke-static/range {v50 .. v50}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1851
    nop

    .line 1695
    .end local v39  # "$i$f$ReusableComposeNode\\12\\1699":I
    .end local v41  # "factory\\12":Lkotlin/jvm/functions/Function0;
    .end local v42  # "$changed\\12":I
    invoke-static/range {v50 .. v50}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1852
    nop

    .line 1688
    .end local v32  # "$changed\\11":I
    .end local v35  # "$i$f$Layout\\11\\1694":I
    .end local v37  # "compositeKeyHash\\11":I
    .end local v53  # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v57  # "materialized\\11":Landroidx/compose/ui/Modifier;
    invoke-static/range {v50 .. v50}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1853
    nop

    .line 636
    .end local v33  # "$changed\\10":I
    .end local v34  # "$i$f$Row\\10\\555":I
    .end local v36  # "verticalAlignment\\10":Landroidx/compose/ui/Alignment$Vertical;
    .end local v38  # "horizontalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v40  # "modifier\\10":Landroidx/compose/ui/Modifier;
    .end local v50  # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v54  # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    const/16 v0, 0x8

    .local v0, "$this$dp\\47":I
    const/4 v1, 0x0

    .line 1854
    .local v1, "$i$f$getDp\\47\\636":I
    int-to-float v2, v0

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 636
    .end local v0  # "$this$dp\\47":I
    .end local v1  # "$i$f$getDp\\47\\636":I
    invoke-static {v0}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v0

    .line 637
    invoke-virtual/range {p0 .. p0}, Lcom/example/data/UploadLog;->getStatus()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    sparse-switch v2, :sswitch_data_a20

    :goto_92f
    goto :goto_98f

    :sswitch_930
    invoke-virtual {v1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_937

    goto :goto_92f

    .line 639
    :cond_937
    const v1, -0x6e559903

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static/range {v64 .. v65}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v1

    move-wide/from16 v34, v1

    goto :goto_9ab

    .line 637
    :sswitch_947
    invoke-virtual {v1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_94e

    goto :goto_92f

    .line 640
    :cond_94e
    const v1, -0x6e558e22

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "639@24709L11"

    invoke-static {v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v4

    const/16 v10, 0xe

    const/4 v11, 0x0

    const v6, 0x3dcccccd  # 0.1f

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static/range {v4 .. v11}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v1

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-wide/from16 v34, v1

    goto :goto_9ab

    .line 637
    :sswitch_978
    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_97f

    goto :goto_92f

    .line 638
    :cond_97f
    const v1, -0x6e559f43

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static/range {v66 .. v67}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v1

    move-wide/from16 v34, v1

    goto :goto_9ab

    .line 641
    :goto_98f
    const v1, -0x6e558506

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "640@24790L11"

    invoke-static {v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getSurfaceVariant-0d7_KjU()J

    move-result-wide v1

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-wide/from16 v34, v1

    .line 637
    :goto_9ab
    nop

    .line 643
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v4, v1

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x8

    .local v1, "$this$dp\\48":I
    const/4 v2, 0x0

    .line 1855
    .local v2, "$i$f$getDp\\48\\643":I
    int-to-float v5, v1

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 643
    .end local v1  # "$this$dp\\48":I
    .end local v2  # "$i$f$getDp\\48\\643":I
    const/16 v9, 0xe

    const/4 v10, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static/range {v4 .. v10}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v32

    .line 636
    move-object/from16 v33, v0

    check-cast v33, Landroidx/compose/ui/graphics/Shape;

    .line 637
    nop

    .line 644
    new-instance v0, Lcom/example/MainActivityKt$$ExternalSyntheticLambda24;

    move-object/from16 v1, p0

    invoke-direct {v0, v1}, Lcom/example/MainActivityKt$$ExternalSyntheticLambda24;-><init>(Lcom/example/data/UploadLog;)V

    const/16 v2, 0x36

    const v4, -0x1ed6dad9

    const/4 v5, 0x1

    invoke-static {v4, v5, v0, v3, v2}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object/from16 v41, v0

    check-cast v41, Lkotlin/jvm/functions/Function2;

    .line 635
    const-wide/16 v36, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    const v43, 0xc00006

    const/16 v44, 0x78

    move-object/from16 v42, v3

    .end local v3  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v42, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v32 .. v44}, Landroidx/compose/material3/SurfaceKt;->Surface-T9BRK9s(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;JJFFLandroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    .line 555
    .end local v42  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v3  # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 663
    nop

    .line 1687
    .end local v3  # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v27  # "$i$a$-Row-MainActivityKt$UploadLogItem$1$1\\9\\1687\\0":I
    .end local v28  # "$changed\\9":I
    .end local v31  # "$this$UploadLogItem_u24lambda_u2463_u24lambda_u2462\\9":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v45 .. v45}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1686
    .end local v26  # "$changed\\8":I
    .end local v45  # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v46  # "$i$a$-Layout-RowKt$Row$1\\8\\1686\\2":I
    nop

    .line 1856
    invoke-interface/range {v49 .. v49}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1665
    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1857
    nop

    .line 1659
    .end local v20  # "$i$f$ReusableComposeNode\\4\\1663":I
    .end local v21  # "$changed\\4":I
    .end local v22  # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1858
    nop

    .line 1656
    .end local v13  # "$changed\\3":I
    .end local v14  # "$i$f$Layout\\3\\1658":I
    .end local v15  # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v17  # "compositeKeyHash\\3":I
    .end local v62  # "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1859
    nop

    .end local v24  # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v30  # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .end local v47  # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v48  # "$changed\\2":I
    .end local v49  # "$composer\\2":Landroidx/compose/runtime/Composer;
    .end local v61  # "$i$f$Row\\2\\548":I
    .end local v63  # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_a0f

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 664
    :cond_a0f
    :goto_a0f
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    :sswitch_data_a12
    .sparse-switch
        -0x447f341d -> :sswitch_468
        -0x100cb1df -> :sswitch_454
        0x7b29883d -> :sswitch_440
    .end sparse-switch

    :sswitch_data_a20
    .sparse-switch
        -0x447f341d -> :sswitch_978
        -0x100cb1df -> :sswitch_947
        0x7b29883d -> :sswitch_930
    .end sparse-switch
.end method

.method static final UploadLogItem$lambda$63$lambda$62$lambda$61(Lcom/example/data/UploadLog;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 28
    .param p0, "$log"  # Lcom/example/data/UploadLog;
    .param p1, "$composer"  # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"  # I

    move-object/from16 v0, p1

    move/from16 v1, p2

    const-string v2, "C651@25225L10,644@24926L800:MainActivity.kt#to5c3"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x3

    const/4 v3, 0x2

    if-ne v2, v3, :cond_1a

    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v2

    if-nez v2, :cond_15

    goto :goto_1a

    .line 644
    :cond_15
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_133

    .line 0
    :cond_1a
    :goto_1a
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_29

    const/4 v2, -0x1

    const-string v3, "com.example.UploadLogItem.<anonymous>.<anonymous>.<anonymous> (MainActivity.kt:644)"

    const v4, -0x1ed6dad9

    invoke-static {v4, v1, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 646
    :cond_29
    invoke-virtual/range {p0 .. p0}, Lcom/example/data/UploadLog;->getStatus()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v3

    const-string v4, "FAILED"

    const-string v5, "UPLOADING"

    const-string v6, "SUCCESS"

    sparse-switch v3, :sswitch_data_136

    :goto_3a
    goto :goto_59

    :sswitch_3b
    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_42

    goto :goto_3a

    .line 648
    :cond_42
    const-string v2, "ব্যর্থ"

    goto :goto_5b

    .line 646
    :sswitch_45
    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_4c

    goto :goto_3a

    .line 649
    :cond_4c
    const-string v2, "চলছে..."

    goto :goto_5b

    .line 646
    :sswitch_4f
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_56

    goto :goto_3a

    .line 647
    :cond_56
    const-string v2, "সফল"

    goto :goto_5b

    .line 650
    :goto_59
    const-string v2, "অপেক্ষমান"

    .line 646
    :goto_5b
    nop

    .line 652
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v7, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v0, v7}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v20

    .line 653
    sget-object v3, Landroidx/compose/ui/text/font/FontWeight;->Companion:Landroidx/compose/ui/text/font/FontWeight$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/text/font/FontWeight$Companion;->getBold()Landroidx/compose/ui/text/font/FontWeight;

    move-result-object v7

    .line 654
    invoke-virtual/range {p0 .. p0}, Lcom/example/data/UploadLog;->getStatus()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    move-result v8

    sparse-switch v8, :sswitch_data_144

    :goto_79
    goto :goto_d0

    :sswitch_7a
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_81

    goto :goto_79

    .line 656
    :cond_81
    const v3, 0x3b74b978

    invoke-interface {v0, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const-wide v3, 0xffc62828L

    invoke-static {v3, v4}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v3

    goto :goto_ea

    .line 654
    :sswitch_94
    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_9b

    goto :goto_79

    .line 657
    :cond_9b
    const v3, 0x3b74c3ce

    invoke-interface {v0, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "656@25507L11"

    invoke-static {v0, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v0, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v3

    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_ea

    .line 654
    :sswitch_b6
    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_bd

    goto :goto_79

    .line 655
    :cond_bd
    const v3, 0x3b74b2b8

    invoke-interface {v0, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const-wide v3, 0xff2e7d32L

    invoke-static {v3, v4}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v3

    goto :goto_ea

    .line 658
    :goto_d0
    const v3, 0x3b74cc17

    invoke-interface {v0, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "657@25573L11"

    invoke-static {v0, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v0, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v3

    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 654
    :goto_ea
    nop

    .line 660
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/16 v6, 0x8

    .local v6, "$this$dp\\1":I
    const/4 v8, 0x0

    .line 1654
    .local v8, "$i$f$getDp\\1\\660":I
    int-to-float v9, v6

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 660
    .end local v6  # "$this$dp\\1":I
    .end local v8  # "$i$f$getDp\\1\\660":I
    const/4 v8, 0x4

    .local v8, "$this$dp\\2":I
    const/4 v9, 0x0

    .line 1654
    .local v9, "$i$f$getDp\\2\\660":I
    int-to-float v10, v8

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 660
    .end local v8  # "$this$dp\\2":I
    .end local v9  # "$i$f$getDp\\2\\660":I
    invoke-static {v5, v6, v8}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 646
    nop

    .line 660
    nop

    .line 654
    nop

    .line 653
    nop

    .line 652
    nop

    .line 645
    move-object v0, v2

    move-wide v2, v3

    move-object v1, v5

    const-wide/16 v4, 0x0

    const/4 v6, 0x0

    const/4 v8, 0x0

    const-wide/16 v9, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const-wide/16 v13, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const v22, 0x30030

    const/16 v23, 0x0

    const v24, 0xffd8

    move-object/from16 v21, p1

    invoke-static/range {v0 .. v24}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_133

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 662
    :cond_133
    :goto_133
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    :sswitch_data_136
    .sparse-switch
        -0x447f341d -> :sswitch_4f
        -0x100cb1df -> :sswitch_45
        0x7b29883d -> :sswitch_3b
    .end sparse-switch

    :sswitch_data_144
    .sparse-switch
        -0x447f341d -> :sswitch_b6
        -0x100cb1df -> :sswitch_94
        0x7b29883d -> :sswitch_7a
    .end sparse-switch
.end method

.method static final UploadLogItem$lambda$64(Lcom/example/data/UploadLog;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lcom/example/MainActivityKt;->UploadLogItem(Lcom/example/data/UploadLog;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final synthetic access$PhotoSenderApp$lambda$0(Landroidx/compose/runtime/State;)Z
    .registers 2
    .param p0, "$isServiceRunning$delegate"  # Landroidx/compose/runtime/State;

    .line 1
    invoke-static {p0}, Lcom/example/MainActivityKt;->PhotoSenderApp$lambda$0(Landroidx/compose/runtime/State;)Z

    move-result v0

    return v0
.end method

.method public static final synthetic access$PhotoSenderApp$lambda$11(Landroidx/compose/runtime/MutableState;)Z
    .registers 2
    .param p0, "$hasGalleryPermission$delegate"  # Landroidx/compose/runtime/MutableState;

    .line 1
    invoke-static {p0}, Lcom/example/MainActivityKt;->PhotoSenderApp$lambda$11(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    return v0
.end method

.method public static final synthetic access$PhotoSenderApp$lambda$12(Landroidx/compose/runtime/MutableState;Z)V
    .registers 2
    .param p0, "$hasGalleryPermission$delegate"  # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"  # Z

    .line 1
    invoke-static {p0, p1}, Lcom/example/MainActivityKt;->PhotoSenderApp$lambda$12(Landroidx/compose/runtime/MutableState;Z)V

    return-void
.end method

.method public static final formatFileSize(J)Ljava/lang/String;
    .registers 14
    .param p0, "bytes"  # J

    .line 721
    const-wide/16 v0, 0x0

    cmp-long v0, p0, v0

    if-gtz v0, :cond_9

    const-string v0, "0 B"

    return-object v0

    .line 722
    :cond_9
    const/4 v0, 0x4

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "B"

    aput-object v2, v0, v1

    const-string v1, "KB"

    const/4 v2, 0x1

    aput-object v1, v0, v2

    const-string v1, "MB"

    const/4 v3, 0x2

    aput-object v1, v0, v3

    const/4 v1, 0x3

    const-string v4, "GB"

    aput-object v4, v0, v1

    .line 723
    .local v0, "units":[Ljava/lang/String;
    long-to-double v4, p0

    invoke-static {v4, v5}, Ljava/lang/Math;->log10(D)D

    move-result-wide v4

    const-wide/high16 v6, 0x4090000000000000L  # 1024.0

    invoke-static {v6, v7}, Ljava/lang/Math;->log10(D)D

    move-result-wide v8

    div-double/2addr v4, v8

    double-to-int v1, v4

    .line 724
    .local v1, "digitGroups":I
    array-length v4, v0

    if-ge v1, v4, :cond_32

    move v4, v1

    goto :goto_34

    :cond_32
    array-length v4, v0

    sub-int/2addr v4, v2

    .line 725
    .local v4, "groupVal":I
    :goto_34
    sget-object v2, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v2

    long-to-double v8, p0

    int-to-double v10, v4

    invoke-static {v6, v7, v10, v11}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v5

    div-double/2addr v8, v5

    invoke-static {v8, v9}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v5

    aget-object v6, v0, v4

    filled-new-array {v5, v6}, [Ljava/lang/Object;

    move-result-object v5

    invoke-static {v5, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v3

    const-string v5, "%.1f %s"

    invoke-static {v2, v5, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "format(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v2
.end method

.method public static final formatTimestamp(J)Ljava/lang/String;
    .registers 5
    .param p0, "millis"  # J

    .line 729
    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "hh:mm a"

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 730
    .local v0, "sdf":Ljava/text/SimpleDateFormat;
    new-instance v1, Ljava/util/Date;

    invoke-direct {v1, p0, p1}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {v0, v1}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "format(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v1
.end method

.method public static final hasRequiredGalleryPermission(Landroid/content/Context;)Z
    .registers 5
    .param p0, "context"  # Landroid/content/Context;

    const-string v0, "context"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 707
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x21

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-lt v0, v1, :cond_1b

    .line 708
    nop

    .line 709
    nop

    .line 710
    nop

    .line 708
    const-string v0, "android.permission.READ_MEDIA_IMAGES"

    invoke-static {p0, v0}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_19

    goto :goto_28

    :cond_19
    move v2, v3

    goto :goto_28

    .line 713
    :cond_1b
    nop

    .line 714
    nop

    .line 715
    nop

    .line 713
    const-string v0, "android.permission.READ_EXTERNAL_STORAGE"

    invoke-static {p0, v0}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_27

    goto :goto_28

    :cond_27
    move v2, v3

    .line 707
    :goto_28
    return v2
.end method
