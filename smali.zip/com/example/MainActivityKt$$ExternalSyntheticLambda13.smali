# classes6.dex

.class public final synthetic Lcom/example/MainActivityKt$$ExternalSyntheticLambda13;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:F


# direct methods
.method public synthetic constructor <init>(F)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/example/MainActivityKt$$ExternalSyntheticLambda13;->f$0:F

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget v0, p0, Lcom/example/MainActivityKt$$ExternalSyntheticLambda13;->f$0:F

    invoke-static {v0}, Lcom/example/MainActivityKt;->ActiveProgressPanel$lambda$49$lambda$48$lambda$43$lambda$42$lambda$41$lambda$40(F)F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0
.end method
