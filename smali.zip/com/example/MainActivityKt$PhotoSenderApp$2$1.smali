# classes6.dex

.class final Lcom/example/MainActivityKt$PhotoSenderApp$2$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "MainActivity.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/MainActivityKt;->PhotoSenderApp(Landroidx/compose/ui/Modifier;Landroid/app/Application;Landroidx/compose/runtime/Composer;II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.example.MainActivityKt$PhotoSenderApp$2$1"
    f = "MainActivity.kt"
    i = {}
    l = {}
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $context:Landroid/content/Context;

.field final synthetic $hasGalleryPermission$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $isServiceRunning$delegate:Landroidx/compose/runtime/State;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/State<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $mainViewModel:Lcom/example/ui/MainViewModel;

.field label:I


# direct methods
.method constructor <init>(Lcom/example/ui/MainViewModel;Landroid/content/Context;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/State;Lkotlin/coroutines/Continuation;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/example/ui/MainViewModel;",
            "Landroid/content/Context;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;",
            "Landroidx/compose/runtime/State<",
            "Ljava/lang/Boolean;",
            ">;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/example/MainActivityKt$PhotoSenderApp$2$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;->$mainViewModel:Lcom/example/ui/MainViewModel;

    iput-object p2, p0, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;->$context:Landroid/content/Context;

    iput-object p3, p0, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;->$hasGalleryPermission$delegate:Landroidx/compose/runtime/MutableState;

    iput-object p4, p0, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;->$isServiceRunning$delegate:Landroidx/compose/runtime/State;

    const/4 v0, 0x2

    invoke-direct {p0, v0, p5}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    new-instance v0, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;

    iget-object v1, p0, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;->$mainViewModel:Lcom/example/ui/MainViewModel;

    iget-object v2, p0, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;->$context:Landroid/content/Context;

    iget-object v3, p0, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;->$hasGalleryPermission$delegate:Landroidx/compose/runtime/MutableState;

    iget-object v4, p0, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;->$isServiceRunning$delegate:Landroidx/compose/runtime/State;

    move-object v5, p2

    invoke-direct/range {v0 .. v5}, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;-><init>(Lcom/example/ui/MainViewModel;Landroid/content/Context;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/State;Lkotlin/coroutines/Continuation;)V

    check-cast v0, Lkotlin/coroutines/Continuation;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object v0

    check-cast v0, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {v0, v1}, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4
    .param p1, "$result"  # Ljava/lang/Object;

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 137
    iget v0, p0, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;->label:I

    packed-switch v0, :pswitch_data_2e

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_10  #0x0
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 138
    iget-object v0, p0, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;->$hasGalleryPermission$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {v0}, Lcom/example/MainActivityKt;->access$PhotoSenderApp$lambda$11(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    if-eqz v0, :cond_2a

    .line 139
    iget-object v0, p0, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;->$isServiceRunning$delegate:Landroidx/compose/runtime/State;

    invoke-static {v0}, Lcom/example/MainActivityKt;->access$PhotoSenderApp$lambda$0(Landroidx/compose/runtime/State;)Z

    move-result v0

    if-nez v0, :cond_2a

    .line 140
    iget-object v0, p0, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;->$mainViewModel:Lcom/example/ui/MainViewModel;

    iget-object v1, p0, Lcom/example/MainActivityKt$PhotoSenderApp$2$1;->$context:Landroid/content/Context;

    invoke-virtual {v0, v1}, Lcom/example/ui/MainViewModel;->startService(Landroid/content/Context;)V

    .line 143
    :cond_2a
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    nop

    :pswitch_data_2e
    .packed-switch 0x0
        :pswitch_10  #00000000
    .end packed-switch
.end method
