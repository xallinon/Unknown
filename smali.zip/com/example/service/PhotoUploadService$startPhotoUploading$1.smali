# classes5.dex

.class final Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "PhotoUploadService.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/service/PhotoUploadService;->startPhotoUploading()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.example.service.PhotoUploadService$startPhotoUploading$1"
    f = "PhotoUploadService.kt"
    i = {
        0x0,
        0x0,
        0x0,
        0x0,
        0x0,
        0x0,
        0x0,
        0x0,
        0x0,
        0x0,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x2,
        0x2,
        0x2,
        0x2,
        0x2,
        0x2,
        0x2,
        0x2,
        0x2,
        0x2,
        0x2,
        0x2,
        0x3,
        0x3,
        0x3,
        0x3,
        0x3,
        0x3,
        0x3,
        0x3,
        0x3,
        0x3,
        0x3,
        0x3,
        0x3,
        0x3,
        0x3,
        0x4,
        0x4,
        0x4,
        0x4,
        0x4,
        0x4,
        0x4,
        0x4,
        0x4,
        0x4,
        0x4,
        0x4,
        0x4,
        0x4,
        0x4,
        0x4,
        0x5,
        0x5,
        0x5,
        0x5,
        0x5,
        0x5,
        0x5,
        0x5,
        0x5,
        0x5,
        0x5,
        0x5,
        0x5,
        0x5,
        0x5,
        0x5,
        0x5,
        0x6,
        0x6,
        0x6,
        0x6,
        0x6,
        0x6,
        0x6,
        0x6,
        0x6,
        0x6,
        0x6,
        0x6,
        0x6,
        0x6,
        0x6,
        0x6,
        0x6,
        0x7,
        0x7,
        0x7,
        0x7,
        0x7,
        0x7,
        0x7,
        0x7,
        0x7,
        0x7,
        0x7,
        0x7,
        0x7,
        0x7,
        0x7,
        0x7,
        0x7,
        0x8,
        0x8,
        0x8,
        0x8
    }
    l = {
        0xaf,
        0xbc,
        0xc5,
        0xcf,
        0xe0,
        0xe2,
        0xea,
        0xf7,
        0x107
    }
    m = "invokeSuspend"
    n = {
        "serverUrl",
        "photoList",
        "photo",
        "displayName",
        "uri",
        "isSimulation",
        "total",
        "skippedAll",
        "index",
        "size",
        "serverUrl",
        "photoList",
        "photo",
        "displayName",
        "uri",
        "existingLog",
        "isSimulation",
        "total",
        "skippedAll",
        "index",
        "size",
        "progressFloat",
        "serverUrl",
        "photoList",
        "photo",
        "displayName",
        "uri",
        "existingLog",
        "isSimulation",
        "total",
        "skippedAll",
        "index",
        "size",
        "progressFloat",
        "serverUrl",
        "photoList",
        "photo",
        "displayName",
        "uri",
        "existingLog",
        "isSimulation",
        "total",
        "skippedAll",
        "index",
        "size",
        "progressFloat",
        "logId",
        "uploadSuccess",
        "simulateTime",
        "serverUrl",
        "photoList",
        "photo",
        "displayName",
        "uri",
        "existingLog",
        "errorMessage",
        "finalStatus",
        "isSimulation",
        "total",
        "skippedAll",
        "index",
        "size",
        "progressFloat",
        "logId",
        "uploadSuccess",
        "serverUrl",
        "photoList",
        "photo",
        "displayName",
        "uri",
        "existingLog",
        "errorMessage",
        "finalStatus",
        "currentLog",
        "isSimulation",
        "total",
        "skippedAll",
        "index",
        "size",
        "progressFloat",
        "logId",
        "uploadSuccess",
        "serverUrl",
        "photoList",
        "photo",
        "displayName",
        "uri",
        "existingLog",
        "errorMessage",
        "finalStatus",
        "currentLog",
        "isSimulation",
        "total",
        "skippedAll",
        "index",
        "size",
        "progressFloat",
        "logId",
        "uploadSuccess",
        "serverUrl",
        "photoList",
        "photo",
        "displayName",
        "uri",
        "existingLog",
        "errorMessage",
        "finalStatus",
        "currentLog",
        "isSimulation",
        "total",
        "skippedAll",
        "index",
        "size",
        "progressFloat",
        "logId",
        "uploadSuccess",
        "serverUrl",
        "photoList",
        "isSimulation",
        "total"
    }
    s = {
        "L$0",
        "L$1",
        "L$2",
        "L$3",
        "L$4",
        "Z$0",
        "I$0",
        "I$1",
        "I$2",
        "J$0",
        "L$0",
        "L$1",
        "L$2",
        "L$3",
        "L$4",
        "L$5",
        "Z$0",
        "I$0",
        "I$1",
        "I$2",
        "J$0",
        "F$0",
        "L$0",
        "L$1",
        "L$2",
        "L$3",
        "L$4",
        "L$5",
        "Z$0",
        "I$0",
        "I$1",
        "I$2",
        "J$0",
        "F$0",
        "L$0",
        "L$1",
        "L$2",
        "L$3",
        "L$4",
        "L$5",
        "Z$0",
        "I$0",
        "I$1",
        "I$2",
        "J$0",
        "F$0",
        "J$1",
        "I$4",
        "J$2",
        "L$0",
        "L$1",
        "L$2",
        "L$3",
        "L$4",
        "L$5",
        "L$6",
        "L$7",
        "Z$0",
        "I$0",
        "I$1",
        "I$2",
        "J$0",
        "F$0",
        "J$1",
        "I$4",
        "L$0",
        "L$1",
        "L$2",
        "L$3",
        "L$4",
        "L$5",
        "L$6",
        "L$7",
        "L$8",
        "Z$0",
        "I$0",
        "I$1",
        "I$2",
        "J$0",
        "F$0",
        "J$1",
        "I$4",
        "L$0",
        "L$1",
        "L$2",
        "L$3",
        "L$4",
        "L$5",
        "L$6",
        "L$7",
        "L$8",
        "Z$0",
        "I$0",
        "I$1",
        "I$2",
        "J$0",
        "F$0",
        "J$1",
        "I$4",
        "L$0",
        "L$1",
        "L$2",
        "L$3",
        "L$4",
        "L$5",
        "L$6",
        "L$7",
        "L$8",
        "Z$0",
        "I$0",
        "I$1",
        "I$2",
        "J$0",
        "F$0",
        "J$1",
        "I$4",
        "L$0",
        "L$1",
        "Z$0",
        "I$0"
    }
.end annotation


# instance fields
.field F$0:F

.field I$0:I

.field I$1:I

.field I$2:I

.field I$3:I

.field I$4:I

.field J$0:J

.field J$1:J

.field J$2:J

.field L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field L$2:Ljava/lang/Object;

.field L$3:Ljava/lang/Object;

.field L$4:Ljava/lang/Object;

.field L$5:Ljava/lang/Object;

.field L$6:Ljava/lang/Object;

.field L$7:Ljava/lang/Object;

.field L$8:Ljava/lang/Object;

.field Z$0:Z

.field label:I

.field final synthetic this$0:Lcom/example/service/PhotoUploadService;


# direct methods
.method constructor <init>(Lcom/example/service/PhotoUploadService;Lkotlin/coroutines/Continuation;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/example/service/PhotoUploadService;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/example/service/PhotoUploadService$startPhotoUploading$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    const/4 v0, 0x2

    invoke-direct {p0, v0, p2}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    new-instance v0, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;

    iget-object v1, p0, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-direct {v0, v1, p2}, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;-><init>(Lcom/example/service/PhotoUploadService;Lkotlin/coroutines/Continuation;)V

    check-cast v0, Lkotlin/coroutines/Continuation;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object v0

    check-cast v0, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {v0, v1}, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 53
    .param p1, "$result"  # Ljava/lang/Object;

    move-object/from16 v1, p0

    const-string v2, "গ্যালারিতে কোনো ছবি পাওয়া যায়নি।"

    const-string v3, "নতুন ছবির জন্য অপেক্ষা করা হচ্ছে..."

    const-string v4, "সকল ছবি ট্রান্সফার সম্পন্ন হয়েছে!"

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 150
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->label:I

    const-string v6, "SUCCESS"

    const-string v7, "PhotoUploadService"

    const-string v8, "toString(...)"

    const-string v10, "repository"

    packed-switch v5, :pswitch_data_afc

    .end local p0  # "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .restart local p0  # "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    :pswitch_21  #0x9
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$0:I

    .local v5, "total":I
    iget-boolean v13, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->Z$0:Z

    .local v13, "isSimulation":Z
    iget-object v14, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$1:Ljava/lang/Object;

    check-cast v14, Ljava/util/List;

    .local v14, "photoList":Ljava/util/List;
    iget-object v15, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$0:Ljava/lang/Object;

    check-cast v15, Ljava/lang/String;

    .local v15, "serverUrl":Ljava/lang/String;
    :try_start_2d
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_30
    .catch Ljava/lang/Exception; {:try_start_2d .. :try_end_30} :catch_3c7
    .catchall {:try_start_2d .. :try_end_30} :catchall_3c1

    move-object v11, v1

    move-object/from16 v18, v2

    move-object/from16 v21, v6

    move-object/from16 v24, v7

    move-object/from16 v28, v8

    move-object/from16 v22, v10

    move v10, v13

    move-object v9, v15

    const/4 v6, 0x0

    const/16 v16, 0x1

    move-object/from16 v1, p1

    goto/16 :goto_a80

    .end local v5  # "total":I
    .end local v13  # "isSimulation":Z
    .end local v14  # "photoList":Ljava/util/List;
    .end local v15  # "serverUrl":Ljava/lang/String;
    :pswitch_44  #0x8
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$4:I

    .local v5, "uploadSuccess":Z
    iget-wide v13, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$1:J

    .local v13, "logId":J
    iget v15, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->F$0:F

    .local v15, "progressFloat":F
    iget-wide v11, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$0:J

    .local v11, "size":J
    iget v9, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$3:I

    move/from16 v18, v5

    .end local v5  # "uploadSuccess":Z
    .local v18, "uploadSuccess":Z
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$2:I

    move/from16 v19, v5

    .local v19, "index":I
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$1:I

    move/from16 v20, v5

    .local v20, "skippedAll":Z
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$0:I

    move/from16 v21, v5

    .local v21, "total":I
    iget-boolean v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->Z$0:Z

    move/from16 v22, v5

    .local v22, "isSimulation":Z
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$8:Ljava/lang/Object;

    check-cast v5, Lcom/example/data/UploadLog;

    move-object/from16 v23, v5

    .local v23, "currentLog":Lcom/example/data/UploadLog;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$7:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    move-object/from16 v24, v5

    .local v24, "finalStatus":Ljava/lang/String;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$6:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    move-object/from16 v25, v5

    .local v25, "errorMessage":Ljava/lang/String;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$5:Ljava/lang/Object;

    check-cast v5, Lcom/example/data/UploadLog;

    move-object/from16 v26, v5

    .local v26, "existingLog":Lcom/example/data/UploadLog;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$4:Ljava/lang/Object;

    check-cast v5, Landroid/net/Uri;

    move-object/from16 v27, v5

    .local v27, "uri":Landroid/net/Uri;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$3:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    move-object/from16 v28, v5

    .local v28, "displayName":Ljava/lang/String;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$2:Ljava/lang/Object;

    check-cast v5, Lcom/example/service/PhotoUploadService$GalleryPhoto;

    move-object/from16 v29, v5

    .local v29, "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$1:Ljava/lang/Object;

    check-cast v5, Ljava/util/List;

    move-object/from16 v30, v5

    .local v30, "photoList":Ljava/util/List;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$0:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    .local v5, "serverUrl":Ljava/lang/String;
    :try_start_94
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_97
    .catch Ljava/lang/Exception; {:try_start_94 .. :try_end_97} :catch_3c7
    .catchall {:try_start_94 .. :try_end_97} :catchall_3c1

    move/from16 v33, v21

    move-object/from16 v21, v6

    move/from16 v6, v33

    move-object/from16 v43, v23

    move-object/from16 v36, v24

    move-object/from16 v37, v25

    move-object/from16 v33, v28

    move-object/from16 v23, v3

    move-object/from16 v25, v4

    move-object/from16 v24, v7

    move-object/from16 v28, v8

    move-wide v3, v13

    move/from16 v14, v19

    move/from16 v7, v22

    move-object/from16 v22, v10

    move v10, v15

    move v15, v9

    move/from16 v9, v18

    move-object/from16 v18, v2

    move-object v2, v1

    move-object v1, v5

    move-object/from16 v5, v26

    move-object/from16 v26, p1

    goto/16 :goto_99e

    .end local v5  # "serverUrl":Ljava/lang/String;
    .end local v11  # "size":J
    .end local v13  # "logId":J
    .end local v15  # "progressFloat":F
    .end local v18  # "uploadSuccess":Z
    .end local v19  # "index":I
    .end local v20  # "skippedAll":Z
    .end local v21  # "total":I
    .end local v22  # "isSimulation":Z
    .end local v23  # "currentLog":Lcom/example/data/UploadLog;
    .end local v24  # "finalStatus":Ljava/lang/String;
    .end local v25  # "errorMessage":Ljava/lang/String;
    .end local v26  # "existingLog":Lcom/example/data/UploadLog;
    .end local v27  # "uri":Landroid/net/Uri;
    .end local v28  # "displayName":Ljava/lang/String;
    .end local v29  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .end local v30  # "photoList":Ljava/util/List;
    :pswitch_c2  #0x7
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$4:I

    .local v5, "uploadSuccess":Z
    iget-wide v11, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$1:J

    .local v11, "logId":J
    iget v9, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->F$0:F

    .local v9, "progressFloat":F
    iget-wide v13, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$0:J

    .local v13, "size":J
    iget v15, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$3:I

    move/from16 v18, v5

    .end local v5  # "uploadSuccess":Z
    .restart local v18  # "uploadSuccess":Z
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$2:I

    move/from16 v19, v5

    .restart local v19  # "index":I
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$1:I

    move/from16 v20, v5

    .restart local v20  # "skippedAll":Z
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$0:I

    move/from16 v21, v5

    .restart local v21  # "total":I
    iget-boolean v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->Z$0:Z

    move/from16 v22, v5

    .restart local v22  # "isSimulation":Z
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$8:Ljava/lang/Object;

    check-cast v5, Lcom/example/data/UploadLog;

    move-object/from16 v23, v5

    .restart local v23  # "currentLog":Lcom/example/data/UploadLog;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$7:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    move-object/from16 v24, v5

    .restart local v24  # "finalStatus":Ljava/lang/String;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$6:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    move-object/from16 v25, v5

    .restart local v25  # "errorMessage":Ljava/lang/String;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$5:Ljava/lang/Object;

    check-cast v5, Lcom/example/data/UploadLog;

    move-object/from16 v26, v5

    .restart local v26  # "existingLog":Lcom/example/data/UploadLog;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$4:Ljava/lang/Object;

    check-cast v5, Landroid/net/Uri;

    move-object/from16 v27, v5

    .restart local v27  # "uri":Landroid/net/Uri;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$3:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    move-object/from16 v28, v5

    .restart local v28  # "displayName":Ljava/lang/String;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$2:Ljava/lang/Object;

    check-cast v5, Lcom/example/service/PhotoUploadService$GalleryPhoto;

    move-object/from16 v29, v5

    .restart local v29  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$1:Ljava/lang/Object;

    check-cast v5, Ljava/util/List;

    move-object/from16 v30, v5

    .restart local v30  # "photoList":Ljava/util/List;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$0:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    .local v5, "serverUrl":Ljava/lang/String;
    :try_start_112
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_115
    .catch Ljava/lang/Exception; {:try_start_112 .. :try_end_115} :catch_3c7
    .catchall {:try_start_112 .. :try_end_115} :catchall_3c1

    move/from16 v33, v21

    move-object/from16 v21, v6

    move/from16 v6, v33

    move-object/from16 v43, v23

    move-object/from16 v36, v24

    move-object/from16 v37, v25

    move-object/from16 v33, v28

    move-object/from16 v23, v3

    move-object/from16 v25, v4

    move-object/from16 v24, v7

    move-object/from16 v28, v8

    move-wide v3, v13

    move/from16 v14, v19

    move/from16 v8, v20

    move/from16 v7, v22

    move-object/from16 v22, v10

    move-wide v12, v11

    move-object v11, v1

    move v10, v9

    move/from16 v9, v18

    move-object/from16 v1, v30

    move-object/from16 v18, v2

    move-object/from16 v2, v26

    move-object/from16 v26, p1

    goto/16 :goto_93d

    .end local v5  # "serverUrl":Ljava/lang/String;
    .end local v9  # "progressFloat":F
    .end local v11  # "logId":J
    .end local v13  # "size":J
    .end local v18  # "uploadSuccess":Z
    .end local v19  # "index":I
    .end local v20  # "skippedAll":Z
    .end local v21  # "total":I
    .end local v22  # "isSimulation":Z
    .end local v23  # "currentLog":Lcom/example/data/UploadLog;
    .end local v24  # "finalStatus":Ljava/lang/String;
    .end local v25  # "errorMessage":Ljava/lang/String;
    .end local v26  # "existingLog":Lcom/example/data/UploadLog;
    .end local v27  # "uri":Landroid/net/Uri;
    .end local v28  # "displayName":Ljava/lang/String;
    .end local v29  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .end local v30  # "photoList":Ljava/util/List;
    :pswitch_143  #0x6
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$4:I

    .local v5, "uploadSuccess":Z
    iget-wide v11, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$1:J

    .restart local v11  # "logId":J
    iget v9, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->F$0:F

    .restart local v9  # "progressFloat":F
    iget-wide v13, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$0:J

    .restart local v13  # "size":J
    iget v15, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$3:I

    move/from16 v18, v5

    .end local v5  # "uploadSuccess":Z
    .restart local v18  # "uploadSuccess":Z
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$2:I

    move/from16 v19, v5

    .restart local v19  # "index":I
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$1:I

    move/from16 v20, v5

    .restart local v20  # "skippedAll":Z
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$0:I

    move/from16 v21, v5

    .restart local v21  # "total":I
    iget-boolean v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->Z$0:Z

    move/from16 v22, v5

    .restart local v22  # "isSimulation":Z
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$8:Ljava/lang/Object;

    check-cast v5, Lcom/example/data/UploadLog;

    move-object/from16 v23, v5

    .restart local v23  # "currentLog":Lcom/example/data/UploadLog;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$7:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    move-object/from16 v24, v5

    .restart local v24  # "finalStatus":Ljava/lang/String;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$6:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    move-object/from16 v25, v5

    .restart local v25  # "errorMessage":Ljava/lang/String;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$5:Ljava/lang/Object;

    check-cast v5, Lcom/example/data/UploadLog;

    move-object/from16 v26, v5

    .restart local v26  # "existingLog":Lcom/example/data/UploadLog;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$4:Ljava/lang/Object;

    check-cast v5, Landroid/net/Uri;

    move-object/from16 v27, v5

    .restart local v27  # "uri":Landroid/net/Uri;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$3:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    move-object/from16 v28, v5

    .restart local v28  # "displayName":Ljava/lang/String;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$2:Ljava/lang/Object;

    check-cast v5, Lcom/example/service/PhotoUploadService$GalleryPhoto;

    move-object/from16 v29, v5

    .restart local v29  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$1:Ljava/lang/Object;

    check-cast v5, Ljava/util/List;

    move-object/from16 v30, v5

    .restart local v30  # "photoList":Ljava/util/List;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$0:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    .local v5, "serverUrl":Ljava/lang/String;
    :try_start_193
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_196
    .catch Ljava/lang/Exception; {:try_start_193 .. :try_end_196} :catch_3c7
    .catchall {:try_start_193 .. :try_end_196} :catchall_3c1

    move/from16 v34, v21

    move-object/from16 v21, v6

    move/from16 v6, v34

    move-wide/from16 v34, v13

    move/from16 v14, v19

    move-object/from16 v43, v23

    move-object/from16 v36, v24

    move-object/from16 v37, v25

    move-object/from16 v23, v3

    move-object/from16 v25, v4

    move-object/from16 v24, v7

    move-wide v12, v11

    move/from16 v7, v22

    move-object v11, v1

    move-object/from16 v22, v10

    move-object/from16 v1, v27

    move-object/from16 v27, v28

    move-object/from16 v28, v8

    move v10, v9

    move/from16 v9, v18

    move-object/from16 v18, v2

    move-object/from16 v2, v26

    move-object/from16 v26, p1

    goto/16 :goto_88c

    .end local v5  # "serverUrl":Ljava/lang/String;
    .end local v9  # "progressFloat":F
    .end local v11  # "logId":J
    .end local v13  # "size":J
    .end local v18  # "uploadSuccess":Z
    .end local v19  # "index":I
    .end local v20  # "skippedAll":Z
    .end local v21  # "total":I
    .end local v22  # "isSimulation":Z
    .end local v23  # "currentLog":Lcom/example/data/UploadLog;
    .end local v24  # "finalStatus":Ljava/lang/String;
    .end local v25  # "errorMessage":Ljava/lang/String;
    .end local v26  # "existingLog":Lcom/example/data/UploadLog;
    .end local v27  # "uri":Landroid/net/Uri;
    .end local v28  # "displayName":Ljava/lang/String;
    .end local v29  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .end local v30  # "photoList":Ljava/util/List;
    :pswitch_1c3  #0x5
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$4:I

    .local v5, "uploadSuccess":Z
    iget-wide v11, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$1:J

    .restart local v11  # "logId":J
    iget v9, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->F$0:F

    .restart local v9  # "progressFloat":F
    iget-wide v13, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$0:J

    .restart local v13  # "size":J
    iget v15, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$3:I

    move/from16 v18, v5

    .end local v5  # "uploadSuccess":Z
    .restart local v18  # "uploadSuccess":Z
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$2:I

    move/from16 v19, v5

    .restart local v19  # "index":I
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$1:I

    move/from16 v20, v5

    .restart local v20  # "skippedAll":Z
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$0:I

    move/from16 v21, v5

    .restart local v21  # "total":I
    iget-boolean v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->Z$0:Z

    move/from16 v22, v5

    .restart local v22  # "isSimulation":Z
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$7:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    move-object/from16 v23, v5

    .local v23, "finalStatus":Ljava/lang/String;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$6:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    move-object/from16 v24, v5

    .local v24, "errorMessage":Ljava/lang/String;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$5:Ljava/lang/Object;

    check-cast v5, Lcom/example/data/UploadLog;

    move-object/from16 v25, v5

    .local v25, "existingLog":Lcom/example/data/UploadLog;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$4:Ljava/lang/Object;

    check-cast v5, Landroid/net/Uri;

    move-object/from16 v26, v5

    .local v26, "uri":Landroid/net/Uri;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$3:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    move-object/from16 v27, v5

    .local v27, "displayName":Ljava/lang/String;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$2:Ljava/lang/Object;

    check-cast v5, Lcom/example/service/PhotoUploadService$GalleryPhoto;

    move-object/from16 v28, v5

    .local v28, "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$1:Ljava/lang/Object;

    check-cast v5, Ljava/util/List;

    move-object/from16 v29, v5

    .local v29, "photoList":Ljava/util/List;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$0:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    .local v5, "serverUrl":Ljava/lang/String;
    :try_start_20d
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_210
    .catch Ljava/lang/Exception; {:try_start_20d .. :try_end_210} :catch_3c7
    .catchall {:try_start_20d .. :try_end_210} :catchall_3c1

    move/from16 v36, v21

    move-object/from16 v21, v6

    move/from16 v6, v36

    move-object/from16 v36, v23

    move-object/from16 v37, v24

    move-object/from16 v23, v3

    move-object/from16 v24, v7

    move v3, v15

    move/from16 v7, v22

    move-object v15, v1

    move-object/from16 v22, v10

    move v10, v9

    move/from16 v9, v18

    move-object/from16 v18, v2

    move-wide v1, v13

    move/from16 v14, v19

    move-object/from16 v19, v28

    move-object/from16 v28, v8

    move-wide v12, v11

    move/from16 v8, v20

    move-object/from16 v20, v25

    move-object/from16 v25, v4

    move-object v11, v5

    move-object/from16 v5, v26

    move-object/from16 v4, v29

    move-object/from16 v26, p1

    goto/16 :goto_7f9

    .end local v5  # "serverUrl":Ljava/lang/String;
    .end local v9  # "progressFloat":F
    .end local v11  # "logId":J
    .end local v13  # "size":J
    .end local v18  # "uploadSuccess":Z
    .end local v19  # "index":I
    .end local v20  # "skippedAll":Z
    .end local v21  # "total":I
    .end local v22  # "isSimulation":Z
    .end local v23  # "finalStatus":Ljava/lang/String;
    .end local v24  # "errorMessage":Ljava/lang/String;
    .end local v25  # "existingLog":Lcom/example/data/UploadLog;
    .end local v26  # "uri":Landroid/net/Uri;
    .end local v27  # "displayName":Ljava/lang/String;
    .end local v28  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .end local v29  # "photoList":Ljava/util/List;
    :pswitch_240  #0x4
    iget-wide v11, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$2:J

    .local v11, "simulateTime":J
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$4:I

    .local v5, "uploadSuccess":Z
    iget-wide v13, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$1:J

    .local v13, "logId":J
    iget v9, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->F$0:F

    move/from16 v18, v9

    move-object v15, v10

    .local v18, "progressFloat":F
    iget-wide v9, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$0:J

    move/from16 v19, v5

    .end local v5  # "uploadSuccess":Z
    .local v9, "size":J
    .local v19, "uploadSuccess":Z
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$3:I

    move/from16 v20, v5

    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$2:I

    move/from16 v21, v5

    .local v21, "index":I
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$1:I

    move/from16 v22, v5

    .local v22, "skippedAll":Z
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$0:I

    move/from16 v23, v5

    .local v23, "total":I
    iget-boolean v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->Z$0:Z

    .local v5, "isSimulation":Z
    const/16 v24, 0x0

    move/from16 v25, v5

    .end local v5  # "isSimulation":Z
    .restart local v24  # "errorMessage":Ljava/lang/String;
    .local v25, "isSimulation":Z
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$5:Ljava/lang/Object;

    check-cast v5, Lcom/example/data/UploadLog;

    move-object/from16 v26, v5

    .local v26, "existingLog":Lcom/example/data/UploadLog;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$4:Ljava/lang/Object;

    check-cast v5, Landroid/net/Uri;

    move-object/from16 v27, v5

    .local v27, "uri":Landroid/net/Uri;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$3:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    move-object/from16 v28, v5

    .local v28, "displayName":Ljava/lang/String;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$2:Ljava/lang/Object;

    check-cast v5, Lcom/example/service/PhotoUploadService$GalleryPhoto;

    move-object/from16 v29, v5

    .local v29, "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$1:Ljava/lang/Object;

    check-cast v5, Ljava/util/List;

    move-object/from16 v30, v5

    .restart local v30  # "photoList":Ljava/util/List;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$0:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    .local v5, "serverUrl":Ljava/lang/String;
    :try_start_287
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_28a
    .catch Ljava/lang/Exception; {:try_start_287 .. :try_end_28a} :catch_3c7
    .catchall {:try_start_287 .. :try_end_28a} :catchall_3c1

    move-wide/from16 v32, v13

    move/from16 v13, v22

    move/from16 v14, v23

    move/from16 v31, v25

    move-object/from16 v23, v3

    move-object/from16 v25, v4

    move-object/from16 v22, v15

    move-object/from16 v4, v27

    move-object/from16 v3, v28

    move-object v15, v1

    move-object/from16 v28, v8

    move-object/from16 v1, v24

    move-object/from16 v24, v7

    move-wide v7, v9

    move/from16 v10, v20

    move-object/from16 v20, v26

    move-object v9, v5

    move-wide/from16 v26, v11

    move/from16 v11, v18

    move/from16 v5, v19

    move/from16 v12, v21

    move-object/from16 v18, v2

    move-object/from16 v21, v6

    move-object v2, v0

    move-object/from16 v0, p1

    goto/16 :goto_6d8

    .end local v5  # "serverUrl":Ljava/lang/String;
    .end local v9  # "size":J
    .end local v11  # "simulateTime":J
    .end local v13  # "logId":J
    .end local v18  # "progressFloat":F
    .end local v19  # "uploadSuccess":Z
    .end local v21  # "index":I
    .end local v22  # "skippedAll":Z
    .end local v23  # "total":I
    .end local v24  # "errorMessage":Ljava/lang/String;
    .end local v25  # "isSimulation":Z
    .end local v26  # "existingLog":Lcom/example/data/UploadLog;
    .end local v27  # "uri":Landroid/net/Uri;
    .end local v28  # "displayName":Ljava/lang/String;
    .end local v29  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .end local v30  # "photoList":Ljava/util/List;
    :pswitch_2ba  #0x3
    move-object v15, v10

    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->F$0:F

    .local v5, "progressFloat":F
    iget-wide v9, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$0:J

    .restart local v9  # "size":J
    iget v11, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$3:I

    iget v12, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$2:I

    .local v12, "index":I
    iget v13, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$1:I

    .local v13, "skippedAll":Z
    iget v14, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$0:I

    move/from16 v18, v5

    .end local v5  # "progressFloat":F
    .local v14, "total":I
    .restart local v18  # "progressFloat":F
    iget-boolean v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->Z$0:Z

    move/from16 v19, v5

    .local v19, "isSimulation":Z
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$5:Ljava/lang/Object;

    check-cast v5, Lcom/example/data/UploadLog;

    move-object/from16 v20, v5

    .local v20, "existingLog":Lcom/example/data/UploadLog;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$4:Ljava/lang/Object;

    check-cast v5, Landroid/net/Uri;

    move-object/from16 v21, v5

    .local v21, "uri":Landroid/net/Uri;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$3:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    move-object/from16 v22, v5

    .local v22, "displayName":Ljava/lang/String;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$2:Ljava/lang/Object;

    check-cast v5, Lcom/example/service/PhotoUploadService$GalleryPhoto;

    move-object/from16 v23, v5

    .local v23, "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$1:Ljava/lang/Object;

    check-cast v5, Ljava/util/List;

    move-object/from16 v24, v5

    .local v24, "photoList":Ljava/util/List;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$0:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    .local v5, "serverUrl":Ljava/lang/String;
    :try_start_2ef
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_2f2
    .catch Ljava/lang/Exception; {:try_start_2ef .. :try_end_2f2} :catch_3c7
    .catchall {:try_start_2ef .. :try_end_2f2} :catchall_3c1

    move-object/from16 v25, v20

    move-object/from16 v20, v5

    move-object/from16 v5, v25

    move-object/from16 v25, v4

    move-object/from16 v28, v8

    move/from16 v27, v14

    move/from16 v14, v19

    move-object/from16 v4, v21

    move-object/from16 v19, v23

    move-object/from16 v26, v24

    move-object/from16 v23, v3

    move-object/from16 v21, v6

    move-object/from16 v24, v7

    move-wide v6, v9

    move v10, v11

    move/from16 v9, v18

    move-object v11, v1

    move-object/from16 v18, v2

    move-object/from16 v2, v22

    move-object/from16 v22, v15

    move-object/from16 v1, p1

    goto/16 :goto_661

    .end local v5  # "serverUrl":Ljava/lang/String;
    .end local v9  # "size":J
    .end local v12  # "index":I
    .end local v13  # "skippedAll":Z
    .end local v14  # "total":I
    .end local v18  # "progressFloat":F
    .end local v19  # "isSimulation":Z
    .end local v20  # "existingLog":Lcom/example/data/UploadLog;
    .end local v21  # "uri":Landroid/net/Uri;
    .end local v22  # "displayName":Ljava/lang/String;
    .end local v23  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .end local v24  # "photoList":Ljava/util/List;
    :pswitch_31b  #0x2
    move-object v15, v10

    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->F$0:F

    .local v5, "progressFloat":F
    iget-wide v9, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$0:J

    .restart local v9  # "size":J
    iget v11, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$3:I

    iget v12, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$2:I

    .restart local v12  # "index":I
    iget v13, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$1:I

    .restart local v13  # "skippedAll":Z
    iget v14, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$0:I

    move/from16 v18, v5

    .end local v5  # "progressFloat":F
    .restart local v14  # "total":I
    .restart local v18  # "progressFloat":F
    iget-boolean v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->Z$0:Z

    move/from16 v19, v5

    .restart local v19  # "isSimulation":Z
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$5:Ljava/lang/Object;

    check-cast v5, Lcom/example/data/UploadLog;

    move-object/from16 v20, v5

    .restart local v20  # "existingLog":Lcom/example/data/UploadLog;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$4:Ljava/lang/Object;

    check-cast v5, Landroid/net/Uri;

    move-object/from16 v21, v5

    .restart local v21  # "uri":Landroid/net/Uri;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$3:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    move-object/from16 v22, v5

    .restart local v22  # "displayName":Ljava/lang/String;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$2:Ljava/lang/Object;

    check-cast v5, Lcom/example/service/PhotoUploadService$GalleryPhoto;

    move-object/from16 v23, v5

    .restart local v23  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$1:Ljava/lang/Object;

    check-cast v5, Ljava/util/List;

    move-object/from16 v24, v5

    .restart local v24  # "photoList":Ljava/util/List;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$0:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    .local v5, "serverUrl":Ljava/lang/String;
    :try_start_350
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_353
    .catch Ljava/lang/Exception; {:try_start_350 .. :try_end_353} :catch_3c7
    .catchall {:try_start_350 .. :try_end_353} :catchall_3c1

    move-object/from16 v25, v4

    move-object/from16 v28, v8

    move/from16 v46, v18

    move-object/from16 v4, v21

    move-object/from16 v26, v24

    move-object/from16 v18, v2

    move-object/from16 v21, v6

    move-object/from16 v24, v7

    move-wide v6, v9

    move v10, v11

    move-object/from16 v2, v22

    move-object v11, v1

    move-object v9, v5

    move-object/from16 v22, v15

    move/from16 v5, v19

    move-object/from16 v19, v23

    move-object/from16 v1, p1

    move-object/from16 v23, v3

    move-object v3, v1

    goto/16 :goto_5e0

    .end local v5  # "serverUrl":Ljava/lang/String;
    .end local v9  # "size":J
    .end local v12  # "index":I
    .end local v13  # "skippedAll":Z
    .end local v14  # "total":I
    .end local v18  # "progressFloat":F
    .end local v19  # "isSimulation":Z
    .end local v20  # "existingLog":Lcom/example/data/UploadLog;
    .end local v21  # "uri":Landroid/net/Uri;
    .end local v22  # "displayName":Ljava/lang/String;
    .end local v23  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .end local v24  # "photoList":Ljava/util/List;
    :pswitch_376  #0x1
    move-object v15, v10

    iget-wide v9, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$0:J

    .restart local v9  # "size":J
    iget v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$3:I

    iget v11, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$2:I

    .local v11, "index":I
    iget v12, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$1:I

    .local v12, "skippedAll":Z
    iget v13, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$0:I

    .local v13, "total":I
    iget-boolean v14, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->Z$0:Z

    move/from16 v18, v5

    .local v14, "isSimulation":Z
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$4:Ljava/lang/Object;

    check-cast v5, Landroid/net/Uri;

    move-object/from16 v19, v5

    .local v19, "uri":Landroid/net/Uri;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$3:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    move-object/from16 v20, v5

    .local v20, "displayName":Ljava/lang/String;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$2:Ljava/lang/Object;

    check-cast v5, Lcom/example/service/PhotoUploadService$GalleryPhoto;

    move-object/from16 v21, v5

    .local v21, "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$1:Ljava/lang/Object;

    check-cast v5, Ljava/util/List;

    move-object/from16 v22, v5

    .local v22, "photoList":Ljava/util/List;
    iget-object v5, v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$0:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    .restart local v5  # "serverUrl":Ljava/lang/String;
    :try_start_3a1
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_3a4
    .catch Ljava/lang/Exception; {:try_start_3a1 .. :try_end_3a4} :catch_3c7
    .catchall {:try_start_3a1 .. :try_end_3a4} :catchall_3c1

    move/from16 v25, v11

    move-object v11, v1

    move v1, v13

    move-object/from16 v13, v22

    move-object/from16 v22, v15

    move/from16 v15, v25

    move-object/from16 v25, v4

    move-wide/from16 v31, v9

    move/from16 v10, v18

    move-object/from16 v4, v19

    move-object/from16 v19, v21

    move-object/from16 v18, v2

    move-object v9, v5

    move-object/from16 v2, p1

    move-object/from16 v5, v20

    goto/16 :goto_4f9

    .line 269
    .end local v5  # "serverUrl":Ljava/lang/String;
    .end local v9  # "size":J
    .end local v11  # "index":I
    .end local v12  # "skippedAll":Z
    .end local v13  # "total":I
    .end local v14  # "isSimulation":Z
    .end local v19  # "uri":Landroid/net/Uri;
    .end local v20  # "displayName":Ljava/lang/String;
    .end local v21  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .end local v22  # "photoList":Ljava/util/List;
    :catchall_3c1
    move-exception v0

    move-object/from16 v26, p1

    move-object v11, v1

    goto/16 :goto_aed

    .line 266
    :catch_3c7
    move-exception v0

    move-object/from16 v26, p1

    move-object v11, v1

    move-object/from16 v24, v7

    goto/16 :goto_ad0

    .line 150
    :pswitch_3cf  #0x0
    move-object v15, v10

    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 151
    nop

    .line 152
    :try_start_3d4
    sget-object v5, Lcom/example/data/UploadStateTracker;->INSTANCE:Lcom/example/data/UploadStateTracker;

    invoke-virtual {v5}, Lcom/example/data/UploadStateTracker;->getCustomServerUrl()Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v5

    invoke-interface {v5}, Lkotlinx/coroutines/flow/StateFlow;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .line 153
    .restart local v5  # "serverUrl":Ljava/lang/String;
    sget-object v9, Lcom/example/data/UploadStateTracker;->INSTANCE:Lcom/example/data/UploadStateTracker;

    invoke-virtual {v9}, Lcom/example/data/UploadStateTracker;->isSimulationMode()Lkotlinx/coroutines/flow/StateFlow;

    move-result-object v9

    invoke-interface {v9}, Lkotlinx/coroutines/flow/StateFlow;->getValue()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Boolean;

    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v9

    .line 155
    .local v9, "isSimulation":Z
    if-eqz v9, :cond_3f4

    const/4 v10, 0x1

    goto :goto_3f5

    :cond_3f4
    const/4 v10, 0x0

    :goto_3f5
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "Starting continuous background upload. Server: "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, ", Simulation: "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v7, v10}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_415
    .catch Ljava/lang/Exception; {:try_start_3d4 .. :try_end_415} :catch_ac9
    .catchall {:try_start_3d4 .. :try_end_415} :catchall_ac3

    move-object v11, v1

    move v10, v9

    move-object v9, v5

    move-object/from16 v5, p1

    .line 157
    .end local p0  # "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    .end local p1  # "$result":Ljava/lang/Object;
    .local v5, "$result":Ljava/lang/Object;
    .local v9, "serverUrl":Ljava/lang/String;
    .local v10, "isSimulation":Z
    .local v11, "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    :goto_41a
    :try_start_41a
    iget-object v12, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v12}, Lcom/example/service/PhotoUploadService;->access$isUploading$p(Lcom/example/service/PhotoUploadService;)Z

    move-result v12

    if-eqz v12, :cond_aa3

    .line 158
    iget-object v12, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v12}, Lcom/example/service/PhotoUploadService;->access$queryGalleryPhotos(Lcom/example/service/PhotoUploadService;)Ljava/util/List;

    move-result-object v12

    .line 159
    .local v12, "photoList":Ljava/util/List;
    invoke-interface {v12}, Ljava/util/List;->size()I

    move-result v13
    :try_end_42c
    .catch Ljava/lang/Exception; {:try_start_41a .. :try_end_42c} :catch_abb
    .catchall {:try_start_41a .. :try_end_42c} :catchall_ab5

    .line 161
    .restart local v13  # "total":I
    if-nez v13, :cond_457

    .line 162
    :try_start_42e
    sget-object v14, Lcom/example/data/UploadStateTracker;->INSTANCE:Lcom/example/data/UploadStateTracker;
    :try_end_430
    .catch Ljava/lang/Exception; {:try_start_42e .. :try_end_430} :catch_44e
    .catchall {:try_start_42e .. :try_end_430} :catchall_ab5

    .restart local p0  # "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    const/4 v1, 0x0

    move-object/from16 p1, v5

    const/4 v5, 0x0

    .end local v5  # "$result":Ljava/lang/Object;
    .restart local p1  # "$result":Ljava/lang/Object;
    :try_start_434
    invoke-virtual {v14, v2, v5, v5, v1}, Lcom/example/data/UploadStateTracker;->updateProgress(Ljava/lang/String;IIF)V

    .line 163
    .end local p0  # "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    iget-object v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v1, v2, v5, v5}, Lcom/example/service/PhotoUploadService;->access$updateNotification(Lcom/example/service/PhotoUploadService;Ljava/lang/String;II)V
    :try_end_43c
    .catch Ljava/lang/Exception; {:try_start_434 .. :try_end_43c} :catch_51d
    .catchall {:try_start_434 .. :try_end_43c} :catchall_9d4

    move-object/from16 v18, v2

    move-object/from16 v21, v6

    move-object/from16 v24, v7

    move-object/from16 v28, v8

    move-object v14, v12

    move v5, v13

    move-object/from16 v22, v15

    const/16 v16, 0x1

    move-object/from16 v1, p1

    goto/16 :goto_a4d

    .line 266
    .end local v9  # "serverUrl":Ljava/lang/String;
    .end local v10  # "isSimulation":Z
    .end local v12  # "photoList":Ljava/util/List;
    .end local v13  # "total":I
    .end local p1  # "$result":Ljava/lang/Object;
    .restart local v5  # "$result":Ljava/lang/Object;
    :catch_44e
    move-exception v0

    move-object/from16 p1, v5

    move-object/from16 v26, p1

    move-object/from16 v24, v7

    goto/16 :goto_ac2

    .line 165
    .restart local v9  # "serverUrl":Ljava/lang/String;
    .restart local v10  # "isSimulation":Z
    .restart local v12  # "photoList":Ljava/util/List;
    .restart local v13  # "total":I
    :cond_457
    move-object/from16 p1, v5

    const/4 v5, 0x0

    .end local v5  # "$result":Ljava/lang/Object;
    .restart local p1  # "$result":Ljava/lang/Object;
    const/4 v1, 0x1

    .line 166
    .local v1, "skippedAll":Z
    const/4 v14, 0x0

    .local v14, "index":I
    :try_start_45c
    move-object/from16 v17, v12

    check-cast v17, Ljava/util/Collection;

    invoke-interface/range {v17 .. v17}, Ljava/util/Collection;->size()I

    move-result v17

    move v5, v14

    move v14, v13

    move-object v13, v12

    move v12, v1

    move/from16 v1, v17

    .end local v1  # "skippedAll":Z
    .local v5, "index":I
    .local v12, "skippedAll":Z
    .local v13, "photoList":Ljava/util/List;
    .local v14, "total":I
    :goto_46a
    if-ge v5, v1, :cond_a03

    .line 167
    move-object/from16 v18, v2

    iget-object v2, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v2}, Lcom/example/service/PhotoUploadService;->access$isUploading$p(Lcom/example/service/PhotoUploadService;)Z

    move-result v2

    if-eqz v2, :cond_9f0

    .line 169
    invoke-interface {v13, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/example/service/PhotoUploadService$GalleryPhoto;

    .line 170
    .local v2, "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    invoke-virtual {v2}, Lcom/example/service/PhotoUploadService$GalleryPhoto;->getName()Ljava/lang/String;

    move-result-object v19

    move-object/from16 v20, v19

    .line 171
    .restart local v20  # "displayName":Ljava/lang/String;
    invoke-virtual {v2}, Lcom/example/service/PhotoUploadService$GalleryPhoto;->getSize()J

    move-result-wide v21

    move-wide/from16 v23, v21

    .line 172
    .local v23, "size":J
    invoke-virtual {v2}, Lcom/example/service/PhotoUploadService$GalleryPhoto;->getUri()Landroid/net/Uri;

    move-result-object v19

    move-object/from16 v21, v19

    .line 175
    .local v21, "uri":Landroid/net/Uri;
    move-object/from16 v19, v2

    .end local v2  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .local v19, "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    iget-object v2, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v2}, Lcom/example/service/PhotoUploadService;->access$getRepository$p(Lcom/example/service/PhotoUploadService;)Lcom/example/data/UploadRepository;

    move-result-object v2
    :try_end_496
    .catch Ljava/lang/Exception; {:try_start_45c .. :try_end_496} :catch_9d9
    .catchall {:try_start_45c .. :try_end_496} :catchall_9d4

    if-nez v2, :cond_49c

    :try_start_498
    invoke-static {v15}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V
    :try_end_49b
    .catch Ljava/lang/Exception; {:try_start_498 .. :try_end_49b} :catch_51d
    .catchall {:try_start_498 .. :try_end_49b} :catchall_9d4

    const/4 v2, 0x0

    :cond_49c
    move-object/from16 v22, v15

    :try_start_49e
    invoke-virtual/range {v21 .. v21}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-static {v15, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object/from16 v25, v4

    move-object v4, v11

    check-cast v4, Lkotlin/coroutines/Continuation;

    iput-object v9, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$0:Ljava/lang/Object;

    iput-object v13, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$1:Ljava/lang/Object;

    move-object/from16 v26, v9

    .end local v9  # "serverUrl":Ljava/lang/String;
    .local v26, "serverUrl":Ljava/lang/String;
    invoke-static/range {v19 .. v19}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    iput-object v9, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$2:Ljava/lang/Object;

    move-object/from16 v9, v20

    .end local v20  # "displayName":Ljava/lang/String;
    .local v9, "displayName":Ljava/lang/String;
    iput-object v9, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$3:Ljava/lang/Object;

    move-object/from16 v20, v9

    move-object/from16 v9, v21

    .end local v21  # "uri":Landroid/net/Uri;
    .local v9, "uri":Landroid/net/Uri;
    .restart local v20  # "displayName":Ljava/lang/String;
    iput-object v9, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$4:Ljava/lang/Object;

    move-object/from16 v21, v9

    const/4 v9, 0x0

    .end local v9  # "uri":Landroid/net/Uri;
    .restart local v21  # "uri":Landroid/net/Uri;
    iput-object v9, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$5:Ljava/lang/Object;

    iput-object v9, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$6:Ljava/lang/Object;

    iput-object v9, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$7:Ljava/lang/Object;

    iput-object v9, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$8:Ljava/lang/Object;

    iput-boolean v10, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->Z$0:Z

    iput v14, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$0:I

    iput v12, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$1:I

    iput v5, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$2:I

    iput v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$3:I

    move/from16 v27, v10

    move-wide/from16 v9, v23

    .end local v10  # "isSimulation":Z
    .end local v23  # "size":J
    .local v9, "size":J
    .local v27, "isSimulation":Z
    iput-wide v9, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$0:J

    move/from16 v23, v1

    const/4 v1, 0x1

    iput v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->label:I

    invoke-virtual {v2, v15, v4}, Lcom/example/data/UploadRepository;->getLogByUri(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v1
    :try_end_4e4
    .catch Ljava/lang/Exception; {:try_start_49e .. :try_end_4e4} :catch_9d9
    .catchall {:try_start_49e .. :try_end_4e4} :catchall_9d4

    if-ne v1, v0, :cond_4e7

    .line 150
    return-object v0

    .line 175
    :cond_4e7
    move-object/from16 v2, p1

    move-object/from16 p1, v1

    move v15, v5

    move-wide/from16 v31, v9

    move v1, v14

    move-object/from16 v4, v21

    move/from16 v10, v23

    move-object/from16 v9, v26

    move/from16 v14, v27

    move-object/from16 v5, v20

    .line 150
    .end local v20  # "displayName":Ljava/lang/String;
    .end local v21  # "uri":Landroid/net/Uri;
    .end local v26  # "serverUrl":Ljava/lang/String;
    .end local v27  # "isSimulation":Z
    .end local p1  # "$result":Ljava/lang/Object;
    .local v1, "total":I
    .local v2, "$result":Ljava/lang/Object;
    .local v4, "uri":Landroid/net/Uri;
    .local v5, "displayName":Ljava/lang/String;
    .local v9, "serverUrl":Ljava/lang/String;
    .local v14, "isSimulation":Z
    .local v15, "index":I
    .local v31, "size":J
    :goto_4f9
    :try_start_4f9
    move-object/from16 v20, p1

    check-cast v20, Lcom/example/data/UploadLog;
    :try_end_4fd
    .catch Ljava/lang/Exception; {:try_start_4f9 .. :try_end_4fd} :catch_9e7
    .catchall {:try_start_4f9 .. :try_end_4fd} :catchall_9e0

    .line 176
    .local v20, "existingLog":Lcom/example/data/UploadLog;
    if-eqz v20, :cond_524

    move-object/from16 p1, v2

    .end local v2  # "$result":Ljava/lang/Object;
    .restart local p1  # "$result":Ljava/lang/Object;
    :try_start_501
    invoke-virtual/range {v20 .. v20}, Lcom/example/data/UploadLog;->getStatus()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2
    :try_end_509
    .catch Ljava/lang/Exception; {:try_start_501 .. :try_end_509} :catch_51d
    .catchall {:try_start_501 .. :try_end_509} :catchall_9d4

    if-eqz v2, :cond_526

    .line 177
    move/from16 v21, v14

    move v14, v1

    move v1, v10

    move/from16 v10, v21

    move-object/from16 v26, p1

    move-object/from16 v23, v3

    move-object/from16 v21, v6

    move-object/from16 v24, v7

    move-object/from16 v28, v8

    goto/16 :goto_9a8

    .line 266
    .end local v1  # "total":I
    .end local v4  # "uri":Landroid/net/Uri;
    .end local v5  # "displayName":Ljava/lang/String;
    .end local v9  # "serverUrl":Ljava/lang/String;
    .end local v12  # "skippedAll":Z
    .end local v13  # "photoList":Ljava/util/List;
    .end local v14  # "isSimulation":Z
    .end local v15  # "index":I
    .end local v19  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .end local v20  # "existingLog":Lcom/example/data/UploadLog;
    .end local v31  # "size":J
    :catch_51d
    move-exception v0

    move-object/from16 v26, p1

    move-object/from16 v24, v7

    goto/16 :goto_ad0

    .line 176
    .end local p1  # "$result":Ljava/lang/Object;
    .restart local v1  # "total":I
    .restart local v2  # "$result":Ljava/lang/Object;
    .restart local v4  # "uri":Landroid/net/Uri;
    .restart local v5  # "displayName":Ljava/lang/String;
    .restart local v9  # "serverUrl":Ljava/lang/String;
    .restart local v12  # "skippedAll":Z
    .restart local v13  # "photoList":Ljava/util/List;
    .restart local v14  # "isSimulation":Z
    .restart local v15  # "index":I
    .restart local v19  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .restart local v20  # "existingLog":Lcom/example/data/UploadLog;
    .restart local v31  # "size":J
    :cond_524
    move-object/from16 p1, v2

    .line 180
    .end local v2  # "$result":Ljava/lang/Object;
    .restart local p1  # "$result":Ljava/lang/Object;
    :cond_526
    const/4 v2, 0x0

    .line 182
    .end local v12  # "skippedAll":Z
    .local v2, "skippedAll":Z
    add-int/lit8 v12, v15, 0x1

    int-to-float v12, v12

    move-object/from16 v21, v6

    int-to-float v6, v1

    div-float v6, v12, v6

    .line 183
    .local v6, "progressFloat":F
    :try_start_52f
    sget-object v12, Lcom/example/data/UploadStateTracker;->INSTANCE:Lcom/example/data/UploadStateTracker;

    move-object/from16 v23, v3

    add-int/lit8 v3, v15, 0x1

    invoke-virtual {v12, v5, v3, v1, v6}, Lcom/example/data/UploadStateTracker;->updateProgress(Ljava/lang/String;IIF)V

    .line 184
    iget-object v3, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;
    :try_end_53a
    .catch Ljava/lang/Exception; {:try_start_52f .. :try_end_53a} :catch_9d9
    .catchall {:try_start_52f .. :try_end_53a} :catchall_9d4

    add-int/lit8 v12, v15, 0x1

    move-object/from16 v24, v7

    :try_start_53e
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    move/from16 v46, v6

    .end local v6  # "progressFloat":F
    .local v46, "progressFloat":F
    const-string v6, "ছবি পাঠানো হচ্ছে: "

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " ("

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, "/"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, ")"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    add-int/lit8 v7, v15, 0x1

    invoke-static {v3, v6, v7, v1}, Lcom/example/service/PhotoUploadService;->access$updateNotification(Lcom/example/service/PhotoUploadService;Ljava/lang/String;II)V

    .line 187
    if-nez v20, :cond_5fa

    .line 188
    iget-object v3, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v3}, Lcom/example/service/PhotoUploadService;->access$getRepository$p(Lcom/example/service/PhotoUploadService;)Lcom/example/data/UploadRepository;

    move-result-object v3

    if-nez v3, :cond_580

    invoke-static/range {v22 .. v22}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v3, 0x0

    .line 189
    :cond_580
    new-instance v26, Lcom/example/data/UploadLog;

    .line 190
    invoke-virtual {v4}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 191
    nop

    .line 192
    nop

    .line 193
    const-string v33, "UPLOADING"

    .line 189
    const/16 v37, 0x61

    const/16 v38, 0x0

    const-wide/16 v27, 0x0

    const/16 v34, 0x0

    const-wide/16 v35, 0x0

    move-object/from16 v30, v5

    move-object/from16 v29, v6

    .end local v5  # "displayName":Ljava/lang/String;
    .local v30, "displayName":Ljava/lang/String;
    invoke-direct/range {v26 .. v38}, Lcom/example/data/UploadLog;-><init>(JLjava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;JILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v12, v26

    move-wide/from16 v6, v31

    .end local v30  # "displayName":Ljava/lang/String;
    .end local v31  # "size":J
    .restart local v5  # "displayName":Ljava/lang/String;
    .local v6, "size":J
    move-object/from16 v28, v8

    move-object v8, v11

    check-cast v8, Lkotlin/coroutines/Continuation;

    .line 188
    iput-object v9, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$0:Ljava/lang/Object;

    iput-object v13, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$1:Ljava/lang/Object;

    move-object/from16 v26, v13

    .end local v13  # "photoList":Ljava/util/List;
    .local v26, "photoList":Ljava/util/List;
    invoke-static/range {v19 .. v19}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    iput-object v13, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$2:Ljava/lang/Object;

    iput-object v5, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$3:Ljava/lang/Object;

    iput-object v4, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$4:Ljava/lang/Object;

    invoke-static/range {v20 .. v20}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    iput-object v13, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$5:Ljava/lang/Object;

    iput-boolean v14, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->Z$0:Z

    iput v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$0:I

    iput v2, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$1:I

    iput v15, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$2:I

    iput v10, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$3:I

    iput-wide v6, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$0:J

    move/from16 v13, v46

    .end local v46  # "progressFloat":F
    .local v13, "progressFloat":F
    iput v13, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->F$0:F

    move/from16 v46, v13

    .end local v13  # "progressFloat":F
    .restart local v46  # "progressFloat":F
    const/4 v13, 0x2

    iput v13, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->label:I

    invoke-virtual {v3, v12, v8}, Lcom/example/data/UploadRepository;->insert(Lcom/example/data/UploadLog;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v3
    :try_end_5d6
    .catch Ljava/lang/Exception; {:try_start_53e .. :try_end_5d6} :catch_a9f
    .catchall {:try_start_53e .. :try_end_5d6} :catchall_9d4

    if-ne v3, v0, :cond_5d9

    .line 150
    return-object v0

    .line 188
    :cond_5d9
    move v13, v2

    move-object v2, v5

    move v5, v14

    move v12, v15

    move v14, v1

    move-object/from16 v1, p1

    .end local v15  # "index":I
    .end local p1  # "$result":Ljava/lang/Object;
    .local v1, "$result":Ljava/lang/Object;
    .local v2, "displayName":Ljava/lang/String;
    .local v5, "isSimulation":Z
    .local v12, "index":I
    .local v13, "skippedAll":Z
    .local v14, "total":I
    :goto_5e0
    :try_start_5e0
    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->longValue()J

    move-result-wide v29
    :try_end_5e6
    .catch Ljava/lang/Exception; {:try_start_5e0 .. :try_end_5e6} :catch_5f5
    .catchall {:try_start_5e0 .. :try_end_5e6} :catchall_5f0

    move-object v15, v11

    move/from16 v11, v46

    move-object v3, v2

    move-wide v7, v6

    move-object/from16 v6, v26

    move-object v2, v0

    goto/16 :goto_673

    .line 269
    .end local v2  # "displayName":Ljava/lang/String;
    .end local v4  # "uri":Landroid/net/Uri;
    .end local v5  # "isSimulation":Z
    .end local v6  # "size":J
    .end local v9  # "serverUrl":Ljava/lang/String;
    .end local v12  # "index":I
    .end local v13  # "skippedAll":Z
    .end local v14  # "total":I
    .end local v19  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .end local v20  # "existingLog":Lcom/example/data/UploadLog;
    .end local v26  # "photoList":Ljava/util/List;
    .end local v46  # "progressFloat":F
    :catchall_5f0
    move-exception v0

    move-object/from16 v26, v1

    goto/16 :goto_aed

    .line 266
    :catch_5f5
    move-exception v0

    move-object/from16 v26, v1

    goto/16 :goto_ad0

    .line 197
    .local v1, "total":I
    .local v2, "skippedAll":Z
    .restart local v4  # "uri":Landroid/net/Uri;
    .local v5, "displayName":Ljava/lang/String;
    .restart local v9  # "serverUrl":Ljava/lang/String;
    .local v13, "photoList":Ljava/util/List;
    .local v14, "isSimulation":Z
    .restart local v15  # "index":I
    .restart local v19  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .restart local v20  # "existingLog":Lcom/example/data/UploadLog;
    .restart local v31  # "size":J
    .restart local v46  # "progressFloat":F
    .restart local p1  # "$result":Ljava/lang/Object;
    :cond_5fa
    move-object/from16 v28, v8

    move-object/from16 v26, v13

    move-wide/from16 v6, v31

    .end local v13  # "photoList":Ljava/util/List;
    .end local v31  # "size":J
    .restart local v6  # "size":J
    .restart local v26  # "photoList":Ljava/util/List;
    :try_start_600
    iget-object v3, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v3}, Lcom/example/service/PhotoUploadService;->access$getRepository$p(Lcom/example/service/PhotoUploadService;)Lcom/example/data/UploadRepository;

    move-result-object v3

    if-nez v3, :cond_60c

    invoke-static/range {v22 .. v22}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v3, 0x0

    :cond_60c
    const-string v40, "UPLOADING"

    const/16 v44, 0x6f

    const/16 v45, 0x0

    const-wide/16 v34, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const-wide/16 v38, 0x0

    const/16 v41, 0x0

    const-wide/16 v42, 0x0

    move-object/from16 v33, v20

    .end local v20  # "existingLog":Lcom/example/data/UploadLog;
    .local v33, "existingLog":Lcom/example/data/UploadLog;
    invoke-static/range {v33 .. v45}, Lcom/example/data/UploadLog;->copy$default(Lcom/example/data/UploadLog;JLjava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;JILjava/lang/Object;)Lcom/example/data/UploadLog;

    move-result-object v8

    move-object/from16 v12, v33

    .end local v33  # "existingLog":Lcom/example/data/UploadLog;
    .local v12, "existingLog":Lcom/example/data/UploadLog;
    move-object v13, v11

    check-cast v13, Lkotlin/coroutines/Continuation;

    iput-object v9, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$0:Ljava/lang/Object;

    move-object/from16 v20, v9

    move-object/from16 v9, v26

    .end local v26  # "photoList":Ljava/util/List;
    .local v9, "photoList":Ljava/util/List;
    .local v20, "serverUrl":Ljava/lang/String;
    iput-object v9, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$1:Ljava/lang/Object;

    move-object/from16 v26, v9

    .end local v9  # "photoList":Ljava/util/List;
    .restart local v26  # "photoList":Ljava/util/List;
    invoke-static/range {v19 .. v19}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    iput-object v9, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$2:Ljava/lang/Object;

    iput-object v5, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$3:Ljava/lang/Object;

    iput-object v4, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$4:Ljava/lang/Object;

    iput-object v12, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$5:Ljava/lang/Object;

    iput-boolean v14, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->Z$0:Z

    iput v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$0:I

    iput v2, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$1:I

    iput v15, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$2:I

    iput v10, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$3:I

    iput-wide v6, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$0:J

    move/from16 v9, v46

    .end local v46  # "progressFloat":F
    .local v9, "progressFloat":F
    iput v9, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->F$0:F

    move/from16 v27, v1

    .end local v1  # "total":I
    .local v27, "total":I
    const/4 v1, 0x3

    iput v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->label:I

    invoke-virtual {v3, v8, v13}, Lcom/example/data/UploadRepository;->update(Lcom/example/data/UploadLog;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v1
    :try_end_658
    .catch Ljava/lang/Exception; {:try_start_600 .. :try_end_658} :catch_a9f
    .catchall {:try_start_600 .. :try_end_658} :catchall_9d4

    if-ne v1, v0, :cond_65b

    .line 150
    return-object v0

    .line 197
    :cond_65b
    move v13, v2

    move-object v2, v5

    move-object v5, v12

    move v12, v15

    move-object/from16 v1, p1

    .line 198
    .end local v15  # "index":I
    .end local p1  # "$result":Ljava/lang/Object;
    .local v1, "$result":Ljava/lang/Object;
    .local v2, "displayName":Ljava/lang/String;
    .local v5, "existingLog":Lcom/example/data/UploadLog;
    .local v12, "index":I
    .local v13, "skippedAll":Z
    :goto_661
    :try_start_661
    invoke-virtual {v5}, Lcom/example/data/UploadLog;->getId()J

    move-result-wide v29
    :try_end_665
    .catch Ljava/lang/Exception; {:try_start_661 .. :try_end_665} :catch_5f5
    .catchall {:try_start_661 .. :try_end_665} :catchall_5f0

    move-object v15, v11

    move v11, v9

    move-object/from16 v9, v20

    move-object/from16 v20, v5

    move v5, v14

    move/from16 v14, v27

    move-object v3, v2

    move-wide v7, v6

    move-object/from16 v6, v26

    move-object v2, v0

    .line 187
    .end local v2  # "displayName":Ljava/lang/String;
    .end local v26  # "photoList":Ljava/util/List;
    .end local v27  # "total":I
    .local v3, "displayName":Ljava/lang/String;
    .local v5, "isSimulation":Z
    .local v6, "photoList":Ljava/util/List;
    .local v7, "size":J
    .local v9, "serverUrl":Ljava/lang/String;
    .local v11, "progressFloat":F
    .local v14, "total":I
    .local v15, "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    .local v20, "existingLog":Lcom/example/data/UploadLog;
    :goto_673
    move-wide/from16 v26, v29

    .line 202
    .local v26, "logId":J
    move-object/from16 p1, v1

    .end local v1  # "$result":Ljava/lang/Object;
    .restart local p1  # "$result":Ljava/lang/Object;
    const/4 v1, 0x0

    .line 203
    .local v1, "uploadSuccess":Z
    const/16 v29, 0x0

    .line 205
    .local v29, "errorMessage":Ljava/lang/String;
    if-eqz v5, :cond_6ee

    .line 206
    const-wide/32 v30, 0x500000

    cmp-long v0, v7, v30

    if-lez v0, :cond_686

    const-wide/16 v30, 0x7d0

    goto :goto_688

    :cond_686
    const-wide/16 v30, 0x3e8

    :goto_688
    move-wide/from16 v32, v30

    .line 207
    .local v32, "simulateTime":J
    :try_start_68a
    move-object v0, v15

    check-cast v0, Lkotlin/coroutines/Continuation;

    iput-object v9, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$0:Ljava/lang/Object;

    iput-object v6, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$1:Ljava/lang/Object;

    move-object/from16 v30, v6

    .end local v6  # "photoList":Ljava/util/List;
    .local v30, "photoList":Ljava/util/List;
    invoke-static/range {v19 .. v19}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    iput-object v6, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$2:Ljava/lang/Object;

    iput-object v3, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$3:Ljava/lang/Object;

    iput-object v4, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$4:Ljava/lang/Object;

    invoke-static/range {v20 .. v20}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    iput-object v6, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$5:Ljava/lang/Object;

    iput-boolean v5, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->Z$0:Z

    iput v14, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$0:I

    iput v13, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$1:I

    iput v12, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$2:I

    iput v10, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$3:I

    iput-wide v7, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$0:J

    iput v11, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->F$0:F

    move/from16 v31, v5

    move-wide/from16 v5, v26

    .end local v26  # "logId":J
    .local v5, "logId":J
    .local v31, "isSimulation":Z
    iput-wide v5, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$1:J

    iput v1, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$4:I

    move-wide/from16 v26, v5

    move-wide/from16 v5, v32

    .end local v32  # "simulateTime":J
    .local v5, "simulateTime":J
    .restart local v26  # "logId":J
    iput-wide v5, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$2:J

    move/from16 v32, v1

    .end local v1  # "uploadSuccess":Z
    .local v32, "uploadSuccess":Z
    const/4 v1, 0x4

    iput v1, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->label:I

    invoke-static {v5, v6, v0}, Lkotlinx/coroutines/DelayKt;->delay(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0
    :try_end_6c8
    .catch Ljava/lang/Exception; {:try_start_68a .. :try_end_6c8} :catch_9c6
    .catchall {:try_start_68a .. :try_end_6c8} :catchall_725

    if-ne v0, v2, :cond_6cb

    .line 150
    return-object v2

    .line 207
    :cond_6cb
    move-wide v0, v5

    move/from16 v5, v32

    move-wide/from16 v32, v26

    move-wide/from16 v26, v0

    move-object/from16 v1, v29

    move-object/from16 v29, v19

    move-object/from16 v0, p1

    .line 208
    .end local v19  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .end local p1  # "$result":Ljava/lang/Object;
    .local v0, "$result":Ljava/lang/Object;
    .local v1, "errorMessage":Ljava/lang/String;
    .local v5, "uploadSuccess":Z
    .local v26, "simulateTime":J
    .local v29, "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .local v32, "logId":J
    :goto_6d8
    const/4 v5, 0x1

    move-object/from16 p1, v0

    move-object v6, v1

    move-object v0, v2

    move v2, v13

    move v1, v14

    move-object/from16 v19, v29

    move-wide/from16 v47, v32

    move v13, v11

    move v14, v12

    move-object v11, v9

    move v12, v10

    move-wide v9, v7

    move-object/from16 v8, v30

    move/from16 v7, v31

    .end local v26  # "simulateTime":J
    goto/16 :goto_76d

    .line 210
    .end local v0  # "$result":Ljava/lang/Object;
    .end local v30  # "photoList":Ljava/util/List;
    .end local v31  # "isSimulation":Z
    .end local v32  # "logId":J
    .local v1, "uploadSuccess":Z
    .local v5, "isSimulation":Z
    .restart local v6  # "photoList":Ljava/util/List;
    .restart local v19  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .local v26, "logId":J
    .local v29, "errorMessage":Ljava/lang/String;
    .restart local p1  # "$result":Ljava/lang/Object;
    :cond_6ee
    move/from16 v32, v1

    move/from16 v31, v5

    move-object/from16 v30, v6

    .line 211
    .end local v1  # "uploadSuccess":Z
    .end local v5  # "isSimulation":Z
    .end local v6  # "photoList":Ljava/util/List;
    .restart local v30  # "photoList":Ljava/util/List;
    .restart local v31  # "isSimulation":Z
    .local v32, "uploadSuccess":Z
    :try_start_6f4
    iget-object v0, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v0, v4, v3, v9}, Lcom/example/service/PhotoUploadService;->access$performRealUpload(Lcom/example/service/PhotoUploadService;Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0
    :try_end_6fa
    .catch Ljava/lang/Exception; {:try_start_6f4 .. :try_end_6fa} :catch_72b
    .catchall {:try_start_6f4 .. :try_end_6fa} :catchall_725

    move v1, v0

    .line 212
    .end local v32  # "uploadSuccess":Z
    .restart local v1  # "uploadSuccess":Z
    if-nez v1, :cond_713

    .line 213
    :try_start_6fd
    const-string v0, "সার্ভার রেসপন্স বা কানেকশন ত্রুটি"
    :try_end_6ff
    .catch Ljava/lang/Exception; {:try_start_6fd .. :try_end_6ff} :catch_711
    .catchall {:try_start_6fd .. :try_end_6ff} :catchall_725

    .end local v29  # "errorMessage":Ljava/lang/String;
    .local v0, "errorMessage":Ljava/lang/String;
    move-object v6, v0

    move v5, v1

    move-object v0, v2

    move v2, v13

    move v1, v14

    move-wide/from16 v47, v26

    move v13, v11

    move v14, v12

    move-object v11, v9

    move v12, v10

    move-wide v9, v7

    move-object/from16 v8, v30

    move/from16 v7, v31

    goto/16 :goto_76d

    .line 215
    .end local v0  # "errorMessage":Ljava/lang/String;
    .restart local v29  # "errorMessage":Ljava/lang/String;
    :catch_711
    move-exception v0

    goto :goto_72e

    .line 212
    :cond_713
    move v5, v1

    move-object v0, v2

    move v2, v13

    move v1, v14

    move-wide/from16 v47, v26

    move-object/from16 v6, v29

    move v13, v11

    move v14, v12

    move-object v11, v9

    move v12, v10

    move-wide v9, v7

    move-object/from16 v8, v30

    move/from16 v7, v31

    goto :goto_76d

    .line 269
    .end local v1  # "uploadSuccess":Z
    .end local v3  # "displayName":Ljava/lang/String;
    .end local v4  # "uri":Landroid/net/Uri;
    .end local v7  # "size":J
    .end local v9  # "serverUrl":Ljava/lang/String;
    .end local v11  # "progressFloat":F
    .end local v12  # "index":I
    .end local v13  # "skippedAll":Z
    .end local v14  # "total":I
    .end local v19  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .end local v20  # "existingLog":Lcom/example/data/UploadLog;
    .end local v26  # "logId":J
    .end local v29  # "errorMessage":Ljava/lang/String;
    .end local v30  # "photoList":Ljava/util/List;
    .end local v31  # "isSimulation":Z
    :catchall_725
    move-exception v0

    move-object/from16 v26, p1

    move-object v11, v15

    goto/16 :goto_aed

    .line 215
    .restart local v3  # "displayName":Ljava/lang/String;
    .restart local v4  # "uri":Landroid/net/Uri;
    .restart local v7  # "size":J
    .restart local v9  # "serverUrl":Ljava/lang/String;
    .restart local v11  # "progressFloat":F
    .restart local v12  # "index":I
    .restart local v13  # "skippedAll":Z
    .restart local v14  # "total":I
    .restart local v19  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .restart local v20  # "existingLog":Lcom/example/data/UploadLog;
    .restart local v26  # "logId":J
    .restart local v29  # "errorMessage":Ljava/lang/String;
    .restart local v30  # "photoList":Ljava/util/List;
    .restart local v31  # "isSimulation":Z
    .restart local v32  # "uploadSuccess":Z
    :catch_72b
    move-exception v0

    move/from16 v1, v32

    .line 216
    .end local v32  # "uploadSuccess":Z
    .local v0, "e":Ljava/lang/Exception;
    .restart local v1  # "uploadSuccess":Z
    :goto_72e
    :try_start_72e
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Network upload failed for "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    move-object v6, v0

    check-cast v6, Ljava/lang/Throwable;
    :try_end_744
    .catch Ljava/lang/Exception; {:try_start_72e .. :try_end_744} :catch_9c6
    .catchall {:try_start_72e .. :try_end_744} :catchall_725

    move/from16 v32, v1

    move-object/from16 v1, v24

    .end local v1  # "uploadSuccess":Z
    .restart local v32  # "uploadSuccess":Z
    :try_start_748
    invoke-static {v1, v5, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 217
    const/4 v5, 0x0

    .line 218
    .end local v32  # "uploadSuccess":Z
    .local v5, "uploadSuccess":Z
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v6
    :try_end_750
    .catch Ljava/lang/Exception; {:try_start_748 .. :try_end_750} :catch_9cc
    .catchall {:try_start_748 .. :try_end_750} :catchall_725

    if-nez v6, :cond_75d

    :try_start_752
    const-string v6, "অজানা নেটওয়ার্ক ত্রুটি"
    :try_end_754
    .catch Ljava/lang/Exception; {:try_start_752 .. :try_end_754} :catch_755
    .catchall {:try_start_752 .. :try_end_754} :catchall_725

    goto :goto_75d

    .line 266
    .end local v0  # "e":Ljava/lang/Exception;
    .end local v3  # "displayName":Ljava/lang/String;
    .end local v4  # "uri":Landroid/net/Uri;
    .end local v5  # "uploadSuccess":Z
    .end local v7  # "size":J
    .end local v9  # "serverUrl":Ljava/lang/String;
    .end local v11  # "progressFloat":F
    .end local v12  # "index":I
    .end local v13  # "skippedAll":Z
    .end local v14  # "total":I
    .end local v19  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .end local v20  # "existingLog":Lcom/example/data/UploadLog;
    .end local v26  # "logId":J
    .end local v29  # "errorMessage":Ljava/lang/String;
    .end local v30  # "photoList":Ljava/util/List;
    .end local v31  # "isSimulation":Z
    :catch_755
    move-exception v0

    move-object/from16 v26, p1

    move-object/from16 v24, v1

    move-object v11, v15

    goto/16 :goto_ad0

    .line 218
    .restart local v0  # "e":Ljava/lang/Exception;
    .restart local v3  # "displayName":Ljava/lang/String;
    .restart local v4  # "uri":Landroid/net/Uri;
    .restart local v5  # "uploadSuccess":Z
    .restart local v7  # "size":J
    .restart local v9  # "serverUrl":Ljava/lang/String;
    .restart local v11  # "progressFloat":F
    .restart local v12  # "index":I
    .restart local v13  # "skippedAll":Z
    .restart local v14  # "total":I
    .restart local v19  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .restart local v20  # "existingLog":Lcom/example/data/UploadLog;
    .restart local v26  # "logId":J
    .restart local v29  # "errorMessage":Ljava/lang/String;
    .restart local v30  # "photoList":Ljava/util/List;
    .restart local v31  # "isSimulation":Z
    :cond_75d
    :goto_75d
    move-object/from16 v24, v1

    move-object v0, v2

    move v2, v13

    move v1, v14

    move-wide/from16 v47, v26

    move v13, v11

    move v14, v12

    move-object v11, v9

    move v12, v10

    move-wide v9, v7

    move-object/from16 v8, v30

    move/from16 v7, v31

    .line 223
    .end local v0  # "e":Ljava/lang/Exception;
    .end local v12  # "index":I
    .end local v26  # "logId":J
    .end local v29  # "errorMessage":Ljava/lang/String;
    .end local v30  # "photoList":Ljava/util/List;
    .end local v31  # "isSimulation":Z
    .local v1, "total":I
    .local v2, "skippedAll":Z
    .local v6, "errorMessage":Ljava/lang/String;
    .local v7, "isSimulation":Z
    .local v8, "photoList":Ljava/util/List;
    .local v9, "size":J
    .local v11, "serverUrl":Ljava/lang/String;
    .local v13, "progressFloat":F
    .local v14, "index":I
    .local v47, "logId":J
    :goto_76d
    if-eqz v5, :cond_772

    move-object/from16 v26, v21

    goto :goto_774

    :cond_772
    :try_start_772
    const-string v26, "FAILED"

    :goto_774
    move-object/from16 v27, v26

    .line 224
    .local v27, "finalStatus":Ljava/lang/String;
    move/from16 v26, v5

    .end local v5  # "uploadSuccess":Z
    .local v26, "uploadSuccess":Z
    iget-object v5, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v5}, Lcom/example/service/PhotoUploadService;->access$getRepository$p(Lcom/example/service/PhotoUploadService;)Lcom/example/data/UploadRepository;

    move-result-object v5

    if-nez v5, :cond_784

    invoke-static/range {v22 .. v22}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v5, 0x0

    :cond_784
    move-object/from16 v29, v5

    invoke-virtual {v4}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v5

    move/from16 v30, v13

    move-object/from16 v13, v28

    .end local v13  # "progressFloat":F
    .local v30, "progressFloat":F
    invoke-static {v5, v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object/from16 v28, v13

    move-object v13, v15

    check-cast v13, Lkotlin/coroutines/Continuation;

    iput-object v11, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$0:Ljava/lang/Object;

    iput-object v8, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$1:Ljava/lang/Object;

    move-object/from16 v31, v8

    .end local v8  # "photoList":Ljava/util/List;
    .local v31, "photoList":Ljava/util/List;
    invoke-static/range {v19 .. v19}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    iput-object v8, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$2:Ljava/lang/Object;

    iput-object v3, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$3:Ljava/lang/Object;

    iput-object v4, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$4:Ljava/lang/Object;

    invoke-static/range {v20 .. v20}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    iput-object v8, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$5:Ljava/lang/Object;

    iput-object v6, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$6:Ljava/lang/Object;

    move-object/from16 v8, v27

    .end local v27  # "finalStatus":Ljava/lang/String;
    .local v8, "finalStatus":Ljava/lang/String;
    iput-object v8, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$7:Ljava/lang/Object;

    iput-boolean v7, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->Z$0:Z

    iput v1, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$0:I

    iput v2, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$1:I

    iput v14, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$2:I

    iput v12, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$3:I

    iput-wide v9, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$0:J

    move/from16 v27, v1

    move/from16 v1, v30

    .end local v30  # "progressFloat":F
    .local v1, "progressFloat":F
    .local v27, "total":I
    iput v1, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->F$0:F

    move/from16 v32, v1

    move/from16 v30, v2

    move-wide/from16 v1, v47

    .end local v2  # "skippedAll":Z
    .end local v47  # "logId":J
    .local v1, "logId":J
    .local v30, "skippedAll":Z
    .local v32, "progressFloat":F
    iput-wide v1, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$1:J

    move-wide/from16 v33, v1

    move/from16 v1, v26

    .end local v26  # "uploadSuccess":Z
    .local v1, "uploadSuccess":Z
    .local v33, "logId":J
    iput v1, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$4:I

    const/4 v2, 0x5

    iput v2, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->label:I

    move-object/from16 v2, v29

    invoke-virtual {v2, v5, v13}, Lcom/example/data/UploadRepository;->getLogByUri(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v2
    :try_end_7db
    .catch Ljava/lang/Exception; {:try_start_772 .. :try_end_7db} :catch_9c6
    .catchall {:try_start_772 .. :try_end_7db} :catchall_725

    if-ne v2, v0, :cond_7de

    .line 150
    return-object v0

    .line 224
    :cond_7de
    move-object/from16 v26, p1

    move-object/from16 p1, v2

    move-object v5, v4

    move-object/from16 v37, v6

    move-object/from16 v36, v8

    move/from16 v6, v27

    move/from16 v8, v30

    move-object/from16 v4, v31

    move-object/from16 v27, v3

    move v3, v12

    move-wide/from16 v12, v33

    move-wide/from16 v49, v9

    move v9, v1

    move-wide/from16 v1, v49

    move/from16 v10, v32

    .line 150
    .end local v3  # "displayName":Ljava/lang/String;
    .end local v30  # "skippedAll":Z
    .end local v31  # "photoList":Ljava/util/List;
    .end local v32  # "progressFloat":F
    .end local v33  # "logId":J
    .end local p1  # "$result":Ljava/lang/Object;
    .local v1, "size":J
    .local v4, "photoList":Ljava/util/List;
    .local v5, "uri":Landroid/net/Uri;
    .local v6, "total":I
    .local v8, "skippedAll":Z
    .local v9, "uploadSuccess":Z
    .local v10, "progressFloat":F
    .local v12, "logId":J
    .local v26, "$result":Ljava/lang/Object;
    .local v27, "displayName":Ljava/lang/String;
    .local v36, "finalStatus":Ljava/lang/String;
    .local v37, "errorMessage":Ljava/lang/String;
    :goto_7f9
    :try_start_7f9
    move-object/from16 v29, p1

    check-cast v29, Lcom/example/data/UploadLog;

    .line 225
    .local v29, "currentLog":Lcom/example/data/UploadLog;
    if-eqz v29, :cond_8a0

    .line 226
    move-object/from16 p1, v5

    .end local v5  # "uri":Landroid/net/Uri;
    .local p1, "uri":Landroid/net/Uri;
    iget-object v5, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v5}, Lcom/example/service/PhotoUploadService;->access$getRepository$p(Lcom/example/service/PhotoUploadService;)Lcom/example/data/UploadRepository;

    move-result-object v5

    if-nez v5, :cond_80d

    invoke-static/range {v22 .. v22}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v5, 0x0

    .line 227
    :cond_80d
    nop

    .line 228
    nop

    .line 229
    nop

    .line 230
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v38

    .line 227
    const/16 v40, 0xf

    const/16 v41, 0x0

    const-wide/16 v30, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const-wide/16 v34, 0x0

    move-object/from16 v42, v5

    invoke-static/range {v29 .. v41}, Lcom/example/data/UploadLog;->copy$default(Lcom/example/data/UploadLog;JLjava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;JILjava/lang/Object;)Lcom/example/data/UploadLog;

    move-result-object v5

    move-object/from16 v43, v29

    .end local v29  # "currentLog":Lcom/example/data/UploadLog;
    .local v43, "currentLog":Lcom/example/data/UploadLog;
    move-object/from16 v29, v5

    move-object v5, v15

    check-cast v5, Lkotlin/coroutines/Continuation;

    .line 226
    iput-object v11, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$0:Ljava/lang/Object;

    iput-object v4, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$1:Ljava/lang/Object;

    move-object/from16 v44, v4

    .end local v4  # "photoList":Ljava/util/List;
    .local v44, "photoList":Ljava/util/List;
    invoke-static/range {v19 .. v19}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    iput-object v4, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$2:Ljava/lang/Object;

    invoke-static/range {v27 .. v27}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    iput-object v4, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$3:Ljava/lang/Object;

    invoke-static/range {p1 .. p1}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    iput-object v4, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$4:Ljava/lang/Object;

    invoke-static/range {v20 .. v20}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    iput-object v4, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$5:Ljava/lang/Object;

    invoke-static/range {v37 .. v37}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    iput-object v4, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$6:Ljava/lang/Object;

    invoke-static/range {v36 .. v36}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    iput-object v4, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$7:Ljava/lang/Object;

    invoke-static/range {v43 .. v43}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    iput-object v4, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$8:Ljava/lang/Object;

    iput-boolean v7, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->Z$0:Z

    iput v6, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$0:I

    iput v8, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$1:I

    iput v14, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$2:I

    iput v3, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$3:I

    iput-wide v1, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$0:J

    iput v10, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->F$0:F

    iput-wide v12, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$1:J

    iput v9, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$4:I

    const/4 v4, 0x6

    iput v4, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->label:I

    move-wide/from16 v34, v1

    move-object/from16 v4, v29

    move-object/from16 v1, v42

    .end local v1  # "size":J
    .local v34, "size":J
    invoke-virtual {v1, v4, v5}, Lcom/example/data/UploadRepository;->update(Lcom/example/data/UploadLog;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v1
    :try_end_87c
    .catch Ljava/lang/Exception; {:try_start_7f9 .. :try_end_87c} :catch_9c2
    .catchall {:try_start_7f9 .. :try_end_87c} :catchall_9be

    if-ne v1, v0, :cond_87f

    .line 150
    return-object v0

    .line 226
    :cond_87f
    move-object/from16 v1, p1

    move-object v5, v11

    move-object v11, v15

    move-object/from16 v29, v19

    move-object/from16 v2, v20

    move-object/from16 v30, v44

    move v15, v3

    move/from16 v20, v8

    .end local v8  # "skippedAll":Z
    .end local v15  # "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    .end local v19  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .end local v44  # "photoList":Ljava/util/List;
    .end local p1  # "uri":Landroid/net/Uri;
    .local v1, "uri":Landroid/net/Uri;
    .local v2, "existingLog":Lcom/example/data/UploadLog;
    .local v5, "serverUrl":Ljava/lang/String;
    .local v11, "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    .local v20, "skippedAll":Z
    .local v29, "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .local v30, "photoList":Ljava/util/List;
    :goto_88c
    :try_start_88c
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_88e
    .catch Ljava/lang/Exception; {:try_start_88c .. :try_end_88e} :catch_89d
    .catchall {:try_start_88c .. :try_end_88e} :catchall_89a

    move/from16 v8, v20

    move-object/from16 v33, v27

    move-wide/from16 v3, v34

    move-object/from16 v27, v1

    move-object/from16 v1, v30

    goto/16 :goto_93d

    .line 269
    .end local v1  # "uri":Landroid/net/Uri;
    .end local v2  # "existingLog":Lcom/example/data/UploadLog;
    .end local v5  # "serverUrl":Ljava/lang/String;
    .end local v6  # "total":I
    .end local v7  # "isSimulation":Z
    .end local v9  # "uploadSuccess":Z
    .end local v10  # "progressFloat":F
    .end local v12  # "logId":J
    .end local v14  # "index":I
    .end local v20  # "skippedAll":Z
    .end local v27  # "displayName":Ljava/lang/String;
    .end local v29  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .end local v30  # "photoList":Ljava/util/List;
    .end local v34  # "size":J
    .end local v36  # "finalStatus":Ljava/lang/String;
    .end local v37  # "errorMessage":Ljava/lang/String;
    .end local v43  # "currentLog":Lcom/example/data/UploadLog;
    :catchall_89a
    move-exception v0

    goto/16 :goto_aed

    .line 266
    :catch_89d
    move-exception v0

    goto/16 :goto_ad0

    .line 234
    .local v1, "size":J
    .restart local v4  # "photoList":Ljava/util/List;
    .local v5, "uri":Landroid/net/Uri;
    .restart local v6  # "total":I
    .restart local v7  # "isSimulation":Z
    .restart local v8  # "skippedAll":Z
    .restart local v9  # "uploadSuccess":Z
    .restart local v10  # "progressFloat":F
    .local v11, "serverUrl":Ljava/lang/String;
    .restart local v12  # "logId":J
    .restart local v14  # "index":I
    .restart local v15  # "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    .restart local v19  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .local v20, "existingLog":Lcom/example/data/UploadLog;
    .restart local v27  # "displayName":Ljava/lang/String;
    .local v29, "currentLog":Lcom/example/data/UploadLog;
    .restart local v36  # "finalStatus":Ljava/lang/String;
    .restart local v37  # "errorMessage":Ljava/lang/String;
    :cond_8a0
    move-wide/from16 v34, v1

    move-object/from16 v44, v4

    move-object/from16 p1, v5

    move-object/from16 v43, v29

    .end local v1  # "size":J
    .end local v4  # "photoList":Ljava/util/List;
    .end local v5  # "uri":Landroid/net/Uri;
    .end local v29  # "currentLog":Lcom/example/data/UploadLog;
    .restart local v34  # "size":J
    .restart local v43  # "currentLog":Lcom/example/data/UploadLog;
    .restart local v44  # "photoList":Ljava/util/List;
    .restart local p1  # "uri":Landroid/net/Uri;
    :try_start_8a8
    iget-object v1, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v1}, Lcom/example/service/PhotoUploadService;->access$getRepository$p(Lcom/example/service/PhotoUploadService;)Lcom/example/data/UploadRepository;

    move-result-object v1

    if-nez v1, :cond_8b4

    invoke-static/range {v22 .. v22}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v1, 0x0

    .line 235
    :cond_8b4
    new-instance v29, Lcom/example/data/UploadLog;

    .line 236
    nop

    .line 237
    invoke-virtual/range {p1 .. p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v2

    move-object/from16 v4, v28

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 238
    nop

    .line 239
    nop

    .line 240
    nop

    .line 241
    nop

    .line 235
    const/16 v40, 0x40

    const/16 v41, 0x0

    const-wide/16 v38, 0x0

    move-object/from16 v32, v2

    move-wide/from16 v30, v12

    move-object/from16 v33, v27

    .end local v12  # "logId":J
    .end local v27  # "displayName":Ljava/lang/String;
    .local v30, "logId":J
    .local v33, "displayName":Ljava/lang/String;
    invoke-direct/range {v29 .. v41}, Lcom/example/data/UploadLog;-><init>(JLjava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;JILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v28, v4

    move-object/from16 v2, v29

    move-wide/from16 v4, v34

    .end local v30  # "logId":J
    .end local v34  # "size":J
    .local v4, "size":J
    .restart local v12  # "logId":J
    move-object/from16 v27, v1

    move-object v1, v15

    check-cast v1, Lkotlin/coroutines/Continuation;

    .line 234
    iput-object v11, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$0:Ljava/lang/Object;

    move-object/from16 v29, v11

    move-object/from16 v11, v44

    .end local v44  # "photoList":Ljava/util/List;
    .local v11, "photoList":Ljava/util/List;
    .local v29, "serverUrl":Ljava/lang/String;
    iput-object v11, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$1:Ljava/lang/Object;

    move-object/from16 v44, v11

    .end local v11  # "photoList":Ljava/util/List;
    .restart local v44  # "photoList":Ljava/util/List;
    invoke-static/range {v19 .. v19}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    iput-object v11, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$2:Ljava/lang/Object;

    invoke-static/range {v33 .. v33}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    iput-object v11, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$3:Ljava/lang/Object;

    invoke-static/range {p1 .. p1}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    iput-object v11, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$4:Ljava/lang/Object;

    invoke-static/range {v20 .. v20}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    iput-object v11, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$5:Ljava/lang/Object;

    invoke-static/range {v37 .. v37}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    iput-object v11, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$6:Ljava/lang/Object;

    invoke-static/range {v36 .. v36}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    iput-object v11, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$7:Ljava/lang/Object;

    invoke-static/range {v43 .. v43}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    iput-object v11, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$8:Ljava/lang/Object;

    iput-boolean v7, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->Z$0:Z

    iput v6, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$0:I

    iput v8, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$1:I

    iput v14, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$2:I

    iput v3, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$3:I

    iput-wide v4, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$0:J

    iput v10, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->F$0:F

    iput-wide v12, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$1:J

    iput v9, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$4:I

    const/4 v11, 0x7

    iput v11, v15, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->label:I

    move-object/from16 v11, v27

    invoke-virtual {v11, v2, v1}, Lcom/example/data/UploadRepository;->insert(Lcom/example/data/UploadLog;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v1
    :try_end_92d
    .catch Ljava/lang/Exception; {:try_start_8a8 .. :try_end_92d} :catch_9c2
    .catchall {:try_start_8a8 .. :try_end_92d} :catchall_9be

    if-ne v1, v0, :cond_930

    .line 150
    return-object v0

    .line 234
    :cond_930
    move-object/from16 v27, p1

    move-object v11, v15

    move-object/from16 v2, v20

    move-object/from16 v1, v44

    move v15, v3

    move-wide v3, v4

    move-object/from16 v5, v29

    move-object/from16 v29, v19

    .line 247
    .end local v4  # "size":J
    .end local v15  # "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    .end local v19  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .end local v20  # "existingLog":Lcom/example/data/UploadLog;
    .end local v44  # "photoList":Ljava/util/List;
    .end local p1  # "uri":Landroid/net/Uri;
    .local v1, "photoList":Ljava/util/List;
    .restart local v2  # "existingLog":Lcom/example/data/UploadLog;
    .local v3, "size":J
    .local v5, "serverUrl":Ljava/lang/String;
    .local v11, "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    .local v27, "uri":Landroid/net/Uri;
    .local v29, "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    :goto_93d
    move-object/from16 p1, v2

    .end local v2  # "existingLog":Lcom/example/data/UploadLog;
    .local p1, "existingLog":Lcom/example/data/UploadLog;
    :try_start_93f
    move-object v2, v11

    check-cast v2, Lkotlin/coroutines/Continuation;

    iput-object v5, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$0:Ljava/lang/Object;

    iput-object v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$1:Ljava/lang/Object;

    move-object/from16 v19, v1

    .end local v1  # "photoList":Ljava/util/List;
    .local v19, "photoList":Ljava/util/List;
    invoke-static/range {v29 .. v29}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    iput-object v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$2:Ljava/lang/Object;

    invoke-static/range {v33 .. v33}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    iput-object v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$3:Ljava/lang/Object;

    invoke-static/range {v27 .. v27}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    iput-object v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$4:Ljava/lang/Object;

    invoke-static/range {p1 .. p1}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    iput-object v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$5:Ljava/lang/Object;

    invoke-static/range {v37 .. v37}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    iput-object v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$6:Ljava/lang/Object;

    invoke-static/range {v36 .. v36}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    iput-object v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$7:Ljava/lang/Object;

    invoke-static/range {v43 .. v43}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    iput-object v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$8:Ljava/lang/Object;

    iput-boolean v7, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->Z$0:Z

    iput v6, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$0:I

    iput v8, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$1:I

    iput v14, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$2:I

    iput v15, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$3:I

    iput-wide v3, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$0:J

    iput v10, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->F$0:F

    iput-wide v12, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->J$1:J

    iput v9, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$4:I

    const/16 v1, 0x8

    iput v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->label:I

    move-wide/from16 v30, v3

    .end local v3  # "size":J
    .local v30, "size":J
    const-wide/16 v3, 0x32

    invoke-static {v3, v4, v2}, Lkotlinx/coroutines/DelayKt;->delay(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v1
    :try_end_990
    .catch Ljava/lang/Exception; {:try_start_93f .. :try_end_990} :catch_89d
    .catchall {:try_start_93f .. :try_end_990} :catchall_89a

    if-ne v1, v0, :cond_993

    .line 150
    return-object v0

    .line 247
    :cond_993
    move-object v1, v5

    move/from16 v20, v8

    move-object v2, v11

    move-wide v3, v12

    move-wide/from16 v11, v30

    move-object/from16 v5, p1

    move-object/from16 v30, v19

    .line 166
    .end local v8  # "skippedAll":Z
    .end local v12  # "logId":J
    .end local v19  # "photoList":Ljava/util/List;
    .end local p1  # "existingLog":Lcom/example/data/UploadLog;
    .local v1, "serverUrl":Ljava/lang/String;
    .local v2, "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    .local v3, "logId":J
    .local v5, "existingLog":Lcom/example/data/UploadLog;
    .local v11, "size":J
    .local v20, "skippedAll":Z
    .local v30, "photoList":Ljava/util/List;
    :goto_99e
    move-object v9, v1

    move-object v11, v2

    move v10, v7

    move v1, v15

    move/from16 v12, v20

    move-object/from16 v13, v30

    move v15, v14

    move v14, v6

    .end local v1  # "serverUrl":Ljava/lang/String;
    .end local v2  # "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    .end local v3  # "logId":J
    .end local v5  # "existingLog":Lcom/example/data/UploadLog;
    .end local v6  # "total":I
    .end local v7  # "isSimulation":Z
    .end local v20  # "skippedAll":Z
    .end local v27  # "uri":Landroid/net/Uri;
    .end local v29  # "photo":Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .end local v30  # "photoList":Ljava/util/List;
    .end local v33  # "displayName":Ljava/lang/String;
    .end local v36  # "finalStatus":Ljava/lang/String;
    .end local v37  # "errorMessage":Ljava/lang/String;
    .end local v43  # "currentLog":Lcom/example/data/UploadLog;
    .local v9, "serverUrl":Ljava/lang/String;
    .local v10, "isSimulation":Z
    .local v11, "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    .local v12, "skippedAll":Z
    .local v13, "photoList":Ljava/util/List;
    .local v14, "total":I
    .local v15, "index":I
    :goto_9a8
    const/16 v16, 0x1

    add-int/lit8 v5, v15, 0x1

    move-object/from16 v2, v18

    move-object/from16 v6, v21

    move-object/from16 v15, v22

    move-object/from16 v3, v23

    move-object/from16 v7, v24

    move-object/from16 v4, v25

    move-object/from16 p1, v26

    move-object/from16 v8, v28

    .end local v15  # "index":I
    .local v5, "index":I
    goto/16 :goto_46a

    .line 269
    .end local v5  # "index":I
    .end local v9  # "serverUrl":Ljava/lang/String;
    .end local v10  # "isSimulation":Z
    .end local v11  # "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    .end local v12  # "skippedAll":Z
    .end local v13  # "photoList":Ljava/util/List;
    .end local v14  # "total":I
    .local v15, "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    :catchall_9be
    move-exception v0

    move-object v11, v15

    goto/16 :goto_aed

    .line 266
    :catch_9c2
    move-exception v0

    move-object v11, v15

    goto/16 :goto_ad0

    .end local v26  # "$result":Ljava/lang/Object;
    .local p1, "$result":Ljava/lang/Object;
    :catch_9c6
    move-exception v0

    move-object/from16 v26, p1

    move-object v11, v15

    goto/16 :goto_ad0

    :catch_9cc
    move-exception v0

    move-object/from16 v24, v1

    move-object/from16 v26, p1

    move-object v11, v15

    goto/16 :goto_ad0

    .line 269
    .end local v15  # "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    .restart local v11  # "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    :catchall_9d4
    move-exception v0

    move-object/from16 v26, p1

    goto/16 :goto_aed

    .line 266
    :catch_9d9
    move-exception v0

    move-object/from16 v24, v7

    move-object/from16 v26, p1

    goto/16 :goto_ad0

    .line 269
    .end local p1  # "$result":Ljava/lang/Object;
    .local v2, "$result":Ljava/lang/Object;
    :catchall_9e0
    move-exception v0

    move-object/from16 p1, v2

    move-object/from16 v26, p1

    .end local v2  # "$result":Ljava/lang/Object;
    .restart local p1  # "$result":Ljava/lang/Object;
    goto/16 :goto_aed

    .line 266
    .end local p1  # "$result":Ljava/lang/Object;
    .restart local v2  # "$result":Ljava/lang/Object;
    :catch_9e7
    move-exception v0

    move-object/from16 p1, v2

    move-object/from16 v24, v7

    move-object/from16 v26, p1

    .end local v2  # "$result":Ljava/lang/Object;
    .restart local p1  # "$result":Ljava/lang/Object;
    goto/16 :goto_ad0

    .line 167
    .restart local v5  # "index":I
    .restart local v9  # "serverUrl":Ljava/lang/String;
    .restart local v10  # "isSimulation":Z
    .restart local v12  # "skippedAll":Z
    .restart local v13  # "photoList":Ljava/util/List;
    .restart local v14  # "total":I
    :cond_9f0
    move-object/from16 v23, v3

    move-object/from16 v25, v4

    move-object/from16 v21, v6

    move-object/from16 v24, v7

    move-object/from16 v28, v8

    move-object/from16 v26, v9

    move/from16 v27, v10

    move-object/from16 v22, v15

    const/16 v16, 0x1

    .end local v9  # "serverUrl":Ljava/lang/String;
    .end local v10  # "isSimulation":Z
    .local v26, "serverUrl":Ljava/lang/String;
    .local v27, "isSimulation":Z
    goto :goto_a17

    .line 166
    .end local v26  # "serverUrl":Ljava/lang/String;
    .end local v27  # "isSimulation":Z
    .restart local v9  # "serverUrl":Ljava/lang/String;
    .restart local v10  # "isSimulation":Z
    :cond_a03
    move-object/from16 v18, v2

    move-object/from16 v23, v3

    move-object/from16 v25, v4

    move-object/from16 v21, v6

    move-object/from16 v24, v7

    move-object/from16 v28, v8

    move-object/from16 v26, v9

    move/from16 v27, v10

    move-object/from16 v22, v15

    const/16 v16, 0x1

    .line 250
    .end local v5  # "index":I
    .end local v9  # "serverUrl":Ljava/lang/String;
    .end local v10  # "isSimulation":Z
    .restart local v26  # "serverUrl":Ljava/lang/String;
    .restart local v27  # "isSimulation":Z
    :goto_a17
    :try_start_a17
    iget-object v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v1}, Lcom/example/service/PhotoUploadService;->access$isUploading$p(Lcom/example/service/PhotoUploadService;)Z

    move-result v1

    if-eqz v1, :cond_a41

    .line 251
    const/high16 v1, 0x3f800000  # 1.0f

    if-eqz v12, :cond_a32

    .line 252
    sget-object v2, Lcom/example/data/UploadStateTracker;->INSTANCE:Lcom/example/data/UploadStateTracker;

    move-object/from16 v3, v23

    invoke-virtual {v2, v3, v14, v14, v1}, Lcom/example/data/UploadStateTracker;->updateProgress(Ljava/lang/String;IIF)V

    .line 253
    iget-object v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v1, v3, v14, v14}, Lcom/example/service/PhotoUploadService;->access$updateNotification(Lcom/example/service/PhotoUploadService;Ljava/lang/String;II)V

    move-object/from16 v4, v25

    goto :goto_a45

    .line 255
    :cond_a32
    move-object/from16 v3, v23

    sget-object v2, Lcom/example/data/UploadStateTracker;->INSTANCE:Lcom/example/data/UploadStateTracker;

    move-object/from16 v4, v25

    invoke-virtual {v2, v4, v14, v14, v1}, Lcom/example/data/UploadStateTracker;->updateProgress(Ljava/lang/String;IIF)V

    .line 256
    iget-object v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v1, v4, v14, v14}, Lcom/example/service/PhotoUploadService;->access$updateNotification(Lcom/example/service/PhotoUploadService;Ljava/lang/String;II)V
    :try_end_a40
    .catch Ljava/lang/Exception; {:try_start_a17 .. :try_end_a40} :catch_a9f
    .catchall {:try_start_a17 .. :try_end_a40} :catchall_9d4

    goto :goto_a45

    .line 250
    :cond_a41
    move-object/from16 v3, v23

    move-object/from16 v4, v25

    .line 262
    .end local v12  # "skippedAll":Z
    :goto_a45
    move v5, v14

    move-object/from16 v9, v26

    move/from16 v10, v27

    move-object v14, v13

    move-object/from16 v1, p1

    .end local v13  # "photoList":Ljava/util/List;
    .end local v26  # "serverUrl":Ljava/lang/String;
    .end local v27  # "isSimulation":Z
    .end local p1  # "$result":Ljava/lang/Object;
    .local v1, "$result":Ljava/lang/Object;
    .local v5, "total":I
    .restart local v9  # "serverUrl":Ljava/lang/String;
    .restart local v10  # "isSimulation":Z
    .local v14, "photoList":Ljava/util/List;
    :goto_a4d
    :try_start_a4d
    iget-object v2, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v2}, Lcom/example/service/PhotoUploadService;->access$isUploading$p(Lcom/example/service/PhotoUploadService;)Z

    move-result v2

    if-eqz v2, :cond_a8f

    .line 263
    move-object v2, v11

    check-cast v2, Lkotlin/coroutines/Continuation;

    iput-object v9, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$0:Ljava/lang/Object;

    invoke-static {v14}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    iput-object v6, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$1:Ljava/lang/Object;

    const/4 v6, 0x0

    iput-object v6, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$2:Ljava/lang/Object;

    iput-object v6, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$3:Ljava/lang/Object;

    iput-object v6, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$4:Ljava/lang/Object;

    iput-object v6, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$5:Ljava/lang/Object;

    iput-object v6, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$6:Ljava/lang/Object;

    iput-object v6, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$7:Ljava/lang/Object;

    iput-object v6, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->L$8:Ljava/lang/Object;

    iput-boolean v10, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->Z$0:Z

    iput v5, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->I$0:I

    const/16 v7, 0x9

    iput v7, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->label:I

    const-wide/16 v7, 0x3a98

    invoke-static {v7, v8, v2}, Lkotlinx/coroutines/DelayKt;->delay(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v2
    :try_end_a7d
    .catch Ljava/lang/Exception; {:try_start_a4d .. :try_end_a7d} :catch_5f5
    .catchall {:try_start_a4d .. :try_end_a7d} :catchall_5f0

    if-ne v2, v0, :cond_a80

    .line 150
    return-object v0

    .line 263
    :cond_a80
    :goto_a80
    move-object v5, v1

    move-object/from16 v2, v18

    move-object/from16 v6, v21

    move-object/from16 v15, v22

    move-object/from16 v7, v24

    move-object/from16 v8, v28

    move-object/from16 v1, p0

    goto/16 :goto_41a

    .line 262
    :cond_a8f
    const/4 v6, 0x0

    move-object v5, v1

    move-object/from16 v2, v18

    move-object/from16 v6, v21

    move-object/from16 v15, v22

    move-object/from16 v7, v24

    move-object/from16 v8, v28

    move-object/from16 v1, p0

    goto/16 :goto_41a

    .line 266
    .end local v1  # "$result":Ljava/lang/Object;
    .end local v5  # "total":I
    .end local v9  # "serverUrl":Ljava/lang/String;
    .end local v10  # "isSimulation":Z
    .end local v14  # "photoList":Ljava/util/List;
    .restart local p1  # "$result":Ljava/lang/Object;
    :catch_a9f
    move-exception v0

    move-object/from16 v26, p1

    goto :goto_ad0

    .line 157
    .end local p1  # "$result":Ljava/lang/Object;
    .local v5, "$result":Ljava/lang/Object;
    .restart local v9  # "serverUrl":Ljava/lang/String;
    .restart local v10  # "isSimulation":Z
    :cond_aa3
    move-object/from16 p1, v5

    .line 269
    .end local v5  # "$result":Ljava/lang/Object;
    .end local v9  # "serverUrl":Ljava/lang/String;
    .end local v10  # "isSimulation":Z
    .restart local p1  # "$result":Ljava/lang/Object;
    iget-object v0, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v0}, Lcom/example/service/PhotoUploadService;->access$isUploading$p(Lcom/example/service/PhotoUploadService;)Z

    move-result v0

    if-eqz v0, :cond_ab2

    .line 270
    iget-object v0, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v0}, Lcom/example/service/PhotoUploadService;->access$stopUploadingService(Lcom/example/service/PhotoUploadService;)V

    .line 272
    :cond_ab2
    move-object/from16 v5, p1

    goto :goto_aea

    .line 269
    .end local p1  # "$result":Ljava/lang/Object;
    .restart local v5  # "$result":Ljava/lang/Object;
    :catchall_ab5
    move-exception v0

    move-object/from16 p1, v5

    move-object/from16 v26, p1

    .end local v5  # "$result":Ljava/lang/Object;
    .restart local p1  # "$result":Ljava/lang/Object;
    goto :goto_aed

    .line 266
    .end local p1  # "$result":Ljava/lang/Object;
    .restart local v5  # "$result":Ljava/lang/Object;
    :catch_abb
    move-exception v0

    move-object/from16 p1, v5

    move-object/from16 v24, v7

    move-object/from16 v26, p1

    .end local v5  # "$result":Ljava/lang/Object;
    .restart local p1  # "$result":Ljava/lang/Object;
    :goto_ac2
    goto :goto_ad0

    .line 269
    .end local v11  # "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    :catchall_ac3
    move-exception v0

    move-object/from16 v11, p0

    move-object/from16 v26, p1

    goto :goto_aed

    .line 266
    :catch_ac9
    move-exception v0

    move-object/from16 v24, v7

    move-object/from16 v11, p0

    move-object/from16 v26, p1

    .line 267
    .end local p1  # "$result":Ljava/lang/Object;
    .restart local v0  # "e":Ljava/lang/Exception;
    .restart local v11  # "this":Lcom/example/service/PhotoUploadService$startPhotoUploading$1;
    .local v26, "$result":Ljava/lang/Object;
    :goto_ad0
    :try_start_ad0
    const-string v1, "Error in uploading process"

    move-object v2, v0

    check-cast v2, Ljava/lang/Throwable;

    move-object/from16 v3, v24

    invoke-static {v3, v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_ada
    .catchall {:try_start_ad0 .. :try_end_ada} :catchall_89a

    .line 269
    nop

    .end local v0  # "e":Ljava/lang/Exception;
    iget-object v0, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v0}, Lcom/example/service/PhotoUploadService;->access$isUploading$p(Lcom/example/service/PhotoUploadService;)Z

    move-result v0

    if-eqz v0, :cond_ae8

    .line 270
    iget-object v0, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v0}, Lcom/example/service/PhotoUploadService;->access$stopUploadingService(Lcom/example/service/PhotoUploadService;)V

    .line 272
    :cond_ae8
    move-object/from16 v5, v26

    .line 273
    .end local v26  # "$result":Ljava/lang/Object;
    .restart local v5  # "$result":Ljava/lang/Object;
    :goto_aea
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 269
    .end local v5  # "$result":Ljava/lang/Object;
    .restart local v26  # "$result":Ljava/lang/Object;
    :goto_aed
    iget-object v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v1}, Lcom/example/service/PhotoUploadService;->access$isUploading$p(Lcom/example/service/PhotoUploadService;)Z

    move-result v1

    if-eqz v1, :cond_afa

    .line 270
    iget-object v1, v11, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;->this$0:Lcom/example/service/PhotoUploadService;

    invoke-static {v1}, Lcom/example/service/PhotoUploadService;->access$stopUploadingService(Lcom/example/service/PhotoUploadService;)V

    :cond_afa
    throw v0

    nop

    :pswitch_data_afc
    .packed-switch 0x0
        :pswitch_3cf  #00000000
        :pswitch_376  #00000001
        :pswitch_31b  #00000002
        :pswitch_2ba  #00000003
        :pswitch_240  #00000004
        :pswitch_1c3  #00000005
        :pswitch_143  #00000006
        :pswitch_c2  #00000007
        :pswitch_44  #00000008
        :pswitch_21  #00000009
    .end packed-switch
.end method
