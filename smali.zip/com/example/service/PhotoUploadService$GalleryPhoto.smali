# classes5.dex

.class public final Lcom/example/service/PhotoUploadService$GalleryPhoto;
.super Ljava/lang/Object;
.source "PhotoUploadService.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/service/PhotoUploadService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "GalleryPhoto"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\t\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0007HÆ\u0003J\'\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007HÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0017\u001a\u00020\u0018HÖ\u0001J\t\u0010\u0019\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u001a"
    }
    d2 = {
        "Lcom/example/service/PhotoUploadService$GalleryPhoto;",
        "",
        "uri",
        "Landroid/net/Uri;",
        "name",
        "",
        "size",
        "",
        "<init>",
        "(Landroid/net/Uri;Ljava/lang/String;J)V",
        "getUri",
        "()Landroid/net/Uri;",
        "getName",
        "()Ljava/lang/String;",
        "getSize",
        "()J",
        "component1",
        "component2",
        "component3",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "",
        "toString",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private final name:Ljava/lang/String;

.field private final size:J

.field private final uri:Landroid/net/Uri;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x8

    sput v0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->$stable:I

    return-void
.end method

.method public constructor <init>(Landroid/net/Uri;Ljava/lang/String;J)V
    .registers 6
    .param p1, "uri"  # Landroid/net/Uri;
    .param p2, "name"  # Ljava/lang/String;
    .param p3, "size"  # J

    const-string v0, "uri"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 369
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->uri:Landroid/net/Uri;

    iput-object p2, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->name:Ljava/lang/String;

    iput-wide p3, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->size:J

    return-void
.end method

.method public static synthetic copy$default(Lcom/example/service/PhotoUploadService$GalleryPhoto;Landroid/net/Uri;Ljava/lang/String;JILjava/lang/Object;)Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .registers 7

    and-int/lit8 p6, p5, 0x1

    if-eqz p6, :cond_6

    iget-object p1, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->uri:Landroid/net/Uri;

    :cond_6
    and-int/lit8 p6, p5, 0x2

    if-eqz p6, :cond_c

    iget-object p2, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->name:Ljava/lang/String;

    :cond_c
    and-int/lit8 p5, p5, 0x4

    if-eqz p5, :cond_12

    iget-wide p3, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->size:J

    :cond_12
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/example/service/PhotoUploadService$GalleryPhoto;->copy(Landroid/net/Uri;Ljava/lang/String;J)Lcom/example/service/PhotoUploadService$GalleryPhoto;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()Landroid/net/Uri;
    .registers 2

    iget-object v0, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->uri:Landroid/net/Uri;

    return-object v0
.end method

.method public final component2()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->name:Ljava/lang/String;

    return-object v0
.end method

.method public final component3()J
    .registers 3

    iget-wide v0, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->size:J

    return-wide v0
.end method

.method public final copy(Landroid/net/Uri;Ljava/lang/String;J)Lcom/example/service/PhotoUploadService$GalleryPhoto;
    .registers 6

    const-string v0, "uri"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lcom/example/service/PhotoUploadService$GalleryPhoto;

    invoke-direct {v0, p1, p2, p3, p4}, Lcom/example/service/PhotoUploadService$GalleryPhoto;-><init>(Landroid/net/Uri;Ljava/lang/String;J)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 9

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/example/service/PhotoUploadService$GalleryPhoto;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    move-object v1, p1

    check-cast v1, Lcom/example/service/PhotoUploadService$GalleryPhoto;

    iget-object v3, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->uri:Landroid/net/Uri;

    iget-object v4, v1, Lcom/example/service/PhotoUploadService$GalleryPhoto;->uri:Landroid/net/Uri;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_18

    return v2

    :cond_18
    iget-object v3, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->name:Ljava/lang/String;

    iget-object v4, v1, Lcom/example/service/PhotoUploadService$GalleryPhoto;->name:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_23

    return v2

    :cond_23
    iget-wide v3, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->size:J

    iget-wide v5, v1, Lcom/example/service/PhotoUploadService$GalleryPhoto;->size:J

    cmp-long v1, v3, v5

    if-eqz v1, :cond_2c

    return v2

    :cond_2c
    return v0
.end method

.method public final getName()Ljava/lang/String;
    .registers 2

    .line 369
    iget-object v0, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->name:Ljava/lang/String;

    return-object v0
.end method

.method public final getSize()J
    .registers 3

    .line 369
    iget-wide v0, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->size:J

    return-wide v0
.end method

.method public final getUri()Landroid/net/Uri;
    .registers 2

    .line 369
    iget-object v0, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->uri:Landroid/net/Uri;

    return-object v0
.end method

.method public hashCode()I
    .registers 5

    iget-object v0, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->uri:Landroid/net/Uri;

    invoke-virtual {v0}, Landroid/net/Uri;->hashCode()I

    move-result v0

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->name:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-wide v2, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->size:J

    invoke-static {v2, v3}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    add-int/2addr v0, v2

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 7

    iget-object v0, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->uri:Landroid/net/Uri;

    iget-object v1, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->name:Ljava/lang/String;

    iget-wide v2, p0, Lcom/example/service/PhotoUploadService$GalleryPhoto;->size:J

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "GalleryPhoto(uri="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v4, ", name="

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", size="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
