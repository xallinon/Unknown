# classes6.dex

.class public final synthetic Lcom/example/MainActivityKt$$ExternalSyntheticLambda19;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Lcom/example/ui/MainViewModel;

.field public final synthetic f$1:Landroid/content/Context;

.field public final synthetic f$2:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(Lcom/example/ui/MainViewModel;Landroid/content/Context;Landroidx/compose/runtime/MutableState;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/MainActivityKt$$ExternalSyntheticLambda19;->f$0:Lcom/example/ui/MainViewModel;

    iput-object p2, p0, Lcom/example/MainActivityKt$$ExternalSyntheticLambda19;->f$1:Landroid/content/Context;

    iput-object p3, p0, Lcom/example/MainActivityKt$$ExternalSyntheticLambda19;->f$2:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/example/MainActivityKt$$ExternalSyntheticLambda19;->f$0:Lcom/example/ui/MainViewModel;

    iget-object v1, p0, Lcom/example/MainActivityKt$$ExternalSyntheticLambda19;->f$1:Landroid/content/Context;

    iget-object v2, p0, Lcom/example/MainActivityKt$$ExternalSyntheticLambda19;->f$2:Landroidx/compose/runtime/MutableState;

    check-cast p1, Ljava/util/Map;

    invoke-static {v0, v1, v2, p1}, Lcom/example/MainActivityKt;->PhotoSenderApp$lambda$14$lambda$13(Lcom/example/ui/MainViewModel;Landroid/content/Context;Landroidx/compose/runtime/MutableState;Ljava/util/Map;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method
